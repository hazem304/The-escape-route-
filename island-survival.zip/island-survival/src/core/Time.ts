import { MAX_FRAME_DT, MAX_SUBSTEPS, PHYSICS_STEP } from '../constants';

/**
 * ساعة اللعبة: خطوة ثابتة للفيزياء (fixed timestep) + زمن عرض متغير.
 * تُستخدم أيضًا لاحقًا كساعة داخل اللعبة (دورة اليوم).
 */
export class Time {
  /** الزمن الحقيقي المنقضي منذ البدء (ثوانٍ) */
  elapsed = 0;
  /** آخر فرق زمني مقيّد (ثوانٍ) */
  delta = 0;
  /** مضاعِف سرعة اللعبة (0 = إيقاف مؤقت) */
  scale = 1;
  /** عدد الإطارات */
  frame = 0;

  private accumulator = 0;
  private last = 0;
  private fpsAcc = 0;
  private fpsFrames = 0;
  fps = 0;

  start(now: number): void {
    this.last = now;
  }

  /** يُستدعى مرة كل إطار؛ يعيد عدد خطوات الفيزياء الواجب تنفيذها */
  tick(now: number): number {
    const raw = (now - this.last) / 1000;
    this.last = now;
    const dt = Math.min(raw, MAX_FRAME_DT);
    this.delta = dt * this.scale;
    this.elapsed += dt;
    this.frame++;

    this.fpsAcc += raw;
    this.fpsFrames++;
    if (this.fpsAcc >= 0.5) {
      this.fps = Math.round(this.fpsFrames / this.fpsAcc);
      this.fpsAcc = 0;
      this.fpsFrames = 0;
    }

    this.accumulator += this.delta;
    let steps = 0;
    while (this.accumulator >= PHYSICS_STEP && steps < MAX_SUBSTEPS) {
      this.accumulator -= PHYSICS_STEP;
      steps++;
    }
    // إن تأخرنا أكثر من الحد نتخلى عن المتبقي حتى لا تتراكم الخطوات
    if (steps === MAX_SUBSTEPS) this.accumulator = 0;
    return steps;
  }

  /** نسبة الاستيفاء بين خطوتي فيزياء (0..1) لتنعيم العرض */
  get alpha(): number {
    return this.accumulator / PHYSICS_STEP;
  }
}
