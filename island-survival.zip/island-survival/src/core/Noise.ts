import { Random } from './Random';

/** ضوضاء Simplex ثنائية الأبعاد بجدول تبديل مبذور (حتمية) */
export class Noise2D {
  private perm = new Uint8Array(512);
  private static readonly G2 = (3 - Math.sqrt(3)) / 6;
  private static readonly F2 = 0.5 * (Math.sqrt(3) - 1);
  private static readonly GRAD: ReadonlyArray<readonly [number, number]> = [
    [1, 1], [-1, 1], [1, -1], [-1, -1], [1, 0], [-1, 0], [0, 1], [0, -1],
  ];

  constructor(seed: number | string) {
    const rnd = new Random(seed);
    const p = new Uint8Array(256);
    for (let i = 0; i < 256; i++) p[i] = i;
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(rnd.next() * (i + 1));
      const tmp = p[i];
      p[i] = p[j];
      p[j] = tmp;
    }
    for (let i = 0; i < 512; i++) this.perm[i] = p[i & 255];
  }

  /** قيمة في [-1,1] تقريبًا */
  noise(x: number, y: number): number {
    const { F2, G2, GRAD } = Noise2D;
    const s = (x + y) * F2;
    const i = Math.floor(x + s);
    const j = Math.floor(y + s);
    const t = (i + j) * G2;
    const x0 = x - (i - t);
    const y0 = y - (j - t);
    const i1 = x0 > y0 ? 1 : 0;
    const j1 = x0 > y0 ? 0 : 1;
    const x1 = x0 - i1 + G2;
    const y1 = y0 - j1 + G2;
    const x2 = x0 - 1 + 2 * G2;
    const y2 = y0 - 1 + 2 * G2;
    const ii = i & 255;
    const jj = j & 255;

    const corner = (cx: number, cy: number, gi: number): number => {
      let tt = 0.5 - cx * cx - cy * cy;
      if (tt < 0) return 0;
      tt *= tt;
      const g = GRAD[gi & 7];
      return tt * tt * (g[0] * cx + g[1] * cy);
    };

    const n0 = corner(x0, y0, this.perm[ii + this.perm[jj]]);
    const n1 = corner(x1, y1, this.perm[ii + i1 + this.perm[jj + j1]]);
    const n2 = corner(x2, y2, this.perm[ii + 1 + this.perm[jj + 1]]);
    return 70 * (n0 + n1 + n2);
  }

  /** ضوضاء كسورية متعددة الأوكتافات، تعيد قيمة في [-1,1] تقريبًا */
  fbm(x: number, y: number, octaves = 5, lacunarity = 2, gain = 0.5): number {
    let amp = 1;
    let freq = 1;
    let sum = 0;
    let norm = 0;
    for (let o = 0; o < octaves; o++) {
      sum += amp * this.noise(x * freq, y * freq);
      norm += amp;
      amp *= gain;
      freq *= lacunarity;
    }
    return sum / norm;
  }

  /** ضوضاء حادة الحواف (ridged) تناسب السلاسل الجبلية، في [0,1] */
  ridged(x: number, y: number, octaves = 4): number {
    let amp = 1;
    let freq = 1;
    let sum = 0;
    let norm = 0;
    for (let o = 0; o < octaves; o++) {
      const n = 1 - Math.abs(this.noise(x * freq, y * freq));
      sum += amp * n * n;
      norm += amp;
      amp *= 0.5;
      freq *= 2;
    }
    return sum / norm;
  }
}
