import RAPIER from '@dimforge/rapier3d-compat';
import { GRAVITY, PHYSICS_STEP } from '../constants';

/**
 * غلاف فوق Rapier (WASM): يهيّئ العالم ويوفّر دوال إنشاء أجسام بسيطة.
 * في المرحلة 2 سيُضاف جسم تضاريس (heightfield) من TerrainGenerator.
 */
export class Physics {
  world!: RAPIER.World;
  private ready = false;

  async init(): Promise<void> {
    await RAPIER.init();
    this.world = new RAPIER.World({ x: 0, y: GRAVITY, z: 0 });
    this.world.timestep = PHYSICS_STEP;
    this.ready = true;
  }

  get isReady(): boolean {
    return this.ready;
  }

  step(): void {
    this.world.step();
  }

  /** أرضية مسطحة مؤقتة حتى تتوفر التضاريس في المرحلة 2 */
  createGround(halfSize: number, y = 0): RAPIER.Collider {
    const desc = RAPIER.ColliderDesc.cuboid(halfSize, 0.5, halfSize).setTranslation(0, y - 0.5, 0);
    return this.world.createCollider(desc);
  }

  /** شبكة مثلثات ثابتة (تضاريس) */
  createTrimesh(vertices: Float32Array, indices: Uint32Array): RAPIER.Collider {
    return this.world.createCollider(RAPIER.ColliderDesc.trimesh(vertices, indices));
  }

  createStaticCylinder(x: number, y: number, z: number, halfHeight: number, radius: number): RAPIER.Collider {
    return this.world.createCollider(RAPIER.ColliderDesc.cylinder(halfHeight, radius).setTranslation(x, y, z));
  }

  removeCollider(c: RAPIER.Collider): void {
    this.world.removeCollider(c, false);
  }

  createStaticBox(center: { x: number; y: number; z: number }, half: { x: number; y: number; z: number }): RAPIER.Collider {
    const desc = RAPIER.ColliderDesc.cuboid(half.x, half.y, half.z).setTranslation(center.x, center.y, center.z);
    return this.world.createCollider(desc);
  }

  /** متحكم شخصية كبسولة: يعيد الجسم والمجسّم وأداة الحركة */
  createCharacter(radius: number, height: number, start: { x: number; y: number; z: number }) {
    const halfCyl = Math.max(0.01, (height - 2 * radius) / 2);
    const body = this.world.createRigidBody(
      RAPIER.RigidBodyDesc.kinematicPositionBased().setTranslation(start.x, start.y, start.z),
    );
    const collider = this.world.createCollider(RAPIER.ColliderDesc.capsule(halfCyl, radius), body);
    const controller = this.world.createCharacterController(0.02);
    controller.enableAutostep(0.4, 0.2, true);
    controller.enableSnapToGround(0.3);
    controller.setMaxSlopeClimbAngle((50 * Math.PI) / 180);
    controller.setMinSlopeSlideAngle((60 * Math.PI) / 180);
    controller.setApplyImpulsesToDynamicBodies(true);
    return { body, collider, controller };
  }

  /** شعاع من نقطة باتجاه معيّن؛ يعيد المسافة لأول اصطدام أو null (يُستخدم لتصادم الكاميرا) */
  raycast(
    origin: { x: number; y: number; z: number },
    dir: { x: number; y: number; z: number },
    maxDist: number,
    exclude?: RAPIER.Collider,
  ): number | null {
    const ray = new RAPIER.Ray(origin, dir);
    const hit = this.world.castRay(ray, maxDist, true, undefined, undefined, exclude);
    return hit ? hit.timeOfImpact : null;
  }
}
