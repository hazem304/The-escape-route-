import { BuildingGrid, type Piece, type SnapTarget } from '../building/Snap';
import { type PieceType } from '../building/Blueprint';
import { CraftQueue, checkRecipe, craft, type CraftContext } from '../crafting/CraftingStation';
import { createCampfireStation, createDryingRack } from '../crafting/Cooking';
import { ProcessingStation } from '../crafting/ProcessingStation';
import { createFurnace } from '../crafting/Smelting';
import type { Recipe, Station } from '../crafting/Recipe';
import { RecipeBook } from '../crafting/RecipeBook';
import { NPC_DEFS } from '../data/npcs';
import { Animal, type AIWorld } from '../entities/Animal';
import { AnimalManager } from '../entities/AnimalManager';
import { NPC } from '../entities/NPC';
import { Gatherer, type GatherOutcome } from '../gameplay/Gatherer';
import { Container } from '../inventory/Container';
import { Inventory, type UseResult } from '../inventory/Inventory';
import { ItemDB } from '../inventory/ItemDatabase';
import { playerNoise } from '../ai/Perception';
import { runAction, useStoryItem, type ActionHooks, type ActionResult } from '../quests/ActionRunner';
import { Journal } from '../quests/Journal';
import { MapData, type Landmark } from '../quests/MapData';
import { QuestManager } from '../quests/QuestManager';
import { evaluateEnding, type EndingId } from '../quests/RescueEnding';
import { Fire, type FuelItem } from '../survival/Fire';
import { FarmPlot, WATER_ITEMS, type Crop, type FarmDrop } from '../survival/Farming';
import { Fishing, type FishCatch, type FishingState } from '../survival/Fishing';
import { ambientTemperature, activityFrom, dayOf, hourOf, HOURS_PER_REAL_SECOND } from '../survival/Environment';
import { canSleep, shouldWake, SLEEP_TIME_SCALE, type SleepRefusal } from '../survival/Sleep';
import { Skills } from '../survival/Skills';
import { SurvivalSystem, type SurvivalContext } from '../survival/SurvivalSystem';
import type { Difficulty } from '../survival/Stats';
import { GroundItems } from '../world/GroundItems';
import { ResourceField } from '../world/ResourceField';
import { scatterResources, type TerrainSampler } from '../world/ScatterGenerator';
import type { TerrainGenerator } from '../world/TerrainGenerator';
import { Random } from './Random';
import type { V2 } from '../ai/Steering';

export const SAVE_VERSION = 1;

/** ما يحتاجه الجلسة من حالة اللاعب الحالية (يقرؤه Game من Player) */
export interface PlayerSnapshot {
  x: number;
  y: number;
  z: number;
  yaw: number;
  loco: 'idle' | 'walk' | 'run' | 'crouch' | 'jump' | 'swim';
  inWater: boolean;
  /** يقطع/يعدّن/يضرب الآن */
  working: boolean;
}

export interface EnvironmentSnapshot {
  weatherTempDelta: number;
  rainIntensity: number;
  windX: number;
  windZ: number;
  waveAmp: number;
  /** داخل كهف؟ */
  inCave: boolean;
}

/** عنصر قصة ملقى في العالم (حطام، مخبأ): يُلتقط مرة واحدة */
export interface StoryPickup {
  id: string;
  x: number;
  y: number;
  z: number;
  item: string;
  count: number;
  /** صفحة مذكرات تُسجَّل عند الالتقاط */
  page?: string;
  /** عنصر مطلوب لفتحه */
  requires?: string;
  taken: boolean;
}

export type SessionEvent =
  | { type: 'notify'; ar: string; en: string }
  | { type: 'questUpdate'; id: string; kind: 'started' | 'progress' | 'completed' }
  | { type: 'landmark'; landmark: Landmark }
  | { type: 'newRecipes'; ids: string[] }
  | { type: 'ending'; id: EndingId }
  | { type: 'levelUp'; skill: string; level: number }
  | { type: 'animalKilled'; species: string }
  | { type: 'pieceRemoved'; piece: Piece }
  | { type: 'fishing'; state: 'cast' | 'bite' | 'caught' | 'escaped' | 'cancel'; item?: string; count?: number }
  | { type: 'woke' };

export interface SessionSave {
  version: number;
  seed: string;
  savedAt: number;
  playTime: number;
  difficulty: Difficulty;
  totalHours: number;
  player: { x: number; y: number; z: number; yaw: number };
  survival: ReturnType<SurvivalSystem['toJSON']>;
  inventory: ReturnType<Inventory['toJSON']>;
  skills: ReturnType<Skills['toJSON']>;
  recipes: ReturnType<RecipeBook['toJSON']>;
  quests: ReturnType<QuestManager['toJSON']>;
  journal: ReturnType<Journal['toJSON']>;
  map: ReturnType<MapData['toJSON']>;
  resources: ReturnType<ResourceField['toJSON']>;
  ground: ReturnType<GroundItems['toJSON']>;
  buildings: Piece[];
  fires: Array<{ pieceId: number } & ReturnType<Fire['toJSON']>>;
  stations: Array<{ pieceId: number; slots: ReturnType<ProcessingStation['toJSON']> }>;
  containers: Array<ReturnType<Container['toJSON']> & { pieceId: number }>;
  npcs: ReturnType<NPC['toJSON']>[];
  /** اختياري: حفظ قديم بلا مزارع يبقى صالحًا */
  farms?: Array<{ pieceId: number; slots: Array<Crop | null> }>;
  story: { taken: string[]; signalDay: number | null; ending: EndingId | null };
}

const CRAFT_STATION_RANGE = 4;
const FIRE_RANGE = 3.5;

/**
 * الجلسة: كل حالة اللعبة الخالصة (بلا Three.js). Game.ts يعرضها ويغذّيها بالإدخال،
 * وSaveSystem يحفظها. هذا يجعل اللعبة كلها قابلة للاختبار بدون متصفح.
 */
export class GameSession {
  readonly rnd: Random;
  readonly survival: SurvivalSystem;
  readonly inventory = new Inventory();
  readonly skills = new Skills();
  readonly recipes = new RecipeBook();
  readonly quests: QuestManager;
  readonly journal = new Journal();
  readonly map: MapData;
  readonly resources = new ResourceField();
  readonly ground = new GroundItems();
  readonly animals = new AnimalManager();
  readonly buildings: BuildingGrid;
  readonly craftQueue = new CraftQueue();
  readonly npcs: NPC[];
  readonly gatherer: Gatherer;
  readonly places: Record<string, V2>;

  readonly fires = new Map<number, Fire>();
  readonly stations = new Map<number, ProcessingStation>();
  readonly containers = new Map<number, Container>();
  readonly story: StoryPickup[] = [];
  readonly farms = new Map<number, FarmPlot>();
  readonly fishing: Fishing;
  /** نقطة رمي الصنارة (للعوّامة) */
  castPos: V2 | null = null;
  private fishPrev: FishingState = 'idle';

  totalHours = 7.5; // الصباح
  playTime = 0;
  sleeping = false;
  ending: EndingId | null = null;
  signalDay: number | null = null;
  /** آخر ساعة تم فيها إشعار dayPassed */
  private lastDay = 0;
  private mapTimer = 0;
  private recentDamage = false;
  private wakeReason: string | null = null;

  events: SessionEvent[] = [];
  onEvent: ((e: SessionEvent) => void) | null = null;

  constructor(readonly seed: string, readonly terrain: TerrainGenerator, difficulty: Difficulty = 'normal') {
    this.rnd = new Random(`${seed}:session`);
    this.fishing = new Fishing(this.rnd);
    this.survival = new SurvivalSystem(() => this.rnd.next());
    this.survival.difficulty = difficulty;

    // حقيبة البداية: جيوب فقط + قماش ومسكّن
    this.quests = new QuestManager({
      itemCount: (id) => this.inventory.count(id),
      giveReward: (r) => {
        for (const it of r.items ?? []) this.giveItem(it.id, it.count);
        for (const x of r.xp ?? []) this.skills.addXp(x.skill, x.amount);
        for (const id of r.recipes ?? []) this.recipes.unlock(id);
      },
    });
    this.journal.attach(this.quests, () => this.day);
    const prev = this.quests.onUpdate;
    this.quests.onUpdate = (id, kind) => {
      prev?.(id, kind);
      this.emit({ type: 'questUpdate', id, kind });
    };
    this.skills.onLevelUp = (skill, level) => this.emit({ type: 'levelUp', skill, level });
    this.inventory.onChange = () => this.onInventoryChanged();

    this.buildings = new BuildingGrid({ height: (x, z) => terrain.height(x, z), slope: (x, z) => terrain.slope(x, z), waterLevel: 0 });

    // ---- أماكن العالم ----
    const sp = terrain.spawn;
    const peak = this.findPeak();
    const inland = this.dirTo(sp, { x: 0, z: 0 });
    const wreck = this.inlandPoint(sp, inland, 55);
    const camp = this.inlandPoint(sp, inland, 22);
    const cave = terrain.caveSites[0];
    this.places = {
      camp,
      beach: { x: sp.x, z: sp.z },
      wreck,
      forest: this.inlandPoint(sp, inland, 90),
      cave: cave ? { x: cave.x, z: cave.z } : camp,
      peak,
      bunker: { x: peak.x + 14, z: peak.z + 6 },
    };

    const lm = (id: string, ar: string, en: string, icon: string, r: number, known = false): Landmark => ({ id, nameAr: ar, nameEn: en, icon, radius: r, known, x: this.places[id].x, z: this.places[id].z });
    this.map = new MapData([
      lm('beach', 'الشاطئ', 'Beach', '🏖️', 25, true),
      lm('camp', 'المخيم', 'Camp', '⛺', 15),
      lm('wreck', 'حطام الطائرة', 'Plane Wreck', '✈️', 22),
      lm('forest', 'الغابة', 'Forest', '🌴', 30),
      ...(cave ? [lm('cave', 'الكهف', 'Cave', '🕳️', 18)] : []),
      lm('peak', 'القمة', 'Peak', '⛰️', 14),
      lm('bunker', 'مدخل المخبأ', 'Bunker Entrance', '🚪', 9),
    ]);

    // ---- الموارد والحيوانات ----
    const keepClear = [{ x: sp.x, z: sp.z, r: 10 }, { x: wreck.x, z: wreck.z, r: 8 }, { x: camp.x, z: camp.z, r: 6 }];
    const sampler: TerrainSampler = terrain;
    scatterResources(sampler, this.resources, seed, {
      half: terrain.half,
      keepClear,
    });
    // لا موارد فوق مصاطب الكهوف
    for (const n of this.resources.all()) if (terrain.insideCaveFootprint(n.x, n.z)) this.resources.remove(n.id);
    this.animals.populate(sampler, seed, terrain.half, keepClear);
    this.animals.onKilled = (a, drops) => this.onAnimalKilled(a, drops);

    this.npcs = NPC_DEFS.map((def) => new NPC(def, this.npcStart(def.id)));

    this.placeStoryItems();

    this.gatherer = new Gatherer(this.resources, this.ground, this.inventory, this.skills, this.recipes, this.rnd);

    // ---- حالة البداية ----
    this.inventory.grid.resize(4, 2);
    this.inventory.add('bandage', 1);
    this.inventory.add('bottle_empty', 1);
    this.noteStartingItems();
    this.quests.onInventoryChanged();
    this.map.update(sp.x, sp.z);
  }

  // ======================= أدوات تهيئة =======================

  private findPeak(): V2 {
    const t = this.terrain;
    let best = { x: 0, z: 0, h: -Infinity };
    for (let z = -120; z <= 120; z += 4) for (let x = -120; x <= 120; x += 4) {
      const h = t.height(x, z);
      if (h > best.h) best = { x, z, h };
    }
    return { x: best.x, z: best.z };
  }

  private dirTo(a: V2, b: V2): V2 {
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const l = Math.hypot(dx, dz) || 1;
    return { x: dx / l, z: dz / l };
  }

  /** نقطة على الخط نحو الداخل؛ إن كانت مغمورة نتقدم حتى تجد يابسة */
  private inlandPoint(from: V2, dir: V2, dist: number): V2 {
    for (let d = dist; d < dist + 80; d += 3) {
      const x = from.x + dir.x * d;
      const z = from.z + dir.z * d;
      if (this.terrain.height(x, z) > 1.8 && this.terrain.slope(x, z) < 0.45) return { x, z };
    }
    return { x: from.x + dir.x * dist, z: from.z + dir.z * dist };
  }

  private npcStart(id: string): V2 {
    const def = NPC_DEFS.find((d) => d.id === id)!;
    const entry = def.schedule.find((s) => (s.from <= s.to ? 8 >= s.from && 8 < s.to : 8 >= s.from || 8 < s.to));
    return { ...(this.places[entry?.place ?? 'camp'] ?? this.places.camp) };
  }

  private placeStoryItems(): void {
    const w = this.places.wreck;
    const b = this.places.bunker;
    const at = (p: V2, dx: number, dz: number): { x: number; y: number; z: number } => ({ x: p.x + dx, y: this.terrain.height(p.x + dx, p.z + dz), z: p.z + dz });
    const add = (id: string, p: V2, dx: number, dz: number, item: string, count = 1, extra: Partial<StoryPickup> = {}): void => {
      this.story.push({ id, ...at(p, dx, dz), item, count, taken: false, ...extra });
    };
    add('w_sail', w, 3, 2, 'sail_cloth');
    add('w_scrap', w, -4, 1, 'scrap_metal', 4);
    add('w_engine', w, 5, -3, 'engine_part');
    add('w_flare', w, -2, -4, 'flare_gun');
    add('w_photo', w, 1, 5, 'old_photo');
    add('w_fuel', w, -5, -2, 'fuel_can');
    add('w_food', w, 2, -2, 'canned_beans', 2);
    add('w_map', w, 6, 4, 'map_piece');
    add('w_p1', w, -1, 3, 'journal_page', 1, { page: 'pilot_1' });
    add('w_p2', w, 4, 0, 'journal_page', 1, { page: 'pilot_2' });
    add('w_p3', w, -3, 5, 'journal_page', 1, { page: 'pilot_3' });
    add('b_rec', b, 2, 2, 'flight_recorder', 1, { requires: 'bunker_key' });
    add('b_phone', b, -2, 2, 'satellite_phone', 1, { requires: 'bunker_key' });
    add('b_p1', b, 0, 3, 'journal_page', 1, { page: 'bunker_1', requires: 'bunker_key' });
    add('b_p2', b, 3, -1, 'journal_page', 1, { page: 'bunker_2', requires: 'bunker_key' });
    add('b_kit', b, -3, -2, 'antibiotic', 2, { requires: 'bunker_key' });
    add('b_bat', b, 1, -3, 'radio_battery', 1, { requires: 'bunker_key' });
  }

  private noteStartingItems(): void {
    for (const e of this.inventory.grid.list()) this.recipes.noteItem(e.stack.defId);
  }

  // ======================= حالات =======================

  get hour(): number {
    return hourOf(this.totalHours);
  }
  get day(): number {
    return dayOf(this.totalHours);
  }

  emit(e: SessionEvent): void {
    this.events.push(e);
    this.onEvent?.(e);
  }

  notify(ar: string, en: string): void {
    this.emit({ type: 'notify', ar, en });
  }

  /** يفرّغ الأحداث المتراكمة (للواجهة) */
  drainEvents(): SessionEvent[] {
    const e = this.events;
    this.events = [];
    return e;
  }

  private onInventoryChanged(): void {
    // اكتشاف وصفات جديدة لكل عنصر جديد، وتحديث أهداف الحيازة
    const opened: string[] = [];
    for (const e of this.inventory.grid.list()) for (const r of this.recipes.noteItem(e.stack.defId)) opened.push(r.id);
    if (opened.length) this.emit({ type: 'newRecipes', ids: opened });
    this.quests.onInventoryChanged();
  }

  giveItem(id: string, count: number): void {
    const left = this.inventory.add(id, count);
    if (left > 0) {
      const p = this.places.camp;
      this.ground.dropNew(id, left, p.x, this.terrain.height(p.x, p.z), p.z);
    }
  }

  /** نقطة الظهور (قدما اللاعب) */
  get spawnPoint(): { x: number; y: number; z: number } {
    const s = this.terrain.spawn;
    return { x: s.x, y: s.y, z: s.z };
  }

  placeAt(x: number, y: number, z: number): string | null {
    const named = this.map.placeAt(x, z);
    if (named) return named;
    // البحر المفتوح: بعيد عن الجزيرة وفي ماء عميق
    if (Math.hypot(x, z) > 235 && this.terrain.height(x, z) < -8) return 'open_sea';
    void y;
    return null;
  }

  // ======================= التحديث =======================

  /**
   * @param dt ثواني حقيقية
   * @param p حالة اللاعب
   * @param env الطقس والبيئة
   */
  update(dt: number, p: PlayerSnapshot, env: EnvironmentSnapshot): void {
    if (this.ending) return;
    this.playTime += dt;

    const timeScale = this.sleeping ? SLEEP_TIME_SCALE : 1;
    const dh = dt * HOURS_PER_REAL_SECOND * timeScale;
    this.totalHours += dh;

    // اليوم الجديد
    const day = this.day;
    if (day !== this.lastDay) {
      this.lastDay = day;
      this.quests.notify({ type: 'dayPassed', day });
    }

    const inShelter = this.buildings.isSheltered(p.x, p.z) || env.inCave;
    const fireHeat = this.heatAt(p.x, p.z);
    const alt = this.terrain.height(p.x, p.z);
    const ambient = ambientTemperature(this.hour, env.weatherTempDelta, alt) + (env.inCave ? -2 : 0);
    const load = this.inventory.burden;
    const eq = this.inventory.equipment;

    const ctx: SurvivalContext = {
      ambientTemp: ambient,
      isRaining: env.rainIntensity > 0.15 && !inShelter,
      inWater: p.inWater,
      fireHeat,
      inShelter,
      activity: activityFrom(p.loco, p.working, this.sleeping),
      sleeping: this.sleeping,
      hour: this.hour,
      warmth: eq.warmth,
      sunProtection: eq.sunProtection,
      rainProof: eq.rainProof,
      staminaDrainMult: load.staminaDrainMultiplier,
    };
    const hpBefore = this.survival.stats.health;
    this.survival.update(dt, dh, ctx);
    this.recentDamage = this.survival.stats.health < hpBefore - 0.01 && this.survival.conditions.size === 0;

    // الفساد والنار والمحطات والموارد
    this.inventory.updateSpoil(dh);
    for (const c of this.containers.values()) c.updateSpoil(dh);
    for (const [id, f] of this.fires) {
      f.update(dh * 60, env.rainIntensity, Math.hypot(env.windX, env.windZ));
      void id;
    }
    for (const [id, st] of this.stations) st.update(dt, this.stationHeat(id));
    for (const plot of this.farms.values()) plot.update(dh, env.rainIntensity);
    this.updateFishing(dt, p);
    this.resources.update(dh);
    this.ground.update(dt);
    this.gatherer.update(dt);
    for (const ev of this.craftQueue.update(dt, this.inventory, this.craftContext(p))) {
      const out = ev.recipe.output;
      if (ev.overflow > 0) this.ground.dropNew(out.id, ev.overflow, p.x, p.y, p.z);
      this.quests.notify({ type: 'crafted', item: out.id, count: out.count });
      const d = ItemDB.get(out.id);
      this.notify(`تم صنع ${d.nameAr}`, `Crafted ${d.nameEn}`);
    }

    // الناجون
    for (const n of this.npcs) n.update(dt, this.hour, this.places);

    // الحيوانات
    this.animals.update(dt, this.aiWorld(p, env));

    // الخريطة والأماكن (كل نصف ثانية)
    this.mapTimer -= dt;
    if (this.mapTimer <= 0) {
      this.mapTimer = 0.5;
      for (const l of this.map.update(p.x, p.z)) this.emit({ type: 'landmark', landmark: l });
      const place = this.placeAt(p.x, p.y, p.z);
      if (place) this.quests.notify({ type: 'arrived', place });
    }

    // النوم: الاستيقاظ التلقائي
    if (this.sleeping) {
      const wake = shouldWake({
        energy: this.survival.stats.energy,
        hostileNearby: this.hostileNearby(p),
        inShelterOrBed: inShelter,
        bodyTemp: this.survival.stats.bodyTemp,
        hunger: this.survival.stats.hunger,
        thirst: this.survival.stats.thirst,
        damaged: this.recentDamage,
      });
      if (wake) this.wake();
    }

    this.checkEnding(p);
  }

  private wake(): void {
    this.sleeping = false;
    this.emit({ type: 'woke' });
  }

  private checkEnding(p: PlayerSnapshot): void {
    const id = evaluateEnding({
      flags: this.quests.flags,
      place: this.placeAt(p.x, p.y, p.z),
      has: (i) => this.inventory.has(i),
      alive: !this.survival.dead,
      day: this.day,
      signalDay: this.signalDay,
    });
    if (id) {
      this.ending = id;
      this.emit({ type: 'ending', id });
    }
  }

  private hostileNearby(p: PlayerSnapshot): boolean {
    for (const a of this.animals.animals) {
      if (!a.alive || a.species.temperament === 'prey') continue;
      if (Math.hypot(a.pos.x - p.x, a.pos.z - p.z) < 25 && (a.state === 'chase' || a.state === 'attack' || a.species.temperament === 'predator')) return true;
    }
    return false;
  }

  private aiWorld(p: PlayerSnapshot, env: EnvironmentSnapshot): AIWorld {
    const t = this.terrain;
    const night = this.hour < 5.5 || this.hour >= 19;
    const noise = playerNoise(p.working ? 'fight' : p.loco === 'run' ? 'run' : p.loco === 'walk' ? 'walk' : p.loco === 'crouch' ? 'crouch' : p.loco === 'swim' ? 'swim' : p.loco === 'jump' ? 'jump' : 'idle');
    const vis = (night ? 0.55 : 1) * (p.loco === 'crouch' ? 0.6 : 1) * (this.sleeping ? 0.4 : 1);
    return {
      height: (x, z) => t.height(x, z),
      slope: (x, z) => t.slope(x, z),
      biomeAt: (x, z) => t.biomeAt(x, z),
      hour: this.hour,
      wind: { x: env.windX, z: env.windZ },
      rnd: this.rnd,
      player: { pos: { x: p.x, z: p.z }, stimulus: { pos: { x: p.x, z: p.z }, noise, visibility: vis }, inWater: p.inWater, alive: !this.survival.dead, y: p.y },
      onAttackPlayer: (dmg, by) => {
        const defense = this.inventory.equipment.defense;
        this.survival.damage(dmg, by.species.id === 'snake' ? 'cut' : 'animal', defense);
        this.recentDamage = true;
        if (this.sleeping) this.wake();
      },
    };
  }

  // ======================= النار والمحطات =======================

  private heatAt(x: number, z: number): number {
    let h = 0;
    for (const [id, f] of this.fires) {
      const piece = this.buildings.get(id);
      if (!piece) continue;
      h = Math.max(h, f.heatAt(Math.hypot(piece.x - x, piece.z - z)));
    }
    return h;
  }

  /** حرارة محطة: النار نفسها، والرف يستفيد من أقوى نار قريبة */
  private stationHeat(pieceId: number): number {
    const own = this.fires.get(pieceId);
    if (own) return own.burning ? own.strength : 0;
    const piece = this.buildings.get(pieceId);
    if (!piece) return 0;
    let best = 0;
    for (const [fid, f] of this.fires) {
      const fp = this.buildings.get(fid);
      if (fp && f.burning && Math.hypot(fp.x - piece.x, fp.z - piece.z) <= 4) best = Math.max(best, f.strength * 0.8);
    }
    return best;
  }

  /** يضيف وقودًا من الحقيبة إلى نار قطعة */
  addFuel(pieceId: number, itemId: string, count = 1): boolean {
    const fire = this.fires.get(pieceId);
    if (!fire || !Fire.isFuel(itemId)) return false;
    const n = Math.min(count, this.inventory.count(itemId));
    if (n <= 0) return false;
    this.inventory.remove(itemId, n);
    fire.addFuel(itemId as FuelItem, n);
    return true;
  }

  /** إشعال نار بأفضل أداة في الحقيبة. @returns null إن لا أداة */
  ignite(pieceId: number, rainIntensity: number): { ok: boolean; reason?: 'noFire' | 'noTool' | 'noFuel' | 'failed'; tool?: string } {
    const fire = this.fires.get(pieceId);
    if (!fire) return { ok: false, reason: 'noFire' };
    if (fire.fuel <= 0) return { ok: false, reason: 'noFuel' };
    let best: { uid: number; p: number; id: string } | null = null;
    for (const e of this.inventory.grid.list()) {
      const d = ItemDB.get(e.stack.defId);
      const p = typeof d.effects.ignite === 'number' ? d.effects.ignite : 0;
      if (p > 0 && e.stack.durability !== 0 && (!best || p > best.p)) best = { uid: e.stack.uid, p, id: d.id };
    }
    if (!best) return { ok: false, reason: 'noTool' };
    const ok = fire.ignite(best.p, this.rnd.next(), rainIntensity);
    // عيدان الثقاب تُستهلك كوحدات؛ الأدوات الأخرى تتآكل
    if (best.id === 'matches') this.inventory.remove('matches', 1);
    else this.inventory.damage(best.uid, 1);
    if (ok) {
      this.quests.notify({ type: 'flag', flag: 'fire_lit' });
      if (this.hasSignalPotential(pieceId)) this.lightSignal();
    }
    return ok ? { ok: true, tool: best.id } : { ok: false, reason: 'failed', tool: best.id };
  }

  /** نار كبيرة على القمة بوقود كافٍ تُحتسب نار إشارة */
  private hasSignalPotential(pieceId: number): boolean {
    const piece = this.buildings.get(pieceId);
    const fire = this.fires.get(pieceId);
    if (!piece || !fire) return false;
    return this.map.placeAt(piece.x, piece.z) === 'peak' && fire.fuel >= 120 && this.quests.flags.has('ending_rescue_ready') === false && this.quests.status('signal_fire') === 'active';
  }

  private lightSignal(): void {
    this.signalDay = this.day;
    this.quests.notify({ type: 'flag', flag: 'signal_lit' });
    this.notify('أُشعلت نار الإشارة! ابقَ حيًا حتى تصل المروحية.', 'Signal fire lit! Survive until the helicopter arrives.');
  }

  /** المحطات المتاحة قرب اللاعب لسياق الصنع */
  nearbyStations(p: { x: number; z: number }): Set<Station> {
    const s = new Set<Station>(['hand']);
    for (const piece of this.buildings.list()) {
      const d = Math.hypot(piece.x - p.x, piece.z - p.z);
      if (piece.type === 'workbench' && d <= CRAFT_STATION_RANGE) s.add('workbench');
    }
    return s;
  }

  craftContext(p: { x: number; z: number }): CraftContext {
    return { stations: this.nearbyStations(p), skills: this.skills };
  }

  /** محطة معالجة (موقد/فرن/رف) ضمن مدى اللاعب */
  nearestProcessing(p: { x: number; z: number }, kind: Station): { pieceId: number; station: ProcessingStation; fire: Fire | null } | null {
    let best: { pieceId: number; d: number } | null = null;
    for (const [id, st] of this.stations) {
      if (st.config.station !== kind) continue;
      const piece = this.buildings.get(id);
      if (!piece) continue;
      const d = Math.hypot(piece.x - p.x, piece.z - p.z);
      if (d <= FIRE_RANGE && (!best || d < best.d)) best = { pieceId: id, d };
    }
    return best ? { pieceId: best.pieceId, station: this.stations.get(best.pieceId)!, fire: this.fires.get(best.pieceId) ?? null } : null;
  }

  // ======================= أفعال اللاعب =======================

  /** ضربة جمع/قطع. تستهلك النفَس وتعيد النتيجة */
  swing(origin: { x: number; y: number; z: number }, dir: { x: number; y: number; z: number }, feet: { x: number; y: number; z: number }): GatherOutcome {
    const r = this.gatherer.swing(origin, dir, this.survival.stats.stamina, feet);
    const cost = (r as { staminaCost?: number }).staminaCost;
    if (cost) this.survival.stats.stamina = Math.max(0, this.survival.stats.stamina - cost);
    if (r.kind === 'hit' || r.kind === 'destroyed') this.quests.onInventoryChanged();
    return r;
  }

  /** هجوم على حيوان بالسلاح الممسوك */
  attack(p: { x: number; z: number; yaw: number }, env: EnvironmentSnapshot): { hit: Animal | null; killed: boolean; weapon: string | null } {
    const held = this.inventory.held;
    const def = held ? ItemDB.get(held.defId) : null;
    const dmg = def && typeof def.effects.damage === 'number' && held && held.durability !== 0 ? def.effects.damage : 4;
    const reach = def && (def.id.startsWith('spear')) ? 3.2 : 2.4;
    const res = this.animals.playerAttack(this.aiWorld({ ...p, y: 0, loco: 'idle', inWater: false, working: true }, env), p, p.yaw, dmg, reach);
    if (res.hit && held && def && def.durability > 0) this.inventory.damage(held.uid, 1);
    if (res.hit) this.skills.addXp('hunting', res.killed ? 6 : 1);
    return { ...res, weapon: def?.id ?? null };
  }

  private onAnimalKilled(a: Animal, drops: Array<{ id: string; count: number }>): void {
    for (const d of drops) this.ground.dropNew(d.id, d.count, a.pos.x + this.rnd.range(-0.4, 0.4), a.y, a.pos.z + this.rnd.range(-0.4, 0.4));
    this.quests.notify({ type: 'killed', species: a.species.id });
    this.emit({ type: 'animalKilled', species: a.species.id });
  }

  /** يستهلك عنصرًا (طعام/ماء/دواء/قصة) */
  useItem(uid: number, p: { x: number; y: number; z: number }): UseResult | ActionResult {
    const e = this.inventory.grid.get(uid);
    if (!e) return { ok: false, reason: 'notFound', effects: {}, state: 'none' };
    const def = ItemDB.get(e.stack.defId);
    if (def.type === 'story') return useStoryItem(def.id, this.actionHooks(), this.placeAt(p.x, p.y, p.z));
    if (def.id === 'bottle_empty' || def.id === 'canteen_empty') return this.fillContainerItem(uid, p);
    const r = this.inventory.use(uid);
    if (r.ok) {
      const { gotSick } = this.survival.consume(r.effects);
      if (gotSick) this.notify('شعرت بالغثيان... ربما أكلت شيئًا فاسدًا.', 'You feel nauseous... something was off.');
      if (r.state === 'rotten') this.notify('كان الطعام فاسدًا!', 'That food was rotten!');
    }
    return r;
  }

  /** تعبئة زجاجة/قربة من ماء بحر مالح؟ لا: ماء عذب من المطر فقط، وإلا ماء ملوث من البرك */
  private fillContainerItem(uid: number, p: { x: number; y: number; z: number }): ActionResult {
    const e = this.inventory.grid.get(uid);
    if (!e) return { ok: false, reason: 'notFound' };
    const isCanteen = e.stack.defId === 'canteen_empty';
    // قرب جامع مطر مُلئ؟ نبسّطها: تعبئة ماء ملوث من أي مياه ضحلة، وماء مطر قرب جامع المطر
    const nearCollector = this.buildings.list().some((b) => b.type === 'collector' && Math.hypot(b.x - p.x, b.z - p.z) < 3);
    const h = this.terrain.height(p.x, p.z);
    const inShallows = h < 0.3 && h > -2;
    if (!nearCollector && !inShallows) return { ok: false, reason: 'noWater' };
    this.inventory.remove(e.stack.defId, 1);
    this.giveItem(isCanteen ? 'canteen_full' : nearCollector ? 'rainwater' : 'water_dirty', 1);
    return { ok: true };
  }

  actionHooks(): ActionHooks {
    return {
      inv: this.inventory,
      quests: this.quests,
      dropOverflow: (id, n) => {
        const p = this.places.camp;
        this.ground.dropNew(id, n, p.x, this.terrain.height(p.x, p.z), p.z);
      },
      notify: (ar, en) => this.notify(ar, en),
    };
  }

  /** ينفّذ إجراءات حوار ويسجل الأفعال */
  applyDialogue(npcId: string, log: { trustDelta: number; flags: string[]; actions: string[] }): void {
    const npc = this.npcs.find((n) => n.def.id === npcId);
    if (npc) {
      npc.adjustTrust(log.trustDelta);
      for (const f of log.flags) npc.flags.add(f);
    }
    for (const f of log.flags) this.quests.notify({ type: 'flag', flag: f });
    for (const a of log.actions) runAction(a, this.actionHooks());
    // الراية radio_done تتطلب أن يكون عمر قد استلم البطارية: نستنتجها من الحوار نفسه
    this.quests.notify({ type: 'talked', npc: npcId });
    if (npc) this.journal.noteNPC(npc, this.day);
  }

  /** حالة الحوار للناجي: الثقة والرايات (الجلسة + العامة) */
  dialogueContext(npcId: string): { trust: number; flags: ReadonlySet<string>; itemCount(id: string): number } {
    const npc = this.npcs.find((n) => n.def.id === npcId)!;
    return { trust: npc.trust, flags: new Set([...npc.flags, ...this.quests.flags]), itemCount: (id) => this.inventory.count(id) };
  }

  giveGift(npcId: string, itemId: string): { accepted: boolean; delta: number } {
    const npc = this.npcs.find((n) => n.def.id === npcId);
    if (!npc || !this.inventory.has(itemId)) return { accepted: false, delta: 0 };
    const r = npc.gift(itemId, this.day);
    if (r.accepted) this.inventory.remove(itemId, 1);
    return r;
  }

  /** يلتقط أقرب عنصر قصة مفتوح ضمن المدى */
  takeStoryPickup(p: { x: number; z: number }, range = 2.4): { ok: boolean; reason?: 'none' | 'locked'; pickup?: StoryPickup } {
    let best: StoryPickup | null = null;
    let bd = range;
    for (const s of this.story) {
      if (s.taken) continue;
      const d = Math.hypot(s.x - p.x, s.z - p.z);
      if (d <= bd) {
        bd = d;
        best = s;
      }
    }
    if (!best) return { ok: false, reason: 'none' };
    if (best.requires && !this.inventory.has(best.requires)) {
      this.notify('مغلق. تحتاج إلى مفتاح.', 'Locked. You need a key.');
      return { ok: false, reason: 'locked', pickup: best };
    }
    if (best.page) {
      this.journal.collectPage(best.page, this.day);
      best.taken = true;
      this.notify('وجدت صفحة من المذكرات.', 'You found a journal page.');
      return { ok: true, pickup: best };
    }
    const left = this.inventory.add(best.item, best.count);
    if (left >= best.count) {
      this.notify('الحقيبة ممتلئة.', 'Inventory full.');
      return { ok: false, reason: 'none', pickup: best };
    }
    if (left > 0) this.ground.dropNew(best.item, left, best.x, best.y, best.z);
    best.taken = true;
    if (best.item === 'map_piece') this.map.fullMapUnlocked = true;
    const d = ItemDB.get(best.item);
    this.notify(`حصلت على ${d.nameAr}`, `Obtained ${d.nameEn}`);
    return { ok: true, pickup: best };
  }

  // ======================= الصنع والبناء =======================

  craftNow(recipe: Recipe, p: { x: number; z: number }): ReturnType<typeof craft> {
    const ctx = this.craftContext(p);
    const r = craft(recipe, this.inventory, ctx);
    if (r.ok) this.quests.notify({ type: 'crafted', item: recipe.output.id, count: recipe.output.count });
    return r;
  }

  /** يبدأ صنعًا مؤقتًا (شريط تقدم) */
  craftQueued(recipe: Recipe, p: { x: number; z: number }): ReturnType<CraftQueue['start']> {
    return this.craftQueue.start(recipe, this.inventory, this.craftContext(p));
  }

  canCraft(recipe: Recipe, p: { x: number; z: number }): boolean {
    return checkRecipe(recipe, this.inventory, this.craftContext(p)).length === 0;
  }

  /** يُدخل وصفة في محطة معالجة؛ ويُبلغ المهام عند السحب */
  processInsert(pieceId: number, recipe: Recipe): ReturnType<ProcessingStation['insert']> {
    const st = this.stations.get(pieceId);
    if (!st) return { ok: false, reason: 'wrongStation' };
    return st.insert(recipe, this.inventory);
  }

  processCollect(pieceId: number, slot: number): ReturnType<ProcessingStation['collect']> {
    const st = this.stations.get(pieceId);
    if (!st) return { ok: false };
    const r = st.collect(slot, this.inventory);
    if (r.ok && r.item) {
      this.quests.notify({ type: 'crafted', item: r.item, count: r.count ?? 1 });
      this.skills.addXp('survival', 2);
    }
    return r;
  }

  place(type: PieceType, target: SnapTarget): ReturnType<BuildingGrid['build']> {
    const r = this.buildings.build(type, target, this.inventory);
    if (!r.ok) return r;
    const piece = r.piece;
    if (type === 'campfire') {
      this.fires.set(piece.id, new Fire(piece.x, piece.y, piece.z, false));
      this.stations.set(piece.id, createCampfireStation());
    } else if (type === 'furnace') {
      this.fires.set(piece.id, new Fire(piece.x, piece.y, piece.z, true));
      this.stations.set(piece.id, createFurnace());
    } else if (type === 'rack') {
      this.stations.set(piece.id, createDryingRack());
    } else if (type === 'farm') {
      this.farms.set(piece.id, new FarmPlot());
    } else if (type === 'storage' || type === 'barrel' || type === 'cooler') {
      const defId = type === 'storage' ? 'storage_box' : type;
      this.containers.set(piece.id, new Container(`piece-${piece.id}`, defId));
    }
    this.quests.notify({ type: 'built', piece: type });
    this.skills.addXp('building', 2);
    return r;
  }

  /** يزيل قطعة (وما سقط معها): يعيد جزءًا من المواد ويرمي المحتويات */
  removePiece(id: number): Piece[] {
    const removed = this.buildings.remove(id);
    for (const piece of removed) {
      for (const [item, n] of Object.entries(BuildingGrid.refund(piece))) this.ground.dropNew(item, n, piece.x, piece.y + 0.5, piece.z);
      const c = this.containers.get(piece.id);
      if (c) for (const e of c.grid.list()) this.ground.drop(e.stack, piece.x, piece.y + 0.5, piece.z);
      const st = this.stations.get(piece.id);
      if (st) st.slots.forEach((s, i) => s && st.discard(i));
      this.fires.delete(piece.id);
      this.stations.delete(piece.id);
      this.containers.delete(piece.id);
      this.farms.delete(piece.id);
      this.emit({ type: 'pieceRemoved', piece });
    }
    return removed;
  }

  // ======================= الصيد =======================

  private heldId(): string {
    const h = this.inventory.held;
    return h ? ItemDB.get(h.defId).id : '';
  }

  /** يرمي الصنارة/الشبكة نحو نقطة في الماء بعمق depth */
  castLine(target: V2, depth: number): { ok: true } | { ok: false; reason: 'noRod' | 'shallow' | 'busy' } {
    const id = this.heldId();
    if (id !== 'fishing_rod' && id !== 'fishing_net') return { ok: false, reason: 'noRod' };
    if (this.fishing.state === 'waiting' || this.fishing.state === 'bite') return { ok: false, reason: 'busy' };
    let bait: string | null = null;
    for (const e of this.inventory.grid.list()) {
      if (Fishing.isBait(e.stack.defId)) {
        bait = e.stack.defId;
        break;
      }
    }
    const ok = this.fishing.start({ depth, bait, skill: Math.min(10, this.skills.level('hunting')), hour: this.hour, rodPower: id === 'fishing_net' ? 2 : 1 });
    if (!ok) return { ok: false, reason: 'shallow' };
    if (bait) this.inventory.remove(bait, 1);
    this.castPos = { x: target.x, z: target.z };
    this.fishPrev = 'waiting';
    this.emit({ type: 'fishing', state: 'cast' });
    return { ok: true };
  }

  /** يسحب الخيط: ينجح أثناء اللدغة؛ السحب المبكر يلغي الرمية */
  reelLine(): FishCatch | null {
    const before = this.fishing.state;
    const c = this.fishing.reel();
    if (c) {
      this.giveItem(c.id, c.count);
      const h = this.inventory.held;
      if (h) this.inventory.damage(h.uid, 1);
      this.skills.addXp('hunting', 4);
      this.emit({ type: 'fishing', state: 'caught', item: c.id, count: c.count });
    } else if (before === 'waiting') {
      this.emit({ type: 'fishing', state: 'cancel' });
    }
    this.fishPrev = this.fishing.state;
    return c;
  }

  private updateFishing(dt: number, p: PlayerSnapshot): void {
    const f = this.fishing;
    if (f.state === 'waiting' || f.state === 'bite') {
      const id = this.heldId();
      const far = this.castPos ? Math.hypot(this.castPos.x - p.x, this.castPos.z - p.z) > 16 : false;
      if (far || (id !== 'fishing_rod' && id !== 'fishing_net')) {
        f.cancel();
        this.fishPrev = 'idle';
        this.emit({ type: 'fishing', state: 'cancel' });
        return;
      }
      f.update(dt);
    }
    if (f.state !== this.fishPrev) {
      if (f.state === 'bite') this.emit({ type: 'fishing', state: 'bite' });
      else if (f.state === 'escaped') this.emit({ type: 'fishing', state: 'escaped' });
      this.fishPrev = f.state;
    }
  }

  // ======================= الزراعة =======================

  farmMode(pieceId: number): 'harvest' | 'water' | 'plant' | 'info' | null {
    const plot = this.farms.get(pieceId);
    if (!plot) return null;
    if (plot.ripeCount > 0) return 'harvest';
    const held = this.inventory.held ? ItemDB.get(this.inventory.held.defId).id : '';
    if (held === 'seeds' && plot.freeSlot() >= 0) return 'plant';
    if ((WATER_ITEMS as readonly string[]).includes(held) && plot.plantedCount > 0 && plot.thirsty) return 'water';
    return 'info';
  }

  /** الفعل المناسب على قطعة مزرعة بحسب ما في اليد وحالة المحاصيل */
  farmAction(pieceId: number): { action: 'harvest' | 'water' | 'plant' | 'info'; drops?: FarmDrop[]; hours?: number | null; planted?: number } | null {
    const plot = this.farms.get(pieceId);
    const mode = this.farmMode(pieceId);
    if (!plot || !mode) return null;
    switch (mode) {
      case 'harvest': {
        const drops = plot.harvest(this.rnd);
        for (const d of drops) this.giveItem(d.id, d.count);
        this.skills.addXp('survival', 4);
        return { action: mode, drops };
      }
      case 'plant':
        this.inventory.remove('seeds', 1);
        plot.plant();
        this.skills.addXp('survival', 1);
        return { action: mode };
      case 'water': {
        const held = this.inventory.held!;
        const id = ItemDB.get(held.defId).id;
        this.inventory.remove(id, 1);
        this.giveItem('bottle_empty', 1);
        return { action: mode, planted: plot.water() };
      }
      default:
        return { action: 'info', hours: plot.hoursToRipe(), planted: plot.plantedCount };
    }
  }

  // ======================= النوم =======================

  /** يحاول النوم؛ قرب فراش أو تحت سقف أفضل */
  trySleep(p: { x: number; z: number }, bodyTempOk = true): { ok: boolean; reason?: SleepRefusal } {
    const nearBed = this.buildings.list().some((b) => b.type === 'bed' && Math.hypot(b.x - p.x, b.z - p.z) < 2.5);
    const r = canSleep({
      energy: this.survival.stats.energy,
      hostileNearby: this.hostileNearby({ x: p.x, y: 0, z: p.z, yaw: 0, loco: 'idle', inWater: false, working: false }),
      inShelterOrBed: nearBed || this.buildings.isSheltered(p.x, p.z),
      bodyTemp: bodyTempOk ? this.survival.stats.bodyTemp : 30,
      hunger: this.survival.stats.hunger,
      thirst: this.survival.stats.thirst,
    });
    if (!r.ok) return r;
    this.sleeping = true;
    return { ok: true };
  }

  get wakeNote(): string | null {
    return this.wakeReason;
  }

  // ======================= الحفظ =======================

  toJSON(player: { x: number; y: number; z: number; yaw: number }): SessionSave {
    return {
      version: SAVE_VERSION,
      seed: this.seed,
      savedAt: Date.now(),
      playTime: this.playTime,
      difficulty: this.survival.difficulty,
      totalHours: this.totalHours,
      player: { ...player },
      survival: this.survival.toJSON(),
      inventory: this.inventory.toJSON(),
      skills: this.skills.toJSON(),
      recipes: this.recipes.toJSON(),
      quests: this.quests.toJSON(),
      journal: this.journal.toJSON(),
      map: this.map.toJSON(),
      resources: this.resources.toJSON(),
      ground: this.ground.toJSON(),
      buildings: this.buildings.toJSON(),
      fires: [...this.fires].map(([pieceId, f]) => ({ pieceId, ...f.toJSON() })),
      stations: [...this.stations].map(([pieceId, s]) => ({ pieceId, slots: s.toJSON() })),
      containers: [...this.containers].map(([pieceId, c]) => ({ pieceId, ...c.toJSON() })),
      npcs: this.npcs.map((n) => n.toJSON()),
      farms: [...this.farms].map(([pieceId, f]) => ({ pieceId, slots: f.toJSON() })),
      story: { taken: this.story.filter((s) => s.taken).map((s) => s.id), signalDay: this.signalDay, ending: this.ending },
    };
  }

  /** يستعيد حالة محفوظة على جلسة مولّدة بنفس البذرة */
  load(d: SessionSave): void {
    if (d.seed !== this.seed) throw new Error(`GameSession.load: البذرة لا تطابق (${d.seed} ≠ ${this.seed})`);
    this.totalHours = d.totalHours;
    this.lastDay = dayOf(d.totalHours);
    this.playTime = d.playTime;
    this.survival.load(d.survival);
    this.inventory.load(d.inventory);
    this.skills.load(d.skills);
    this.recipes.load(d.recipes);
    this.quests.load(d.quests);
    this.journal.load(d.journal);
    this.map.load(d.map);
    this.resources.load(d.resources);
    this.ground.load(d.ground);
    this.buildings.load(d.buildings);

    this.fires.clear();
    this.stations.clear();
    this.containers.clear();
    for (const f of d.fires) this.fires.set(f.pieceId, Fire.fromJSON(f));
    for (const s of d.stations) {
      const piece = this.buildings.get(s.pieceId);
      if (!piece) continue;
      const st = piece.type === 'campfire' ? createCampfireStation() : piece.type === 'furnace' ? createFurnace() : createDryingRack();
      st.load(s.slots, (id) => this.recipes.get(id));
      this.stations.set(s.pieceId, st);
    }
    for (const c of d.containers) this.containers.set(c.pieceId, Container.fromJSON(c));
    this.farms.clear();
    for (const f of d.farms ?? []) if (this.buildings.get(f.pieceId)) this.farms.set(f.pieceId, FarmPlot.fromJSON(f.slots));
    this.fishing.cancel();
    this.castPos = null;

    for (const n of d.npcs) this.npcs.find((x) => x.def.id === n.id)?.load(n);
    const taken = new Set(d.story.taken);
    for (const s of this.story) s.taken = taken.has(s.id);
    this.signalDay = d.story.signalDay;
    this.ending = d.story.ending;
    this.sleeping = false;
    this.mapTimer = 0;
  }
}
