/** كشف الجهاز: دوال نقية قابلة للاختبار بتمرير المدخلات */
export interface DeviceInfo {
  coarsePointer: boolean;
  width: number;
  height: number;
  memoryGB?: number;
  cores?: number;
}

export function isPhone(d: DeviceInfo): boolean {
  return d.coarsePointer && Math.min(d.width, d.height) < 820;
}

/** جودة افتراضية: الهواتف 'low' (و'medium' للقوية)، وغيرها 'medium' */
export function defaultQuality(d: DeviceInfo): 'low' | 'medium' {
  if (!isPhone(d)) return 'medium';
  const strong = (d.memoryGB ?? 0) >= 6 && (d.cores ?? 0) >= 8;
  return strong ? 'medium' : 'low';
}

export function readDevice(): DeviceInfo {
  const nav = navigator as Navigator & { deviceMemory?: number };
  return {
    coarsePointer: typeof matchMedia === 'function' && matchMedia('(pointer: coarse)').matches,
    width: window.innerWidth,
    height: window.innerHeight,
    memoryGB: nav.deviceMemory,
    cores: navigator.hardwareConcurrency,
  };
}
