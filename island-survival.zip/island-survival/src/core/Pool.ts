/** مجمّع كائنات: يمنع إنشاء/تحرير الذاكرة المتكرر (جسيمات، تأثيرات، مقذوفات) */
export class Pool<T> {
  private free: T[] = [];
  private inUse = new Set<T>();
  created = 0;

  constructor(private factory: () => T, private reset: (item: T) => void, warm = 0, readonly max = Infinity) {
    for (let i = 0; i < warm; i++) this.free.push(this.make());
  }

  private make(): T {
    this.created++;
    return this.factory();
  }

  /** @returns null إن بلغ الحد الأقصى */
  acquire(): T | null {
    let item = this.free.pop();
    if (item === undefined) {
      if (this.created >= this.max) return null;
      item = this.make();
    }
    this.inUse.add(item);
    return item;
  }

  release(item: T): boolean {
    if (!this.inUse.delete(item)) return false; // لا تحرير مزدوج
    this.reset(item);
    this.free.push(item);
    return true;
  }

  releaseAll(): void {
    for (const it of [...this.inUse]) this.release(it);
  }

  get active(): number {
    return this.inUse.size;
  }

  get available(): number {
    return this.free.length;
  }

  forEachActive(fn: (item: T) => void): void {
    for (const it of this.inUse) fn(it);
  }
}
