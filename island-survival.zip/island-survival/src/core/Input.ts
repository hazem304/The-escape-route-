/**
 * نظام الإدخال الموحّد: لوحة مفاتيح + ماوس (Pointer Lock) + لمس + ذراع تحكم.
 * يوفّر محاور منطقية (move / look) وأزرار (جري، قفز، ...) بغضّ النظر عن الجهاز.
 */

export type Action = 'forward' | 'back' | 'left' | 'right' | 'run' | 'jump' | 'crouch' | 'toggleView' | 'interact' | 'pause'
  | 'attack' | 'inventory' | 'craft' | 'build' | 'map' | 'journal' | 'sleep' | 'rotate'
  | 'slot1' | 'slot2' | 'slot3' | 'slot4' | 'slot5' | 'slot6' | 'slot7' | 'slot8';

const KEY_MAP: Record<string, Action> = {
  KeyW: 'forward', ArrowUp: 'forward',
  KeyS: 'back', ArrowDown: 'back',
  KeyA: 'left', ArrowLeft: 'left',
  KeyD: 'right', ArrowRight: 'right',
  ShiftLeft: 'run', ShiftRight: 'run',
  Space: 'jump',
  KeyC: 'crouch', ControlLeft: 'crouch',
  KeyV: 'toggleView',
  KeyE: 'interact',
  Tab: 'inventory', KeyI: 'inventory', KeyK: 'craft', KeyB: 'build', KeyM: 'map', KeyJ: 'journal', KeyZ: 'sleep', KeyR: 'rotate',
  Escape: 'pause', KeyF: 'attack',
  Digit1: 'slot1', Digit2: 'slot2', Digit3: 'slot3', Digit4: 'slot4', Digit5: 'slot5', Digit6: 'slot6', Digit7: 'slot7', Digit8: 'slot8',
};

export class Input {
  private down = new Set<Action>();
  private pressedThisFrame = new Set<Action>();

  /** دلتا النظر المتراكمة منذ آخر إطار (راديان قبل تطبيق الحساسية) */
  private lookDX = 0;
  private lookDY = 0;

  /** محور الحركة من اللمس/ذراع التحكم (-1..1) */
  private touchMove = { x: 0, y: 0 };
  private padMove = { x: 0, y: 0 };
  private padLook = { x: 0, y: 0 };

  pointerLocked = false;
  isTouch = false;

  onLockChange: ((locked: boolean) => void) | null = null;

  private lookTouchId: number | null = null;
  private lookTouchLast = { x: 0, y: 0 };
  private moveTouchId: number | null = null;
  private moveOrigin = { x: 0, y: 0 };

  constructor(private canvas: HTMLElement) {
    this.isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.releaseAll);
    document.addEventListener('mousemove', this.onMouseMove);
    document.addEventListener('mousedown', this.onMouseDown);
    document.addEventListener('mouseup', this.onMouseUp);
    document.addEventListener('wheel', this.onWheel, { passive: true });
    document.addEventListener('pointerlockchange', this.onLockChanged);
    canvas.addEventListener('touchstart', this.onTouchStart, { passive: false });
    canvas.addEventListener('touchmove', this.onTouchMove, { passive: false });
    canvas.addEventListener('touchend', this.onTouchEnd);
    canvas.addEventListener('touchcancel', this.onTouchEnd);
  }

  dispose(): void {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.releaseAll);
    document.removeEventListener('mousemove', this.onMouseMove);
    document.removeEventListener('mousedown', this.onMouseDown);
    document.removeEventListener('mouseup', this.onMouseUp);
    document.removeEventListener('wheel', this.onWheel);
    document.removeEventListener('pointerlockchange', this.onLockChanged);
    this.canvas.removeEventListener('touchstart', this.onTouchStart);
    this.canvas.removeEventListener('touchmove', this.onTouchMove);
    this.canvas.removeEventListener('touchend', this.onTouchEnd);
    this.canvas.removeEventListener('touchcancel', this.onTouchEnd);
  }

  requestLock(): void {
    if (this.isTouch) return;
    void this.canvas.requestPointerLock();
  }

  exitLock(): void {
    if (document.pointerLockElement) document.exitPointerLock();
  }

  /** ضغط/إفلات أزرار افتراضية (من أزرار اللمس على الشاشة) */
  setVirtual(action: Action, isDown: boolean): void {
    if (isDown) {
      if (!this.down.has(action)) this.pressedThisFrame.add(action);
      this.down.add(action);
    } else {
      this.down.delete(action);
    }
  }

  /** عصا الحركة الافتراضية */
  setTouchMove(x: number, y: number): void {
    this.touchMove.x = x;
    this.touchMove.y = y;
  }

  isDown(a: Action): boolean {
    return this.down.has(a);
  }

  /** true في الإطار الذي ضُغط فيه الزر فقط */
  wasPressed(a: Action): boolean {
    return this.pressedThisFrame.has(a);
  }

  /** محور الحركة المدمج: x يمين+، y أمام+ */
  getMove(): { x: number; y: number } {
    let x = (this.isDown('right') ? 1 : 0) - (this.isDown('left') ? 1 : 0);
    let y = (this.isDown('forward') ? 1 : 0) - (this.isDown('back') ? 1 : 0);
    x += this.touchMove.x + this.padMove.x;
    y += this.touchMove.y + this.padMove.y;
    const len = Math.hypot(x, y);
    if (len > 1) {
      x /= len;
      y /= len;
    }
    return { x, y };
  }

  /** يعيد دلتا النظر ويصفّرها */
  consumeLook(dt: number): { dx: number; dy: number } {
    const PAD_SPEED = 2.6; // راديان/ثانية عند أقصى ميل للعصا
    const dx = this.lookDX + this.padLook.x * PAD_SPEED * dt;
    const dy = this.lookDY + this.padLook.y * PAD_SPEED * dt;
    this.lookDX = 0;
    this.lookDY = 0;
    return { dx, dy };
  }

  /** يُستدعى في بداية كل إطار لقراءة ذراع التحكم */
  pollGamepad(): void {
    const pads = navigator.getGamepads?.() ?? [];
    const pad = pads.find((p): p is Gamepad => !!p && p.connected);
    if (!pad) {
      this.padMove.x = this.padMove.y = this.padLook.x = this.padLook.y = 0;
      return;
    }
    const dz = (v: number) => (Math.abs(v) < 0.15 ? 0 : v);
    this.padMove.x = dz(pad.axes[0] ?? 0);
    this.padMove.y = -dz(pad.axes[1] ?? 0);
    this.padLook.x = dz(pad.axes[2] ?? 0);
    this.padLook.y = dz(pad.axes[3] ?? 0);
    this.setVirtualFromPad('jump', pad.buttons[0]?.pressed);
    this.setVirtualFromPad('crouch', pad.buttons[1]?.pressed);
    this.setVirtualFromPad('interact', pad.buttons[2]?.pressed);
    this.setVirtualFromPad('toggleView', pad.buttons[3]?.pressed);
    this.setVirtualFromPad('run', pad.buttons[10]?.pressed); // ضغط العصا اليسرى
  }

  private padState = new Map<Action, boolean>();
  private setVirtualFromPad(a: Action, isDown: boolean | undefined): void {
    const was = this.padState.get(a) ?? false;
    const now = !!isDown;
    if (now !== was) {
      this.padState.set(a, now);
      this.setVirtual(a, now);
    }
  }

  /** يُستدعى في نهاية كل إطار */
  endFrame(): void {
    this.pressedThisFrame.clear();
  }

  private releaseAll = (): void => {
    this.down.clear();
    this.pressedThisFrame.clear();
    this.touchMove.x = this.touchMove.y = 0;
  };

  private onKeyDown = (e: KeyboardEvent): void => {
    const a = KEY_MAP[e.code];
    if (!a) return;
    if (e.code === 'Space' || e.code === 'Tab' || e.code.startsWith('Arrow')) e.preventDefault();
    if (!e.repeat) this.pressedThisFrame.add(a);
    this.down.add(a);
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    const a = KEY_MAP[e.code];
    if (a) this.down.delete(a);
  };

  private onMouseMove = (e: MouseEvent): void => {
    if (!this.pointerLocked) return;
    this.lookDX += e.movementX;
    this.lookDY += e.movementY;
  };

  private wheel = 0;
  /** عجلة الماوس المتراكمة (+ لأسفل) ثم تُصفَّر */
  consumeWheel(): number {
    const w = this.wheel;
    this.wheel = 0;
    return Math.sign(w);
  }

  private onMouseDown = (e: MouseEvent): void => {
    if (!this.pointerLocked || e.button !== 0) return;
    this.pressedThisFrame.add('attack');
    this.down.add('attack');
  };

  private onMouseUp = (e: MouseEvent): void => {
    if (e.button === 0) this.down.delete('attack');
  };

  private onWheel = (e: WheelEvent): void => {
    if (this.pointerLocked) this.wheel += e.deltaY;
  };

  private onLockChanged = (): void => {
    this.pointerLocked = document.pointerLockElement === this.canvas;
    if (!this.pointerLocked) this.releaseAll();
    this.onLockChange?.(this.pointerLocked);
  };

  // ---- لمس: أي إصبع على الكانفاس يدير الكاميرا (عصا الحركة عنصر DOM مستقل) ----
  private onTouchStart = (e: TouchEvent): void => {
    e.preventDefault();
    for (const t of Array.from(e.changedTouches)) {
      if (this.lookTouchId === null) {
        this.lookTouchId = t.identifier;
        this.lookTouchLast = { x: t.clientX, y: t.clientY };
      }
    }
  };

  private onTouchMove = (e: TouchEvent): void => {
    e.preventDefault();
    for (const t of Array.from(e.changedTouches)) {
      if (t.identifier === this.lookTouchId) {
        this.lookDX += (t.clientX - this.lookTouchLast.x) * 2.0;
        this.lookDY += (t.clientY - this.lookTouchLast.y) * 2.0;
        this.lookTouchLast = { x: t.clientX, y: t.clientY };
      }
    }
  };

  private onTouchEnd = (e: TouchEvent): void => {
    for (const t of Array.from(e.changedTouches)) {
      if (t.identifier === this.lookTouchId) this.lookTouchId = null;
    }
  };

  /** يربط عصا الحركة وأزرار اللمس الموجودة في index.html */
  bindTouchControls(): void {
    const touchRoot = document.getElementById('touch');
    if (!touchRoot) return;
    touchRoot.classList.add('on');

    const stick = document.getElementById('stickMove');
    const knob = stick?.querySelector<HTMLElement>('.knob');
    if (stick && knob) {
      const RADIUS = 50;
      const update = (t: Touch): void => {
        let dx = t.clientX - this.moveOrigin.x;
        let dy = t.clientY - this.moveOrigin.y;
        const len = Math.hypot(dx, dy);
        if (len > RADIUS) {
          dx = (dx / len) * RADIUS;
          dy = (dy / len) * RADIUS;
        }
        knob.style.transform = `translate(${dx}px, ${dy}px)`;
        this.setTouchMove(dx / RADIUS, -dy / RADIUS);
      };
      stick.addEventListener('touchstart', (e) => {
        e.preventDefault();
        const t = e.changedTouches[0];
        this.moveTouchId = t.identifier;
        const r = stick.getBoundingClientRect();
        this.moveOrigin = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
        update(t);
      }, { passive: false });
      stick.addEventListener('touchmove', (e) => {
        e.preventDefault();
        for (const t of Array.from(e.changedTouches)) if (t.identifier === this.moveTouchId) update(t);
      }, { passive: false });
      const end = (e: TouchEvent): void => {
        for (const t of Array.from(e.changedTouches)) {
          if (t.identifier === this.moveTouchId) {
            this.moveTouchId = null;
            knob.style.transform = '';
            this.setTouchMove(0, 0);
          }
        }
      };
      stick.addEventListener('touchend', end);
      stick.addEventListener('touchcancel', end);
    }

    const bindBtn = (id: string, action: Action): void => {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('touchstart', (e) => { e.preventDefault(); this.setVirtual(action, true); }, { passive: false });
      const up = (e: Event): void => { e.preventDefault(); this.setVirtual(action, false); };
      el.addEventListener('touchend', up);
      el.addEventListener('touchcancel', up);
    };
    bindBtn('btnJump', 'jump');
    bindBtn('btnRun', 'run');
    bindBtn('btnView', 'toggleView');
    bindBtn('btnAttack', 'attack');
    bindBtn('btnUse', 'interact');
    bindBtn('btnBag', 'inventory');
    bindBtn('btnMenu', 'pause');
  }
}
