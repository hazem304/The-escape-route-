/** آلة حالات عامة: لكل حالة دوال دخول/خروج/تحديث اختيارية */
export interface State<C> {
  enter?(ctx: C, prev: string | null): void;
  exit?(ctx: C, next: string): void;
  update?(ctx: C, dt: number): void;
}

export class StateMachine<C, N extends string = string> {
  private states = new Map<N, State<C>>();
  private currentName: N | null = null;

  constructor(private ctx: C) {}

  add(name: N, state: State<C>): this {
    this.states.set(name, state);
    return this;
  }

  get current(): N | null {
    return this.currentName;
  }

  is(name: N): boolean {
    return this.currentName === name;
  }

  set(name: N): void {
    if (name === this.currentName) return;
    const next = this.states.get(name);
    if (!next) throw new Error(`StateMachine: unknown state "${name}"`);
    const prevName = this.currentName;
    if (prevName !== null) this.states.get(prevName)?.exit?.(this.ctx, name);
    this.currentName = name;
    next.enter?.(this.ctx, prevName);
  }

  update(dt: number): void {
    if (this.currentName !== null) this.states.get(this.currentName)?.update?.(this.ctx, dt);
  }
}
