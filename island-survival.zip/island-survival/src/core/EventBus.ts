/** ناقل أحداث بسيط ومُنمَّط الأنواع */
export type Handler<T> = (payload: T) => void;

export class EventBus<Events extends Record<string, unknown>> {
  private handlers = new Map<keyof Events, Set<Handler<never>>>();

  on<K extends keyof Events>(event: K, handler: Handler<Events[K]>): () => void {
    let set = this.handlers.get(event);
    if (!set) {
      set = new Set();
      this.handlers.set(event, set);
    }
    set.add(handler as Handler<never>);
    return () => this.off(event, handler);
  }

  once<K extends keyof Events>(event: K, handler: Handler<Events[K]>): () => void {
    const off = this.on(event, (p) => {
      off();
      handler(p);
    });
    return off;
  }

  off<K extends keyof Events>(event: K, handler: Handler<Events[K]>): void {
    this.handlers.get(event)?.delete(handler as Handler<never>);
  }

  emit<K extends keyof Events>(event: K, payload: Events[K]): void {
    const set = this.handlers.get(event);
    if (!set) return;
    // نسخة من المجموعة حتى لا يؤثر الإلغاء أثناء الإطلاق على التكرار
    for (const h of [...set]) (h as Handler<Events[K]>)(payload);
  }

  clear(): void {
    this.handlers.clear();
  }
}

/** أحداث اللعبة المعروفة حاليًا (تتوسع في المراحل التالية) */
export interface GameEvents extends Record<string, unknown> {
  'player:jump': undefined;
  'player:land': { speed: number };
  'player:viewChanged': { mode: 'first' | 'third' };
  'player:waterChanged': { inWater: boolean };
  'game:pause': undefined;
  'game:resume': undefined;
  'config:changed': undefined;
  'weather:changed': { type: string };
  /** distance بالمتر تقريبًا؛ الصوت يتأخر حسب المسافة */
  'weather:thunder': { distance: number };
}
