import type { Language } from '../config';
import ar from '../data/i18n_ar.json';
import en from '../data/i18n_en.json';

type Dict = Record<string, string>;

const dicts: Record<Language, Dict> = { ar, en };
let current: Language = 'ar';

export function setLanguage(lang: Language): void {
  current = lang;
  if (typeof document !== 'undefined') {
    document.documentElement.lang = lang;
    // اتجاه RTL تلقائي للعربية
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    applyToDom();
  }
}

export function getLanguage(): Language {
  return current;
}

/** ترجمة مع استبدال {param} */
export function t(key: string, params?: Record<string, string | number>): string {
  let s = dicts[current][key] ?? dicts.en[key] ?? key;
  if (params) for (const [k, v] of Object.entries(params)) s = s.split(`{${k}}`).join(String(v));
  return s;
}

/** اسم عنصر ثنائي اللغة (nameAr/nameEn) حسب اللغة الحالية */
export function pick(o: { ar: string; en: string }): string {
  return current === 'ar' ? o.ar : o.en;
}

/** يملأ كل العناصر الحاملة للسمة data-i18n */
export function applyToDom(root: ParentNode = document): void {
  root.querySelectorAll<HTMLElement>('[data-i18n]').forEach((el) => {
    el.textContent = t(el.dataset.i18n ?? '');
  });
}
