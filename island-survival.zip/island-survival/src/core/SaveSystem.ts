import { SAVE_VERSION, type SessionSave } from './GameSession';

export const SLOT_COUNT = 3;

export interface SlotInfo {
  slot: number;
  empty: boolean;
  savedAt?: number;
  playTime?: number;
  day?: number;
  difficulty?: string;
  corrupt?: boolean;
}

/** واجهة تخزين مفتاح→نص؛ تُنفَّذ بـ IndexedDB وlocalStorage وذاكرة */
export interface StorageBackend {
  readonly name: string;
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
  remove(key: string): Promise<void>;
}

export class MemoryBackend implements StorageBackend {
  readonly name = 'memory';
  readonly data = new Map<string, string>();
  async get(k: string): Promise<string | null> {
    return this.data.get(k) ?? null;
  }
  async set(k: string, v: string): Promise<void> {
    this.data.set(k, v);
  }
  async remove(k: string): Promise<void> {
    this.data.delete(k);
  }
}

export class LocalStorageBackend implements StorageBackend {
  readonly name = 'localStorage';
  async get(k: string): Promise<string | null> {
    return localStorage.getItem(k);
  }
  async set(k: string, v: string): Promise<void> {
    localStorage.setItem(k, v);
  }
  async remove(k: string): Promise<void> {
    localStorage.removeItem(k);
  }
}

export class IndexedDBBackend implements StorageBackend {
  readonly name = 'indexedDB';
  private dbp: Promise<IDBDatabase> | null = null;

  private db(): Promise<IDBDatabase> {
    this.dbp ??= new Promise((res, rej) => {
      const req = indexedDB.open('island-survival', 1);
      req.onupgradeneeded = () => req.result.createObjectStore('kv');
      req.onsuccess = () => res(req.result);
      req.onerror = () => rej(req.error);
    });
    return this.dbp;
  }

  private async tx<T>(mode: IDBTransactionMode, f: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
    const db = await this.db();
    return new Promise((res, rej) => {
      const r = f(db.transaction('kv', mode).objectStore('kv'));
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }

  async get(k: string): Promise<string | null> {
    return ((await this.tx('readonly', (s) => s.get(k))) as string | undefined) ?? null;
  }
  async set(k: string, v: string): Promise<void> {
    await this.tx('readwrite', (s) => s.put(v, k));
  }
  async remove(k: string): Promise<void> {
    await this.tx('readwrite', (s) => s.delete(k));
  }
}

/** يختار IndexedDB ثم localStorage ثم الذاكرة بحسب المتاح */
export function createBackend(): StorageBackend {
  try {
    if (typeof indexedDB !== 'undefined') return new IndexedDBBackend();
  } catch {
    /* ننتقل للتالي */
  }
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('__t', '1');
      localStorage.removeItem('__t');
      return new LocalStorageBackend();
    }
  } catch {
    /* وضع خاص */
  }
  return new MemoryBackend();
}

/** FNV-1a 32 بت: يكشف التلف العرضي (لا حماية من التلاعب) */
export function checksum(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}

interface Envelope {
  v: number;
  sum: string;
  body: string;
}

type Migration = (d: Record<string, unknown>) => Record<string, unknown>;
/** migrations[n] يرقّي من الإصدار n إلى n+1 */
export const MIGRATIONS: Record<number, Migration> = {};

export function migrate(d: Record<string, unknown>): Record<string, unknown> {
  let v = (d.version as number) ?? 0;
  while (v < SAVE_VERSION) {
    const m = MIGRATIONS[v];
    if (!m) throw new Error(`لا ترقية من الإصدار ${v}`);
    d = m(d);
    v++;
    d.version = v;
  }
  if (v > SAVE_VERSION) throw new Error(`حفظ من إصدار أحدث (${v})`);
  return d;
}

export type LoadError = 'empty' | 'corrupt' | 'version';

export class SaveSystem {
  constructor(private backend: StorageBackend = createBackend()) {}

  private key(slot: number): string {
    if (!Number.isInteger(slot) || slot < 0 || slot >= SLOT_COUNT) throw new RangeError(`خانة غير صالحة: ${slot}`);
    return `save.${slot}`;
  }

  async save(slot: number, data: SessionSave): Promise<void> {
    const body = JSON.stringify(data);
    const env: Envelope = { v: SAVE_VERSION, sum: checksum(body), body };
    // نكتب نسخة احتياطية للسابقة أولًا: انقطاع منتصف الكتابة لا يفقد كل شيء
    const k = this.key(slot);
    const prev = await this.backend.get(k);
    if (prev) await this.backend.set(`${k}.bak`, prev);
    await this.backend.set(k, JSON.stringify(env));
  }

  async load(slot: number): Promise<{ ok: true; data: SessionSave } | { ok: false; error: LoadError }> {
    const k = this.key(slot);
    const r = await this.tryRead(k);
    if (r.ok || r.error === 'empty' || r.error === 'version') {
      if (r.ok || r.error !== 'empty') return r;
      return r;
    }
    // تالف: نحاول النسخة الاحتياطية
    const b = await this.tryRead(`${k}.bak`);
    return b.ok ? b : r;
  }

  private async tryRead(k: string): Promise<{ ok: true; data: SessionSave } | { ok: false; error: LoadError }> {
    const raw = await this.backend.get(k);
    if (raw === null) return { ok: false, error: 'empty' };
    try {
      const env = JSON.parse(raw) as Envelope;
      if (typeof env.body !== 'string' || checksum(env.body) !== env.sum) return { ok: false, error: 'corrupt' };
      const data = migrate(JSON.parse(env.body) as Record<string, unknown>);
      return { ok: true, data: data as unknown as SessionSave };
    } catch (e) {
      return { ok: false, error: /إصدار/.test(String(e)) ? 'version' : 'corrupt' };
    }
  }

  async delete(slot: number): Promise<void> {
    const k = this.key(slot);
    await this.backend.remove(k);
    await this.backend.remove(`${k}.bak`);
  }

  async list(): Promise<SlotInfo[]> {
    const out: SlotInfo[] = [];
    for (let i = 0; i < SLOT_COUNT; i++) {
      const r = await this.load(i);
      if (r.ok) {
        out.push({ slot: i, empty: false, savedAt: r.data.savedAt, playTime: r.data.playTime, day: Math.floor(r.data.totalHours / 24) + 1, difficulty: r.data.difficulty });
      } else out.push({ slot: i, empty: r.error === 'empty', corrupt: r.error === 'corrupt' });
    }
    return out;
  }
}

/** حفظ تلقائي: كل فترة وعند الأحداث المهمة، دون تداخل كتابتين */
export class AutoSaver {
  private since = 0;
  private busy = false;
  constructor(
    private sys: SaveSystem,
    private slot: number,
    private snapshot: () => SessionSave,
    private intervalSec = 120,
  ) {}

  tick(dt: number): void {
    this.since += dt;
    if (this.since >= this.intervalSec) void this.now();
  }

  async now(): Promise<boolean> {
    if (this.busy) return false;
    this.busy = true;
    this.since = 0;
    try {
      await this.sys.save(this.slot, this.snapshot());
      return true;
    } catch {
      return false;
    } finally {
      this.busy = false;
    }
  }
}
