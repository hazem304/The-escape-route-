/** مولّد أرقام عشوائية حتمي (mulberry32) لتوليد عالم ثابت من بذرة */
export class Random {
  private state: number;

  constructor(seed: number | string) {
    this.state = typeof seed === 'number' ? seed >>> 0 : Random.hashString(seed);
  }

  static hashString(s: string): number {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return h;
  }

  /** رقم في [0,1) */
  next(): number {
    this.state = (this.state + 0x6d2b79f5) >>> 0;
    let t = this.state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  range(min: number, max: number): number {
    return min + (max - min) * this.next();
  }

  int(min: number, maxInclusive: number): number {
    return Math.floor(this.range(min, maxInclusive + 1));
  }

  chance(p: number): boolean {
    return this.next() < p;
  }

  pick<T>(arr: readonly T[]): T {
    if (arr.length === 0) throw new Error('Random.pick: empty array');
    return arr[Math.floor(this.next() * arr.length)];
  }

  /** توزيع تقريبي طبيعي (مجموع ثلاثة أرقام) في [-1,1] */
  gaussian(): number {
    return (this.next() + this.next() + this.next()) / 1.5 - 1;
  }
}
