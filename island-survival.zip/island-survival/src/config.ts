import type { QualityLevel } from './constants';
import { defaultQuality, readDevice } from './core/Device';

export type Language = 'ar' | 'en';

/** إعدادات المستخدم القابلة للتعديل والحفظ */
export interface GameConfig {
  language: Language;
  quality: QualityLevel;
  invertY: boolean;
  mouseSensitivity: number; // مضاعِف 0.2 - 3
  fov: number;
  masterVolume: number;
  sfxVolume: number;
  musicVolume: number;
  ambientVolume: number;
  postfx: boolean;
  subtitles: boolean;
}

const KEY = 'island-survival:config';

const DEFAULTS: GameConfig = {
  language: 'ar',
  quality: 'medium',
  invertY: false,
  mouseSensitivity: 1,
  fov: 70,
  masterVolume: 0.8,
  sfxVolume: 1,
  musicVolume: 0.5,
  ambientVolume: 0.8,
  postfx: true,
  subtitles: false,
};

export function loadConfig(): GameConfig {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...DEFAULTS, ...(JSON.parse(raw) as Partial<GameConfig>) };
  } catch {
    // التخزين قد يكون محجوبًا (وضع التصفح الخاص) — نكمل بالقيم الافتراضية
  }
  return { ...DEFAULTS, quality: defaultQuality(readDevice()) };
}

export function saveConfig(cfg: GameConfig): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(cfg));
  } catch {
    // تجاهل
  }
}

/** درجات الجودة وما تغيّره في العرض */
export const QUALITY_PRESETS: Record<QualityLevel, { pixelRatio: number; shadows: boolean; shadowMapSize: number }> = {
  low: { pixelRatio: 1, shadows: false, shadowMapSize: 512 },
  medium: { pixelRatio: Math.min(window.devicePixelRatio, 1.5), shadows: true, shadowMapSize: 1024 },
  high: { pixelRatio: Math.min(window.devicePixelRatio, 2), shadows: true, shadowMapSize: 2048 },
};
