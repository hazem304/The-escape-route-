import './ui/ui.css';
import { Game } from './Game';
import { installErrorPanel, lockGestures, registerServiceWorker } from './mobile';

installErrorPanel();
lockGestures();
registerServiceWorker();

const canvas = document.getElementById('game') as HTMLCanvasElement | null;
if (!canvas) throw new Error('عنصر الكانفاس #game غير موجود');

const game = new Game(canvas);
game.start().catch((err) => {
  console.error(err);
  const overlay = document.getElementById('overlay');
  if (overlay) overlay.textContent = `خطأ أثناء التحميل: ${(err as Error).message}`;
});

// للتطوير فقط: الوصول للعبة من الكونسول
(window as unknown as { game: Game }).game = game;
