import * as THREE from 'three';
import { BLUEPRINTS, CELL_SIZE, WALL_HEIGHT, type PieceType } from '../building/Blueprint';
import type { Piece } from '../building/Snap';
import type { GameSession } from '../core/GameSession';
import type { Animal, SpeciesId } from '../entities/Animal';
import { createHumanoid, HumanoidAnimator, type HumanoidRig } from '../entities/HumanoidMesh';
import type { NPC } from '../entities/NPC';
import { ItemDB } from '../inventory/ItemDatabase';
import type { AssetLoader } from './AssetLoader';
import { ClipPlayer } from './ClipPlayer';

const mat = (c: number, rough = 0.9): THREE.MeshStandardMaterial => new THREE.MeshStandardMaterial({ color: c, roughness: rough, metalness: 0 });
const box = (w: number, h: number, d: number, m: THREE.Material, y = 0): THREE.Mesh => {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  mesh.position.y = y;
  mesh.castShadow = mesh.receiveShadow = true;
  return mesh;
};

// ====================== الحيوانات ======================
interface AnimalLook { l: number; h: number; w: number; leg: number; color: number; head: number }
const LOOKS: Record<SpeciesId, AnimalLook> = {
  deer: { l: 1.3, h: 0.55, w: 0.45, leg: 0.8, color: 0xa87a4a, head: 0.28 },
  boar: { l: 1.2, h: 0.6, w: 0.55, leg: 0.4, color: 0x4a3a30, head: 0.3 },
  crab: { l: 0.28, h: 0.08, w: 0.22, leg: 0.05, color: 0xd05030, head: 0.0 },
  seagull: { l: 0.45, h: 0.14, w: 0.14, leg: 0.1, color: 0xf2f2f2, head: 0.1 },
  shark: { l: 3.2, h: 0.6, w: 0.7, leg: 0, color: 0x6c7c88, head: 0.0 },
  snake: { l: 1.2, h: 0.07, w: 0.07, leg: 0, color: 0x6a8a2a, head: 0.0 },
  jaguar: { l: 1.5, h: 0.6, w: 0.5, leg: 0.55, color: 0xc8a020, head: 0.3 },
};

interface AnimalView { group: THREE.Group; legs: THREE.Object3D[]; wings: THREE.Object3D[]; phase: number; fromAsset: boolean; player?: ClipPlayer }

function buildAnimal(id: SpeciesId): AnimalView {
  const L = LOOKS[id];
  const g = new THREE.Group();
  const m = mat(L.color);
  const legs: THREE.Object3D[] = [];
  const wings: THREE.Object3D[] = [];
  const bodyY = L.leg + L.h / 2;
  g.add(box(L.w, L.h, L.l, m, bodyY));
  if (L.head > 0) {
    const head = box(L.head, L.head, L.head * 1.3, m, bodyY + L.h * 0.2);
    head.position.z = L.l / 2 + L.head * 0.4;
    g.add(head);
    if (id === 'deer') { // قرون
      for (const s of [-1, 1]) { const a = box(0.03, 0.28, 0.03, mat(0x8a6a40), bodyY + L.h * 0.2 + 0.28); a.position.set(s * 0.08, a.position.y, L.l / 2 + L.head * 0.3); g.add(a); }
    }
  }
  if (L.leg > 0 && id !== 'seagull') {
    for (const [x, z] of [[-1, 1], [1, 1], [-1, -1], [1, -1]]) {
      const leg = new THREE.Group();
      leg.position.set((x * L.w) / 2.4, L.leg, (z * L.l) / 2.6);
      const m1 = box(0.07, L.leg, 0.07, m, -L.leg / 2);
      leg.add(m1);
      legs.push(leg);
      g.add(leg);
    }
  }
  if (id === 'shark') {
    const fin = box(0.05, 0.55, 0.5, m, bodyY + 0.5); fin.rotation.x = -0.4; g.add(fin);
    const tail = box(0.05, 0.7, 0.5, m, bodyY); tail.position.z = -L.l / 2 - 0.2; g.add(tail);
  }
  if (id === 'seagull') {
    for (const s of [-1, 1]) {
      const w = new THREE.Group(); w.position.set(s * 0.07, bodyY, 0);
      const wing = box(0.5, 0.02, 0.2, mat(0xe8e8e8), 0); wing.position.x = s * 0.25; w.add(wing);
      wings.push(w); g.add(w);
    }
    const beak = box(0.03, 0.03, 0.1, mat(0xe0a020), bodyY); beak.position.z = L.l / 2 + 0.06; g.add(beak);
  }
  if (id === 'snake') {
    g.remove(g.children[0]);
    for (let i = 0; i < 8; i++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.045, 6, 5), m); s.position.set(Math.sin(i * 0.9) * 0.08, 0.05, -i * 0.15 + 0.5); g.add(s); }
  }
  if (id === 'crab') {
    for (const s of [-1, 1]) { const claw = box(0.06, 0.04, 0.1, mat(0xe06040), 0.12); claw.position.set(s * 0.14, 0.1, 0.16); g.add(claw); }
  }
  if (id === 'jaguar') { // بقع
    const sp = mat(0x2a2010);
    for (let i = 0; i < 8; i++) { const d = box(0.1, 0.02, 0.1, sp, bodyY + L.h / 2 + 0.005); d.position.set((Math.random() - 0.5) * 0.3, d.position.y, (Math.random() - 0.5) * 1.1); g.add(d); }
  }
  return { group: g, legs, wings, phase: Math.random() * 6, fromAsset: false };
}

export class AnimalViews {
  readonly group = new THREE.Group();
  private views = new Map<number, AnimalView>();
  constructor(private assets?: AssetLoader) {}

  update(animals: readonly Animal[], dt: number, camPos: THREE.Vector3, maxDist = 160): void {
    const seen = new Set<number>();
    for (const a of animals) {
      const dx = a.pos.x - camPos.x;
      const dz = a.pos.z - camPos.z;
      if (dx * dx + dz * dz > maxDist * maxDist) continue; // خارج المدى: لا مجسم
      seen.add(a.id);
      let v = this.views.get(a.id);
      if (!v) {
        v = this.make(a.species.id);
        this.views.set(a.id, v);
        this.group.add(v.group);
      }
      const g = v.group;
      g.position.set(a.pos.x, a.y + (a.species.domain === 'air' ? 6 + Math.sin(v.phase + performance.now() * 0.001) * 0.8 : 0), a.pos.z);
      g.rotation.y = a.heading;
      const speed = Math.hypot(a.vel.x, a.vel.z);
      v.phase += dt * (2 + speed * 2.5);
      const dead = a.state === 'dead';
      if (v.player) {
        v.player.set(dead ? 'dead' : speed > 3 ? 'run' : speed > 0.2 ? 'walk' : 'idle', speed);
        v.player.update(dt);
      }
      g.rotation.z = v.player ? 0 : THREE.MathUtils.lerp(g.rotation.z, dead ? Math.PI / 2 : 0, Math.min(1, dt * 6));
      v.legs.forEach((leg, i) => { leg.rotation.x = Math.sin(v!.phase + (i % 2 === (i < 2 ? 0 : 1) ? 0 : Math.PI)) * Math.min(0.9, speed * 0.25); });
      v.wings.forEach((w, i) => { w.rotation.z = Math.sin(v!.phase * 3) * 0.7 * (i === 0 ? 1 : -1); });
      if (a.species.id === 'shark') g.position.y = Math.min(a.y, -0.6) + Math.sin(v.phase * 0.5) * 0.05;
    }
    for (const [id, v] of this.views) if (!seen.has(id)) { this.group.remove(v.group); this.views.delete(id); }
  }

  private make(id: SpeciesId): AnimalView {
    if (this.assets?.has(`animal_${id}`)) {
      const g = new THREE.Group();
      const m = this.assets.model(`animal_${id}`, () => new THREE.Group());
      g.add(m);
      const cp = new ClipPlayer(m, this.assets.clips(`animal_${id}`));
      return { group: g, legs: [], wings: [], phase: 0, fromAsset: true, player: cp.hasClips ? cp : undefined };
    }
    return buildAnimal(id);
  }

  get count(): number { return this.views.size; }
}

// ====================== الناجون ======================
const NPC_TINT: Record<string, number> = { layla: 0xd05a7a, omar: 0x4a7ad0, yusuf: 0x6aa04a };

export class NPCViews {
  readonly group = new THREE.Group();
  private views = new Map<string, { rig: HumanoidRig; anim: HumanoidAnimator; root: THREE.Group; last: { x: number; z: number }; player?: ClipPlayer }>();

  constructor(npcs: readonly NPC[], getY: (x: number, z: number) => number, private assets?: AssetLoader) {
    for (const n of npcs) {
      const asset = this.assets?.has(`npc_${n.def.id}`);
      const rig = createHumanoid(1.7);
      const root = new THREE.Group();
      let player: ClipPlayer | undefined;
      if (asset) {
        const m = this.assets!.model(`npc_${n.def.id}`, () => rig.root);
        root.add(m);
        const cp = new ClipPlayer(m, this.assets!.clips(`npc_${n.def.id}`));
        if (cp.hasClips) player = cp;
      }
      if (!asset) {
        root.add(rig.root);
        rig.root.rotation.y = Math.PI;
        // علامة ملوّنة فوق الرأس تميّز كل ناجٍ
        const mark = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.22, 8), new THREE.MeshBasicMaterial({ color: NPC_TINT[n.def.id] ?? 0xffffff }));
        mark.rotation.x = Math.PI; mark.position.y = 2.2; root.add(mark);
      }
      root.position.set(n.pos.x, getY(n.pos.x, n.pos.z), n.pos.z);
      this.group.add(root);
      this.views.set(n.def.id, { rig, anim: new HumanoidAnimator(rig), root, last: { x: n.pos.x, z: n.pos.z }, player });
    }
  }

  update(npcs: readonly NPC[], dt: number, getY: (x: number, z: number) => number): void {
    for (const n of npcs) {
      const v = this.views.get(n.def.id);
      if (!v) continue;
      const dx = n.pos.x - v.last.x;
      const dz = n.pos.z - v.last.z;
      const speed = Math.hypot(dx, dz) / Math.max(dt, 1e-3);
      if (speed > 0.15) v.root.rotation.y = Math.atan2(dx, dz);
      v.last = { x: n.pos.x, z: n.pos.z };
      v.root.position.set(n.pos.x, getY(n.pos.x, n.pos.z), n.pos.z);
      const mode = speed > 1.5 ? 'run' : speed > 0.15 ? 'walk' : 'idle';
      if (v.player) {
        v.player.set(mode, speed);
        v.player.update(dt);
      } else v.anim.update(dt, mode, speed);
    }
  }

  /** أقرب ناجٍ ضمن المدى (للتحدث) */
  nearest(npcs: readonly NPC[], x: number, z: number, range: number): NPC | null {
    let best: NPC | null = null;
    let bd = range;
    for (const n of npcs) {
      const d = Math.hypot(n.pos.x - x, n.pos.z - z);
      if (d < bd) { bd = d; best = n; }
    }
    return best;
  }
}

// ====================== عناصر الأرض والقصة (سبرايت إيموجي) ======================
const iconCache = new Map<string, THREE.SpriteMaterial>();
function iconMaterial(emoji: string, glow = false): THREE.SpriteMaterial {
  const key = emoji + glow;
  let m = iconCache.get(key);
  if (m) return m;
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const ctx = c.getContext('2d')!;
  if (glow) {
    const g = ctx.createRadialGradient(64, 64, 4, 64, 64, 62);
    g.addColorStop(0, 'rgba(255,230,120,.75)'); g.addColorStop(1, 'rgba(255,230,120,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, 128, 128);
  }
  ctx.font = '72px system-ui, "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji"';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(emoji, 64, 70);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  m = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false });
  iconCache.set(key, m);
  return m;
}

export class GroundViews {
  readonly group = new THREE.Group();
  private items = new Map<number, THREE.Sprite>();
  private story = new Map<string, THREE.Sprite>();
  private timer = 0;

  update(session: GameSession, dt: number, elapsed: number): void {
    this.timer -= dt;
    if (this.timer <= 0) {
      this.timer = 0.2;
      const live = new Set<number>();
      for (const it of session.ground.list()) {
        live.add(it.id);
        if (!this.items.has(it.id)) {
          const s = new THREE.Sprite(iconMaterial(ItemDB.get(it.stack.defId).icon));
          s.scale.set(0.5, 0.5, 1);
          this.items.set(it.id, s);
          this.group.add(s);
        }
        this.items.get(it.id)!.position.set(it.x, it.y + 0.3, it.z);
      }
      for (const [id, s] of this.items) if (!live.has(id)) { this.group.remove(s); this.items.delete(id); }
      for (const p of session.story) {
        const s = this.story.get(p.id);
        if (p.taken) { if (s) { this.group.remove(s); this.story.delete(p.id); } continue; }
        if (!s) {
          const sp = new THREE.Sprite(iconMaterial(p.page ? '📜' : ItemDB.get(p.item).icon, true));
          sp.scale.set(0.9, 0.9, 1);
          sp.position.set(p.x, p.y + 0.5, p.z);
          this.story.set(p.id, sp);
          this.group.add(sp);
        }
      }
    }
    // طفو خفيف لعناصر القصة
    for (const s of this.story.values()) s.position.y += Math.sin(elapsed * 2 + s.position.x) * 0.0015;
  }

  get itemCount(): number { return this.items.size; }
}

// ====================== المباني ======================
const WOOD = mat(0x9a6a3a); const DARK = mat(0x6a4020); const STONE = mat(0x8a8780, 1); const THATCH = mat(0xc8b060, 1); const CLOTH = mat(0x4a7a9a); const METAL = mat(0x55595c, 0.5);

function buildPiece(p: Piece, assets?: AssetLoader): THREE.Object3D {
  const g = new THREE.Group();
  const t = p.type as PieceType;
  const asset = assets?.has(`piece_${t}`);
  if (asset) { g.add(assets!.model(`piece_${t}`, () => new THREE.Group())); return g; }
  switch (t) {
    case 'foundation': g.add(box(CELL_SIZE, 0.3, CELL_SIZE, WOOD, -0.1)); break;
    case 'wall': g.add(box(CELL_SIZE, WALL_HEIGHT, 0.2, WOOD, WALL_HEIGHT / 2)); break;
    case 'doorway': {
      g.add(box(0.8, WALL_HEIGHT, 0.2, WOOD, WALL_HEIGHT / 2).translateX(-1.1));
      g.add(box(0.8, WALL_HEIGHT, 0.2, WOOD, WALL_HEIGHT / 2).translateX(1.1));
      g.add(box(1.4, 0.5, 0.2, WOOD, WALL_HEIGHT - 0.25));
      break;
    }
    case 'door': g.add(box(1.4, 2.0, 0.12, DARK, 1.0)); break;
    case 'roof': {
      const r = new THREE.Mesh(new THREE.BoxGeometry(CELL_SIZE + 0.4, 0.15, CELL_SIZE + 0.4), THATCH);
      r.castShadow = true; g.add(r); break;
    }
    case 'campfire': {
      for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2; const s = new THREE.Mesh(new THREE.DodecahedronGeometry(0.12), STONE); s.position.set(Math.cos(a) * 0.45, 0.1, Math.sin(a) * 0.45); g.add(s); }
      for (let i = 0; i < 3; i++) { const l = box(0.1, 0.1, 0.7, DARK, 0.15); l.rotation.y = (i / 3) * Math.PI; l.rotation.x = 0.2; g.add(l); }
      break;
    }
    case 'workbench': g.add(box(1.6, 0.1, 0.8, WOOD, 0.85)); for (const [x, z] of [[-0.7, -0.3], [0.7, -0.3], [-0.7, 0.3], [0.7, 0.3]]) g.add(box(0.1, 0.85, 0.1, DARK, 0.42).translateX(x).translateZ(z)); break;
    case 'storage': g.add(box(0.9, 0.55, 0.6, WOOD, 0.28)); g.add(box(0.95, 0.12, 0.65, DARK, 0.6)); break;
    case 'barrel': { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.34, 0.9, 12), WOOD); b.position.y = 0.45; b.castShadow = true; g.add(b); const r = new THREE.Mesh(new THREE.TorusGeometry(0.37, 0.02, 6, 16), METAL); r.rotation.x = Math.PI / 2; r.position.y = 0.6; g.add(r); break; }
    case 'cooler': g.add(box(0.9, 0.6, 0.6, mat(0x5a7a8a), 0.3)); g.add(box(0.92, 0.08, 0.62, mat(0xdddddd), 0.64)); break;
    case 'bed': g.add(box(1.0, 0.18, 2.0, CLOTH, 0.12)); g.add(box(0.8, 0.12, 0.4, mat(0xe8e0d0), 0.26).translateZ(-0.7)); break;
    case 'rack': for (const x of [-0.7, 0.7]) g.add(box(0.07, 1.4, 0.07, WOOD, 0.7).translateX(x)); g.add(box(1.6, 0.06, 0.06, WOOD, 1.35)); g.add(box(1.6, 0.06, 0.06, WOOD, 0.9)); break;
    case 'furnace': { const f = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.65, 1.3, 10), STONE); f.position.y = 0.65; f.castShadow = true; g.add(f); g.add(box(0.35, 0.3, 0.1, mat(0x201815), 0.4).translateZ(0.55)); break; }
    case 'collector': { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.3, 0.5, 12, 1, true), mat(0x6a7a8a)); c.position.y = 0.5; g.add(c); g.add(box(0.8, 0.05, 0.8, WOOD, 0.9)); break; }
    case 'farm': { g.add(box(3, 0.1, 3, mat(0x4a3220), 0.05)); for (const x of [-1.5, 1.5]) g.add(box(0.1, 0.25, 3, WOOD, 0.1).translateX(x)); for (const z of [-1.5, 1.5]) g.add(box(3, 0.25, 0.1, WOOD, 0.1).translateZ(z)); void 0; break; }
    case 'raft': { for (let i = 0; i < 6; i++) g.add(box(0.7, 0.18, 4.2, WOOD, 0.1).translateX(-1.75 + i * 0.7)); for (const z of [-1.2, 1.2]) g.add(box(4.2, 0.12, 0.2, DARK, 0.25).translateZ(z)); const mast = box(0.08, 2.6, 0.08, DARK, 1.5); g.add(mast); const sail = box(1.5, 1.6, 0.03, mat(0xe6dcc0), 1.8); sail.position.z = 0.1; g.add(sail); break; }
  }
  void BLUEPRINTS;
  return g;
}

export class BuildingViews {
  readonly group = new THREE.Group();
  private views = new Map<number, THREE.Object3D>();
  private lights = new Map<number, THREE.PointLight>();
  constructor(private assets?: AssetLoader) {}

  /** يزامن المجسمات مع الجلسة (إضافة/حذف) ويحدّث أضواء النار */
  sync(session: GameSession): void {
    const live = new Set<number>();
    for (const p of session.buildings.list()) {
      live.add(p.id);
      if (!this.views.has(p.id)) {
        const o = buildPiece(p, this.assets);
        o.position.set(p.x, p.y, p.z);
        o.rotation.y = p.yaw;
        this.views.set(p.id, o);
        this.group.add(o);
      }
    }
    for (const [id, o] of this.views) if (!live.has(id)) { this.group.remove(o); this.views.delete(id); const l = this.lights.get(id); if (l) { this.group.remove(l); this.lights.delete(id); } }
    for (const [id, f] of session.fires) {
      const piece = session.buildings.get(id);
      if (!piece) continue;
      let l = this.lights.get(id);
      if (!l) { l = new THREE.PointLight(0xff9040, 0, 18, 1.6); this.group.add(l); this.lights.set(id, l); }
      l.position.set(piece.x, piece.y + 1, piece.z);
      l.intensity = f.burning ? 14 * f.strength * (0.9 + Math.random() * 0.2) : 0;
    }
  }

  object(id: number): THREE.Object3D | undefined { return this.views.get(id); }
  get count(): number { return this.views.size; }
}

/** شبح المعاينة عند البناء: أخضر صالح / أحمر غير صالح */
export function makeGhost(type: PieceType): THREE.Object3D {
  const o = buildPiece({ id: 0, type, cx: 0, cz: 0, x: 0, y: 0, z: 0, yaw: 0 });
  o.traverse((c) => {
    const m = c as THREE.Mesh;
    if (m.isMesh) m.material = new THREE.MeshBasicMaterial({ color: 0x40ff80, transparent: true, opacity: 0.45, depthWrite: false });
  });
  return o;
}

export function tintGhost(o: THREE.Object3D, ok: boolean): void {
  o.traverse((c) => { const m = c as THREE.Mesh; if (m.isMesh) (m.material as THREE.MeshBasicMaterial).color.setHex(ok ? 0x40ff80 : 0xff4040); });
}
