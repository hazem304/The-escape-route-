export type ClipState = 'idle' | 'walk' | 'run' | 'dead';

const PATTERNS: Record<ClipState, RegExp[]> = {
  dead: [/death|die|dead/i],
  run: [/run|gallop|sprint|fly/i],
  walk: [/walk|trot|swim|move/i],
  idle: [/idle|stand|breath|rest/i],
};
const FALLBACK: Record<ClipState, ClipState[]> = {
  dead: ['idle'],
  run: ['walk', 'idle'],
  walk: ['run', 'idle'],
  idle: ['walk'],
};

/** يختار فهرس مقطع الأنيميشن المناسب للحالة بالاسم، مع بدائل؛ -1 إن لم يوجد */
export function pickClip(names: readonly string[], state: ClipState): number {
  for (const st of [state, ...FALLBACK[state]]) {
    for (const re of PATTERNS[st]) {
      const i = names.findIndex((n) => re.test(n));
      if (i >= 0) return i;
    }
  }
  return names.length > 0 && state !== 'dead' ? 0 : -1;
}
