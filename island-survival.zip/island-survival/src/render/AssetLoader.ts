import * as THREE from 'three';
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { KTX2Loader } from 'three/examples/jsm/loaders/KTX2Loader.js';

export interface ManifestEntry {
  id: string;
  /** المسار نسبةً لـ assets/ */
  file: string;
  category: string;
  /** أقصى مثلثات مسموحة (للتحقق) */
  maxTris?: number;
  /** مقياس/إزاحة/دوران تصحيحية */
  scale?: number;
  offsetY?: number;
  rotY?: number;
  /** يعتمد الأنيميشن الداخلي؟ */
  animated?: boolean;
  /** required = لم يُولَّد بعد (يُتجاهل) · generated/integrated = يُحمَّل */
  status?: 'required' | 'generated' | 'integrated';
  integration?: 'auto' | 'not_wired';
  minTris?: number;
}

export interface Manifest { version: number; basePath?: string; assets: ManifestEntry[] }

/**
 * محمّل الأصول: يقرأ asset_manifest.json ثم يحاول تحميل GLB لكل معرّف.
 * أي أصل غير موجود/فاشل يبقى المجسّم الإجرائي (لا انهيار). `model(id, fallback)` يُرجِع نسخة مستقلة.
 */
export class AssetLoader {
  private gltf: GLTFLoader;
  private cache = new Map<string, THREE.Object3D>();
  private entries = new Map<string, ManifestEntry>();
  private failed = new Set<string>();
  private clipMap = new Map<string, THREE.AnimationClip[]>();
  basePath = '/assets/';
  /** يُستدعى عند وصول أصل جديد ليبدّل المشهد مجسماته */
  onLoaded: ((id: string) => void) | null = null;

  constructor(renderer?: THREE.WebGLRenderer) {
    this.gltf = new GLTFLoader();
    const draco = new DRACOLoader();
    draco.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.5.7/');
    this.gltf.setDRACOLoader(draco);
    if (renderer) {
      try {
        const ktx2 = new KTX2Loader();
        ktx2.setTranscoderPath('https://cdn.jsdelivr.net/npm/three@0.170.0/examples/jsm/libs/basis/');
        ktx2.detectSupport(renderer);
        this.gltf.setKTX2Loader(ktx2);
      } catch { /* لا يدعم KTX2: التركيبات PNG/JPG تعمل */ }
    }
  }

  async loadManifest(url = '/assets/asset_manifest.json'): Promise<number> {
    try {
      const res = await fetch(url);
      if (!res.ok) return 0;
      const m = (await res.json()) as Manifest;
      if (m.basePath) this.basePath = m.basePath;
      // الأصول المطلوبة ولم تُولَّد بعد تبقى إجرائية دون طلب شبكة
      let n = 0;
      for (const e of m.assets) {
        if (e.status === 'required') continue;
        this.entries.set(e.id, e);
        n++;
      }
      return n;
    } catch {
      return 0; // لا مانيفست = كل شيء إجرائي
    }
  }

  has(id: string): boolean {
    return this.cache.has(id);
  }

  /** يحمّل أصلًا واحدًا (يتجاهل الفشل بصمت ويعتبره غير متوفر) */
  async load(id: string): Promise<boolean> {
    if (this.cache.has(id)) return true;
    const e = this.entries.get(id);
    if (!e || this.failed.has(id)) return false;
    try {
      const g = await this.gltf.loadAsync(this.basePath + e.file);
      const root = g.scene;
      this.clipMap.set(id, g.animations);
      this.normalize(root, e);
      this.cache.set(id, root);
      this.onLoaded?.(id);
      return true;
    } catch {
      this.failed.add(id);
      return false;
    }
  }

  /** يحمّل كل الأصول المعلنة تدريجيًا دون تعطيل البدء */
  async loadAll(concurrency = 3): Promise<void> {
    const ids = [...this.entries.keys()];
    let i = 0;
    await Promise.all(Array.from({ length: concurrency }, async () => {
      while (i < ids.length) await this.load(ids[i++]);
    }));
  }

  private normalize(root: THREE.Object3D, e: ManifestEntry): void {
    root.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = true;
        m.receiveShadow = true;
      }
    });
    if (e.scale) root.scale.multiplyScalar(e.scale);
    if (e.offsetY) root.position.y += e.offsetY;
    if (e.rotY) root.rotation.y += e.rotY;
  }

  /** مقاطع الأنيميشن المضمّنة للأصل (قد تكون فارغة) */
  clips(id: string): THREE.AnimationClip[] {
    return this.clipMap.get(id) ?? [];
  }

  /** مجسّم الأصل (نسخة جديدة) أو البديل الإجرائي */
  model(id: string, fallback: () => THREE.Object3D): THREE.Object3D {
    const src = this.cache.get(id);
    if (!src) return fallback();
    return cloneSkinned(src);
  }

  /** عدد المثلثات لتحقق الميزانية */
  static triCount(o: THREE.Object3D): number {
    let n = 0;
    o.traverse((c) => {
      const m = c as THREE.Mesh;
      if (m.isMesh) n += (m.geometry.index ? m.geometry.index.count : m.geometry.attributes.position.count) / 3;
    });
    return n;
  }

  /** يتحقق من ميزانية المضلعات؛ يعيد المخالفات */
  budgetViolations(): string[] {
    const out: string[] = [];
    for (const [id, o] of this.cache) {
      const max = this.entries.get(id)?.maxTris;
      const n = AssetLoader.triCount(o);
      if (max && n > max) out.push(`${id}: ${Math.round(n)} > ${max}`);
    }
    return out;
  }
}

/** نسخ مع دعم الهياكل العظمية (clone عادي يكسر SkinnedMesh) */
function cloneSkinned(src: THREE.Object3D): THREE.Object3D {
  const clone = src.clone(true);
  const srcBones = new Map<string, THREE.Object3D>();
  src.traverse((o) => srcBones.set(o.uuid, o));
  const pairs: Array<[THREE.SkinnedMesh, THREE.SkinnedMesh]> = [];
  const a: THREE.Object3D[] = [];
  const b: THREE.Object3D[] = [];
  src.traverse((o) => a.push(o));
  clone.traverse((o) => b.push(o));
  a.forEach((o, i) => {
    if ((o as THREE.SkinnedMesh).isSkinnedMesh) pairs.push([o as THREE.SkinnedMesh, b[i] as THREE.SkinnedMesh]);
  });
  for (const [s, c] of pairs) {
    const bones = s.skeleton.bones.map((bone) => b[a.indexOf(bone)] as THREE.Bone);
    c.bind(new THREE.Skeleton(bones, s.skeleton.boneInverses), c.matrixWorld);
  }
  return clone;
}
