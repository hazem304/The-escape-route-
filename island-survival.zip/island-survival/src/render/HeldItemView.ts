import * as THREE from 'three';

const WOOD = 0x8a5a2b;
const STONE = 0x8d9096;

function box(w: number, h: number, d: number, color: number, x = 0, y = 0, z = 0): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshStandardMaterial({ color, roughness: 0.85 }));
  m.position.set(x, y, z);
  return m;
}

/** مجسم إجرائي بسيط للعنصر الممسوك بحسب النوع/المعرّف */
export function buildHeld(id: string, type: string): THREE.Object3D {
  const g = new THREE.Group();
  if (id === 'fishing_rod') {
    const rod = box(0.02, 0.02, 0.9, WOOD, 0, 0, -0.35);
    g.add(rod);
  } else if (id === 'fishing_net') {
    g.add(box(0.025, 0.025, 0.6, WOOD, 0, 0, -0.2), box(0.28, 0.28, 0.02, 0xbfae7a, 0, 0, -0.55));
  } else if (type === 'weapon') {
    g.add(box(0.035, 0.12, 0.05, WOOD, 0, 0, 0), box(0.04, 0.02, 0.1, 0x555555, 0, 0.07, 0), box(0.02, 0.5, 0.06, 0xc9ced6, 0, 0.35, 0));
  } else if (type === 'tool') {
    g.add(box(0.035, 0.5, 0.035, WOOD, 0, 0.2, 0), box(0.2, 0.07, 0.05, STONE, 0, 0.45, 0));
  } else if (type === 'food' || type === 'drink' || type === 'medicine') {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), new THREE.MeshStandardMaterial({ color: type === 'drink' ? 0x4aa3df : type === 'food' ? 0xd9803a : 0xe8e8e8 }));
    g.add(m);
  } else {
    g.add(box(0.12, 0.12, 0.12, 0xa08a6a));
  }
  return g;
}

/** يُعلَّق بالكاميرا ويُرى في المنظور الأول فقط؛ يتأرجح أثناء الضرب */
export class HeldItemView {
  readonly root = new THREE.Group();
  private key = '';
  private model: THREE.Object3D | null = null;

  constructor() {
    this.root.position.set(0.32, -0.3, -0.55);
    this.root.rotation.set(0.3, -0.4, 0);
  }

  update(id: string | null, type: string, visible: boolean, swing01: number, t: number): void {
    this.root.visible = visible && !!id;
    if (!id) return;
    const key = `${id}|${type}`;
    if (key !== this.key) {
      this.key = key;
      if (this.model) this.root.remove(this.model);
      this.model = buildHeld(id, type);
      this.root.add(this.model);
    }
    const s = Math.sin(swing01 * Math.PI);
    this.root.rotation.x = 0.3 - s * 1.1;
    this.root.position.y = -0.3 + Math.sin(t * 1.7) * 0.004 - s * 0.05;
  }
}
