import * as THREE from 'three';
import { BokehPass } from 'three/examples/jsm/postprocessing/BokehPass.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { GTAOPass } from 'three/examples/jsm/postprocessing/GTAOPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { SMAAPass } from 'three/examples/jsm/postprocessing/SMAAPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import type { QualityLevel } from '../constants';

export interface PostFXSettings {
  /** 0..1: تأثر الشاشة بالحالة (برد/ضرر/إغماء) */
  desaturate: number;
  vignette: number;
  /** وهج الحرارة العالية 0..1 */
  warmTint: number;
  coolTint: number;
}

/** أي المؤثرات تعمل في كل جودة */
export const POSTFX_BY_QUALITY: Record<QualityLevel, { bloom: boolean; gtao: boolean; dof: boolean; smaa: boolean; grade: boolean }> = {
  low: { bloom: false, gtao: false, dof: false, smaa: false, grade: true },
  medium: { bloom: true, gtao: false, dof: false, smaa: true, grade: true },
  high: { bloom: true, gtao: true, dof: true, smaa: true, grade: true },
};

const GradeShader = {
  uniforms: {
    tDiffuse: { value: null as THREE.Texture | null },
    uTime: { value: 0 },
    uSaturation: { value: 1.08 },
    uContrast: { value: 1.06 },
    uVignette: { value: 0.32 },
    uGrain: { value: 0.035 },
    uWarm: { value: 0 },
    uCool: { value: 0 },
    uLiftShadows: { value: new THREE.Vector3(0.0, 0.01, 0.02) },
    uGainHighlights: { value: new THREE.Vector3(1.03, 1.0, 0.96) },
  },
  vertexShader: /* glsl */ `varying vec2 vUv; void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse; uniform float uTime, uSaturation, uContrast, uVignette, uGrain, uWarm, uCool;
    uniform vec3 uLiftShadows, uGainHighlights; varying vec2 vUv;
    float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233)) + uTime) * 43758.5453); }
    void main() {
      vec3 c = texture2D(tDiffuse, vUv).rgb;
      // تدرّج لوني: رفع الظلال وتدفئة الإضاءات
      float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
      c = c * mix(vec3(1.0), uGainHighlights, smoothstep(0.3, 1.0, l)) + uLiftShadows * (1.0 - smoothstep(0.0, 0.4, l));
      c = mix(vec3(l), c, uSaturation);
      c = (c - 0.5) * uContrast + 0.5;
      c += vec3(0.05, 0.015, -0.03) * uWarm - vec3(0.03, 0.0, -0.05) * uCool;
      // فينيت
      vec2 q = vUv - 0.5; float v = smoothstep(0.35, 0.95, length(q) * 1.25);
      c *= 1.0 - v * uVignette;
      // حبيبات
      c += (hash(vUv * 1000.0) - 0.5) * uGrain;
      gl_FragColor = vec4(max(c, 0.0), 1.0);
    }`,
};

/**
 * سلسلة ما بعد المعالجة: GTAO (ظلال محيطية) → عمق الميدان الخفيف → Bloom → تدرّج لوني/فينيت/حبيبات
 * → OutputPass (توحيد الألوان) → SMAA. تُفعَّل بحسب الجودة، ويمكن إيقافها كلها (renderer مباشر).
 */
export class PostFX {
  readonly composer: EffectComposer;
  private renderPass: RenderPass;
  private gtao: GTAOPass | null = null;
  private bokeh: BokehPass | null = null;
  private bloom: UnrealBloomPass;
  private grade: ShaderPass;
  private output: OutputPass;
  private smaa: SMAAPass;
  enabled = true;

  constructor(private renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.PerspectiveCamera, quality: QualityLevel) {
    const size = renderer.getSize(new THREE.Vector2());
    const pr = renderer.getPixelRatio();
    this.composer = new EffectComposer(renderer);
    this.composer.setPixelRatio(pr);
    this.composer.setSize(size.x, size.y);

    this.renderPass = new RenderPass(scene, camera);
    this.composer.addPass(this.renderPass);

    this.gtao = new GTAOPass(scene, camera, size.x, size.y);
    this.gtao.output = GTAOPass.OUTPUT.Default;
    this.gtao.updateGtaoMaterial({ radius: 0.6, distanceExponent: 1.5, thickness: 1, scale: 1, samples: 12, distanceFallOff: 1, screenSpaceRadius: false });
    this.composer.addPass(this.gtao);

    this.bokeh = new BokehPass(scene, camera, { focus: 6, aperture: 0.00006, maxblur: 0.004 });
    this.composer.addPass(this.bokeh);

    this.bloom = new UnrealBloomPass(new THREE.Vector2(size.x, size.y), 0.35, 0.6, 0.85);
    this.composer.addPass(this.bloom);

    this.grade = new ShaderPass(GradeShader);
    this.composer.addPass(this.grade);

    this.output = new OutputPass();
    this.composer.addPass(this.output);

    this.smaa = new SMAAPass(size.x * pr, size.y * pr);
    this.composer.addPass(this.smaa);

    this.setQuality(quality);
  }

  setQuality(q: QualityLevel): void {
    const c = POSTFX_BY_QUALITY[q];
    if (this.gtao) this.gtao.enabled = c.gtao;
    if (this.bokeh) this.bokeh.enabled = c.dof;
    this.bloom.enabled = c.bloom;
    this.grade.enabled = c.grade;
    this.smaa.enabled = c.smaa;
  }

  setSize(w: number, h: number): void {
    this.composer.setSize(w, h);
    this.gtao?.setSize(w, h);
    const pr = this.renderer.getPixelRatio();
    this.smaa.setSize(w * pr, h * pr);
  }

  /** تغيّر ما بعد المعالجة مع حالة اللاعب والبيئة */
  setState(s: Partial<PostFXSettings>, elapsed: number, focusDistance?: number): void {
    const u = this.grade.uniforms as Record<string, { value: unknown }>;
    u.uTime.value = elapsed % 100;
    if (s.desaturate !== undefined) u.uSaturation.value = 1.08 * (1 - s.desaturate * 0.85);
    if (s.vignette !== undefined) u.uVignette.value = 0.32 + s.vignette * 0.5;
    if (s.warmTint !== undefined) u.uWarm.value = s.warmTint;
    if (s.coolTint !== undefined) u.uCool.value = s.coolTint;
    if (focusDistance !== undefined && this.bokeh) (this.bokeh.uniforms as Record<string, { value: number }>).focus.value = focusDistance;
  }

  render(dt: number): void {
    this.composer.render(dt);
  }

  dispose(): void {
    this.composer.dispose();
    this.gtao?.dispose();
    this.bloom.dispose();
  }
}
