import * as THREE from 'three';
import type { GameSession } from '../core/GameSession';
import { SLOTS_PER_PLOT } from '../survival/Farming';

const OFFSETS: Array<[number, number]> = [[-0.55, -0.55], [0.55, -0.55], [-0.55, 0.55], [0.55, 0.55]];
const HEIGHT = [0.12, 0.3, 0.55, 0.8];
const COLORS = [0x7fbf4f, 0x5fae3a, 0x3f9a30, 0xc8a53a];

/** يعرض محاصيل كل قطعة مزرعة بحسب مرحلة النمو (0–3؛ الأخيرة ناضجة) */
export class CropViews {
  readonly group = new THREE.Group();
  private meshes = new Map<string, { mesh: THREE.Mesh; stage: number }>();
  private geo = new THREE.ConeGeometry(0.18, 1, 6);
  private mats = COLORS.map((c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.9 }));

  sync(session: GameSession): void {
    const live = new Set<string>();
    for (const [pid, plot] of session.farms) {
      const piece = session.buildings.get(pid);
      if (!piece) continue;
      const cos = Math.cos(piece.yaw);
      const sin = Math.sin(piece.yaw);
      for (let i = 0; i < SLOTS_PER_PLOT; i++) {
        const st = plot.stage(i);
        if (st === null) continue;
        const key = `${pid}:${i}`;
        live.add(key);
        let v = this.meshes.get(key);
        if (!v) {
          const mesh = new THREE.Mesh(this.geo, this.mats[st]);
          const [ox, oz] = OFFSETS[i];
          mesh.position.set(piece.x + ox * cos + oz * sin, piece.y, piece.z - ox * sin + oz * cos);
          this.group.add(mesh);
          v = { mesh, stage: -1 };
          this.meshes.set(key, v);
        }
        if (v.stage !== st) {
          v.stage = st;
          v.mesh.material = this.mats[st];
          v.mesh.scale.set(1, HEIGHT[st], 1);
          v.mesh.position.y = piece.y + HEIGHT[st] / 2;
        }
      }
    }
    for (const [k, v] of this.meshes) {
      if (!live.has(k)) {
        this.group.remove(v.mesh);
        this.meshes.delete(k);
      }
    }
  }
}
