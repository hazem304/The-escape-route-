import * as THREE from 'three';
import { pickClip, type ClipState } from './ClipPicker';

/** يشغّل أنيميشن GLB المضمّن مع مزج بين الحالات */
export class ClipPlayer {
  private mixer: THREE.AnimationMixer;
  private actions: THREE.AnimationAction[];
  private names: string[];
  private current = -1;
  private state: ClipState | null = null;

  constructor(root: THREE.Object3D, clips: readonly THREE.AnimationClip[]) {
    this.mixer = new THREE.AnimationMixer(root);
    this.names = clips.map((c) => c.name);
    this.actions = clips.map((c) => this.mixer.clipAction(c));
  }

  get hasClips(): boolean {
    return this.actions.length > 0;
  }

  set(state: ClipState, speed = 1): void {
    if (state !== this.state) {
      this.state = state;
      const i = pickClip(this.names, state);
      if (i !== this.current) {
        const next = i >= 0 ? this.actions[i] : null;
        const prev = this.current >= 0 ? this.actions[this.current] : null;
        if (next) {
          next.reset();
          next.setLoop(state === 'dead' ? THREE.LoopOnce : THREE.LoopRepeat, Infinity);
          next.clampWhenFinished = state === 'dead';
          next.play();
          if (prev) prev.crossFadeTo(next, 0.25, false);
        }
        this.current = i;
      }
    }
    const a = this.current >= 0 ? this.actions[this.current] : null;
    if (a && state !== 'idle' && state !== 'dead') a.timeScale = THREE.MathUtils.clamp(speed / 2, 0.6, 1.8);
  }

  update(dt: number): void {
    this.mixer.update(dt);
  }
}
