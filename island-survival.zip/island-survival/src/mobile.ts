/** تهيئة الهاتف: لوحة أخطاء على الشاشة (بلا كونسول)، ملء الشاشة، تثبيت الاتجاه، PWA */

let panel: HTMLDivElement | null = null;
const log: string[] = [];

function show(msg: string): void {
  log.push(msg);
  if (log.length > 20) log.shift();
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'errPanel';
    panel.style.cssText =
      'position:fixed;left:8px;right:8px;bottom:8px;max-height:45%;overflow:auto;z-index:99999;background:rgba(120,10,10,.94);color:#fff;font:12px/1.4 monospace;direction:ltr;text-align:left;padding:8px 10px;border-radius:10px;white-space:pre-wrap;word-break:break-word';
    const bar = document.createElement('div');
    bar.style.cssText = 'display:flex;gap:8px;margin-bottom:6px;direction:rtl;font:14px system-ui';
    const copy = document.createElement('button');
    copy.textContent = 'نسخ التقرير';
    const close = document.createElement('button');
    close.textContent = 'إغلاق';
    for (const b of [copy, close]) b.style.cssText = 'padding:6px 12px;border-radius:8px;border:0;background:#fff;color:#400';
    copy.onclick = () => void navigator.clipboard?.writeText(report()).catch(() => undefined);
    close.onclick = () => {
      panel?.remove();
      panel = null;
    };
    bar.append(copy, close);
    const body = document.createElement('div');
    body.id = 'errBody';
    panel.append(bar, body);
    document.body.appendChild(panel);
  }
  const body = panel.querySelector('#errBody');
  if (body) body.textContent = log.join('\n\n');
}

export function report(): string {
  return `UA: ${navigator.userAgent}\nscreen: ${window.innerWidth}x${window.innerHeight} dpr=${window.devicePixelRatio}\n\n${log.join('\n\n')}`;
}

export function installErrorPanel(): void {
  window.addEventListener('error', (e) => show(`${e.message}\n${e.filename ?? ''}:${e.lineno ?? ''}\n${(e.error as Error | undefined)?.stack ?? ''}`));
  window.addEventListener('unhandledrejection', (e) => {
    const r = e.reason as Error | string | undefined;
    show(`Promise: ${typeof r === 'string' ? r : `${r?.message ?? ''}\n${r?.stack ?? ''}`}`);
  });
  const orig = console.error;
  console.error = (...a: unknown[]) => {
    show(a.map((x) => (x instanceof Error ? `${x.message}\n${x.stack ?? ''}` : String(x))).join(' '));
    orig.apply(console, a);
  };
}

/** يُستدعى من نقرة المستخدم: ملء الشاشة + قفل أفقي (يتجاهل الفشل بصمت، مثل iOS) */
export async function enterImmersive(): Promise<void> {
  try {
    const el = document.documentElement as HTMLElement & { webkitRequestFullscreen?: () => Promise<void> };
    if (!document.fullscreenElement) await (el.requestFullscreen?.() ?? el.webkitRequestFullscreen?.());
  } catch {
    /* غير مدعوم */
  }
  try {
    const o = screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> };
    await o.lock?.('landscape');
  } catch {
    /* غير مدعوم */
  }
}

export function registerServiceWorker(): void {
  if ('serviceWorker' in navigator && location.protocol !== 'file:' && !location.hash.includes('dev')) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js').catch(() => undefined);
    });
  }
}

/** يمنع تكبير اللمس المزدوج والقائمة المنبثقة وسحب التحديث */
export function lockGestures(): void {
  document.addEventListener('contextmenu', (e) => e.preventDefault());
  document.addEventListener('gesturestart', (e) => e.preventDefault());
  let last = 0;
  document.addEventListener(
    'touchend',
    (e) => {
      const n = Date.now();
      if (n - last < 300 && (e.target as HTMLElement)?.tagName !== 'INPUT') e.preventDefault();
      last = n;
    },
    { passive: false },
  );
}
