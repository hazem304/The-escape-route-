/** أنواع أهداف المهام وكيفية تقدّمها من أحداث اللعبة */
export type Objective =
  | { type: 'collect'; item: string; count: number; textAr: string; textEn: string }
  | { type: 'craft'; item: string; count: number; textAr: string; textEn: string }
  | { type: 'kill'; species: string; count: number; textAr: string; textEn: string }
  | { type: 'reach'; place: string; textAr: string; textEn: string }
  | { type: 'talk'; npc: string; textAr: string; textEn: string }
  | { type: 'flag'; flag: string; textAr: string; textEn: string }
  | { type: 'build'; piece: string; count: number; textAr: string; textEn: string }
  | { type: 'survive'; days: number; textAr: string; textEn: string };

/** أحداث تُغذّي المهام */
export type QuestEvent =
  | { type: 'itemGained'; item: string; count: number }
  | { type: 'crafted'; item: string; count: number }
  | { type: 'killed'; species: string }
  | { type: 'arrived'; place: string }
  | { type: 'talked'; npc: string }
  | { type: 'flag'; flag: string }
  | { type: 'built'; piece: string }
  | { type: 'dayPassed'; day: number };

export function objectiveTarget(o: Objective): number {
  switch (o.type) {
    case 'collect': case 'craft': case 'kill': case 'build': return o.count;
    case 'survive': return o.days;
    default: return 1;
  }
}

/** كم يضيف الحدث لهذا الهدف (0 = لا علاقة) */
export function progressFrom(o: Objective, e: QuestEvent): number {
  switch (o.type) {
    case 'collect': return e.type === 'itemGained' && e.item === o.item ? e.count : 0;
    case 'craft': return e.type === 'crafted' && e.item === o.item ? e.count : 0;
    case 'kill': return e.type === 'killed' && e.species === o.species ? 1 : 0;
    case 'reach': return e.type === 'arrived' && e.place === o.place ? 1 : 0;
    case 'talk': return e.type === 'talked' && e.npc === o.npc ? 1 : 0;
    case 'flag': return e.type === 'flag' && e.flag === o.flag ? 1 : 0;
    case 'build': return e.type === 'built' && e.piece === o.piece ? 1 : 0;
    case 'survive': return 0; // يُحدَّث بالأيام مباشرة
  }
}
