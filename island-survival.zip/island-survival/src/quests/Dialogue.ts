/** محرك حوار متفرع: عقد بنصوص ثنائية اللغة، شروط، وتأثيرات على الثقة والحالة */
export interface DialogueChoice {
  textAr: string;
  textEn: string;
  next: string | null; // null = إنهاء
  /** تغيير الثقة */
  trust?: number;
  /** شرط ظهور الخيار */
  requires?: DialogueCondition;
  /** رايات تُضبط عند الاختيار */
  setFlags?: string[];
  /** اسم فعل تنفّذه اللعبة (give_item:radio_battery، start_quest:xyz ...) */
  action?: string;
}

export interface DialogueCondition {
  minTrust?: number;
  maxTrust?: number;
  hasFlags?: string[];
  notFlags?: string[];
  hasItems?: Array<{ id: string; count: number }>;
}

export interface DialogueNode {
  id: string;
  textAr: string;
  textEn: string;
  choices: DialogueChoice[];
  /** عقدة بديلة تُعرض بدلًا منها إن تحقق شرطها (للحوارات المتكررة) */
  variants?: Array<{ when: DialogueCondition; node: string }>;
}

export interface DialogueGraph {
  start: string;
  nodes: Record<string, DialogueNode>;
}

export interface DialogueContext {
  trust: number;
  flags: ReadonlySet<string>;
  itemCount(id: string): number;
}

export function checkCondition(c: DialogueCondition | undefined, ctx: DialogueContext): boolean {
  if (!c) return true;
  if (c.minTrust !== undefined && ctx.trust < c.minTrust) return false;
  if (c.maxTrust !== undefined && ctx.trust > c.maxTrust) return false;
  if (c.hasFlags && !c.hasFlags.every((f) => ctx.flags.has(f))) return false;
  if (c.notFlags && c.notFlags.some((f) => ctx.flags.has(f))) return false;
  if (c.hasItems && !c.hasItems.every((i) => ctx.itemCount(i.id) >= i.count)) return false;
  return true;
}

export interface DialogueEffects {
  trustDelta: number;
  flags: string[];
  actions: string[];
}

/** يشغّل الحوار خطوة بخطوة؛ الواجهة تعرض current() وتستدعي choose(i) */
export class DialogueRunner {
  private nodeId: string | null;
  readonly log: DialogueEffects = { trustDelta: 0, flags: [], actions: [] };

  constructor(private graph: DialogueGraph, private ctx: DialogueContext) {
    this.nodeId = this.resolve(graph.start);
  }

  private resolve(id: string): string {
    const node = this.graph.nodes[id];
    if (!node) throw new Error(`Dialogue: عقدة مفقودة "${id}"`);
    for (const v of node.variants ?? []) if (checkCondition(v.when, this.ctx)) return this.resolve(v.node);
    return id;
  }

  get finished(): boolean {
    return this.nodeId === null;
  }

  current(): { node: DialogueNode; choices: Array<{ index: number; choice: DialogueChoice }> } | null {
    if (!this.nodeId) return null;
    const node = this.graph.nodes[this.nodeId];
    const choices = node.choices.map((choice, index) => ({ index, choice })).filter(({ choice }) => checkCondition(choice.requires, this.currentCtx()));
    return { node, choices };
  }

  /** السياق يتضمن تأثير الاختيارات السابقة داخل نفس الحوار */
  private currentCtx(): DialogueContext {
    const flags = new Set([...this.ctx.flags, ...this.log.flags]);
    return { trust: this.ctx.trust + this.log.trustDelta, flags, itemCount: (id) => this.ctx.itemCount(id) };
  }

  /** @param index الفهرس الأصلي للخيار في العقدة (كما في current().choices[i].index) */
  choose(index: number): boolean {
    const cur = this.current();
    if (!cur) return false;
    const entry = cur.choices.find((c) => c.index === index);
    if (!entry) return false;
    const c = entry.choice;
    this.log.trustDelta += c.trust ?? 0;
    if (c.setFlags) this.log.flags.push(...c.setFlags);
    if (c.action) this.log.actions.push(c.action);
    this.nodeId = c.next === null ? null : this.resolve(c.next);
    return true;
  }
}
