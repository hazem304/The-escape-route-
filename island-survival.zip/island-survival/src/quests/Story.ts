import type { Objective } from './Objectives';

export interface QuestReward {
  items?: Array<{ id: string; count: number }>;
  xp?: Array<{ skill: 'survival' | 'hunting' | 'crafting' | 'building'; amount: number }>;
  flags?: string[];
  /** وصفات تُفتح */
  recipes?: string[];
}

export interface QuestDef {
  id: string;
  titleAr: string;
  titleEn: string;
  descAr: string;
  descEn: string;
  /** مهام يجب إنجازها قبل التفعيل */
  requires?: string[];
  /** تُفعَّل تلقائيًا عند توفر الشروط، وإلا تحتاج quest:ID من حوار */
  auto?: boolean;
  /** الأهداف تُنجز بالترتيب (الأول قبل الثاني) */
  objectives: Objective[];
  reward?: QuestReward;
  /** رايات تُضبط عند اكتمال المهمة */
  onComplete?: string[];
  main?: boolean;
}

/** مهام القصة الرئيسية والجانبية */
export const QUESTS: QuestDef[] = [
  {
    id: 'wake_up', main: true, auto: true,
    titleAr: 'الاستيقاظ على الشاطئ', titleEn: 'Wake on the Shore',
    descAr: 'نجوتَ من التحطم. اجمع ما تحتاجه لتبقى حيًا الليلة الأولى.',
    descEn: 'You survived the crash. Gather what you need to last the first night.',
    objectives: [
      { type: 'collect', item: 'stick', count: 6, textAr: 'اجمع 6 عصي', textEn: 'Collect 6 sticks' },
      { type: 'collect', item: 'plant_fiber', count: 4, textAr: 'اجمع 4 ألياف نباتية', textEn: 'Collect 4 plant fibers' },
      { type: 'collect', item: 'stone', count: 3, textAr: 'اجمع 3 حجارة', textEn: 'Collect 3 stones' },
    ],
    reward: { xp: [{ skill: 'survival', amount: 10 }], items: [{ id: 'bandage', count: 2 }] },
  },
  {
    id: 'first_tools', main: true, requires: ['wake_up'], auto: true,
    titleAr: 'أدوات الإنسان الأول', titleEn: 'First Tools',
    descAr: 'اصنع أول أدواتك: سكين ثم فأس.',
    descEn: 'Craft your first tools: a knife, then an axe.',
    objectives: [
      { type: 'craft', item: 'knife_stone', count: 1, textAr: 'اصنع سكينًا حجريًا', textEn: 'Craft a stone knife' },
      { type: 'craft', item: 'axe_stone', count: 1, textAr: 'اصنع فأسًا حجريًا', textEn: 'Craft a stone axe' },
    ],
    reward: { xp: [{ skill: 'crafting', amount: 20 }] },
  },
  {
    id: 'fire_and_water', main: true, requires: ['first_tools'], auto: true,
    titleAr: 'نار وماء', titleEn: 'Fire and Water',
    descAr: 'أوقد نارًا وغلِ الماء قبل أن تشربه.',
    descEn: 'Light a fire and boil water before drinking.',
    objectives: [
      { type: 'craft', item: 'campfire_kit', count: 1, textAr: 'اصنع عدة موقد', textEn: 'Craft a campfire kit' },
      { type: 'build', piece: 'campfire', count: 1, textAr: 'ضع الموقد', textEn: 'Place the campfire' },
      { type: 'craft', item: 'water_boiled', count: 1, textAr: 'اغلِ ماءً', textEn: 'Boil some water' },
    ],
    reward: { xp: [{ skill: 'survival', amount: 25 }], items: [{ id: 'bottle_empty', count: 2 }] },
  },
  {
    id: 'find_survivors', main: true, requires: ['fire_and_water'], auto: true,
    titleAr: 'لستَ وحدك', titleEn: 'Not Alone',
    descAr: 'دخان بعيد يوحي بوجود ناجين. ابحث عنهم.',
    descEn: 'Distant smoke suggests survivors. Find them.',
    objectives: [
      { type: 'talk', npc: 'layla', textAr: 'تحدّث إلى ليلى', textEn: 'Talk to Layla' },
      { type: 'talk', npc: 'omar', textAr: 'تحدّث إلى عمر', textEn: 'Talk to Omar' },
      { type: 'talk', npc: 'yusuf', textAr: 'تحدّث إلى يوسف', textEn: 'Talk to Yusuf' },
    ],
    reward: { xp: [{ skill: 'survival', amount: 20 }], items: [{ id: 'compass', count: 1 }] },
    onComplete: ['met_all_survivors'],
  },
  {
    id: 'repair_radio', main: true, requires: ['find_survivors'],
    titleAr: 'إصلاح الراديو', titleEn: 'Repair the Radio',
    descAr: 'عمر يحتاج خردة معدن وسبيكة نحاس وبطارية من يوسف.',
    descEn: 'Omar needs scrap metal, a copper ingot and a battery from Yusuf.',
    objectives: [
      { type: 'collect', item: 'scrap_metal', count: 3, textAr: 'اجمع 3 خردة معدن', textEn: 'Collect 3 scrap metal' },
      { type: 'collect', item: 'copper_ingot', count: 1, textAr: 'اصهر سبيكة نحاس', textEn: 'Smelt a copper ingot' },
      { type: 'collect', item: 'radio_battery', count: 1, textAr: 'احصل على البطارية من يوسف', textEn: "Get the battery from Yusuf" },
      { type: 'flag', flag: 'radio_done', textAr: 'سلّم القطع لعمر', textEn: 'Deliver the parts to Omar' },
    ],
    reward: { xp: [{ skill: 'crafting', amount: 40 }] },
    onComplete: ['distress_sent'],
  },
  {
    id: 'signal_fire', main: true, requires: ['repair_radio'], auto: true,
    titleAr: 'إشارة الإنقاذ', titleEn: 'Rescue Signal',
    descAr: 'النداء أُرسل. ابنِ نارًا كبيرة على القمة وانتظر المروحية.',
    descEn: 'The call is out. Build a big fire on the peak and wait for the helicopter.',
    objectives: [
      { type: 'collect', item: 'firewood', count: 20, textAr: 'اجمع 20 حطبة', textEn: 'Collect 20 firewood' },
      { type: 'reach', place: 'peak', textAr: 'اصعد إلى القمة', textEn: 'Climb to the peak' },
      { type: 'flag', flag: 'signal_lit', textAr: 'أشعل نار الإشارة', textEn: 'Light the signal fire' },
      { type: 'survive', days: 2, textAr: 'ابقَ حيًا حتى وصول الإنقاذ (يومان)', textEn: 'Stay alive until rescue (2 days)' },
    ],
    onComplete: ['ending_rescue_ready'],
  },

  // ---- النهاية البديلة: الطوافة ----
  {
    id: 'build_raft', requires: ['first_tools'],
    titleAr: 'طوافة الأمل', titleEn: 'Raft of Hope',
    descAr: 'إن تأخر الإنقاذ فالبحر طريق آخر. اجمع الخشب والحبال وقماش الشراع.',
    descEn: 'If rescue is slow, the sea is another way. Gather wood, rope and sail cloth.',
    objectives: [
      { type: 'collect', item: 'wood_log', count: 8, textAr: 'اجمع 8 جذوع', textEn: 'Collect 8 logs' },
      { type: 'collect', item: 'bamboo', count: 10, textAr: 'اجمع 10 خيزرانات', textEn: 'Collect 10 bamboo' },
      { type: 'collect', item: 'sail_cloth', count: 1, textAr: 'احصل على قماش الشراع من الحطام', textEn: 'Find sail cloth in the wreck' },
      { type: 'craft', item: 'raft_kit', count: 1, textAr: 'اصنع عدة الطوافة', textEn: 'Craft the raft kit' },
      { type: 'build', piece: 'raft', count: 1, textAr: 'أنزل الطوافة إلى الماء', textEn: 'Launch the raft' },
      { type: 'reach', place: 'open_sea', textAr: 'أبحر نحو الأفق', textEn: 'Sail towards the horizon' },
    ],
    onComplete: ['ending_raft_ready'],
  },

  // ---- سر الجزيرة ----
  {
    id: 'island_secret', requires: ['find_survivors'],
    titleAr: 'سر الجزيرة', titleEn: 'The Island Secret',
    descAr: 'يوسف يلمّح إلى مخبأ تحت البركان. اكتشف ما يخفيه.',
    descEn: 'Yusuf hints at a bunker under the volcano. Discover what it hides.',
    objectives: [
      { type: 'collect', item: 'bunker_key', count: 1, textAr: 'اكسب ثقة يوسف وخذ المفتاح', textEn: "Earn Yusuf's trust and take the key" },
      { type: 'reach', place: 'bunker', textAr: 'ادخل المخبأ تحت البركان', textEn: 'Enter the bunker under the volcano' },
      { type: 'collect', item: 'flight_recorder', count: 1, textAr: 'ابحث عن الصندوق الأسود', textEn: 'Find the flight recorder' },
      { type: 'collect', item: 'satellite_phone', count: 1, textAr: 'خذ الهاتف الفضائي', textEn: 'Take the satellite phone' },
    ],
    reward: { xp: [{ skill: 'survival', amount: 60 }] },
    onComplete: ['ending_secret_ready'],
  },

  // ---- جانبية ----
  {
    id: 'hunter', requires: ['first_tools'],
    titleAr: 'الصياد', titleEn: 'The Hunter',
    descAr: 'اللحم أساس البقاء. اصنع رمحًا وصِد.',
    descEn: 'Meat is survival. Craft a spear and hunt.',
    objectives: [
      { type: 'craft', item: 'spear_wood', count: 1, textAr: 'اصنع رمحًا', textEn: 'Craft a spear' },
      { type: 'kill', species: 'deer', count: 1, textAr: 'صِد غزالًا', textEn: 'Hunt a deer' },
      { type: 'craft', item: 'cooked_meat', count: 1, textAr: 'اشوِ اللحم', textEn: 'Grill the meat' },
    ],
    reward: { xp: [{ skill: 'hunting', amount: 30 }], items: [{ id: 'fishing_net', count: 1 }] },
  },
  {
    id: 'shelter', requires: ['first_tools'],
    titleAr: 'سقف فوق الرأس', titleEn: 'A Roof Overhead',
    descAr: 'ابنِ ملجأً يقيك المطر والبرد.',
    descEn: 'Build a shelter against rain and cold.',
    objectives: [
      { type: 'build', piece: 'foundation', count: 1, textAr: 'ابنِ أساسًا', textEn: 'Build a foundation' },
      { type: 'build', piece: 'wall', count: 2, textAr: 'ابنِ جدارين', textEn: 'Build two walls' },
      { type: 'build', piece: 'roof', count: 1, textAr: 'ضع سقفًا', textEn: 'Add a roof' },
      { type: 'build', piece: 'bed', count: 1, textAr: 'ضع فراشًا', textEn: 'Place a bed' },
    ],
    reward: { xp: [{ skill: 'building', amount: 40 }] },
  },
  {
    id: 'ironworks', requires: ['first_tools'],
    titleAr: 'عصر الحديد', titleEn: 'The Iron Age',
    descAr: 'ابحث عن الحديد في الكهف واصهره.',
    descEn: 'Find iron in the cave and smelt it.',
    objectives: [
      { type: 'reach', place: 'cave', textAr: 'ادخل الكهف', textEn: 'Enter the cave' },
      { type: 'collect', item: 'iron_ore', count: 4, textAr: 'اجمع 4 خام حديد', textEn: 'Collect 4 iron ore' },
      { type: 'craft', item: 'iron_ingot', count: 2, textAr: 'اصهر سبيكتي حديد', textEn: 'Smelt 2 iron ingots' },
      { type: 'craft', item: 'axe_iron', count: 1, textAr: 'اصنع فأسًا حديديًا', textEn: 'Craft an iron axe' },
    ],
    reward: { xp: [{ skill: 'crafting', amount: 50 }] },
  },
];

export const QUEST_BY_ID = new Map(QUESTS.map((q) => [q.id, q]));
