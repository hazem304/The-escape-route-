import { objectiveTarget, progressFrom, type QuestEvent } from './Objectives';
import { QUESTS, QUEST_BY_ID, type QuestDef, type QuestReward } from './Story';

export type QuestStatus = 'locked' | 'available' | 'active' | 'completed';

interface QuestState {
  status: QuestStatus;
  /** تقدّم كل هدف */
  progress: number[];
  /** فهرس الهدف الحالي (الأهداف متسلسلة) */
  current: number;
}

export interface QuestHooks {
  /** عدد العنصر الحالي في الحقيبة (لأهداف collect التي تتحقق بالحيازة) */
  itemCount(id: string): number;
  /** يمنح مكافأة */
  giveReward(r: QuestReward): void;
}

/**
 * مدير المهام: أهداف متسلسلة، تفعيل تلقائي عند توفر الشروط، رايات عالمية،
 * وحفظ/تحميل. أهداف collect تتحقق بحيازة العناصر (لا بالتقاطها فقط) فلا تضيع بالرمي.
 */
export class QuestManager {
  private states = new Map<string, QuestState>();
  readonly flags = new Set<string>();
  day = 0;
  onUpdate: ((questId: string, kind: 'started' | 'progress' | 'completed') => void) | null = null;

  constructor(private hooks: QuestHooks) {
    for (const q of QUESTS) this.states.set(q.id, { status: 'locked', progress: q.objectives.map(() => 0), current: 0 });
    this.refreshAvailability();
  }

  status(id: string): QuestStatus {
    return this.states.get(id)?.status ?? 'locked';
  }

  get active(): QuestDef[] {
    return QUESTS.filter((q) => this.status(q.id) === 'active');
  }

  get available(): QuestDef[] {
    return QUESTS.filter((q) => this.status(q.id) === 'available');
  }

  get completed(): QuestDef[] {
    return QUESTS.filter((q) => this.status(q.id) === 'completed');
  }

  /** المهمة الرئيسية الحالية (للتتبع على الشاشة) */
  get tracked(): QuestDef | null {
    const act = this.active;
    return act.find((q) => q.main) ?? act[0] ?? null;
  }

  progressOf(id: string): { objectives: Array<{ done: boolean; value: number; target: number; current: boolean }> } {
    const q = QUEST_BY_ID.get(id)!;
    const s = this.states.get(id)!;
    return {
      objectives: q.objectives.map((o, i) => ({
        done: s.status === 'completed' || i < s.current,
        value: Math.min(s.progress[i], objectiveTarget(o)),
        target: objectiveTarget(o),
        current: s.status === 'active' && i === s.current,
      })),
    };
  }

  private requirementsMet(q: QuestDef): boolean {
    return (q.requires ?? []).every((r) => this.status(r) === 'completed');
  }

  /** يحدّث locked→available وتفعيل auto */
  private refreshAvailability(): void {
    let changed = true;
    while (changed) {
      changed = false;
      for (const q of QUESTS) {
        const s = this.states.get(q.id)!;
        if (s.status === 'locked' && this.requirementsMet(q)) {
          s.status = 'available';
          changed = true;
        }
        if (s.status === 'available' && q.auto) {
          this.start(q.id);
          changed = true;
        }
      }
    }
  }

  start(id: string): boolean {
    const q = QUEST_BY_ID.get(id);
    const s = this.states.get(id);
    if (!q || !s || (s.status !== 'available' && s.status !== 'locked') || !this.requirementsMet(q)) return false;
    s.status = 'active';
    s.current = 0;
    s.progress = q.objectives.map(() => 0);
    this.onUpdate?.(id, 'started');
    this.syncCurrent(q, s); // قد تكون الحيازة مكتملة أصلًا
    return true;
  }

  /** يغذّي حدثًا لكل المهام النشطة */
  notify(e: QuestEvent): void {
    if (e.type === 'flag') this.flags.add(e.flag);
    if (e.type === 'dayPassed') this.day = e.day;

    for (const q of [...this.active]) {
      const s = this.states.get(q.id)!;
      const o = q.objectives[s.current];
      if (!o) continue;

      if (o.type === 'survive') {
        if (e.type === 'dayPassed') s.progress[s.current] = Math.min(o.days, s.progress[s.current] + 1);
      } else if (o.type === 'flag') {
        if (this.flags.has(o.flag)) s.progress[s.current] = 1;
      } else if (o.type === 'collect') {
        // الحيازة الفعلية هي المرجع
        s.progress[s.current] = Math.min(o.count, this.hooks.itemCount(o.item));
      } else {
        s.progress[s.current] += progressFrom(o, e);
      }
      this.syncCurrent(q, s);
    }
    this.refreshAvailability();
  }

  /** يُستدعى حين تتغير الحقيبة: يحدّث أهداف الحيازة (مثلًا بعد استلام عنصر من حوار) */
  onInventoryChanged(): void {
    this.notify({ type: 'itemGained', item: '', count: 0 });
  }

  /** ينقل التقدم إلى الهدف التالي إن اكتمل الحالي؛ يكمل المهمة عند الانتهاء */
  private syncCurrent(q: QuestDef, s: QuestState): void {
    let advanced = false;
    while (s.current < q.objectives.length) {
      const o = q.objectives[s.current];
      // ضبط تقدم أهداف الحيازة فور الدخول فيها
      if (o.type === 'collect') s.progress[s.current] = Math.min(o.count, this.hooks.itemCount(o.item));
      if (o.type === 'flag' && this.flags.has(o.flag)) s.progress[s.current] = 1;
      if (s.progress[s.current] >= objectiveTarget(o)) {
        s.current++;
        advanced = true;
      } else break;
    }
    if (s.current >= q.objectives.length) {
      this.complete(q, s);
    } else if (advanced) {
      this.onUpdate?.(q.id, 'progress');
    } else {
      this.onUpdate?.(q.id, 'progress');
    }
  }

  private complete(q: QuestDef, s: QuestState): void {
    if (s.status === 'completed') return;
    s.status = 'completed';
    for (const f of q.onComplete ?? []) this.flags.add(f);
    if (q.reward) {
      for (const f of q.reward.flags ?? []) this.flags.add(f);
      this.hooks.giveReward(q.reward);
    }
    this.onUpdate?.(q.id, 'completed');
  }

  /** هل النهاية جاهزة؟ */
  endingsReady(): { rescue: boolean; raft: boolean; secret: boolean } {
    return {
      rescue: this.flags.has('ending_rescue_ready'),
      raft: this.flags.has('ending_raft_ready'),
      secret: this.flags.has('ending_secret_ready'),
    };
  }

  toJSON(): { states: Array<[string, QuestState]>; flags: string[]; day: number } {
    return { states: [...this.states], flags: [...this.flags], day: this.day };
  }

  load(d: { states: Array<[string, QuestState]>; flags: string[]; day: number }): void {
    for (const [id, st] of d.states) if (this.states.has(id)) this.states.set(id, st);
    this.flags.clear();
    d.flags.forEach((f) => this.flags.add(f));
    this.day = d.day;
  }
}
