export type EndingId = 'rescue' | 'raft' | 'secret' | 'death';

export interface EndingDef {
  id: EndingId;
  titleAr: string;
  titleEn: string;
  textAr: string;
  textEn: string;
}

export const ENDINGS: Record<EndingId, EndingDef> = {
  rescue: {
    id: 'rescue', titleAr: 'الإنقاذ', titleEn: 'Rescue',
    textAr: 'تحوّل الدخان إلى إشارة رأتها المروحية. حملوك مع الناجين وأنت ترى الجزيرة تصغر في الأفق. لقد عدتَ إلى الحياة.',
    textEn: 'The smoke became a beacon the helicopter could see. They lifted you and the survivors as the island shrank on the horizon. You came back to life.',
  },
  raft: {
    id: 'raft', titleAr: 'عبور البحر', titleEn: 'Across the Sea',
    textAr: 'أيام من الملح والشمس، ثم ظهرت سفينة شحن. الطوافة التي صنعتها بيدك حملتك إلى حيث لم تتخيل أن تصل.',
    textEn: 'Days of salt and sun, then a cargo ship appeared. The raft you built with your own hands carried you further than you imagined.',
  },
  secret: {
    id: 'secret', titleAr: 'سر الجزيرة', titleEn: 'The Island Secret',
    textAr: 'من الصندوق الأسود عرفت أن الطائرة لم تسقط بالصدفة، وبالهاتف الفضائي أرسلت الحقيقة إلى العالم. ما كان مخفيًا لم يعد كذلك.',
    textEn: "From the flight recorder you learned the crash was no accident, and with the satellite phone you sent the truth to the world. What was hidden no longer is.",
  },
  death: {
    id: 'death', titleAr: 'النهاية', titleEn: 'The End',
    textAr: 'لم تنجُ هذه المرة. الجزيرة تحتفظ بأسرارها.',
    textEn: 'You did not survive this time. The island keeps its secrets.',
  },
};

export interface EndingContext {
  /** الرايات العالمية */
  flags: ReadonlySet<string>;
  /** مكان اللاعب الآن (اسم مكان مسمّى) */
  place: string | null;
  /** هل يملك العنصر */
  has(item: string): boolean;
  /** اللاعب حي؟ */
  alive: boolean;
  /** اليوم الحالي */
  day: number;
  /** اليوم الذي أُشعلت فيه إشارة الإنقاذ (أو null) */
  signalDay: number | null;
}

/** أيام الانتظار بعد إشعال الإشارة حتى تصل المروحية */
export const RESCUE_WAIT_DAYS = 2;

/** يقيّم الشروط ويعيد النهاية المستحقة الآن أو null. النهاية السرية لها الأولوية لأنها الأصعب. */
export function evaluateEnding(c: EndingContext): EndingId | null {
  if (!c.alive) return 'death';
  if (c.flags.has('ending_secret_ready') && c.has('flight_recorder') && c.has('satellite_phone') && c.flags.has('secret_sent')) return 'secret';
  if (c.flags.has('ending_raft_ready') && c.place === 'open_sea') return 'raft';
  if (c.flags.has('ending_rescue_ready') && c.flags.has('signal_lit') && c.signalDay !== null && c.day - c.signalDay >= RESCUE_WAIT_DAYS) return 'rescue';
  return null;
}
