import type { QuestManager } from './QuestManager';
import type { NPC } from '../entities/NPC';
import { QUESTS } from './Story';

export interface JournalEntry {
  id: string;
  /** يوم اللعبة */
  day: number;
  textAr: string;
  textEn: string;
}

/** مفكرة اللاعب: سجل تلقائي لأحداث القصة + صفحات مذكرات يجدها + ملاحظات */
export class Journal {
  readonly entries: JournalEntry[] = [];
  readonly pages = new Set<string>();

  add(id: string, day: number, textAr: string, textEn: string): void {
    // لا تكرار لنفس المعرّف
    if (this.entries.some((e) => e.id === id)) return;
    this.entries.push({ id, day, textAr, textEn });
  }

  /** يربط المهام بالمفكرة: تُسجَّل بداية وإنجاز كل مهمة رئيسية */
  attach(quests: QuestManager, getDay: () => number): void {
    const prev = quests.onUpdate;
    quests.onUpdate = (id, kind) => {
      prev?.(id, kind);
      const q = QUESTS.find((x) => x.id === id);
      if (!q) return;
      if (kind === 'started') this.add(`${id}:start`, getDay(), `بدأت مهمة: ${q.titleAr}. ${q.descAr}`, `Started: ${q.titleEn}. ${q.descEn}`);
      if (kind === 'completed') this.add(`${id}:done`, getDay(), `أنجزت: ${q.titleAr}.`, `Completed: ${q.titleEn}.`);
    };
  }

  /** صفحة مذكرات (عنصر قصة): نصوص ثابتة تُكتشف */
  collectPage(pageId: string, day: number): boolean {
    if (this.pages.has(pageId)) return false;
    const p = JOURNAL_PAGES[pageId];
    if (!p) return false;
    this.pages.add(pageId);
    this.add(`page:${pageId}`, day, p.ar, p.en);
    return true;
  }

  noteNPC(npc: NPC, day: number): void {
    this.add(`npc:${npc.def.id}`, day, `التقيت ${npc.def.nameAr}. ${npc.def.bioAr}`, `Met ${npc.def.nameEn}. ${npc.def.bioEn}`);
  }

  toJSON(): { entries: JournalEntry[]; pages: string[] } {
    return { entries: this.entries, pages: [...this.pages] };
  }

  load(d: { entries: JournalEntry[]; pages: string[] }): void {
    this.entries.length = 0;
    this.entries.push(...d.entries);
    this.pages.clear();
    d.pages.forEach((p) => this.pages.add(p));
  }
}

/** صفحات مذكرات الطيار المبعثرة في الحطام والمخبأ: تكشف القصة تدريجيًا */
export const JOURNAL_PAGES: Record<string, { ar: string; en: string }> = {
  pilot_1: {
    ar: 'مذكرات الطيار — الصفحة 1: مسارنا تغيّر قبل ساعة من الإقلاع بأمر لم أفهمه. قيل إنه "حمولة إضافية" من جهة لا أعرفها.',
    en: "Pilot's journal — page 1: Our route changed an hour before takeoff on an order I didn't understand. They called it an 'extra cargo' from a party I don't know.",
  },
  pilot_2: {
    ar: 'الصفحة 2: المحرك الأيسر توقف بلا إنذار. الأجهزة تُظهر قراءات غير ممكنة. أظن أن أحدًا عبث بها.',
    en: 'Page 2: The left engine died without warning. The instruments show impossible readings. I think someone tampered with them.',
  },
  pilot_3: {
    ar: 'الصفحة 3: إن وجد أحدٌ هذا، فالجزيرة المقابلة ليست مهجورة. رأيت أضواء تحت البركان. هناك قبو.',
    en: "Page 3: If anyone finds this — the island ahead isn't abandoned. I saw lights under the volcano. There's a bunker.",
  },
  bunker_1: {
    ar: 'سجل القبو: مشروع الإرسال الصامت. كل إشارة من الجزيرة تُحجب. الهاتف الفضائي هو الوحيد الذي يتجاوز الحجب.',
    en: 'Bunker log: Silent Relay project. Every signal from the island is jammed. The satellite phone is the only one that bypasses it.',
  },
  bunker_2: {
    ar: 'ملاحظة أخيرة: الصندوق الأسود يحمل التسجيل الكامل. من يرسله يغيّر كل شيء.',
    en: 'Final note: the flight recorder holds the full recording. Whoever sends it changes everything.',
  },
};
