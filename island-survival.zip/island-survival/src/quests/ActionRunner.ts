import type { Inventory } from '../inventory/Inventory';
import { ItemDB } from '../inventory/ItemDatabase';
import type { QuestManager } from './QuestManager';

export interface ActionHooks {
  inv: Inventory;
  quests: QuestManager;
  /** رمي ما لا يتسع في الحقيبة على الأرض */
  dropOverflow(id: string, count: number): void;
  /** رسالة للاعب */
  notify(textAr: string, textEn: string): void;
}

export interface ActionResult {
  ok: boolean;
  reason?: string;
}

/**
 * ينفّذ إجراءات الحوار بصيغة نصية:
 *   give_item:ID[:N]   take_item:ID[:N]   flag:NAME   quest:ID
 * take_item يفشل بلا تغيير إن لم يتوفر العدد (لا يأخذ جزءًا).
 */
export function runAction(action: string, h: ActionHooks): ActionResult {
  const [cmd, a, b] = action.split(':');
  const n = b ? Math.max(1, parseInt(b, 10) || 1) : 1;

  switch (cmd) {
    case 'give_item': {
      if (!ItemDB.has(a)) return { ok: false, reason: 'unknownItem' };
      const left = h.inv.add(a, n);
      if (left > 0) h.dropOverflow(a, left);
      h.quests.onInventoryChanged();
      const d = ItemDB.get(a);
      h.notify(`حصلت على ${d.nameAr} ×${n}`, `Received ${d.nameEn} ×${n}`);
      return { ok: true };
    }
    case 'take_item': {
      if (!ItemDB.has(a)) return { ok: false, reason: 'unknownItem' };
      if (h.inv.count(a) < n) return { ok: false, reason: 'notEnough' };
      h.inv.remove(a, n);
      h.quests.onInventoryChanged();
      return { ok: true };
    }
    case 'flag':
      h.quests.notify({ type: 'flag', flag: a });
      return { ok: true };
    case 'quest':
      return h.quests.start(a) ? { ok: true } : { ok: false, reason: 'cannotStart' };
    default:
      return { ok: false, reason: 'unknownAction' };
  }
}

/** استخدام عناصر القصة: الهاتف الفضائي مع الصندوق الأسود يرسلان الحقيقة */
export function useStoryItem(itemId: string, h: ActionHooks, place: string | null): ActionResult {
  if (itemId === 'satellite_phone') {
    if (!h.inv.has('flight_recorder')) {
      h.notify('تحتاج إلى الصندوق الأسود لتُرسل شيئًا ذا قيمة.', 'You need the flight recorder to send anything meaningful.');
      return { ok: false, reason: 'needRecorder' };
    }
    if (place !== 'bunker' && place !== 'peak') {
      h.notify('لا توجد إشارة هنا. اصعد إلى القمة أو ادخل المخبأ.', 'No signal here. Climb to the peak or enter the bunker.');
      return { ok: false, reason: 'noSignal' };
    }
    h.quests.notify({ type: 'flag', flag: 'secret_sent' });
    h.notify('أُرسلت البيانات. العالم سيعرف.', 'Data sent. The world will know.');
    return { ok: true };
  }
  if (itemId === 'flare_gun' || itemId === 'flare') {
    if (place !== 'peak') return { ok: false, reason: 'notOnPeak' };
    return { ok: true };
  }
  return { ok: false, reason: 'notStoryItem' };
}
