/** بيانات الخريطة: معالم مسمّاة تُكتشف بالاقتراب، وتحويل الإحداثيات لشاشة الخريطة */
export interface Landmark {
  id: string;
  nameAr: string;
  nameEn: string;
  x: number;
  z: number;
  /** نصف قطر الاكتشاف (م) */
  radius: number;
  icon: string;
  /** يُظهر الخريطة مبكرًا بلا اكتشاف (مثل نقطة الظهور) */
  known?: boolean;
}

export class MapData {
  private discovered = new Set<string>();
  /** خلايا الضباب المستكشفة (شبكة 32م) */
  private explored = new Set<string>();
  static readonly FOG_CELL = 32;
  /** بوصلة ضرورية لعرض الشمال؟ الخريطة نفسها تتطلب قطعة خريطة لتفتح كاملة */
  fullMapUnlocked = false;

  constructor(readonly landmarks: Landmark[]) {
    for (const l of landmarks) if (l.known) this.discovered.add(l.id);
  }

  /** يستدعى كل فترة بموضع اللاعب. @returns المعالم المكتشفة حديثًا */
  update(x: number, z: number, viewRadius = 40): Landmark[] {
    const found: Landmark[] = [];
    const cell = MapData.FOG_CELL;
    const r = Math.ceil(viewRadius / cell);
    const cx = Math.floor(x / cell);
    const cz = Math.floor(z / cell);
    for (let dz = -r; dz <= r; dz++) {
      for (let dx = -r; dx <= r; dx++) {
        if (dx * dx + dz * dz <= r * r) this.explored.add(`${cx + dx},${cz + dz}`);
      }
    }
    for (const l of this.landmarks) {
      if (this.discovered.has(l.id)) continue;
      if (Math.hypot(l.x - x, l.z - z) <= l.radius) {
        this.discovered.add(l.id);
        found.push(l);
      }
    }
    return found;
  }

  isDiscovered(id: string): boolean {
    return this.discovered.has(id);
  }

  isExplored(x: number, z: number): boolean {
    return this.fullMapUnlocked || this.explored.has(`${Math.floor(x / MapData.FOG_CELL)},${Math.floor(z / MapData.FOG_CELL)}`);
  }

  /** المعالم الظاهرة على الخريطة */
  visibleLandmarks(): Landmark[] {
    return this.landmarks.filter((l) => this.fullMapUnlocked || this.discovered.has(l.id));
  }

  /** اسم أقرب معلم ضمن نطاق (لتفعيل أماكن المهام مثل 'peak' و'cave') */
  placeAt(x: number, z: number): string | null {
    let best: Landmark | null = null;
    let bd = Infinity;
    for (const l of this.landmarks) {
      const d = Math.hypot(l.x - x, l.z - z);
      if (d <= l.radius && d < bd) {
        bd = d;
        best = l;
      }
    }
    return best?.id ?? null;
  }

  /** من إحداثيات العالم إلى بكسلات الخريطة (الشمال للأعلى: -z) */
  static worldToMap(x: number, z: number, worldHalf: number, size: number): { px: number; py: number } {
    return { px: ((x + worldHalf) / (worldHalf * 2)) * size, py: ((z + worldHalf) / (worldHalf * 2)) * size };
  }

  static mapToWorld(px: number, py: number, worldHalf: number, size: number): { x: number; z: number } {
    return { x: (px / size) * worldHalf * 2 - worldHalf, z: (py / size) * worldHalf * 2 - worldHalf };
  }

  toJSON(): { discovered: string[]; explored: string[]; full: boolean } {
    return { discovered: [...this.discovered], explored: [...this.explored], full: this.fullMapUnlocked };
  }

  load(d: { discovered: string[]; explored: string[]; full: boolean }): void {
    this.discovered = new Set(d.discovered);
    this.explored = new Set(d.explored);
    this.fullMapUnlocked = d.full;
  }
}
