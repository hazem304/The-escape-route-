import { clamp, smoothstep } from '../core/math';

export interface AmbienceInput {
  hour: number;
  weather: { rain: number; wind: number; storm: number };
  biome: string;
  inCave: boolean;
  underwater: boolean;
  /** المسافة لأقرب شاطئ (م): الأمواج تُسمع قرب الماء */
  shoreDist: number;
  health: number;
  /** حيوان مفترس قريب؟ يرفع التوتر الموسيقي */
  danger: boolean;
}

export interface AmbienceMix {
  wind: number;
  waves: number;
  rain: number;
  birds: number;
  crickets: number;
  jungle: number;
  cave: number;
  heartbeat: number;
  /** قطع الترددات العالية: 20000 = لا شيء، ~600 تحت الماء */
  lowpassHz: number;
  /** حدة الموسيقى 0..1 (0 هادئة، 1 متوترة) */
  tension: number;
  musicLevel: number;
}

const isDay = (h: number): number => smoothstep(5, 7, h) * (1 - smoothstep(18, 20, h));

/** دالة خالصة: حالة العالم → أحجام طبقات الصوت (0..1) */
export function mixAmbience(a: AmbienceInput): AmbienceMix {
  const day = isDay(a.hour);
  const night = clamp(1 - day, 0, 1);
  const inside = a.inCave ? 1 : 0;
  const open = 1 - inside;
  const veg = a.biome === 'jungle' ? 1 : a.biome === 'grass' ? 0.6 : 0;
  const rainy = clamp(a.weather.rain, 0, 1);

  const wind = clamp((0.15 + a.weather.wind * 0.7 + a.weather.storm * 0.3) * open * (a.biome === 'rock' || a.biome === 'volcanic' ? 1.3 : 1), 0, 1);
  const waves = clamp((1 - smoothstep(10, 120, a.shoreDist)) * open * (0.5 + a.weather.storm * 0.5), 0, 1);
  const rain = clamp(rainy * (a.inCave ? 0.15 : 1), 0, 1);
  const birds = clamp(day * (0.25 + veg * 0.75) * open * (1 - rainy * 0.9) * (1 - a.weather.storm), 0, 1);
  const crickets = clamp(night * (0.2 + veg * 0.5) * open * (1 - rainy), 0, 1);
  const jungle = clamp(veg * open * (0.4 + 0.3 * day), 0, 1);
  const cave = inside;
  const heartbeat = a.health < 35 ? clamp((35 - a.health) / 35, 0, 1) : 0;

  const tension = clamp(night * 0.35 + (a.danger ? 0.6 : 0) + a.weather.storm * 0.3 + heartbeat * 0.3 + inside * 0.2, 0, 1);
  const musicLevel = clamp(0.5 - rainy * 0.15 - (a.underwater ? 0.4 : 0), 0, 1);

  const under = a.underwater ? 1 : 0;
  return {
    wind: wind * (1 - under * 0.8),
    waves: a.underwater ? 0.5 : waves,
    rain: rain * (1 - under * 0.7),
    birds: birds * (1 - under),
    crickets: crickets * (1 - under),
    jungle: jungle * (1 - under),
    cave,
    heartbeat,
    lowpassHz: under ? 600 : 20000,
    tension,
    musicLevel,
  };
}

/** تنعيم أسّي لكل قيمة (يمنع الانقطاعات الحادة عند تغيّر الحالة) */
export function smoothMix(prev: AmbienceMix, target: AmbienceMix, dt: number, rate = 1.5): AmbienceMix {
  const k = 1 - Math.exp(-dt * rate);
  const out = { ...target };
  for (const key of Object.keys(target) as Array<keyof AmbienceMix>) {
    out[key] = prev[key] + (target[key] - prev[key]) * k;
  }
  return out;
}
