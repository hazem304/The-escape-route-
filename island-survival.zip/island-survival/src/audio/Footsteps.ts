export type Surface = 'sand' | 'grass' | 'jungle' | 'rock' | 'wet' | 'wood' | 'water';

export function surfaceFor(biome: string, inWater: boolean, onBuilding = false, shallow = false): Surface {
  if (inWater) return 'water';
  if (onBuilding) return 'wood';
  if (shallow || biome === 'shallows') return 'wet';
  switch (biome) {
    case 'beach': return 'sand';
    case 'grass': return 'grass';
    case 'jungle': return 'jungle';
    case 'rock': case 'volcanic': return 'rock';
    default: return 'sand';
  }
}

/** طول الخطوة (م) وفق الحالة الحركية */
export const STRIDE: Record<string, number> = { walk: 0.8, run: 1.15, crouch: 0.55, swim: 1.6, idle: 0, jump: 0 };
export const STEP_VOLUME: Record<string, number> = { walk: 0.5, run: 0.85, crouch: 0.2, swim: 0.45, idle: 0, jump: 0 };

/** يحسب لحظات الخطوات من المسافة المقطوعة: خطوة كل stride متر */
export class StrideTimer {
  private acc = 0;
  private left = false;

  /** @returns null أو {left, volume} عند اكتمال خطوة */
  advance(distance: number, loco: string, grounded: boolean): { left: boolean; volume: number } | null {
    const stride = STRIDE[loco] ?? 0;
    if (stride <= 0 || (!grounded && loco !== 'swim')) {
      if (stride <= 0) this.acc = 0;
      return null;
    }
    this.acc += distance;
    if (this.acc >= stride) {
      this.acc -= stride;
      this.left = !this.left;
      return { left: this.left, volume: STEP_VOLUME[loco] ?? 0.5 };
    }
    return null;
  }

  reset(): void {
    this.acc = 0;
  }
}
