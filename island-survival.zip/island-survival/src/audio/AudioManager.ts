import { smoothMix, type AmbienceMix } from './AmbienceMix';
import type { Surface } from './Footsteps';

export type SfxName =
  | 'step' | 'jump' | 'land' | 'splash' | 'chop' | 'mine' | 'dig' | 'pickup' | 'craft' | 'build' | 'click' | 'equip'
  | 'eat' | 'drink' | 'hurt' | 'hit' | 'swing' | 'fire_light' | 'thunder' | 'growl' | 'howl' | 'ding' | 'break';

export interface Vec3 { x: number; y: number; z: number }

export interface AudioVolumes { master: number; sfx: number; music: number; ambient: number }

const ZERO_MIX: AmbienceMix = { wind: 0, waves: 0, rain: 0, birds: 0, crickets: 0, jungle: 0, cave: 0, heartbeat: 0, lowpassHz: 20000, tension: 0, musicLevel: 0 };

/**
 * صوت اللعبة بـ Web Audio دون ملفات: ضوضاء مفلترة للرياح والأمواج والمطر، وتركيب لحظي للمؤثرات،
 * وموسيقى توليدية. يُنشأ AudioContext عند أول تفاعل (سياسة المتصفحات).
 * ملاحظة: الأصوات المُركَّبة بديل مؤقت؛ ملفات حقيقية تُوصَل لاحقًا عبر registerBuffer.
 */
export class AudioManager {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private busSfx!: GainNode;
  private busMusic!: GainNode;
  private busAmb!: GainNode;
  private ambLowpass!: BiquadFilterNode;
  private layers: Partial<Record<keyof AmbienceMix, GainNode>> = {};
  private noise: { white: AudioBuffer; pink: AudioBuffer; brown: AudioBuffer } | null = null;
  private mix: AmbienceMix = { ...ZERO_MIX };
  private target: AmbienceMix = { ...ZERO_MIX };
  private birdTimer = 0;
  private musicTimer = 0;
  private beatTimer = 0;
  private buffers = new Map<string, AudioBuffer>();
  volumes: AudioVolumes = { master: 0.8, sfx: 1, music: 0.5, ambient: 0.8 };
  /** ترجمة الأصوات للصم/ضعاف السمع */
  onCaption: ((key: string) => void) | null = null;

  get ready(): boolean {
    return this.ctx !== null && this.ctx.state === 'running';
  }

  /** يُستدعى من حدث نقر/لمس */
  /** يوقف السياق مؤقتًا (قائمة الإيقاف)؛ unlock() يستأنفه */
  suspend(): void {
    void this.ctx?.suspend();
  }

  async unlock(): Promise<void> {
    if (!this.ctx) this.build();
    if (this.ctx && this.ctx.state !== 'running') await this.ctx.resume();
  }

  setVolumes(v: Partial<AudioVolumes>): void {
    Object.assign(this.volumes, v);
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.volumes.master, t, 0.05);
    this.busSfx.gain.setTargetAtTime(this.volumes.sfx, t, 0.05);
    this.busMusic.gain.setTargetAtTime(this.volumes.music, t, 0.05);
    this.busAmb.gain.setTargetAtTime(this.volumes.ambient, t, 0.05);
  }

  /** يسجّل ملف صوت حقيقي يحل محل المركَّب باسم المؤثر */
  async registerBuffer(name: string, data: ArrayBuffer): Promise<void> {
    if (!this.ctx) this.build();
    this.buffers.set(name, await this.ctx!.decodeAudioData(data));
  }

  setAmbience(m: AmbienceMix): void {
    this.target = m;
  }

  /** موضع المستمع واتجاهه (الكاميرا) */
  setListener(pos: Vec3, forward: Vec3, up: Vec3 = { x: 0, y: 1, z: 0 }): void {
    if (!this.ctx) return;
    const l = this.ctx.listener;
    if (l.positionX) {
      l.positionX.value = pos.x; l.positionY.value = pos.y; l.positionZ.value = pos.z;
      l.forwardX.value = forward.x; l.forwardY.value = forward.y; l.forwardZ.value = forward.z;
      l.upX.value = up.x; l.upY.value = up.y; l.upZ.value = up.z;
    }
  }

  update(dt: number, heartbeat = this.target.heartbeat): void {
    if (!this.ctx || this.ctx.state !== 'running') return;
    this.mix = smoothMix(this.mix, this.target, dt);
    const t = this.ctx.currentTime;
    for (const k of Object.keys(this.layers) as Array<keyof AmbienceMix>) this.layers[k]!.gain.setTargetAtTime(this.mix[k], t, 0.2);
    this.ambLowpass.frequency.setTargetAtTime(this.mix.lowpassHz, t, 0.15);

    // طيور متقطعة
    this.birdTimer -= dt;
    if (this.birdTimer <= 0) {
      this.birdTimer = 1.5 + Math.random() * 5;
      if (Math.random() < this.mix.birds) this.chirp();
    }
    // نبض القلب
    this.beatTimer -= dt;
    if (this.beatTimer <= 0 && heartbeat > 0.05) {
      this.beatTimer = 0.9 - heartbeat * 0.35;
      this.tone(55, 0.12, 'sine', 0.5 * heartbeat, this.busAmb);
      setTimeout(() => this.tone(48, 0.1, 'sine', 0.35 * heartbeat, this.busAmb), 180);
    }
    // موسيقى توليدية
    this.musicTimer -= dt;
    if (this.musicTimer <= 0 && this.mix.musicLevel > 0.05) {
      this.musicTimer = 5 + Math.random() * 4 - this.mix.tension * 2.5;
      this.playChord();
    }
  }

  // ---------- مؤثرات ----------
  sfx(name: SfxName, opts: { pos?: Vec3; volume?: number; surface?: Surface } = {}): void {
    if (!this.ctx || this.ctx.state !== 'running') return;
    const vol = opts.volume ?? 1;
    const out = opts.pos ? this.spatial(opts.pos) : this.busSfx;
    const buf = this.buffers.get(name);
    if (buf) return this.playBuffer(buf, vol, out);
    this.synth(name, vol, out, opts.surface ?? 'sand');
    if (name === 'thunder') this.onCaption?.('snd_thunder');
    else if (name === 'growl') this.onCaption?.('snd_growl');
    else if (name === 'howl') this.onCaption?.('snd_howl');
  }

  step(surface: Surface, volume: number, pos?: Vec3): void {
    this.sfx('step', { surface, volume, pos });
  }

  /** مصدر نار/ماء ثابت يطقطق عند موضع (يُستدعى كل إطار قريب) */
  crackle(pos: Vec3, intensity: number): void {
    if (Math.random() < intensity * 0.12) this.sfx('fire_light', { pos, volume: 0.15 * intensity });
  }

  // ---------- بناء الرسم الصوتي ----------
  private build(): void {
    const AC = (window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext);
    const ctx = new AC();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.busSfx = ctx.createGain();
    this.busMusic = ctx.createGain();
    this.busAmb = ctx.createGain();
    this.ambLowpass = ctx.createBiquadFilter();
    this.ambLowpass.type = 'lowpass';
    this.ambLowpass.frequency.value = 20000;
    const comp = ctx.createDynamicsCompressor();
    this.busAmb.connect(this.ambLowpass).connect(this.master);
    this.busSfx.connect(this.master);
    this.busMusic.connect(this.master);
    this.master.connect(comp).connect(ctx.destination);
    this.setVolumes({});

    this.noise = { white: this.makeNoise('white'), pink: this.makeNoise('pink'), brown: this.makeNoise('brown') };
    const n = this.noise;
    const layer = (key: keyof AmbienceMix, src: AudioBuffer, setup: (s: AudioNode) => AudioNode): void => {
      const s = ctx.createBufferSource();
      s.buffer = src;
      s.loop = true;
      const g = ctx.createGain();
      g.gain.value = 0;
      setup(s).connect(g).connect(this.busAmb);
      s.start();
      this.layers[key] = g;
    };
    layer('wind', n.brown, (s) => this.filt(s, 'bandpass', 420, 0.6, 0.07));
    layer('waves', n.pink, (s) => this.filt(s, 'lowpass', 700, 0.5, 0.11));
    layer('rain', n.white, (s) => this.filt(s, 'highpass', 1400, 0.4));
    layer('jungle', n.pink, (s) => this.filt(s, 'bandpass', 2600, 2, 0.13));
    layer('cave', n.brown, (s) => this.filt(s, 'lowpass', 160, 0.7));
    // صراصير: تضمين سعوي لجيب مرتفع
    const osc = ctx.createOscillator();
    osc.frequency.value = 4300;
    const am = ctx.createGain();
    am.gain.value = 0;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 9;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 0.05;
    lfo.connect(lfoGain).connect(am.gain);
    const cg = ctx.createGain();
    cg.gain.value = 0;
    osc.connect(am).connect(cg).connect(this.busAmb);
    osc.start();
    lfo.start();
    this.layers.crickets = cg;
  }

  /** مرشح مع تحريك بطيء للتردد لإحساس الرياح/الأمواج */
  private filt(src: AudioNode, type: BiquadFilterType, freq: number, q: number, lfoRate = 0): AudioNode {
    const ctx = this.ctx!;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    f.Q.value = q;
    if (lfoRate > 0) {
      const l = ctx.createOscillator();
      l.frequency.value = lfoRate;
      const lg = ctx.createGain();
      lg.gain.value = freq * 0.45;
      l.connect(lg).connect(f.frequency);
      l.start();
    }
    src.connect(f);
    return f;
  }

  private makeNoise(kind: 'white' | 'pink' | 'brown'): AudioBuffer {
    const ctx = this.ctx!;
    const len = ctx.sampleRate * 4;
    const b = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = b.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, last = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      if (kind === 'white') d[i] = w * 0.5;
      else if (kind === 'pink') {
        b0 = 0.99765 * b0 + w * 0.099046; b1 = 0.963 * b1 + w * 0.2965164; b2 = 0.57 * b2 + w * 1.0526913;
        d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.2;
      } else {
        last = (last + 0.02 * w) / 1.02;
        d[i] = last * 3.5;
      }
    }
    // ربط النهاية بالبداية لتجنب النقرة عند التكرار
    const fade = 512;
    for (let i = 0; i < fade; i++) { const k = i / fade; d[len - fade + i] = d[len - fade + i] * (1 - k) + d[i] * k; }
    return b;
  }

  private spatial(pos: Vec3): AudioNode {
    const ctx = this.ctx!;
    const p = ctx.createPanner();
    p.panningModel = 'HRTF';
    p.distanceModel = 'inverse';
    p.refDistance = 2;
    p.maxDistance = 80;
    p.rolloffFactor = 1.4;
    p.positionX.value = pos.x; p.positionY.value = pos.y; p.positionZ.value = pos.z;
    p.connect(this.busSfx);
    return p;
  }

  private playBuffer(b: AudioBuffer, vol: number, out: AudioNode): void {
    const s = this.ctx!.createBufferSource();
    s.buffer = b;
    const g = this.ctx!.createGain();
    g.gain.value = vol;
    s.connect(g).connect(out);
    s.start();
  }

  // ---------- تركيب ----------
  private tone(freq: number, dur: number, type: OscillatorType, vol: number, out: AudioNode, slideTo?: number, delay = 0): void {
    const ctx = this.ctx!;
    const t = ctx.currentTime + delay;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + Math.min(0.02, dur / 3));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(out);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  private burst(dur: number, filterType: BiquadFilterType, freq: number, q: number, vol: number, out: AudioNode, sweepTo?: number, delay = 0): void {
    const ctx = this.ctx!;
    const t = ctx.currentTime + delay;
    const s = ctx.createBufferSource();
    s.buffer = this.noise!.white;
    s.loopStart = Math.random() * 2;
    s.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = filterType;
    f.frequency.setValueAtTime(freq, t);
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, t + dur);
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(out);
    s.start(t, s.loopStart);
    s.stop(t + dur + 0.05);
  }

  private synth(name: SfxName, v: number, out: AudioNode, surface: Surface): void {
    const j = 0.85 + Math.random() * 0.3; // تنويع لكسر التكرار
    switch (name) {
      case 'step': {
        const cfg: Record<Surface, [BiquadFilterType, number, number]> = {
          sand: ['lowpass', 900, 0.25], grass: ['bandpass', 1800, 0.18], jungle: ['bandpass', 1300, 0.22],
          rock: ['highpass', 1500, 0.28], wet: ['lowpass', 600, 0.3], wood: ['bandpass', 500, 0.35], water: ['bandpass', 800, 0.3],
        };
        const [ft, fq, vol] = cfg[surface];
        this.burst(surface === 'water' ? 0.25 : 0.1, ft, fq * j, 1, vol * v, out);
        if (surface === 'wood' || surface === 'rock') this.tone(120 * j, 0.08, 'triangle', 0.15 * v, out);
        break;
      }
      case 'jump': this.burst(0.12, 'lowpass', 700, 1, 0.12 * v, out); break;
      case 'land': this.burst(0.18, 'lowpass', 400, 1, 0.45 * v, out); this.tone(70, 0.15, 'sine', 0.35 * v, out); break;
      case 'splash': this.burst(0.5, 'bandpass', 1800 * j, 0.7, 0.4 * v, out, 500); break;
      case 'chop': this.burst(0.08, 'bandpass', 2500, 1.5, 0.4 * v, out); this.tone(140 * j, 0.14, 'triangle', 0.5 * v, out, 60); break;
      case 'mine': this.burst(0.05, 'highpass', 3000, 1, 0.45 * v, out); this.tone(1200 * j, 0.12, 'square', 0.12 * v, out, 800); this.tone(90, 0.1, 'sine', 0.4 * v, out); break;
      case 'dig': this.burst(0.2, 'lowpass', 1200, 1, 0.35 * v, out); break;
      case 'pickup': this.tone(520 * j, 0.09, 'sine', 0.18 * v, out, 780); break;
      case 'craft': this.tone(330, 0.1, 'triangle', 0.2 * v, out); this.tone(494, 0.14, 'triangle', 0.2 * v, out, undefined, 0.09); break;
      case 'build': this.burst(0.1, 'bandpass', 700, 1, 0.45 * v, out); this.tone(100, 0.2, 'triangle', 0.5 * v, out, 55); break;
      case 'click': this.tone(900, 0.04, 'square', 0.06 * v, out); break;
      case 'equip': this.burst(0.15, 'bandpass', 2200, 2, 0.2 * v, out); break;
      case 'eat': for (let i = 0; i < 3; i++) this.burst(0.07, 'bandpass', 1400, 1.2, 0.22 * v, out, undefined, i * 0.15); break;
      case 'drink': for (let i = 0; i < 3; i++) this.tone(300 + i * 40, 0.12, 'sine', 0.2 * v, out, 150, i * 0.16); break;
      case 'hurt': this.tone(200 * j, 0.25, 'sawtooth', 0.35 * v, out, 90); this.burst(0.15, 'lowpass', 500, 1, 0.4 * v, out); break;
      case 'hit': this.burst(0.09, 'lowpass', 900, 1, 0.5 * v, out); this.tone(100, 0.1, 'sine', 0.5 * v, out); break;
      case 'swing': this.burst(0.18, 'bandpass', 1500, 0.8, 0.14 * v, out, 3500); break;
      case 'fire_light': this.burst(0.04, 'highpass', 3500 + Math.random() * 3000, 1, 0.3 * v, out); break;
      case 'thunder': this.burst(2.8, 'lowpass', 220, 0.6, 0.9 * v, out, 60); this.burst(1.2, 'lowpass', 600, 0.6, 0.5 * v, out, 100, 0.05); break;
      case 'growl': this.tone(75 * j, 0.9, 'sawtooth', 0.4 * v, out, 55); this.burst(0.9, 'lowpass', 300, 2, 0.25 * v, out); break;
      case 'howl': this.tone(420, 1.8, 'sine', 0.3 * v, out, 640); this.tone(430, 1.8, 'sine', 0.2 * v, out, 330, 1.6); break;
      case 'ding': this.tone(880, 0.5, 'sine', 0.25 * v, out); this.tone(1320, 0.7, 'sine', 0.15 * v, out); break;
      case 'break': this.burst(0.25, 'highpass', 2000, 1, 0.5 * v, out); this.tone(180, 0.2, 'sawtooth', 0.3 * v, out, 60); break;
    }
  }

  private chirp(): void {
    const base = 2200 + Math.random() * 2500;
    const n = 2 + Math.floor(Math.random() * 3);
    for (let i = 0; i < n; i++) this.tone(base, 0.09, 'sine', 0.1 * this.mix.birds, this.busAmb, base * (1.15 + Math.random() * 0.3), i * 0.12);
  }

  /** وتر طويل من سلّم خماسي؛ التوتر يخفض السلّم ويضيف نغمة متنافرة */
  private playChord(): void {
    const ctx = this.ctx!;
    const scale = [0, 3, 5, 7, 10];
    const root = 110 * Math.pow(2, scale[Math.floor(Math.random() * 5)] / 12);
    const tens = this.mix.tension;
    const notes = [1, 1.5, 2, tens > 0.5 ? 2.12 : 2.5];
    for (const m of notes) {
      const o = ctx.createOscillator();
      o.type = 'sine';
      o.frequency.value = root * m;
      const g = ctx.createGain();
      const t = ctx.currentTime;
      const peak = 0.05 * this.mix.musicLevel;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t + 3);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 8);
      o.connect(g).connect(this.busMusic);
      o.start(t);
      o.stop(t + 8.2);
    }
  }

  dispose(): void {
    void this.ctx?.close();
    this.ctx = null;
  }
}
