import type { Random } from '../core/Random';
import type { Inventory } from '../inventory/Inventory';
import { ItemDB } from '../inventory/ItemDatabase';
import type { RecipeBook } from '../crafting/RecipeBook';
import type { Skills } from '../survival/Skills';
import { GroundItems } from '../world/GroundItems';
import type { NodeState, ToolPower } from '../world/ResourceNode';
import { BARE_HANDS, NODE_DEFS, toolPowerOf } from '../world/ResourceNode';
import type { ResourceField } from '../world/ResourceField';

export const REACH = 3.2;
export const SWING_COOLDOWN = 0.6;
export const SWING_STAMINA = 4;
/** انخفاضات رأسية تُضاف إلى اتجاه النظر عند التصويب */
const AIM_ASSIST_DROPS = [0, 0.3, 0.6, 0.9];

export type GatherOutcome =
  | { kind: 'cooldown' }
  | { kind: 'tired' }
  | { kind: 'miss' }
  | { kind: 'wrongTool'; node: NodeState; needs: 'chop' | 'mine' | 'dig' | 'hand' }
  | { kind: 'hit' | 'destroyed'; node: NodeState; drops: Array<{ id: string; count: number }>; dropped: number; toolBroke: boolean; newRecipes: string[] };

/**
 * ينفّذ ضربة جمع: رمي شعاع من الكاميرا ← ضربة على العقدة ← غلة للحقيبة (والفائض للأرض)
 * ← تآكل الأداة ← خبرة. كل المنطق خالص ليُختبر.
 */
export class Gatherer {
  private cooldown = 0;

  constructor(
    private field: ResourceField,
    private ground: GroundItems,
    private inv: Inventory,
    private skills: Skills,
    private recipes: RecipeBook,
    private rnd: Random,
  ) {}

  update(dt: number): void {
    this.cooldown = Math.max(0, this.cooldown - dt);
  }

  get ready(): boolean {
    return this.cooldown <= 0;
  }

  /**
   * @param stamina النفَس الحالي (يمنع الضرب إن نفد)
   * @param feet موضع القدمين لإسقاط الفائض على الأرض
   */
  swing(origin: { x: number; y: number; z: number }, dir: { x: number; y: number; z: number }, stamina: number, feet: { x: number; y: number; z: number }): GatherOutcome & { staminaCost?: number } {
    if (this.cooldown > 0) return { kind: 'cooldown' };
    if (stamina < SWING_STAMINA) return { kind: 'tired' };
    this.cooldown = SWING_COOLDOWN;

    // مساعدة التصويب: النباتات المنخفضة تقع تحت مستوى النظر، فنجرّب أشعة مائلة للأسفل إن لم يصب الأساسي
    let hit = null as ReturnType<ResourceField['raycast']>;
    for (const drop of AIM_ASSIST_DROPS) {
      hit = this.field.raycast(origin.x, origin.y, origin.z, dir.x, dir.y - drop, dir.z, REACH);
      if (hit) break;
    }
    if (!hit) return { kind: 'miss', staminaCost: SWING_STAMINA * 0.5 };

    const held = this.inv.held;
    const tool: ToolPower = held ? toolPowerOf(ItemDB.get(held.defId).effects) : BARE_HANDS;
    // أداة بلا متانة لا تعمل
    const usable = held && held.durability !== 0 ? tool : BARE_HANDS;

    const gloves = this.inv.equipment.gatherBonus;
    const bonus = gloves + this.skills.bonus('survival', 0.04);
    const res = this.field.hit(hit.node.id, usable, this.rnd, bonus);

    if (!res.ok) {
      return { kind: 'wrongTool', node: hit.node, needs: NODE_DEFS[hit.node.kind].action, staminaCost: SWING_STAMINA * 0.5 };
    }

    // تآكل الأداة (النباتات اليدوية لا تتلف شيئًا)
    let toolBroke = false;
    if (held && NODE_DEFS[hit.node.kind].action !== 'hand' && usable !== BARE_HANDS) {
      toolBroke = this.inv.damage(held.uid, 1);
    }

    let dropped = 0;
    const newRecipes: string[] = [];
    for (const d of res.drops) {
      const left = this.inv.add(d.id, d.count);
      if (left < d.count) for (const r of this.recipes.noteItem(d.id)) newRecipes.push(r.id);
      if (left > 0) {
        this.ground.dropNew(d.id, left, feet.x, feet.y, feet.z);
        dropped += left;
      }
    }
    this.skills.addXp('survival', res.destroyed ? 3 : 1);
    return { kind: res.destroyed ? 'destroyed' : 'hit', node: hit.node, drops: res.drops, dropped, toolBroke, newRecipes, staminaCost: SWING_STAMINA };
  }
}
