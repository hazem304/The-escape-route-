/** جدول يومي: يحدد النشاط بحسب ساعة اليوم */
export type Activity = 'sleep' | 'camp' | 'forage' | 'work' | 'patrol' | 'idle';

export interface ScheduleEntry {
  /** من (شاملة) إلى (غير شاملة) بالساعات، ويُسمح باللفّ عبر منتصف الليل (from > to) */
  from: number;
  to: number;
  activity: Activity;
  /** معرّف موقع مسمّى يحلّه العالم (camp, beach, cave...) */
  place: string;
}

export class Schedule {
  constructor(private entries: ScheduleEntry[], private fallback: ScheduleEntry = { from: 0, to: 24, activity: 'idle', place: 'camp' }) {}

  at(hour: number): ScheduleEntry {
    const h = ((hour % 24) + 24) % 24;
    for (const e of this.entries) {
      const inside = e.from <= e.to ? h >= e.from && h < e.to : h >= e.from || h < e.to;
      if (inside) return e;
    }
    return this.fallback;
  }
}
