/** سلوكيات توجيه ثنائية الأبعاد (x,z) */
export interface V2 {
  x: number;
  z: number;
}

export const len = (v: V2): number => Math.hypot(v.x, v.z);
export const sub = (a: V2, b: V2): V2 => ({ x: a.x - b.x, z: a.z - b.z });
export const norm = (v: V2): V2 => {
  const l = len(v);
  return l < 1e-6 ? { x: 0, z: 0 } : { x: v.x / l, z: v.z / l };
};
export const scale = (v: V2, s: number): V2 => ({ x: v.x * s, z: v.z * s });

/** السرعة المرغوبة نحو الهدف */
export function seek(from: V2, to: V2, speed: number): V2 {
  return scale(norm(sub(to, from)), speed);
}

/** هروب من تهديد */
export function flee(from: V2, threat: V2, speed: number): V2 {
  return scale(norm(sub(from, threat)), speed);
}

/** وصول: يبطئ عند الاقتراب (نصف قطر slow) */
export function arrive(from: V2, to: V2, speed: number, slowRadius = 3): V2 {
  const d = sub(to, from);
  const l = len(d);
  if (l < 0.2) return { x: 0, z: 0 };
  return scale(norm(d), speed * Math.min(1, l / slowRadius));
}

/** تجوال: يغيّر الاتجاه تدريجيًا حول الاتجاه الحالي. angleNoise في [-1,1] */
export function wander(heading: number, angleNoise: number, maxTurn = 0.6): number {
  return heading + angleNoise * maxTurn;
}

/**
 * تجنب العوائق: يفحص أمامه (خطوات) ويحرف الاتجاه إلى جهة أخرى إن كانت غير سالكة.
 * @param walkable دالة تحدد صلاحية النقطة
 */
export function avoidObstacles(pos: V2, heading: number, walkable: (x: number, z: number) => boolean, lookAhead = 3): number {
  const probe = (a: number): boolean => walkable(pos.x + Math.sin(a) * lookAhead, pos.z + Math.cos(a) * lookAhead);
  if (probe(heading)) return heading;
  // نجرّب زوايا متزايدة يمينًا ويسارًا
  for (let k = 1; k <= 6; k++) {
    const a = (k * Math.PI) / 8;
    if (probe(heading + a)) return heading + a;
    if (probe(heading - a)) return heading - a;
  }
  return heading + Math.PI; // محاصر: نستدير
}

/** الاتجاه (yaw) من متجه حركة: 0 = +z */
export const headingOf = (v: V2): number => Math.atan2(v.x, v.z);

/** يدير الزاوية الحالية نحو الهدف بأقصى معدل */
export function turnToward(current: number, target: number, maxDelta: number): number {
  let d = (target - current) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return current + Math.max(-maxDelta, Math.min(maxDelta, d));
}
