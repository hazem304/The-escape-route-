import type { V2 } from './Steering';
import { len, sub } from './Steering';

export interface Senses {
  /** مدى الرؤية (م) */
  sight: number;
  /** نصف زاوية مخروط الرؤية (راديان) */
  fov: number;
  /** مدى السمع (م) عند ضجيج 1 */
  hearing: number;
  /** مدى الشم مع الريح (م) */
  smell: number;
}

export interface Stimulus {
  pos: V2;
  /** ضجيج اللاعب 0..1: 0.1 انحناء، 0.35 مشي، 1 جري/قتال */
  noise: number;
  /** مستوى الظهور 0..1 (الليل/الانحناء/الاختباء يقلله) */
  visibility: number;
}

export type Detected = 'none' | 'smell' | 'hear' | 'see';

export interface PerceptionResult {
  detected: Detected;
  distance: number;
}

/** رؤية + سمع + شم. الريح تحمل الرائحة من الهدف نحو الحيوان فقط إن كان الحيوان في اتجاه الريح. */
export function perceive(self: V2, heading: number, senses: Senses, target: Stimulus, wind: V2, occluded = false): PerceptionResult {
  const to = sub(target.pos, self);
  const d = len(to);

  // الرؤية: مخروط + مدى متناسب مع الظهور + عدم وجود حاجز
  if (!occluded && d <= senses.sight * target.visibility) {
    const ang = Math.atan2(to.x, to.z);
    let diff = Math.abs(((ang - heading + Math.PI) % (Math.PI * 2)) - Math.PI);
    if (diff > Math.PI) diff = Math.PI * 2 - diff;
    if (diff <= senses.fov) return { detected: 'see', distance: d };
  }

  // السمع: يتناسب مع الضجيج
  if (d <= senses.hearing * target.noise) return { detected: 'hear', distance: d };

  // الشم: الريح تهب باتجاه wind؛ الرائحة تنتقل من الهدف إلى الحيوان إن كان الحيوان "أسفل الريح" من الهدف
  const wl = len(wind);
  if (wl > 0.01 && d <= senses.smell) {
    const dirFromTargetToSelf = { x: -to.x / (d || 1), z: -to.z / (d || 1) };
    const alignment = (dirFromTargetToSelf.x * wind.x + dirFromTargetToSelf.z * wind.z) / wl;
    if (alignment > 0.5) return { detected: 'smell', distance: d };
  }
  return { detected: 'none', distance: d };
}

/** ضجيج اللاعب من حالته */
export function playerNoise(state: 'idle' | 'crouch' | 'walk' | 'run' | 'swim' | 'fight' | 'jump'): number {
  switch (state) {
    case 'idle': return 0.05;
    case 'crouch': return 0.12;
    case 'walk': return 0.35;
    case 'swim': return 0.4;
    case 'jump': return 0.6;
    case 'run': return 0.85;
    case 'fight': return 1;
  }
}
