import type { V2 } from './Steering';

/** شبكة سير: خلايا بحجم cell متر تغطي مربعًا حول الأصل */
export interface NavConfig {
  half: number;
  cell: number;
  walkable: (x: number, z: number) => boolean;
}

interface Node {
  i: number;
  g: number;
  f: number;
  parent: number;
}

/** كومة ثنائية دنيا (لـ A*) */
class MinHeap {
  private a: Node[] = [];
  get size(): number {
    return this.a.length;
  }
  push(n: Node): void {
    this.a.push(n);
    let i = this.a.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (this.a[p].f <= this.a[i].f) break;
      [this.a[p], this.a[i]] = [this.a[i], this.a[p]];
      i = p;
    }
  }
  pop(): Node {
    const top = this.a[0];
    const last = this.a.pop()!;
    if (this.a.length > 0) {
      this.a[0] = last;
      let i = 0;
      for (;;) {
        const l = i * 2 + 1;
        const r = l + 1;
        let m = i;
        if (l < this.a.length && this.a[l].f < this.a[m].f) m = l;
        if (r < this.a.length && this.a[r].f < this.a[m].f) m = r;
        if (m === i) break;
        [this.a[m], this.a[i]] = [this.a[i], this.a[m]];
        i = m;
      }
    }
    return top;
  }
}

/**
 * A* على شبكة 8 اتجاهات مع منع قطع الزوايا وتنعيم المسار.
 * سريعة بما يكفي لعدد قليل من الطلبات في الثانية (الحيوانات تطلب مسارًا نادرًا).
 */
export class NavGrid {
  readonly n: number;
  private blocked: Uint8Array;

  constructor(private cfg: NavConfig) {
    this.n = Math.floor((cfg.half * 2) / cfg.cell);
    this.blocked = new Uint8Array(this.n * this.n);
    this.rebuild();
  }

  rebuild(): void {
    for (let j = 0; j < this.n; j++) {
      for (let i = 0; i < this.n; i++) {
        const c = this.center(i, j);
        this.blocked[j * this.n + i] = this.cfg.walkable(c.x, c.z) ? 0 : 1;
      }
    }
  }

  /** يحجب خلايا تحت عائق ديناميكي (مبنى مثلًا) */
  block(x: number, z: number, radius: number): void {
    const r = Math.ceil(radius / this.cfg.cell);
    const { i, j } = this.cellOf(x, z);
    for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) this.setBlocked(i + di, j + dj, true);
  }

  private setBlocked(i: number, j: number, v: boolean): void {
    if (i >= 0 && j >= 0 && i < this.n && j < this.n) this.blocked[j * this.n + i] = v ? 1 : 0;
  }

  cellOf(x: number, z: number): { i: number; j: number } {
    return { i: Math.floor((x + this.cfg.half) / this.cfg.cell), j: Math.floor((z + this.cfg.half) / this.cfg.cell) };
  }

  center(i: number, j: number): V2 {
    return { x: -this.cfg.half + (i + 0.5) * this.cfg.cell, z: -this.cfg.half + (j + 0.5) * this.cfg.cell };
  }

  isWalkableCell(i: number, j: number): boolean {
    return i >= 0 && j >= 0 && i < this.n && j < this.n && this.blocked[j * this.n + i] === 0;
  }

  /** @returns قائمة نقاط عالمية من البداية للنهاية، أو null إن لا طريق */
  findPath(from: V2, to: V2, maxExpansions = 4000): V2[] | null {
    const s = this.cellOf(from.x, from.z);
    let t = this.cellOf(to.x, to.z);
    if (!this.isWalkableCell(s.i, s.j)) return null;
    if (!this.isWalkableCell(t.i, t.j)) {
      const near = this.nearestWalkable(t.i, t.j, 4);
      if (!near) return null;
      t = near;
    }
    const start = s.j * this.n + s.i;
    const goal = t.j * this.n + t.i;
    if (start === goal) return [this.center(t.i, t.j)];

    const gScore = new Map<number, number>([[start, 0]]);
    const parent = new Map<number, number>();
    const closed = new Set<number>();
    const open = new MinHeap();
    const h = (i: number, j: number): number => {
      const dx = Math.abs(i - t.i);
      const dz = Math.abs(j - t.j);
      return dx + dz + (Math.SQRT2 - 2) * Math.min(dx, dz); // مسافة octile
    };
    open.push({ i: start, g: 0, f: h(s.i, s.j), parent: -1 });

    let expansions = 0;
    while (open.size > 0 && expansions++ < maxExpansions) {
      const cur = open.pop();
      if (closed.has(cur.i)) continue;
      closed.add(cur.i);
      if (cur.i === goal) return this.smooth(this.reconstruct(parent, goal, from, to));
      const ci = cur.i % this.n;
      const cj = Math.floor(cur.i / this.n);

      for (let dj = -1; dj <= 1; dj++) {
        for (let di = -1; di <= 1; di++) {
          if (di === 0 && dj === 0) continue;
          const ni = ci + di;
          const nj = cj + dj;
          if (!this.isWalkableCell(ni, nj)) continue;
          // لا قطع للزوايا بين خليتين محجوبتين
          if (di !== 0 && dj !== 0 && (!this.isWalkableCell(ci + di, cj) || !this.isWalkableCell(ci, cj + dj))) continue;
          const idx = nj * this.n + ni;
          if (closed.has(idx)) continue;
          const g = cur.g + (di !== 0 && dj !== 0 ? Math.SQRT2 : 1);
          if (g < (gScore.get(idx) ?? Infinity)) {
            gScore.set(idx, g);
            parent.set(idx, cur.i);
            open.push({ i: idx, g, f: g + h(ni, nj), parent: cur.i });
          }
        }
      }
    }
    return null;
  }

  private nearestWalkable(i: number, j: number, r: number): { i: number; j: number } | null {
    for (let k = 1; k <= r; k++) {
      for (let dj = -k; dj <= k; dj++) {
        for (let di = -k; di <= k; di++) {
          if (Math.max(Math.abs(di), Math.abs(dj)) !== k) continue;
          if (this.isWalkableCell(i + di, j + dj)) return { i: i + di, j: j + dj };
        }
      }
    }
    return null;
  }

  private reconstruct(parent: Map<number, number>, goal: number, from: V2, to: V2): V2[] {
    const cells: number[] = [goal];
    let c = goal;
    while (parent.has(c)) {
      c = parent.get(c)!;
      cells.push(c);
    }
    cells.reverse();
    const pts = cells.map((idx) => this.center(idx % this.n, Math.floor(idx / this.n)));
    // نبدأ من الموضع الفعلي وننهي عند الهدف إن كانت خليته سالكة
    pts[0] = { x: from.x, z: from.z };
    const last = this.cellOf(to.x, to.z);
    if (this.isWalkableCell(last.i, last.j)) pts[pts.length - 1] = { x: to.x, z: to.z };
    return pts;
  }

  /** خط رؤية بين نقطتين (يمر عبر خلايا سالكة فقط) */
  lineOfWalk(a: V2, b: V2): boolean {
    const dist = Math.hypot(b.x - a.x, b.z - a.z);
    const steps = Math.ceil(dist / (this.cfg.cell * 0.5));
    for (let k = 0; k <= steps; k++) {
      const t = steps === 0 ? 0 : k / steps;
      const c = this.cellOf(a.x + (b.x - a.x) * t, a.z + (b.z - a.z) * t);
      if (!this.isWalkableCell(c.i, c.j)) return false;
    }
    return true;
  }

  /** حذف النقاط الوسيطة التي يمكن تخطيها بخط مستقيم */
  private smooth(path: V2[]): V2[] {
    if (path.length <= 2) return path;
    const out: V2[] = [path[0]];
    let anchor = 0;
    for (let i = 2; i < path.length; i++) {
      if (!this.lineOfWalk(path[anchor], path[i])) {
        out.push(path[i - 1]);
        anchor = i - 1;
      }
    }
    out.push(path[path.length - 1]);
    return out;
  }
}
