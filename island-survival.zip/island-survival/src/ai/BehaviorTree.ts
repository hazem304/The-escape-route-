/** شجرة سلوك بسيطة: Sequence / Selector / Condition / Action / Inverter / Cooldown / Parallel(any) */
export type Status = 'success' | 'failure' | 'running';

export interface BTNode<C> {
  tick(ctx: C, dt: number): Status;
  reset?(): void;
}

export class Condition<C> implements BTNode<C> {
  constructor(private fn: (ctx: C) => boolean) {}
  tick(ctx: C): Status {
    return this.fn(ctx) ? 'success' : 'failure';
  }
}

export class Action<C> implements BTNode<C> {
  constructor(private fn: (ctx: C, dt: number) => Status) {}
  tick(ctx: C, dt: number): Status {
    return this.fn(ctx, dt);
  }
}

/** ينفّذ الأبناء بالترتيب؛ يفشل عند أول فشل؛ يتذكر الابن الجاري */
export class Sequence<C> implements BTNode<C> {
  private i = 0;
  constructor(private children: Array<BTNode<C>>) {}
  tick(ctx: C, dt: number): Status {
    while (this.i < this.children.length) {
      const s = this.children[this.i].tick(ctx, dt);
      if (s === 'running') return 'running';
      if (s === 'failure') {
        this.reset();
        return 'failure';
      }
      this.i++;
    }
    this.reset();
    return 'success';
  }
  reset(): void {
    this.i = 0;
    this.children.forEach((c) => c.reset?.());
  }
}

/** يجرّب الأبناء بالترتيب (أولوية)؛ ينجح عند أول نجاح/جريان. يعيد التقييم من البداية كل نبضة لتفضيل الأعلى أولوية */
export class Selector<C> implements BTNode<C> {
  private lastRunning = -1;
  constructor(private children: Array<BTNode<C>>) {}
  tick(ctx: C, dt: number): Status {
    for (let i = 0; i < this.children.length; i++) {
      const s = this.children[i].tick(ctx, dt);
      if (s !== 'failure') {
        // تغيّر الابن الجاري => نصفّر السابق
        if (this.lastRunning !== i && this.lastRunning >= 0) this.children[this.lastRunning].reset?.();
        this.lastRunning = s === 'running' ? i : -1;
        return s;
      }
    }
    this.lastRunning = -1;
    return 'failure';
  }
  reset(): void {
    this.lastRunning = -1;
    this.children.forEach((c) => c.reset?.());
  }
}

export class Inverter<C> implements BTNode<C> {
  constructor(private child: BTNode<C>) {}
  tick(ctx: C, dt: number): Status {
    const s = this.child.tick(ctx, dt);
    return s === 'success' ? 'failure' : s === 'failure' ? 'success' : 'running';
  }
  reset(): void {
    this.child.reset?.();
  }
}

/** يمنع تكرار الفعل قبل مرور مدة */
export class Cooldown<C> implements BTNode<C> {
  private remaining = 0;
  constructor(private seconds: number, private child: BTNode<C>) {}
  tick(ctx: C, dt: number): Status {
    this.remaining = Math.max(0, this.remaining - dt);
    if (this.remaining > 0) return 'failure';
    const s = this.child.tick(ctx, dt);
    if (s === 'success') this.remaining = this.seconds;
    return s;
  }
  reset(): void {
    this.child.reset?.();
  }
}

/** يشغّل فعلًا لمدة ثم ينجح (مثل الرعي 5 ثوانٍ) */
export class Timed<C> implements BTNode<C> {
  private t = 0;
  constructor(private duration: () => number, private fn: (ctx: C, dt: number) => void) {}
  tick(ctx: C, dt: number): Status {
    if (this.t === 0) this.t = this.duration();
    this.fn(ctx, dt);
    this.t -= dt;
    if (this.t <= 0) {
      this.t = 0;
      return 'success';
    }
    return 'running';
  }
  reset(): void {
    this.t = 0;
  }
}
