import * as THREE from 'three';

export interface ParticleSpec {
  /** عمر الجسيمة (ث) min/max */
  life: [number, number];
  /** حجم البداية/النهاية (م) */
  size: [number, number];
  /** لون البداية/النهاية */
  colorA: THREE.ColorRepresentation;
  colorB: THREE.ColorRepresentation;
  /** شفافية البداية */
  alpha: number;
  /** تسارع ثابت (م/ث²)، سالب Y = جاذبية */
  gravity: THREE.Vector3;
  /** سرعة عشوائية أولية */
  spread: number;
  /** سرعة اتجاهية إضافية */
  velocity: THREE.Vector3;
  /** تأثر بالرياح 0..1 */
  windFactor: number;
  additive: boolean;
  /** تباطؤ الهواء (1/ث) */
  drag: number;
}

export const PRESETS = {
  fire: { life: [0.5, 1.0], size: [0.35, 0.05], colorA: 0xffd060, colorB: 0xff3010, alpha: 0.9, gravity: new THREE.Vector3(0, 1.6, 0), spread: 0.25, velocity: new THREE.Vector3(0, 0.6, 0), windFactor: 0.2, additive: true, drag: 0.8 },
  sparks: { life: [0.6, 1.4], size: [0.05, 0.01], colorA: 0xffe090, colorB: 0xff5a10, alpha: 1, gravity: new THREE.Vector3(0, 0.5, 0), spread: 1.2, velocity: new THREE.Vector3(0, 1.4, 0), windFactor: 0.6, additive: true, drag: 0.4 },
  smoke: { life: [2.5, 4.5], size: [0.3, 1.8], colorA: 0x6c6c6c, colorB: 0x9a9a9a, alpha: 0.35, gravity: new THREE.Vector3(0, 0.5, 0), spread: 0.2, velocity: new THREE.Vector3(0, 0.8, 0), windFactor: 0.9, additive: false, drag: 0.3 },
  splash: { life: [0.4, 0.9], size: [0.12, 0.04], colorA: 0xd8f0ff, colorB: 0x88c0e0, alpha: 0.85, gravity: new THREE.Vector3(0, -9.8, 0), spread: 1.6, velocity: new THREE.Vector3(0, 3.2, 0), windFactor: 0.1, additive: false, drag: 0.2 },
  dust: { life: [0.5, 1.1], size: [0.15, 0.7], colorA: 0xc8b890, colorB: 0xd8cca8, alpha: 0.45, gravity: new THREE.Vector3(0, 0.2, 0), spread: 0.7, velocity: new THREE.Vector3(0, 0.3, 0), windFactor: 0.5, additive: false, drag: 2 },
  chips: { life: [0.5, 1.0], size: [0.06, 0.05], colorA: 0x8a5a2a, colorB: 0x6a4020, alpha: 1, gravity: new THREE.Vector3(0, -12, 0), spread: 2.2, velocity: new THREE.Vector3(0, 2.2, 0), windFactor: 0, additive: false, drag: 0.1 },
  rockChips: { life: [0.4, 0.9], size: [0.05, 0.04], colorA: 0x9a948a, colorB: 0x6a665e, alpha: 1, gravity: new THREE.Vector3(0, -12, 0), spread: 2.4, velocity: new THREE.Vector3(0, 2, 0), windFactor: 0, additive: false, drag: 0.1 },
  leaves: { life: [1.0, 2.0], size: [0.1, 0.08], colorA: 0x5a8a30, colorB: 0x8a9a30, alpha: 1, gravity: new THREE.Vector3(0, -2.5, 0), spread: 1.6, velocity: new THREE.Vector3(0, 1.4, 0), windFactor: 0.5, additive: false, drag: 1.2 },
} satisfies Record<string, ParticleSpec>;

export type PresetName = keyof typeof PRESETS;

const VERT = /* glsl */ `
  attribute float aSize; attribute float aAlpha; attribute vec3 aColor;
  uniform float uScale;
  varying float vAlpha; varying vec3 vColor;
  void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_PointSize = aSize * uScale / max(0.2, -mv.z);
    gl_Position = projectionMatrix * mv;
    vAlpha = aAlpha; vColor = aColor;
  }
`;
const FRAG = /* glsl */ `
  varying float vAlpha; varying vec3 vColor;
  void main() {
    vec2 c = gl_PointCoord - 0.5;
    float d = length(c);
    if (d > 0.5 || vAlpha <= 0.002) discard;
    float a = smoothstep(0.5, 0.15, d) * vAlpha;
    gl_FragColor = vec4(vColor, a);
  }
`;

/**
 * نظام جسيمات CPU بمجموعة ثابتة (pool) في Points واحد: لا تخصيص ذاكرة أثناء اللعب.
 * كل نظام له إعداد (Spec) واحد؛ يستخدم لكل نوع تأثير نظام مستقل.
 */
export class ParticleSystem {
  readonly points: THREE.Points;
  private pos: Float32Array;
  private vel: Float32Array;
  private age: Float32Array;
  private life: Float32Array;
  private base: Float32Array; // حجم البداية لكل جسيمة
  private aSize: Float32Array;
  private aAlpha: Float32Array;
  private aColor: Float32Array;
  private cursor = 0;
  private colA: THREE.Color;
  private colB: THREE.Color;
  private tmp = new THREE.Color();
  private material: THREE.ShaderMaterial;
  /** الجسيمات الحية (للتشخيص والاختبار) */
  alive = 0;

  constructor(readonly spec: ParticleSpec, readonly max = 400) {
    this.pos = new Float32Array(max * 3);
    this.vel = new Float32Array(max * 3);
    this.age = new Float32Array(max).fill(1e9);
    this.life = new Float32Array(max).fill(1);
    this.base = new Float32Array(max);
    this.aSize = new Float32Array(max);
    this.aAlpha = new Float32Array(max);
    this.aColor = new Float32Array(max * 3);
    this.colA = new THREE.Color(spec.colorA);
    this.colB = new THREE.Color(spec.colorB);

    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aSize', new THREE.BufferAttribute(this.aSize, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aAlpha', new THREE.BufferAttribute(this.aAlpha, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('aColor', new THREE.BufferAttribute(this.aColor, 3).setUsage(THREE.DynamicDrawUsage));
    this.material = new THREE.ShaderMaterial({
      vertexShader: VERT, fragmentShader: FRAG, transparent: true, depthWrite: false,
      blending: spec.additive ? THREE.AdditiveBlending : THREE.NormalBlending,
      uniforms: { uScale: { value: 600 } },
    });
    this.points = new THREE.Points(g, this.material);
    this.points.frustumCulled = false;
    this.points.renderOrder = 5;
  }

  /** @param viewportHeight يضبط حجم النقطة بالبكسل ليتناسب مع المسافة */
  setViewport(heightPx: number, fovDeg: number): void {
    this.material.uniforms.uScale.value = heightPx / (2 * Math.tan((fovDeg * Math.PI) / 360));
  }

  emit(x: number, y: number, z: number, count = 1, jitter = 0): void {
    const s = this.spec;
    for (let n = 0; n < count; n++) {
      const i = this.cursor;
      this.cursor = (this.cursor + 1) % this.max;
      this.pos[i * 3] = x + (Math.random() - 0.5) * jitter;
      this.pos[i * 3 + 1] = y + (Math.random() - 0.5) * jitter * 0.3;
      this.pos[i * 3 + 2] = z + (Math.random() - 0.5) * jitter;
      this.vel[i * 3] = s.velocity.x + (Math.random() - 0.5) * 2 * s.spread;
      this.vel[i * 3 + 1] = s.velocity.y + (Math.random() - 0.3) * s.spread;
      this.vel[i * 3 + 2] = s.velocity.z + (Math.random() - 0.5) * 2 * s.spread;
      this.age[i] = 0;
      this.life[i] = s.life[0] + Math.random() * (s.life[1] - s.life[0]);
      this.base[i] = 0.7 + Math.random() * 0.6;
    }
  }

  update(dt: number, wind: { x: number; z: number }): void {
    const s = this.spec;
    let alive = 0;
    for (let i = 0; i < this.max; i++) {
      const a = this.age[i];
      if (a >= this.life[i]) {
        this.aAlpha[i] = 0;
        continue;
      }
      alive++;
      const t = (this.age[i] += dt) / this.life[i];
      const drag = Math.exp(-s.drag * dt);
      this.vel[i * 3] = (this.vel[i * 3] + (s.gravity.x + wind.x * s.windFactor * 2) * dt) * drag;
      this.vel[i * 3 + 1] = (this.vel[i * 3 + 1] + s.gravity.y * dt) * drag;
      this.vel[i * 3 + 2] = (this.vel[i * 3 + 2] + (s.gravity.z + wind.z * s.windFactor * 2) * dt) * drag;
      this.pos[i * 3] += this.vel[i * 3] * dt;
      this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      const tt = Math.min(1, t);
      this.aSize[i] = (s.size[0] + (s.size[1] - s.size[0]) * tt) * this.base[i];
      // يتلاشى في الربع الأخير وينبثق في أول 10%
      this.aAlpha[i] = s.alpha * Math.min(1, tt * 10) * (1 - Math.max(0, (tt - 0.7) / 0.3));
      this.tmp.copy(this.colA).lerp(this.colB, tt);
      this.aColor[i * 3] = this.tmp.r; this.aColor[i * 3 + 1] = this.tmp.g; this.aColor[i * 3 + 2] = this.tmp.b;
    }
    this.alive = alive;
    const g = this.points.geometry;
    for (const n of ['position', 'aSize', 'aAlpha', 'aColor']) (g.getAttribute(n) as THREE.BufferAttribute).needsUpdate = true;
  }

  dispose(): void {
    this.points.geometry.dispose();
    this.material.dispose();
  }
}

/** يدير أنظمة الجسيمات الشائعة ويوفر دوال سريعة للأحداث */
export class FXManager {
  readonly group = new THREE.Group();
  private systems = new Map<PresetName, ParticleSystem>();
  wind = { x: 0, z: 0 };

  constructor() {
    for (const [name, spec] of Object.entries(PRESETS) as Array<[PresetName, ParticleSpec]>) {
      const s = new ParticleSystem(spec, name === 'smoke' ? 300 : name === 'fire' ? 500 : 250);
      this.systems.set(name, s);
      this.group.add(s.points);
    }
  }

  sys(name: PresetName): ParticleSystem {
    return this.systems.get(name)!;
  }

  setViewport(heightPx: number, fovDeg: number): void {
    for (const s of this.systems.values()) s.setViewport(heightPx, fovDeg);
  }

  /** شعلة موقد: تُستدعى كل إطار مع dt لتوزيع الانبعاث */
  fire(x: number, y: number, z: number, strength: number, dt: number): void {
    if (strength <= 0.02) return;
    this.acc.fire += dt * 60 * strength;
    this.acc.smoke += dt * 6 * strength;
    this.acc.sparks += dt * 4 * strength;
    const f = Math.floor(this.acc.fire); this.acc.fire -= f;
    const s = Math.floor(this.acc.smoke); this.acc.smoke -= s;
    const k = Math.floor(this.acc.sparks); this.acc.sparks -= k;
    if (f) this.sys('fire').emit(x, y + 0.15, z, f, 0.3);
    if (s) this.sys('smoke').emit(x, y + 0.9, z, s, 0.2);
    if (k) this.sys('sparks').emit(x, y + 0.4, z, k, 0.2);
  }
  private acc = { fire: 0, smoke: 0, sparks: 0 };

  splash(x: number, y: number, z: number, power = 1): void {
    this.sys('splash').emit(x, y, z, Math.round(14 * power), 0.3);
  }
  dust(x: number, y: number, z: number, n = 4): void {
    this.sys('dust').emit(x, y + 0.05, z, n, 0.4);
  }
  hit(x: number, y: number, z: number, kind: 'wood' | 'rock' | 'leaf'): void {
    this.sys(kind === 'wood' ? 'chips' : kind === 'rock' ? 'rockChips' : 'leaves').emit(x, y, z, 8, 0.2);
  }

  update(dt: number): void {
    for (const s of this.systems.values()) s.update(dt, this.wind);
  }

  dispose(): void {
    for (const s of this.systems.values()) s.dispose();
  }
}

/** سرب يراعات ليلي حول اللاعب */
export class Fireflies {
  readonly points: THREE.Points;
  private base: Float32Array;
  private pos: Float32Array;
  private phase: Float32Array;
  private material: THREE.ShaderMaterial;

  constructor(private count = 60, private radius = 22) {
    this.base = new Float32Array(count * 3);
    this.pos = new Float32Array(count * 3);
    this.phase = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const r = Math.sqrt(Math.random()) * radius;
      this.base[i * 3] = Math.cos(a) * r;
      this.base[i * 3 + 1] = 0.5 + Math.random() * 2.5;
      this.base[i * 3 + 2] = Math.sin(a) * r;
      this.phase[i] = Math.random() * 100;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    g.setAttribute('aPhase', new THREE.BufferAttribute(this.phase, 1));
    this.material = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uTime: { value: 0 }, uNight: { value: 0 }, uScale: { value: 600 } },
      vertexShader: /* glsl */ `
        attribute float aPhase; uniform float uTime; uniform float uNight; uniform float uScale; varying float vA;
        void main() {
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          float blink = 0.5 + 0.5 * sin(uTime * 2.2 + aPhase);
          vA = blink * uNight;
          gl_PointSize = 0.09 * uScale / max(0.2, -mv.z);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: /* glsl */ `
        varying float vA;
        void main() { float d = length(gl_PointCoord - 0.5); if (d > 0.5 || vA < 0.01) discard; gl_FragColor = vec4(0.75, 1.0, 0.35, smoothstep(0.5, 0.0, d) * vA); }`,
    });
    this.points = new THREE.Points(g, this.material);
    this.points.frustumCulled = false;
  }

  setViewport(heightPx: number, fovDeg: number): void {
    this.material.uniforms.uScale.value = heightPx / (2 * Math.tan((fovDeg * Math.PI) / 360));
  }

  /** @param night 0..1 (كثافة الظلام) و groundY دالة ارتفاع الأرض للحفاظ على اليراعات فوقها */
  update(elapsed: number, center: THREE.Vector3, night: number, rain: number, groundY: (x: number, z: number) => number): void {
    const vis = night * (1 - rain);
    this.material.uniforms.uTime.value = elapsed;
    this.material.uniforms.uNight.value = vis;
    this.points.visible = vis > 0.02;
    if (!this.points.visible) return;
    for (let i = 0; i < this.count; i++) {
      const p = this.phase[i];
      // تتبع اللاعب (التفاف حول المركز) مع انجراف بطيء
      let bx = this.base[i * 3] + Math.sin(elapsed * 0.3 + p) * 1.5;
      let bz = this.base[i * 3 + 2] + Math.cos(elapsed * 0.27 + p) * 1.5;
      const wrap = this.radius * 2;
      bx = ((((bx - center.x) % wrap) + wrap * 1.5) % wrap) - this.radius + center.x;
      bz = ((((bz - center.z) % wrap) + wrap * 1.5) % wrap) - this.radius + center.z;
      this.pos[i * 3] = bx;
      this.pos[i * 3 + 2] = bz;
      this.pos[i * 3 + 1] = Math.max(0, groundY(bx, bz)) + this.base[i * 3 + 1] + Math.sin(elapsed * 0.8 + p) * 0.3;
    }
    (this.points.geometry.getAttribute('position') as THREE.BufferAttribute).needsUpdate = true;
  }

  dispose(): void {
    this.points.geometry.dispose();
    this.material.dispose();
  }
}
