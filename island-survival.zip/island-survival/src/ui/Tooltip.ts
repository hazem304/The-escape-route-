import { getLanguage, t } from '../core/i18n';
import { ItemDB } from '../inventory/ItemDatabase';
import { RARITY_COLORS, spoilState, type ItemStack } from '../inventory/Item';
import { h } from './dom';

export function itemName(defId: string): string {
  const d = ItemDB.get(defId);
  return getLanguage() === 'ar' ? d.nameAr : d.nameEn;
}

const EFFECT_LABEL: Record<string, [string, string]> = {
  hunger: ['جوع', 'Hunger'], thirst: ['عطش', 'Thirst'], health: ['صحة', 'Health'], energy: ['طاقة', 'Energy'],
  stamina: ['نفَس', 'Stamina'], sanity: ['اتزان', 'Sanity'], damage: ['ضرر', 'Damage'], warmth: ['دفء', 'Warmth'],
  defense: ['حماية', 'Defense'], ignite: ['إشعال', 'Ignite'],
};

/** محتوى تلميح العنصر */
export function tooltipFor(stack: ItemStack): HTMLElement {
  const d = ItemDB.get(stack.defId);
  const st = spoilState(d, stack);
  const ar = getLanguage() === 'ar';
  const lines: string[] = [];
  for (const [k, v] of Object.entries(d.effects)) {
    const lab = EFFECT_LABEL[k];
    if (lab && typeof v === 'number') lines.push(`${ar ? lab[0] : lab[1]}: ${v > 0 && k !== 'damage' && k !== 'warmth' && k !== 'defense' && k !== 'ignite' ? '+' : ''}${v}`);
  }
  const body = h('div', {},
    h('b', { style: `color:${RARITY_COLORS[d.rarity]}` }, `${d.icon} ${itemName(d.id)}`),
    h('div', { class: 'dim' }, t(`rarity_${d.rarity}`), ` · ${t('weight')}: ${(d.weight * stack.count).toFixed(1)}`),
  );
  if (d.durability > 0) body.append(h('div', {}, `${t('durability')}: ${Math.ceil(stack.durability)}/${d.durability}`));
  if (st !== 'none') body.append(h('div', {}, t(`spoil_${st}`)));
  for (const l of lines) body.append(h('div', {}, l));
  return body;
}

/** تلميح عائم يتبع المؤشر */
export class Tooltip {
  readonly root = h('div', { class: 'tip', hidden: true });
  show(content: HTMLElement, x: number, y: number): void {
    this.root.replaceChildren(content);
    this.root.hidden = false;
    const w = this.root.offsetWidth || 220;
    const hh = this.root.offsetHeight || 80;
    this.root.style.left = `${Math.min(x + 14, window.innerWidth - w - 6)}px`;
    this.root.style.top = `${Math.min(y + 14, window.innerHeight - hh - 6)}px`;
  }
  hide(): void {
    this.root.hidden = true;
  }
}
