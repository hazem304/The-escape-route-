type Child = Node | string | number | null | undefined | false;
type Attrs = Record<string, string | number | boolean | EventListener | undefined | null> & { class?: string; style?: string };

/** مُنشئ عناصر DOM مختصر: h('div', {class:'x', onclick: fn}, 'نص', child) */
export function h<K extends keyof HTMLElementTagNameMap>(tag: K, attrs: Attrs = {}, ...kids: Child[]): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v as EventListener);
    else if (k === 'class') el.className = String(v);
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, String(v));
  }
  for (const c of kids) if (c !== null && c !== undefined && c !== false) el.append(typeof c === 'number' ? String(c) : c);
  return el;
}

export function clear(el: Element): void {
  while (el.firstChild) el.removeChild(el.firstChild);
}

export function clamp01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

export function fmtClock(hour: number): string {
  const hh = Math.floor(hour) % 24;
  const mm = Math.floor((hour % 1) * 60);
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

export function fmtDuration(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

/** لوحة قابلة للفتح والإغلاق */
export abstract class Panel {
  readonly root: HTMLElement;
  isOpen = false;
  constructor(readonly id: string, cls = '') {
    this.root = h('div', { class: `panel ${cls}`, id: `panel-${id}`, hidden: true });
    this.root.addEventListener('contextmenu', (e) => e.preventDefault());
  }
  open(): void {
    this.isOpen = true;
    this.root.hidden = false;
    this.refresh();
  }
  close(): void {
    this.isOpen = false;
    this.root.hidden = true;
    this.onClose();
  }
  toggle(): void {
    if (this.isOpen) this.close();
    else this.open();
  }
  protected onClose(): void {}
  abstract refresh(): void;
  /** يُستدعى ~4 مرات/ث أثناء الفتح لتحديث القيم الحية */
  tick(): void {
    this.refresh();
  }
}
