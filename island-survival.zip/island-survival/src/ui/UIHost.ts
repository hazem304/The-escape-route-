import type { GameSession } from '../core/GameSession';
import type { ToastKind } from './Notifications';
import type { SfxName } from '../audio/AudioManager';

/** ما تحتاجه الواجهة من اللعبة (يُنفَّذ في Game.ts وفي اختبارات المتصفح) */
export interface UIHost {
  session: GameSession;
  player(): { x: number; y: number; z: number; yaw: number };
  notify(text: string, kind?: ToastKind): void;
  sfx(name: SfxName): void;
}

import type { GameConfig } from '../config';
import type { SaveSystem } from '../core/SaveSystem';
import type { PieceType } from '../building/Blueprint';
import type { Difficulty } from '../survival/Stats';

/** الواجهة الكاملة التي تنفذها Game لقوائم الإيقاف والبناء */
export interface GameUIHost extends UIHost {
  saves: SaveSystem;
  config: GameConfig;
  setConfig(patch: Partial<GameConfig>): void;
  saveTo(slot: number): Promise<boolean>;
  loadFrom(slot: number): Promise<boolean>;
  newGame(difficulty: Difficulty): void;
  resume(): void;
  startBuild(type: PieceType): void;
  setDemolish(on: boolean): void;
  /** يُغلق كل شيء ويستأنف اللعب بعد إغلاق لوحة */
  panelClosed(): void;
}
