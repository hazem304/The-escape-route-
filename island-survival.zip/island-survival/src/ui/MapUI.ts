import { getLanguage, t } from '../core/i18n';
import { MapData } from '../quests/MapData';
import { h, Panel } from './dom';
import type { UIHost } from './UIHost';

const RES = 128;
const SIZE = 512;

function colorFor(hgt: number): [number, number, number] {
  if (hgt < -8) return [14, 50, 80];
  if (hgt < 0) return [30, 100, 140];
  if (hgt < 1.6) return [214, 196, 140];
  if (hgt < 9) return [96, 140, 70];
  if (hgt < 20) return [64, 104, 52];
  if (hgt < 32) return [118, 114, 106];
  return [70, 66, 62];
}

/** الخريطة: تضاريس ملونة مغطاة بضباب الاستكشاف + معالم + سهم اللاعب */
export class MapUI extends Panel {
  private canvas = h('canvas', { class: 'map', width: SIZE, height: SIZE });
  private base: ImageData | null = null;
  private legend = h('div', { class: 'dim' });

  constructor(private host: UIHost) {
    super('map');
    this.root.append(h('h2', {}, h('span', {}, `🗺 ${t('map')}`), h('button', { onclick: () => this.close() }, '✕')), h('div', { class: 'mapwrap' }, this.canvas), this.legend);
  }

  private ensureBase(): ImageData {
    if (this.base) return this.base;
    const terr = this.host.session.terrain;
    const img = new ImageData(RES, RES);
    for (let j = 0; j < RES; j++) for (let i = 0; i < RES; i++) {
      const w = MapData.mapToWorld((i + 0.5) * (SIZE / RES), (j + 0.5) * (SIZE / RES), terr.half, SIZE);
      const [r, g, b] = colorFor(terr.height(w.x, w.z));
      const k = (j * RES + i) * 4;
      img.data[k] = r; img.data[k + 1] = g; img.data[k + 2] = b; img.data[k + 3] = 255;
    }
    return (this.base = img);
  }

  refresh(): void {
    const s = this.host.session;
    const half = s.terrain.half;
    const ctx = this.canvas.getContext('2d')!;
    const base = this.ensureBase();
    const full = s.map.fullMapUnlocked;
    // نطبق الضباب على نسخة
    const img = new ImageData(new Uint8ClampedArray(base.data), RES, RES);
    for (let j = 0; j < RES; j++) for (let i = 0; i < RES; i++) {
      const w = MapData.mapToWorld((i + 0.5) * (SIZE / RES), (j + 0.5) * (SIZE / RES), half, SIZE);
      if (!full && !s.map.isExplored(w.x, w.z)) {
        const k = (j * RES + i) * 4;
        img.data[k] = 10; img.data[k + 1] = 18; img.data[k + 2] = 24;
      }
    }
    const off = document.createElement('canvas');
    off.width = RES; off.height = RES;
    off.getContext('2d')!.putImageData(img, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.clearRect(0, 0, SIZE, SIZE);
    ctx.drawImage(off, 0, 0, SIZE, SIZE);

    const ar = getLanguage() === 'ar';
    ctx.font = '16px system-ui'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (const l of (full ? s.map.landmarks : s.map.visibleLandmarks())) {
      const { px, py } = MapData.worldToMap(l.x, l.z, half, SIZE);
      ctx.fillText(l.icon, px, py);
      ctx.fillStyle = '#fff'; ctx.font = '11px system-ui';
      ctx.fillText(ar ? l.nameAr : l.nameEn, px, py + 15);
      ctx.font = '16px system-ui';
    }
    // اللاعب
    const p = this.host.player();
    const m = MapData.worldToMap(p.x, p.z, half, SIZE);
    ctx.save();
    ctx.translate(m.px, m.py);
    ctx.rotate(-p.yaw + Math.PI);
    ctx.fillStyle = '#ff5050'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, -9); ctx.lineTo(6, 7); ctx.lineTo(0, 3); ctx.lineTo(-6, 7); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.restore();
    this.legend.textContent = `▲ ${t('map_you')}`;
  }
}
