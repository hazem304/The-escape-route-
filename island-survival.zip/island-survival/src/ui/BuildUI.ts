import { BLUEPRINTS, type PieceType } from '../building/Blueprint';
import { getLanguage, t } from '../core/i18n';
import { ItemDB } from '../inventory/ItemDatabase';
import { h, Panel } from './dom';
import { itemName } from './Tooltip';
import type { GameUIHost } from './UIHost';

/** قائمة البناء: كل المخططات مع التكلفة؛ المتاح ماديًا بارز */
export class BuildUI extends Panel {
  demolish = false;
  constructor(private host: GameUIHost) {
    super('build');
  }

  refresh(): void {
    const inv = this.host.session.inventory;
    const ar = getLanguage() === 'ar';
    const list = h('div', { class: 'buildlist' });
    for (const bp of Object.values(BLUEPRINTS)) {
      const afford = Object.entries(bp.cost).every(([id, n]) => inv.count(id) >= n);
      list.append(h('div', { class: `bp${afford ? '' : ' no'}`, onclick: () => { this.host.startBuild(bp.type as PieceType); this.close(); } },
        h('b', {}, ar ? bp.nameAr : bp.nameEn),
        h('small', {}, Object.entries(bp.cost).map(([id, n]) => `${ItemDB.get(id).icon}${itemName(id)} ${inv.count(id)}/${n}`).join(' · '))));
    }
    this.root.replaceChildren(
      h('h2', {}, h('span', {}, `🏗 ${t('build')}`), h('button', { onclick: () => this.close() }, '✕')),
      list,
      h('div', { class: 'actions' }, h('button', { onclick: () => { this.host.setDemolish(true); this.close(); } }, `🔨 ${t('build_remove')}`)),
      h('div', { class: 'dim' }, t('build_hint')),
    );
  }
}
