import { h } from './dom';

export type ToastKind = 'info' | 'good' | 'bad' | 'quest';

/** رسائل عائمة قصيرة تتراكم وتختفي تلقائيًا */
export class Notifications {
  readonly root = h('div', { class: 'toasts' });
  private max = 5;

  push(text: string, kind: ToastKind = 'info', ms = 3200): void {
    // نمنع تكرار نفس الرسالة المتتالية
    const last = this.root.lastElementChild as HTMLElement | null;
    if (last && last.textContent === text) {
      last.dataset.n = String((Number(last.dataset.n) || 1) + 1);
      last.textContent = `${text} ×${last.dataset.n}`;
      return;
    }
    const el = h('div', { class: `toast ${kind === 'info' ? '' : kind}` }, text);
    this.root.append(el);
    while (this.root.children.length > this.max) this.root.firstElementChild?.remove();
    setTimeout(() => el.remove(), ms);
  }
}
