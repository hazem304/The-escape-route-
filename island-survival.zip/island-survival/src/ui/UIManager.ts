import { getLanguage, pick, t } from '../core/i18n';
import type { SessionEvent } from '../core/GameSession';
import { ItemDB } from '../inventory/ItemDatabase';
import { QUEST_BY_ID } from '../quests/Story';
import { BackpackUI } from './BackpackUI';
import { BuildUI } from './BuildUI';
import { CraftUI } from './CraftUI';
import { DialogueUI } from './DialogueUI';
import { h, type Panel } from './dom';
import { EndingUI } from './EndingUI';
import { HUD } from './HUD';
import { JournalUI } from './JournalUI';
import { MapUI } from './MapUI';
import { PauseMenu } from './PauseMenu';
import { Tutorial } from './Tutorial';
import type { GameUIHost } from './UIHost';

export type PanelName = 'backpack' | 'craft' | 'map' | 'journal' | 'build' | 'pause' | 'dialogue' | 'ending';

/**
 * يجمع الواجهة كلها: HUD دائم + لوحات (واحدة مفتوحة في كل مرة).
 * Game يستدعي open/close/toggle ويمرّر update(dt) كل إطار.
 */
export class UIManager {
  readonly root = h('div', { id: 'ui' });
  readonly hud: HUD;
  readonly backpack: BackpackUI;
  readonly craft: CraftUI;
  readonly map: MapUI;
  readonly journal: JournalUI;
  readonly build: BuildUI;
  readonly pause: PauseMenu;
  readonly dialogue: DialogueUI;
  readonly ending: EndingUI;
  readonly tutorial: Tutorial;
  private panels: Record<PanelName, Panel>;
  private tickTimer = 0;

  constructor(private host: GameUIHost, mount: HTMLElement = document.body) {
    this.hud = new HUD(host, (i) => { host.session.inventory.hotbar.select(i); host.sfx('click'); });
    this.backpack = new BackpackUI(host);
    this.craft = new CraftUI(host);
    this.map = new MapUI(host);
    this.journal = new JournalUI(host);
    this.build = new BuildUI(host);
    this.pause = new PauseMenu(host);
    this.dialogue = new DialogueUI(host);
    this.ending = new EndingUI(host);
    this.tutorial = new Tutorial(host);
    this.panels = { backpack: this.backpack, craft: this.craft, map: this.map, journal: this.journal, build: this.build, pause: this.pause, dialogue: this.dialogue, ending: this.ending };
    this.root.append(this.hud.root, this.tutorial.root, ...Object.values(this.panels).map((p) => p.root), this.backpack.tooltip.root);
    mount.append(this.root);
    this.dialogue.onEnd = () => this.afterClose();
  }

  /** هل لوحة مفتوحة (اللعبة تحرر المؤشر وتتجاهل الحركة) */
  get anyOpen(): boolean {
    return Object.values(this.panels).some((p) => p.isOpen);
  }

  get current(): PanelName | null {
    for (const [k, p] of Object.entries(this.panels)) if (p.isOpen) return k as PanelName;
    return null;
  }

  open(name: PanelName): void {
    // لوحة واحدة في كل مرة (ما عدا الحوار فوق كل شيء)
    for (const [k, p] of Object.entries(this.panels)) if (k !== name && p.isOpen) p.close();
    this.panels[name].open();
    this.tutorial.panelOpened(name);
    this.host.sfx('click');
  }

  close(name?: PanelName): void {
    const n = name ?? this.current;
    if (!n) return;
    this.panels[n].close();
    this.afterClose();
  }

  closeAll(): void {
    for (const p of Object.values(this.panels)) if (p.isOpen) p.close();
    this.afterClose();
  }

  toggle(name: PanelName): void {
    if (this.panels[name].isOpen) this.close(name);
    else this.open(name);
  }

  private afterClose(): void {
    if (!this.anyOpen) this.host.panelClosed();
  }

  update(dt: number): void {
    this.hud.update(dt);
    this.tutorial.update(dt);
    this.handleEvents();
    this.tickTimer -= dt;
    if (this.tickTimer <= 0) {
      this.tickTimer = 0.25;
      for (const p of Object.values(this.panels)) if (p.isOpen) p.tick();
    }
  }

  private handleEvents(): void {
    for (const e of this.host.session.drainEvents()) this.onEvent(e);
  }

  private onEvent(e: SessionEvent): void {
    const n = this.hud.notifications;
    switch (e.type) {
      case 'notify': n.push(pick({ ar: e.ar, en: e.en }), 'info'); break;
      case 'questUpdate': {
        if (e.kind === 'started' || e.kind === 'completed') {
          const q = QUEST_NAME(e.id);
          n.push(t(e.kind === 'started' ? 'quest_started' : 'quest_done', { name: q }), 'quest', 4500);
          this.host.sfx('ding');
        }
        break;
      }
      case 'landmark': n.push(t('landmark_found', { name: pick({ ar: e.landmark.nameAr, en: e.landmark.nameEn }) }), 'good'); break;
      case 'newRecipes': n.push(t('new_recipes', { n: e.ids.length }), 'good'); break;
      case 'levelUp': n.push(t('level_up', { skill: t(`skill_${e.skill}`), n: e.level }), 'good'); this.host.sfx('ding'); break;
      case 'woke': n.push(t('woke_up')); this.hud.setDark(false); break;
      case 'ending': this.open('ending'); this.ending.show(e.id); break;
      case 'fishing':
        if (e.state === 'cast') n.push(t('fish_cast'));
        else if (e.state === 'bite') { n.push(t('fish_bite'), 'good', 1500); this.host.sfx('ding'); }
        else if (e.state === 'escaped') n.push(t('fish_escaped'), 'bad');
        else if (e.state === 'cancel') n.push(t('fish_cancel'));
        else if (e.state === 'caught' && e.item) n.push(t('got_item', { name: pick({ ar: ItemDB.get(e.item).nameAr, en: ItemDB.get(e.item).nameEn }), n: e.count ?? 1 }), 'good');
        break;
      case 'animalKilled': break;
      case 'pieceRemoved': n.push(t('piece_removed')); break;
    }
  }

  /** تلميح العنصر في الأرض لمسافة قريبة */
  groundPrompt(defId: string): string {
    return t('prompt_pickup', { name: `${ItemDB.get(defId).icon} ${pick({ ar: ItemDB.get(defId).nameAr, en: ItemDB.get(defId).nameEn })}` });
  }
}

function QUEST_NAME(id: string): string {
  const q = QUEST_BY_ID.get(id);
  return q ? (getLanguage() === 'ar' ? q.titleAr : q.titleEn) : id;
}
