import { t } from '../core/i18n';
import type { SlotInfo } from '../core/SaveSystem';
import type { Difficulty } from '../survival/Stats';
import { clear, fmtDuration, h, Panel } from './dom';
import type { GameUIHost } from './UIHost';

type View = 'main' | 'save' | 'load' | 'settings' | 'new';

/** قائمة الإيقاف: متابعة / حفظ / تحميل / إعدادات / لعبة جديدة */
export class PauseMenu extends Panel {
  private view: View = 'main';

  constructor(private host: GameUIHost) {
    super('pause', 'menu');
  }

  override open(): void {
    this.view = 'main';
    super.open();
  }

  refresh(): void {
    clear(this.root);
    this.root.append(h('h2', {}, h('span', {}, this.view === 'main' ? t('paused') : t(`menu_${this.view === 'new' ? 'new' : this.view}`)), this.view === 'main' ? null : h('button', { onclick: () => this.go('main') }, t('back'))));
    if (this.view === 'main') this.main();
    else if (this.view === 'settings') this.settings();
    else if (this.view === 'new') this.newGame();
    else void this.slots(this.view);
  }

  private go(v: View): void {
    this.view = v;
    this.host.sfx('click');
    this.refresh();
  }

  override tick(): void {
    // لا نعيد رسم القوائم الجارية (تُبقي المنزلقات سليمة)
  }

  private main(): void {
    this.root.append(h('div', { class: 'col' },
      h('button', { class: 'primary', onclick: () => this.host.resume() }, t('menu_resume')),
      h('button', { onclick: () => this.go('save') }, `💾 ${t('menu_save')}`),
      h('button', { onclick: () => this.go('load') }, `📂 ${t('menu_load')}`),
      h('button', { onclick: () => this.go('settings') }, `⚙ ${t('menu_settings')}`),
      h('button', { onclick: () => this.go('new') }, `✦ ${t('menu_new')}`),
    ));
  }

  private async slots(mode: 'save' | 'load'): Promise<void> {
    const list = await this.host.saves.list();
    if (this.view !== mode) return;
    const col = h('div', { class: 'col' });
    for (const s of list) col.append(this.slotRow(s, mode));
    this.root.append(col);
  }

  private slotRow(s: SlotInfo, mode: 'save' | 'load'): HTMLElement {
    const info = s.empty ? t('slot_empty') : s.corrupt ? t('slot_corrupt')
      : t('slot_info', { day: s.day ?? 1, time: fmtDuration(s.playTime ?? 0), diff: t(`diff_${s.difficulty ?? 'normal'}`) });
    const date = s.savedAt ? new Date(s.savedAt).toLocaleString() : '';
    const act = h('button', {
      class: 'primary', disabled: mode === 'load' && (s.empty || !!s.corrupt),
      onclick: async () => {
        if (mode === 'save') {
          if (!s.empty && !confirm(t('confirm_overwrite'))) return;
          const ok = await this.host.saveTo(s.slot);
          this.host.notify(t(ok ? 'saved' : 'save_failed'), ok ? 'good' : 'bad');
        } else {
          const ok = await this.host.loadFrom(s.slot);
          this.host.notify(t(ok ? 'loaded' : 'load_failed'), ok ? 'good' : 'bad');
          if (ok) this.host.resume();
        }
        this.refresh();
      },
    }, mode === 'save' ? t('menu_save') : t('menu_load'));
    const del = s.empty ? null : h('button', { onclick: async () => { if (confirm(t('confirm_delete'))) { await this.host.saves.delete(s.slot); this.refresh(); } } }, '🗑');
    return h('div', { class: 'slotrow' }, h('div', { class: 'info' }, h('b', {}, t('slot_n', { n: s.slot + 1 })), h('div', { class: 'dim' }, info), h('div', { class: 'dim' }, date)), act, del);
  }

  private settings(): void {
    const c = this.host.config;
    const row = (label: string, ctl: HTMLElement): HTMLElement => h('div', { class: 'setrow' }, h('span', {}, label), ctl);
    const range = (key: 'masterVolume' | 'sfxVolume' | 'musicVolume' | 'ambientVolume' | 'mouseSensitivity' | 'fov', min: number, max: number, step: number): HTMLElement =>
      h('input', { type: 'range', min, max, step, value: c[key], oninput: (e: Event) => this.host.setConfig({ [key]: Number((e.target as HTMLInputElement).value) }) });
    const check = (key: 'invertY' | 'postfx' | 'subtitles'): HTMLElement =>
      h('input', { type: 'checkbox', checked: c[key], onchange: (e: Event) => this.host.setConfig({ [key]: (e.target as HTMLInputElement).checked }) });
    const select = (opts: Array<[string, string]>, cur: string, on: (v: string) => void): HTMLElement => {
      const el = h('select', { onchange: (e: Event) => on((e.target as HTMLSelectElement).value) }, ...opts.map(([v, l]) => h('option', { value: v, selected: v === cur }, l)));
      return el;
    };
    this.root.append(
      row(t('set_language'), select([['ar', 'العربية'], ['en', 'English']], c.language, (v) => { this.host.setConfig({ language: v as 'ar' | 'en' }); this.refresh(); })),
      row(t('set_quality'), select([['low', t('q_low')], ['medium', t('q_medium')], ['high', t('q_high')]], c.quality, (v) => this.host.setConfig({ quality: v as 'low' | 'medium' | 'high' }))),
      row(t('set_postfx'), check('postfx')),
      row(t('set_fov'), range('fov', 55, 100, 1)),
      row(t('set_sens'), range('mouseSensitivity', 0.2, 3, 0.05)),
      row(t('set_invertY'), check('invertY')),
      row(t('set_master'), range('masterVolume', 0, 1, 0.05)),
      row(t('set_sfx'), range('sfxVolume', 0, 1, 0.05)),
      row(t('set_music'), range('musicVolume', 0, 1, 0.05)),
      row(t('set_ambient'), range('ambientVolume', 0, 1, 0.05)),
      row(t('set_subtitles'), check('subtitles')),
    );
  }

  private newGame(): void {
    const col = h('div', { class: 'col' });
    for (const d of ['easy', 'normal', 'hard', 'realistic'] as Difficulty[]) {
      col.append(h('button', { onclick: () => { if (confirm(t('confirm_overwrite'))) this.host.newGame(d); } }, t(`diff_${d}`)));
    }
    this.root.append(h('div', { class: 'dim' }, t('difficulty')), col);
  }

}
