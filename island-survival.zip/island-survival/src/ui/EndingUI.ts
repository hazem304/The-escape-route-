import { t } from '../core/i18n';
import type { EndingId } from '../quests/RescueEnding';
import { fmtDuration, h, Panel } from './dom';
import type { GameUIHost } from './UIHost';

export class EndingUI extends Panel {
  private endingId: EndingId = 'death';
  constructor(private host: GameUIHost) {
    super('ending', 'ending');
  }

  show(id: EndingId): void {
    this.endingId = id;
    this.open();
  }

  refresh(): void {
    const s = this.host.session;
    const cause = s.survival.deathCause ?? 'unknown';
    const causeKey = ['fall', 'animal', 'cut', 'fire', 'drown', 'starve', 'cold'].includes(cause) ? cause : 'unknown';
    this.root.replaceChildren(
      h('h1', {}, t(`ending_${this.endingId}`)),
      h('p', {}, t(`ending_${this.endingId}_text`)),
      ...(this.endingId === 'death' ? [h('p', { class: 'dim' }, t(`death_cause_${causeKey}`))] : []),
      h('p', { class: 'dim' }, `${t('stats_days')}: ${s.day + 1} · ${t('stats_played')}: ${fmtDuration(s.playTime)}`),
      h('div', { class: 'actions' },
        h('button', { class: 'primary', onclick: () => this.host.newGame(s.survival.difficulty) }, t('retry')),
        h('button', { onclick: () => { this.host.resume(); } }, t('menu_load'))),
    );
  }

  override tick(): void {}
}
