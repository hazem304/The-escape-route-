import { t } from '../core/i18n';
import { HOTBAR_SIZE } from '../inventory/Hotbar';
import { ItemDB } from '../inventory/ItemDatabase';
import { clamp01, clear, fmtClock, h } from './dom';
import { Notifications } from './Notifications';
import type { UIHost } from './UIHost';
import { getLanguage } from '../core/i18n';

interface BarRef { el: HTMLElement; fill: HTMLElement; label: HTMLElement; name: string }

/** العناصر الدائمة على الشاشة */
export class HUD {
  readonly root = h('div', { class: 'hud' });
  readonly notifications = new Notifications();
  private bars: Record<string, BarRef> = {};
  private clock = h('div');
  private temp = h('div', { class: 'temp' });
  private conds = h('div', { class: 'conds' });
  private tracker = h('div', { class: 'tracker', hidden: true });
  private prompt = h('div', { class: 'prompt', hidden: true });
  private caption = h('div', { class: 'caption', hidden: true });
  private hurt = h('div', { class: 'hurt' });
  private dark = h('div', { class: 'dark' });
  private weight = h('div', { class: 'weightwarn', hidden: true });
  readonly hotbar = h('div', { class: 'hotbar' });
  private slotEls: HTMLElement[] = [];
  private lastHealth = 100;
  private capTimer = 0;
  private trackerKey = '';

  constructor(private host: UIHost, private onSelectSlot: (i: number) => void) {
    const stats = h('div', { class: 'hud-stats' });
    for (const n of ['health', 'hunger', 'thirst', 'energy', 'stamina', 'sanity']) {
      const fill = h('i');
      const label = h('span');
      const el = h('div', { class: `bar ${n}` }, fill, label);
      stats.append(el);
      this.bars[n] = { el, fill, label, name: n };
    }
    const top = h('div', { class: 'hud-top' }, this.clock, this.temp, this.conds);
    for (let i = 0; i < HOTBAR_SIZE; i++) {
      const el = h('div', { class: 'hslot', 'data-hslot': i, onclick: () => this.onSelectSlot(i) });
      this.slotEls.push(el);
      this.hotbar.append(el);
    }
    this.root.append(this.hurt, this.dark, stats, top, this.tracker, this.hotbar, this.prompt, this.caption, this.weight, this.notifications.root);
  }

  setPrompt(text: string | null): void {
    this.prompt.hidden = !text;
    if (text) this.prompt.textContent = text;
  }

  showCaption(text: string): void {
    this.caption.textContent = text;
    this.caption.hidden = false;
    this.capTimer = 2.2;
  }

  /** تعتيم الشاشة (النوم/النهاية) */
  setDark(on: boolean): void {
    this.dark.style.opacity = on ? '1' : '0';
  }

  update(dt: number): void {
    const s = this.host.session;
    const st = s.survival.stats;

    const set = (n: string, v: number, text: string): void => {
      const b = this.bars[n];
      const p = clamp01(v / 100);
      b.fill.style.width = `${Math.round(p * 100)}%`;
      b.label.textContent = `${text} ${Math.round(v)}`;
      b.el.classList.toggle('low', p < 0.2);
    };
    set('health', st.health, t('stat_health'));
    set('hunger', st.hunger, t('stat_hunger'));
    set('thirst', st.thirst, t('stat_thirst'));
    set('energy', st.energy, t('stat_energy'));
    set('stamina', st.stamina, t('stat_stamina'));
    set('sanity', st.sanity, t('stat_sanity'));

    this.clock.textContent = `${t('day_n', { n: s.day + 1 })} · ${fmtClock(s.hour)}`;
    this.temp.textContent = `${t('stat_temp')}: ${st.bodyTemp.toFixed(1)}°` + (st.wetness > 0.3 ? ` · ${t('stat_wet')} ${Math.round(st.wetness * 100)}%` : '');

    // الحالات المرضية
    const ids = [...s.survival.conditions.keys()].join(',');
    if (this.conds.dataset.k !== ids) {
      this.conds.dataset.k = ids;
      clear(this.conds);
      for (const id of s.survival.conditions.keys()) this.conds.append(h('span', { class: 'cond' }, t(`cond_${id}`)));
    }

    // وميض الضرر
    if (st.health < this.lastHealth - 0.5) {
      this.hurt.style.opacity = String(Math.min(1, 0.4 + (this.lastHealth - st.health) / 25));
      setTimeout(() => (this.hurt.style.opacity = st.health < 25 ? '0.45' : '0'), 160);
    }
    this.lastHealth = st.health;

    this.updateTracker();
    this.updateHotbar();

    const burden = s.inventory.burden;
    this.weight.hidden = burden.speedMultiplier >= 0.999;
    if (!this.weight.hidden) this.weight.textContent = t('overweight');

    if (this.capTimer > 0 && (this.capTimer -= dt) <= 0) this.caption.hidden = true;
  }

  private updateTracker(): void {
    const q = this.host.session.quests.tracked;
    if (!q) {
      this.tracker.hidden = true;
      return;
    }
    const prog = this.host.session.quests.progressOf(q.id);
    const key = q.id + prog.objectives.map((o) => `${o.done ? 1 : 0}${o.value}`).join('|') + getLanguage();
    if (key === this.trackerKey) return;
    this.trackerKey = key;
    this.tracker.hidden = false;
    clear(this.tracker);
    const ar = getLanguage() === 'ar';
    this.tracker.append(h('b', {}, ar ? q.titleAr : q.titleEn));
    q.objectives.forEach((o, i) => {
      const p = prog.objectives[i];
      const txt = (ar ? o.textAr : o.textEn) + (p.target > 1 ? ` (${p.value}/${p.target})` : '');
      this.tracker.append(h('div', { class: `obj ${p.done ? 'done' : p.current ? 'cur' : ''}` }, `${p.done ? '✓' : p.current ? '▸' : '·'} ${txt}`));
    });
  }

  private updateHotbar(): void {
    const inv = this.host.session.inventory;
    this.slotEls.forEach((el, i) => {
      const uid = inv.hotbar.slots[i];
      const e = uid !== null ? inv.grid.get(uid) : undefined;
      const sel = i === inv.hotbar.selected;
      const key = `${i}:${e?.stack.defId}:${e?.stack.count}:${Math.round(e?.stack.durability ?? 0)}:${sel}`;
      if (el.dataset.k === key) return;
      el.dataset.k = key;
      el.className = `hslot${sel ? ' sel' : ''}`;
      clear(el);
      el.append(h('span', { class: 'k' }, i + 1));
      if (e) {
        const d = ItemDB.get(e.stack.defId);
        el.append(d.icon);
        if (e.stack.count > 1) el.append(h('span', { class: 'n' }, e.stack.count));
        if (d.durability > 0) el.append(h('span', { class: 'd', style: `width:${clamp01(e.stack.durability / d.durability) * 100}%` }));
      }
    });
  }
}
