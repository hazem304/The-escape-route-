import { getLanguage, t } from '../core/i18n';
import { JOURNAL_PAGES } from '../quests/Journal';
import type { QuestDef } from '../quests/Story';
import { clear, h, Panel } from './dom';
import type { UIHost } from './UIHost';

type Tab = 'quests' | 'journal';

/** المهام والمذكرات */
export class JournalUI extends Panel {
  private tab: Tab = 'quests';
  private body = h('div');

  constructor(private host: UIHost) {
    super('journal');
    this.root.append(h('h2', {}, h('span', {}, `📖 ${t('journal')}`), h('button', { onclick: () => this.close() }, '✕')), h('div', { class: 'tabs', id: 'jtabs' }), this.body);
  }

  refresh(): void {
    const tabs = this.root.querySelector('#jtabs')!;
    clear(tabs);
    for (const k of ['quests', 'journal'] as const) tabs.append(h('button', { class: this.tab === k ? 'on' : '', onclick: () => { this.tab = k; this.refresh(); } }, t(k)));
    clear(this.body);
    if (this.tab === 'quests') this.renderQuests();
    else this.renderJournal();
  }

  private questCard(q: QuestDef, withProgress: boolean): HTMLElement {
    const ar = getLanguage() === 'ar';
    const el = h('div', { class: `quest${q.main ? ' main' : ''}` }, h('h4', {}, ar ? q.titleAr : q.titleEn, ' ', h('span', { class: 'dim' }, q.main ? t('quest_main') : t('quest_side'))), h('div', { class: 'dim' }, ar ? q.descAr : q.descEn));
    if (withProgress) {
      const prog = this.host.session.quests.progressOf(q.id);
      q.objectives.forEach((o, i) => {
        const p = prog.objectives[i];
        el.append(h('div', { class: `obj ${p.done ? 'done' : p.current ? 'cur' : ''}` }, `${p.done ? '✓' : p.current ? '▸' : '·'} ${ar ? o.textAr : o.textEn}${p.target > 1 ? ` (${p.value}/${p.target})` : ''}`));
      });
    }
    return el;
  }

  private renderQuests(): void {
    const q = this.host.session.quests;
    const group = (title: string, list: QuestDef[], prog: boolean): void => {
      if (!list.length) return;
      this.body.append(h('h3', {}, title));
      for (const d of list) this.body.append(this.questCard(d, prog));
    };
    if (!q.active.length && !q.available.length && !q.completed.length) this.body.append(h('div', { class: 'dim' }, t('no_quests')));
    group(t('quest_active'), q.active, true);
    group(t('quest_available'), q.available, false);
    group(t('quest_completed'), q.completed, false);
  }

  private renderJournal(): void {
    const j = this.host.session.journal;
    const ar = getLanguage() === 'ar';
    if (!j.entries.length && !j.pages.size) this.body.append(h('div', { class: 'dim' }, t('journal_empty')));
    if (j.pages.size) {
      this.body.append(h('h3', {}, t('journal_pages')));
      for (const id of j.pages) {
        const pg = JOURNAL_PAGES[id];
        if (pg) this.body.append(h('div', { class: 'page' }, ar ? pg.ar : pg.en));
      }
    }
    if (j.entries.length) {
      this.body.append(h('h3', {}, t('journal_entries')));
      for (const e of [...j.entries].reverse()) this.body.append(h('div', { class: 'entry' }, h('span', { class: 'dim' }, t('journal_day', { n: e.day + 1 }), ' · '), ar ? e.textAr : e.textEn));
    }
  }
}
