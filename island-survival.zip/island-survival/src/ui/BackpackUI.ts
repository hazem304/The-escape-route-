import { t } from '../core/i18n';
import { Container } from '../inventory/Container';
import { DragController } from '../inventory/DragDrop';
import { Grid } from '../inventory/Grid';
import { ItemDB } from '../inventory/ItemDatabase';
import { EQUIP_SLOTS, RARITY_COLORS, spoilState, type ItemStack } from '../inventory/Item';
import { clamp01, clear, h, Panel } from './dom';
import { itemName, Tooltip, tooltipFor } from './Tooltip';
import type { UIHost } from './UIHost';

interface GridView { grid: Grid; el: HTMLElement; id: string }

/** الحقيبة: شبكة سحب وإفلات + التجهيز + حاوية مفتوحة اختيارية + إجراءات العنصر المحدد */
export class BackpackUI extends Panel {
  private drag = new DragController();
  private views: GridView[] = [];
  private ghost: HTMLElement | null = null;
  private selected: { uid: number; grid: Grid } | null = null;
  private container: Container | null = null;
  private body = h('div');
  readonly tooltip = new Tooltip();
  /** يُستدعى عند الإفلات خارج اللوحة على شريط سريع: يُحدَّد من HUD عبر data-hslot */
  constructor(private host: UIHost) {
    super('backpack', 'bag');
    this.root.append(this.body);
    window.addEventListener('keydown', (e) => {
      if (this.isOpen && this.drag.active && e.code === 'KeyR') {
        this.drag.rotate();
        this.updateGhostSize();
      }
    });
  }

  openContainer(c: Container | null): void {
    this.container = c;
    if (this.isOpen) this.refresh();
  }

  protected override onClose(): void {
    this.cancelDrag();
    this.selected = null;
    this.container = null;
    this.tooltip.hide();
  }

  private get cell(): number {
    return parseFloat(getComputedStyle(this.root).getPropertyValue('--cell')) || 46;
  }

  override tick(): void {
    if (!this.drag.active) this.refresh();
  }

  refresh(): void {
    if (!this.drag.active) this.render();
  }

  private render(): void {
    const inv = this.host.session.inventory;
    this.views = [];
    clear(this.body);
    const load = inv.burden;
    const pct = clamp01(inv.totalWeight / inv.maxWeight);
    const wbar = h('div', { class: `wbar ${load.speedMultiplier < 0.6 ? 'heavy' : load.speedMultiplier < 0.999 ? 'over' : ''}` }, h('i', { style: `width:${pct * 100}%` }));

    this.body.append(
      h('h2', {}, h('span', {}, `🎒 ${t('inventory')}`), h('button', { onclick: () => this.close() }, '✕')),
      h('div', { class: 'dim' }, `${t('weight')}: ${inv.totalWeight.toFixed(1)} / ${inv.maxWeight}`),
      wbar,
    );

    const row = h('div', { class: 'row' });
    row.append(this.equipmentView());
    const col = h('div', {}, h('div', { class: 'row' }, h('button', { onclick: () => { inv.sort(); this.host.sfx('click'); this.refresh(); } }, t('act_sort'))), this.gridView(inv.grid, 'bag'));
    row.append(col);
    if (this.container) row.append(h('div', {}, h('h3', {}, `📦 ${t('container')}`), this.gridView(this.container.grid, 'box')));
    this.body.append(row, this.actionBar(), h('div', { class: 'dim' }, t('drag_hint')));
  }

  // ---------- شبكة ----------
  private gridView(grid: Grid, id: string): HTMLElement {
    const c = this.cell;
    const el = h('div', { class: 'igrid', style: `width:${grid.width * c}px;height:${grid.height * c}px` });
    this.views.push({ grid, el, id });
    for (const e of grid.list()) el.append(this.tile(grid, e.stack, e.x, e.y, e.rotated, c));
    return el;
  }

  private tile(grid: Grid, stack: ItemStack, x: number, y: number, rotated: boolean, c: number): HTMLElement {
    const d = ItemDB.get(stack.defId);
    const [w, hh] = Grid.dims(d, rotated);
    const st = spoilState(d, stack);
    const el = h('div', {
      class: `item${this.selected?.uid === stack.uid ? ' sel' : ''}${st === 'stale' ? ' stale' : st === 'rotten' ? ' rotten' : ''}`,
      style: `left:${x * c}px;top:${y * c}px;width:${w * c}px;height:${hh * c}px;border-color:${RARITY_COLORS[d.rarity]}`,
      'data-uid': stack.uid,
    }, d.icon);
    if (stack.count > 1) el.append(h('span', { class: 'cnt' }, stack.count));
    if (d.durability > 0) el.append(h('span', { class: 'dur', style: `width:${clamp01(stack.durability / d.durability) * 100}%;background:${RARITY_COLORS[d.rarity]}` }));
    el.addEventListener('pointerdown', (ev) => this.onDown(ev, grid, stack.uid));
    el.addEventListener('pointerenter', (ev) => this.tooltip.show(tooltipFor(stack), ev.clientX, ev.clientY));
    el.addEventListener('pointermove', (ev) => !this.drag.active && this.tooltip.show(tooltipFor(stack), ev.clientX, ev.clientY));
    el.addEventListener('pointerleave', () => this.tooltip.hide());
    return el;
  }

  // ---------- سحب ----------
  private onDown(ev: PointerEvent, grid: Grid, uid: number): void {
    if (ev.button !== 0 && ev.pointerType === 'mouse') return;
    ev.preventDefault();
    const sx = ev.clientX;
    const sy = ev.clientY;
    let dragging = false;
    const move = (e: PointerEvent): void => {
      if (!dragging && Math.hypot(e.clientX - sx, e.clientY - sy) > 6) {
        dragging = true;
        this.tooltip.hide();
        if (!this.drag.pickup(grid, uid)) {
          dragging = false;
          return;
        }
        this.makeGhost();
      }
      if (dragging) this.moveGhost(e.clientX, e.clientY);
    };
    const up = (e: PointerEvent): void => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      if (dragging) this.finishDrag(e.clientX, e.clientY);
      else {
        this.selected = this.selected?.uid === uid ? null : { uid, grid };
        this.host.sfx('click');
        this.refresh();
      }
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', up);
  }

  private makeGhost(): void {
    const hd = this.drag.held!;
    const d = ItemDB.get(hd.stack.defId);
    const c = this.cell;
    const [w, hh] = Grid.dims(d, hd.rotated);
    this.ghost = h('div', { class: 'item ghost', style: `width:${w * c}px;height:${hh * c}px;border-color:${RARITY_COLORS[d.rarity]}` }, d.icon);
    document.body.append(this.ghost);
    this.render();
  }

  private updateGhostSize(): void {
    if (!this.ghost || !this.drag.held) return;
    const d = ItemDB.get(this.drag.held.stack.defId);
    const [w, hh] = Grid.dims(d, this.drag.held.rotated);
    this.ghost.style.width = `${w * this.cell}px`;
    this.ghost.style.height = `${hh * this.cell}px`;
  }

  private moveGhost(x: number, y: number): void {
    if (!this.ghost) return;
    const w = this.ghost.offsetWidth;
    const hh = this.ghost.offsetHeight;
    this.ghost.style.left = `${x - w / 2}px`;
    this.ghost.style.top = `${y - hh / 2}px`;
  }

  private finishDrag(px: number, py: number): void {
    const held = this.drag.held!;
    const ghostRect = this.ghost!.getBoundingClientRect();
    this.ghost?.remove();
    this.ghost = null;
    const under = document.elementFromPoint(px, py);
    const inv = this.host.session.inventory;

    const hs = under?.closest('[data-hslot]') as HTMLElement | null;
    const view = this.views.find((v) => v.el.contains(under) || v.el === under) ?? this.views.find((v) => {
      const r = v.el.getBoundingClientRect();
      return px >= r.left && px <= r.right && py >= r.top && py <= r.bottom;
    });

    if (hs) {
      const uid = held.stack.uid;
      this.drag.cancel();
      if (inv.grid.get(uid)) inv.hotbar.assign(Number(hs.dataset.hslot), uid);
    } else if (view) {
      const r = view.el.getBoundingClientRect();
      const c = this.cell;
      const x = Math.round((ghostRect.left - r.left) / c);
      const y = Math.round((ghostRect.top - r.top) / c);
      const res = this.drag.drop(view.grid, x, y);
      if (res === 'rejected') {
        this.drag.cancel();
        this.host.sfx('click');
      } else this.host.sfx('equip');
    } else if (!this.root.contains(under) && !(under?.closest('.panel'))) {
      // خارج اللوحة: رمي على الأرض
      const stack = held.stack;
      this.drag.held = null;
      const p = this.host.player();
      this.host.session.ground.drop(stack, p.x - Math.sin(p.yaw) * 1.2, p.y, p.z - Math.cos(p.yaw) * 1.2);
      inv.hotbar.clearUid(stack.uid);
    } else {
      this.drag.cancel();
    }
    inv.onChange?.();
    this.refresh();
  }

  private cancelDrag(): void {
    if (this.drag.active) this.drag.cancel();
    this.ghost?.remove();
    this.ghost = null;
  }

  // ---------- تجهيز ----------
  private equipmentView(): HTMLElement {
    const inv = this.host.session.inventory;
    const wrap = h('div', {}, h('h3', {}, t('equipment')));
    const g = h('div', { class: 'eqgrid' });
    for (const slot of EQUIP_SLOTS) {
      const s = inv.equipment.get(slot);
      const el = h('div', { class: `eqslot${s ? ' full' : ''}`, onclick: () => { if (s) { inv.unequip(slot); this.host.sfx('equip'); this.refresh(); } } },
        s ? ItemDB.get(s.defId).icon : '', h('small', {}, t(`slot_${slot}`)));
      if (s) {
        el.addEventListener('pointerenter', (ev) => this.tooltip.show(tooltipFor(s), ev.clientX, ev.clientY));
        el.addEventListener('pointerleave', () => this.tooltip.hide());
      }
      g.append(el);
    }
    wrap.append(g, h('div', { class: 'dim' }, `🛡 ${inv.equipment.defense} · 🔥 ${inv.equipment.warmth}`));
    return wrap;
  }

  // ---------- إجراءات ----------
  private actionBar(): HTMLElement {
    const bar = h('div', { class: 'actions' });
    const sel = this.selected;
    if (!sel) return bar;
    const inv = this.host.session.inventory;
    const e = sel.grid.get(sel.uid);
    if (!e) {
      this.selected = null;
      return bar;
    }
    const d = ItemDB.get(e.stack.defId);
    bar.append(h('b', {}, `${d.icon} ${itemName(d.id)}`));
    const inBag = sel.grid === inv.grid;
    const btn = (label: string, fn: () => void, primary = false): void => {
      bar.append(h('button', { class: primary ? 'primary' : '', onclick: () => { fn(); this.refresh(); } }, label));
    };
    const usable = ['food', 'drink', 'medicine', 'story'].includes(d.type) || d.id.endsWith('_empty');
    if (inBag && usable) btn(t('act_use'), () => this.use(sel.uid), true);
    if (inBag && ['clothing', 'backpack', 'tool', 'weapon'].includes(d.type)) btn(t('act_equip'), () => { const r = inv.equip(sel.uid); if (!r.ok && r.reason) this.host.notify(r.reason, 'bad'); this.host.sfx('equip'); });
    if (inBag) btn(t('act_hotbar'), () => { const i = inv.hotbar.firstFree(); inv.hotbar.assign(i < 0 ? inv.hotbar.selected : i, sel.uid); });
    if (e.stack.count > 1) btn(t('act_split'), () => { if (sel.grid === inv.grid) inv.split(sel.uid, Math.floor(e.stack.count / 2)); });
    // نقل بين الحقيبة والحاوية
    if (this.container) btn(inBag ? '→ 📦' : '← 🎒', () => this.transfer(sel.grid, sel.uid));
    btn(t('act_drop'), () => this.dropItem(sel.grid, sel.uid));
    return bar;
  }

  private use(uid: number): void {
    const p = this.host.player();
    const r = this.host.session.useItem(uid, p) as { ok: boolean };
    if (r.ok) {
      const d = ItemDB.get(this.host.session.inventory.grid.get(uid)?.stack.defId ?? '');
      void d;
      this.host.sfx('eat');
    }
    this.selected = null;
  }

  private transfer(from: Grid, uid: number): void {
    const inv = this.host.session.inventory;
    const to = from === inv.grid ? this.container!.grid : inv.grid;
    const e = from.get(uid);
    if (!e) return;
    const stack = e.stack;
    from.remove(uid);
    const left = to.addStack(stack);
    if (left > 0) {
      from.addStack({ ...stack, count: left });
      this.host.notify(t('inv_full'), 'bad');
    }
    inv.hotbar.clearUid(uid);
    inv.onChange?.();
    this.selected = null;
  }

  private dropItem(from: Grid, uid: number): void {
    const inv = this.host.session.inventory;
    const e = from.get(uid);
    if (!e) return;
    from.remove(uid);
    inv.hotbar.clearUid(uid);
    const p = this.host.player();
    this.host.session.ground.drop(e.stack, p.x - Math.sin(p.yaw) * 1.2, p.y, p.z - Math.cos(p.yaw) * 1.2);
    inv.onChange?.();
    this.selected = null;
  }
}
