import { getLanguage, t } from '../core/i18n';
import { checkRecipe } from '../crafting/CraftingStation';
import type { Missing, Recipe, Station } from '../crafting/Recipe';
import { ItemDB } from '../inventory/ItemDatabase';
import { clear, h, Panel } from './dom';
import { itemName } from './Tooltip';
import type { UIHost } from './UIHost';

const PROCESSING: Station[] = ['campfire', 'furnace', 'drying_rack'];

function missingText(m: Missing): string {
  switch (m.kind) {
    case 'ingredient': return t('missing_ingredient', { name: itemName(m.id), have: m.have, need: m.need });
    case 'tool': return t('missing_tool', { name: itemName(m.id) });
    case 'station': return t('missing_station', { name: t(`station_${m.station}`) });
    case 'skill': return t('missing_skill', { name: t(`skill_${m.skill}`), need: m.need });
    case 'space': return t('missing_space');
  }
}

export function recipeName(r: Recipe): string {
  return getLanguage() === 'ar' ? r.nameAr : r.nameEn;
}

/** الصناعة: قائمة الوصفات المعروفة + التفاصيل + طابور الصنع + محطات الطهي القريبة */
export class CraftUI extends Panel {
  private sel: string | null = null;
  private filter: Station | 'all' = 'all';
  private list = h('div', { class: 'recipes' });
  private detail = h('div', { class: 'detail' });
  private stations = h('div');
  private queue = h('div');

  constructor(private host: UIHost) {
    super('craft');
    this.root.append(
      h('h2', {}, h('span', {}, `🔨 ${t('crafting')}`), h('button', { onclick: () => this.close() }, '✕')),
      h('div', { class: 'tabs', id: 'craft-tabs' }),
      h('div', { class: 'row' }, this.list, this.detail),
      this.queue,
      this.stations,
    );
  }

  private tabs(): void {
    const el = this.root.querySelector('#craft-tabs')!;
    clear(el);
    for (const f of ['all', 'hand', 'workbench', 'campfire', 'furnace', 'drying_rack'] as const) {
      el.append(h('button', { class: this.filter === f ? 'on' : '', onclick: () => { this.filter = f; this.refresh(); } }, f === 'all' ? '★' : t(`station_${f}`)));
    }
  }

  refresh(): void {
    const s = this.host.session;
    const p = this.host.player();
    this.tabs();
    clear(this.list);
    const all = s.recipes.list(this.filter === 'all' ? undefined : this.filter);
    if (all.length === 0) this.list.append(h('div', { class: 'dim' }, t('no_recipes')));
    // الممكن صنعه أولًا
    const rows = all.map((r) => ({ r, ok: s.canCraft(r, p) })).sort((a, b) => Number(b.ok) - Number(a.ok));
    for (const { r, ok } of rows) {
      this.list.append(h('div', { class: `recipe${this.sel === r.id ? ' sel' : ''}${ok ? '' : ' no'}`, onclick: () => { this.sel = r.id; this.host.sfx('click'); this.refresh(); } },
        h('span', { class: 'ic' }, ItemDB.get(r.output.id).icon), h('span', {}, recipeName(r)), r.output.count > 1 ? h('span', { class: 'dim' }, `×${r.output.count}`) : null));
    }
    this.renderDetail();
    this.renderQueue();
    this.renderStations();
  }

  private renderDetail(): void {
    clear(this.detail);
    const r = this.sel ? this.host.session.recipes.get(this.sel) : undefined;
    if (!r) return;
    const s = this.host.session;
    const p = this.host.player();
    const missing = checkRecipe(r, s.inventory, s.craftContext(p));
    const d = ItemDB.get(r.output.id);
    this.detail.append(h('h3', {}, `${d.icon} ${recipeName(r)} ×${r.output.count}`), h('div', { class: 'dim' }, `${t('station')}: ${t(`station_${r.station}`)} · ⏱ ${r.time}s`), h('h3', {}, t('ingredients')));
    for (const g of r.ingredients) {
      const have = s.inventory.count(g.id);
      this.detail.append(h('div', { class: `ing${have < g.count ? ' miss' : ''}` }, h('span', {}, `${ItemDB.get(g.id).icon} ${itemName(g.id)}`), h('span', {}, `${have}/${g.count}`)));
    }
    if (r.tools.length) this.detail.append(h('h3', {}, t('tools_needed')), ...r.tools.map((x) => h('div', { class: 'ing' }, `${ItemDB.get(x).icon} ${itemName(x)}`)));
    for (const m of missing) if (m.kind !== 'ingredient') this.detail.append(h('div', { class: 'ing miss' }, missingText(m)));

    const processing = PROCESSING.includes(r.station);
    const target = processing ? s.nearestProcessing(p, r.station) : null;
    const can = missing.length === 0 && (!processing || !!target);
    const label = processing ? t('prompt_cook') : t('craft');
    this.detail.append(h('div', { class: 'actions' }, h('button', {
      class: 'primary', disabled: !can,
      onclick: () => this.doCraft(r, processing, target?.pieceId ?? null),
    }, label)));
    if (processing && !target) this.detail.append(h('div', { class: 'ing miss' }, t('missing_station', { name: t(`station_${r.station}`) })));
  }

  private doCraft(r: Recipe, processing: boolean, pieceId: number | null): void {
    const s = this.host.session;
    const p = this.host.player();
    if (processing && pieceId !== null) {
      const res = s.processInsert(pieceId, r);
      if (!res.ok) this.host.notify(res.reason ?? '', 'bad');
      else this.host.sfx('craft');
    } else {
      const res = r.time <= 0.5 ? s.craftNow(r, p) : s.craftQueued(r, p);
      if (res.ok) {
        this.host.sfx('craft');
        if (r.time <= 0.5) this.host.notify(t('crafted', { name: recipeName(r) }), 'good');
      } else if (res.missing[0]) this.host.notify(missingText(res.missing[0]), 'bad');
    }
    this.refresh();
  }

  private renderQueue(): void {
    clear(this.queue);
    const jobs = this.host.session.craftQueue.jobs;
    if (!jobs.length) return;
    this.queue.append(h('h3', {}, '⏳'));
    jobs.forEach((j, i) => {
      const pct = i === 0 ? Math.round((1 - j.remaining / Math.max(0.01, j.recipe.time)) * 100) : 0;
      this.queue.append(h('div', { class: 'ing' }, h('span', {}, recipeName(j.recipe)), h('span', {}, i === 0 ? `${pct}%` : '…')));
    });
  }

  private renderStations(): void {
    clear(this.stations);
    const s = this.host.session;
    const p = this.host.player();
    for (const kind of PROCESSING) {
      const near = s.nearestProcessing(p, kind);
      if (!near) continue;
      const fire = near.fire;
      this.stations.append(h('h3', {}, `${t(`station_${kind}`)}${fire ? (fire.burning ? ' 🔥' : ' ·') : ''}`));
      const box = h('div', { class: 'slots' });
      near.station.slots.forEach((slot, i) => {
        if (!slot) return void box.append(h('div', { class: 'pslot dim' }, t('cook_slot_empty')));
        const pct = Math.min(100, Math.round((slot.progress / slot.recipe.time) * 100));
        const st = slot.state === 'done' ? t('cook_ready') : slot.state === 'burnt' ? t('cook_burnt') : `${pct}%`;
        box.append(h('div', { class: 'pslot' }, ItemDB.get(slot.recipe.output.id).icon, h('span', {}, recipeName(slot.recipe)), h('span', { class: 'dim' }, st),
          h('button', { disabled: slot.state === 'processing', onclick: () => { const r = s.processCollect(near.pieceId, i); if (r.ok) this.host.sfx('pickup'); this.refresh(); } }, t('cook_collect'))));
      });
      this.stations.append(box);
    }
  }
}
