import { t } from '../core/i18n';
import { h } from './dom';
import type { UIHost } from './UIHost';

interface Step { key: string; done: (host: UIHost, st: { moved: number; hp: number }) => boolean }

const KEY = 'island-survival:tutorial';

/** تلميحات تدريجية تنتقل تلقائيًا عند تحقق الشرط (تحرك، جمع، فتح الحقيبة...) */
export class Tutorial {
  readonly root = h('div', { class: 'tut', hidden: true });
  private idx = 0;
  private enabled = true;
  private start: { x: number; z: number } | null = null;
  private moved = 0;
  private opened = new Set<string>();
  private hold = 0;

  private steps: Step[] = [
    { key: 'tut_move', done: (_h, s) => s.moved > 6 },
    { key: 'tut_gather', done: (host) => host.session.inventory.count('stick') + host.session.inventory.count('stone') + host.session.inventory.count('plant_fiber') > 0 },
    { key: 'tut_bag', done: () => this.opened.has('backpack') },
    { key: 'tut_craft', done: () => this.opened.has('craft') },
    { key: 'tut_fire', done: (host) => host.session.fires.size > 0 },
    { key: 'tut_water', done: (host) => host.session.survival.stats.thirst > 98 || host.session.inventory.count('water_boiled') > 0 },
    { key: 'tut_sleep', done: (host) => host.session.sleeping || host.session.day >= 1 },
  ];

  constructor(private host: UIHost) {
    try {
      if (localStorage.getItem(KEY) === 'done') this.enabled = false;
    } catch { /* وضع خاص */ }
    this.root.hidden = !this.enabled;
  }

  /** تُستدعى عند فتح لوحة (لتحقق خطوات الحقيبة/الصنع) */
  panelOpened(id: string): void {
    this.opened.add(id);
  }

  update(dt: number): void {
    if (!this.enabled) return;
    const p = this.host.player();
    this.start ??= { x: p.x, z: p.z };
    this.moved = Math.max(this.moved, Math.hypot(p.x - this.start.x, p.z - this.start.z));
    const step = this.steps[this.idx];
    if (!step) return this.finish();
    this.root.hidden = false;
    this.root.textContent = t(step.key);
    if (this.hold > 0) {
      this.hold -= dt;
      return;
    }
    if (step.done(this.host, { moved: this.moved, hp: this.host.session.survival.stats.health })) {
      this.idx++;
      this.hold = 1.5; // نترك رسالة النجاح لحظة قبل التالية
      this.root.hidden = true;
    }
  }

  private finish(): void {
    this.enabled = false;
    this.root.hidden = true;
    try { localStorage.setItem(KEY, 'done'); } catch { /* تجاهل */ }
  }

  skip(): void {
    this.finish();
  }
}
