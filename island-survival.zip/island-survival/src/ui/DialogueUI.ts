import { getLanguage, t } from '../core/i18n';
import { ItemDB } from '../inventory/ItemDatabase';
import { trustLevel } from '../entities/NPC';
import { DialogueRunner } from '../quests/Dialogue';
import { clear, h, Panel } from './dom';
import { itemName } from './Tooltip';
import type { UIHost } from './UIHost';

/** نافذة الحوار مع ناجٍ: تطبّق تأثير كل اختيار فورًا (الثقة، الرايات، الإجراءات) */
export class DialogueUI extends Panel {
  private runner: DialogueRunner | null = null;
  private npcId = '';
  private applied = { flags: 0, actions: 0, trust: 0 };
  private giftMode = false;
  onEnd: (() => void) | null = null;

  constructor(private host: UIHost) {
    super('dialogue', 'dlg');
  }

  start(npcId: string): void {
    const s = this.host.session;
    this.npcId = npcId;
    this.runner = new DialogueRunner(s.npcs.find((n) => n.def.id === npcId)!.def.dialogue, s.dialogueContext(npcId));
    this.applied = { flags: 0, actions: 0, trust: 0 };
    this.giftMode = false;
    this.open();
  }

  protected override onClose(): void {
    this.runner = null;
    this.onEnd?.();
  }

  private applyNew(): void {
    const r = this.runner!;
    const log = r.log;
    const delta = {
      trustDelta: log.trustDelta - this.applied.trust,
      flags: log.flags.slice(this.applied.flags),
      actions: log.actions.slice(this.applied.actions),
    };
    this.applied = { flags: log.flags.length, actions: log.actions.length, trust: log.trustDelta };
    if (delta.trustDelta || delta.flags.length || delta.actions.length) this.host.session.applyDialogue(this.npcId, delta);
  }

  refresh(): void {
    clear(this.root);
    const s = this.host.session;
    const npc = s.npcs.find((n) => n.def.id === this.npcId);
    if (!npc || !this.runner) return;
    const ar = getLanguage() === 'ar';
    this.root.append(h('div', { class: 'who' }, `${ar ? npc.def.nameAr : npc.def.nameEn} · ${t('trust')}: ${t(`trust_${trustLevel(npc.trust)}`)}`));

    if (this.giftMode) return this.renderGift();

    const cur = this.runner.current();
    if (!cur) return this.close();
    this.root.append(h('div', { class: 'line' }, ar ? cur.node.textAr : cur.node.textEn));
    const box = h('div', { class: 'choices' });
    for (const { index, choice } of cur.choices) {
      box.append(h('button', { onclick: () => {
        this.runner!.choose(index);
        this.applyNew();
        this.host.sfx('click');
        if (this.runner!.finished) this.close();
        else this.refresh();
      } }, ar ? choice.textAr : choice.textEn));
    }
    box.append(h('button', { onclick: () => this.giftToggle(true) }, `🎁 ${t('dlg_gift')}`), h('button', { onclick: () => this.close() }, t('dlg_end')));
    this.root.append(box);
  }

  private giftToggle(on: boolean): void {
    this.giftMode = on;
    this.refresh();
  }

  private renderGift(): void {
    const s = this.host.session;
    this.root.append(h('div', { class: 'line' }, t('gift_pick')));
    const box = h('div', { class: 'choices' });
    const seen = new Set<string>();
    for (const e of s.inventory.grid.list()) {
      if (seen.has(e.stack.defId)) continue;
      seen.add(e.stack.defId);
      const d = ItemDB.get(e.stack.defId);
      if (d.type === 'story') continue;
      box.append(h('button', { onclick: () => {
        const r = s.giveGift(this.npcId, d.id);
        this.host.notify(r.accepted ? t('gift_accepted') : t('gift_refused'), r.accepted ? 'good' : 'bad');
        this.giftToggle(false);
      } }, `${d.icon} ${itemName(d.id)} ×${s.inventory.count(d.id)}`));
    }
    box.append(h('button', { onclick: () => this.giftToggle(false) }, t('back')));
    this.root.append(box);
  }
}
