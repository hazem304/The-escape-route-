import { clamp } from '../core/math';
import type { V2 } from '../ai/Steering';

export interface BoatInput {
  /** -1 يسار .. 1 يمين */
  steer: number;
  /** 0..1 تجديف */
  paddle: number;
  /** الشراع مرفوع؟ */
  sail: boolean;
}

export interface BoatWorld {
  height(x: number, z: number): number;
  wind: V2;
  /** ارتفاع الأمواج 0..~2.4 لإبطاء القارب في العواصف */
  waveAmp: number;
}

/**
 * طوافة: دفع بالمجداف أو الشراع (يستفيد من اتجاه الريح)، ودوران بطيء، واحتكاك الماء.
 * لا تدخل اليابسة: ترتطم وتتوقف عند الشاطئ.
 */
export class Boat {
  pos: V2;
  heading: number; // 0 = +z
  speed = 0;
  readonly radius = 2.2;
  boarded = false;

  constructor(x: number, z: number, heading = 0) {
    this.pos = { x, z };
    this.heading = heading;
  }

  /** الأمواج العاتية تقلل السرعة القصوى */
  private maxSpeed(input: BoatInput, w: BoatWorld): number {
    let max = input.paddle > 0 ? 2.2 : 0;
    if (input.sail) {
      const fx = Math.sin(this.heading);
      const fz = Math.cos(this.heading);
      const wl = Math.hypot(w.wind.x, w.wind.z);
      if (wl > 0.01) {
        // مركّبة الريح الموافقة لاتجاه الإبحار: خلفية = قوة كاملة، معاكسة = لا شيء (الشراع لا يتجه ضد الريح مباشرة)
        const align = (fx * w.wind.x + fz * w.wind.z) / wl;
        max = Math.max(max, Math.max(0, align) * Math.min(6, wl * 0.5 + 1.5));
      }
    }
    return max * (1 - clamp((w.waveAmp - 1) * 0.25, 0, 0.5));
  }

  update(dt: number, input: BoatInput, w: BoatWorld): void {
    if (!this.boarded) {
      // الطوافة غير المستخدمة تنجرف ببطء مع الريح
      this.speed *= Math.exp(-dt * 0.8);
      this.move(dt, w, w.wind.x * 0.02, w.wind.z * 0.02);
      return;
    }
    // الدوران يحتاج سرعة (دفة) لكن المجداف يدير حتى الوقوف ببطء
    const turnRate = 0.35 + Math.min(1, Math.abs(this.speed) / 2) * 0.5;
    this.heading += input.steer * turnRate * dt;

    const target = this.maxSpeed(input, w);
    const accel = target > this.speed ? 0.9 : 1.4; // تسارع أبطأ من الاحتكاك
    this.speed += clamp(target - this.speed, -accel * dt, accel * dt);

    this.move(dt, w, 0, 0);
  }

  private move(dt: number, w: BoatWorld, driftX: number, driftZ: number): void {
    const dx = Math.sin(this.heading) * this.speed * dt + driftX * dt;
    const dz = Math.cos(this.heading) * this.speed * dt + driftZ * dt;
    const nx = this.pos.x + dx;
    const nz = this.pos.z + dz;
    if (this.canFloat(nx, nz, w)) {
      this.pos.x = nx;
      this.pos.z = nz;
    } else {
      // ارتطام: نوقف السرعة ونحاول الانزلاق على محور واحد
      if (this.canFloat(nx, this.pos.z, w)) this.pos.x = nx;
      else if (this.canFloat(this.pos.x, nz, w)) this.pos.z = nz;
      this.speed = 0;
    }
  }

  /** يطفو إن كان الماء أعمق من 0.6م عند المركز ونقاط حول الحافة */
  canFloat(x: number, z: number, w: BoatWorld): boolean {
    if (w.height(x, z) > -0.6) return false;
    for (let k = 0; k < 6; k++) {
      const a = (k / 6) * Math.PI * 2;
      if (w.height(x + Math.cos(a) * this.radius, z + Math.sin(a) * this.radius) > -0.1) return false;
    }
    return true;
  }
}
