import * as THREE from 'three';

/**
 * شخصية بديلة Procedural بنسب بشرية (حتى وصول ملفات GLB النهائية).
 * الهيكل هرمي (مفاصل = Object3D) لتسهيل التحريك بالكود، وتُستبدل لاحقًا بهيكل عظمي حقيقي.
 */
export interface HumanoidRig {
  root: THREE.Group;
  hips: THREE.Group;
  spine: THREE.Group;
  head: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  /** ارتفاع الشخصية بالمتر */
  height: number;
}

function limb(length: number, radius: number, mat: THREE.Material): THREE.Mesh {
  // كبسولة تمتد للأسفل انطلاقًا من المفصل (نقطة الأصل أعلى الطرف)
  const geo = new THREE.CapsuleGeometry(radius, Math.max(0.01, length - 2 * radius), 4, 10);
  geo.translate(0, -length / 2, 0);
  const m = new THREE.Mesh(geo, mat);
  m.castShadow = true;
  return m;
}

export function createHumanoid(height = 1.75): HumanoidRig {
  const s = height / 1.75;

  const skin = new THREE.MeshStandardMaterial({ color: 0xc89a78, roughness: 0.75 });
  const shirt = new THREE.MeshStandardMaterial({ color: 0x4a5d6b, roughness: 0.9 });
  const pants = new THREE.MeshStandardMaterial({ color: 0x3b3a34, roughness: 0.95 });
  const hair = new THREE.MeshStandardMaterial({ color: 0x2a1c14, roughness: 0.9 });
  const shoe = new THREE.MeshStandardMaterial({ color: 0x241a14, roughness: 0.8 });

  const root = new THREE.Group();
  root.name = 'HumanoidRoot';

  // الوركان عند ارتفاع ~0.95م
  const hips = new THREE.Group();
  hips.position.y = 0.95 * s;
  root.add(hips);

  const pelvis = new THREE.Mesh(new THREE.BoxGeometry(0.34 * s, 0.2 * s, 0.2 * s), pants);
  pelvis.castShadow = true;
  hips.add(pelvis);

  const spine = new THREE.Group();
  spine.position.y = 0.08 * s;
  hips.add(spine);

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.17 * s, 0.34 * s, 4, 12), shirt);
  torso.position.y = 0.3 * s;
  torso.scale.z = 0.7;
  torso.castShadow = true;
  spine.add(torso);

  const head = new THREE.Group();
  head.position.y = 0.67 * s;
  spine.add(head);
  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.11 * s, 20, 16), skin);
  skull.position.y = 0.12 * s;
  skull.scale.set(0.95, 1.1, 1.0);
  skull.castShadow = true;
  head.add(skull);
  const hairCap = new THREE.Mesh(
    new THREE.SphereGeometry(0.115 * s, 20, 12, 0, Math.PI * 2, 0, Math.PI * 0.55),
    hair,
  );
  hairCap.position.y = 0.14 * s;
  head.add(hairCap);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.045 * s, 0.05 * s, 0.08 * s, 10), skin);
  neck.position.y = 0.02 * s;
  head.add(neck);

  // ذراعان: المفصل عند الكتف
  const makeArm = (side: 1 | -1): THREE.Group => {
    const g = new THREE.Group();
    g.position.set(side * 0.22 * s, 0.56 * s, 0);
    const upper = limb(0.3 * s, 0.045 * s, shirt);
    g.add(upper);
    const fore = new THREE.Group();
    fore.position.y = -0.3 * s;
    fore.name = 'forearm';
    fore.add(limb(0.28 * s, 0.04 * s, skin));
    g.add(fore);
    spine.add(g);
    return g;
  };
  const armL = makeArm(-1);
  const armR = makeArm(1);

  // ساقان: المفصل عند الورك
  const makeLeg = (side: 1 | -1): THREE.Group => {
    const g = new THREE.Group();
    g.position.set(side * 0.09 * s, -0.05 * s, 0);
    g.add(limb(0.45 * s, 0.07 * s, pants));
    const shin = new THREE.Group();
    shin.position.y = -0.45 * s;
    shin.name = 'shin';
    shin.add(limb(0.43 * s, 0.055 * s, pants));
    const foot = new THREE.Mesh(new THREE.BoxGeometry(0.09 * s, 0.07 * s, 0.24 * s), shoe);
    foot.position.set(0, -0.44 * s, 0.05 * s);
    foot.castShadow = true;
    shin.add(foot);
    g.add(shin);
    hips.add(g);
    return g;
  };
  const legL = makeLeg(-1);
  const legR = makeLeg(1);

  // الوجه يتجه نحو +Z محليًا
  return { root, hips, spine, head, armL, armR, legL, legR, height };
}

/** حالات الحركة التي يفهمها المحرّك البدائي */
export type LocomotionState = 'idle' | 'walk' | 'run' | 'crouch' | 'jump' | 'swim';

/** تحريك بدائي بالجيب (sine) للمشي والجري — يُستبدل بـ AnimationMixer عند وجود GLB */
export class HumanoidAnimator {
  private phase = 0;
  private blend = 0;

  constructor(private rig: HumanoidRig) {}

  update(dt: number, state: LocomotionState, speed: number): void {
    const { hips, spine, armL, armR, legL, legR } = this.rig;
    const moving = state === 'walk' || state === 'run' || state === 'swim';
    const targetBlend = moving ? 1 : 0;
    this.blend += (targetBlend - this.blend) * Math.min(1, dt * 10);

    const freq = state === 'run' ? 11 : state === 'swim' ? 4 : 7;
    this.phase += dt * freq * Math.min(1.5, 0.4 + speed / 3);
    const amp = (state === 'run' ? 0.9 : state === 'swim' ? 0.5 : 0.55) * this.blend;
    const sw = Math.sin(this.phase);

    legL.rotation.x = sw * amp;
    legR.rotation.x = -sw * amp;
    armL.rotation.x = -sw * amp * 0.8;
    armR.rotation.x = sw * amp * 0.8;

    const shinL = legL.getObjectByName('shin');
    const shinR = legR.getObjectByName('shin');
    if (shinL) shinL.rotation.x = Math.max(0, -sw) * amp * 0.9;
    if (shinR) shinR.rotation.x = Math.max(0, sw) * amp * 0.9;

    // ارتداد الجسم أثناء الحركة
    const bob = Math.abs(Math.cos(this.phase)) * 0.025 * this.blend;
    const crouchDrop = state === 'crouch' ? 0.35 : 0;
    hips.position.y += ((0.95 - crouchDrop + bob) * (this.rig.height / 1.75) - hips.position.y) * Math.min(1, dt * 12);

    spine.rotation.x = state === 'crouch' ? 0.35 : state === 'run' ? 0.12 : 0;

    if (state === 'jump') {
      legL.rotation.x = -0.5;
      legR.rotation.x = 0.3;
      armL.rotation.x = -2.2;
      armR.rotation.x = -2.2;
    }
    if (state === 'swim') {
      spine.rotation.x = 1.1;
    }
  }
}
