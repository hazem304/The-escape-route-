import { Action, Condition, Cooldown, Selector, Sequence, Timed, type BTNode } from '../ai/BehaviorTree';
import { perceive, type Senses, type Stimulus } from '../ai/Perception';
import { avoidObstacles, flee, headingOf, len, seek, sub, turnToward, wander, type V2 } from '../ai/Steering';
import type { Random } from '../core/Random';

export type SpeciesId = 'deer' | 'boar' | 'crab' | 'seagull' | 'shark' | 'snake' | 'jaguar';
export type Domain = 'land' | 'water' | 'air';
export type Temperament = 'prey' | 'neutral' | 'predator';
export type AnimalState = 'idle' | 'graze' | 'wander' | 'flee' | 'chase' | 'attack' | 'sleep' | 'patrol' | 'dead';

export interface Species {
  id: SpeciesId;
  nameAr: string;
  nameEn: string;
  hp: number;
  walk: number;
  run: number;
  domain: Domain;
  temperament: Temperament;
  nocturnal: boolean;
  senses: Senses;
  damage: number;
  attackRange: number;
  attackCooldown: number;
  /** نصف قطر "الراحة" الذي يهرب عنده الفريسة / يكمن عنده الأفعى */
  alertRadius: number;
  biomes: string[];
  drops: Array<{ id: string; min: number; max: number; chance: number }>;
  /** كثافة التوزيع الأولي: مسافة الشبكة (م) واحتمال القبول */
  spacing: number;
  probability: number;
}

export const SPECIES: Record<SpeciesId, Species> = {
  deer: {
    id: 'deer', nameAr: 'غزال', nameEn: 'Deer', hp: 40, walk: 1.6, run: 8, domain: 'land', temperament: 'prey', nocturnal: false,
    senses: { sight: 40, fov: 1.6, hearing: 30, smell: 35 }, damage: 0, attackRange: 0, attackCooldown: 0, alertRadius: 25,
    biomes: ['grass', 'jungle'], drops: [{ id: 'raw_meat', min: 2, max: 4, chance: 1 }, { id: 'raw_hide', min: 1, max: 2, chance: 1 }, { id: 'bone', min: 1, max: 3, chance: 0.8 }, { id: 'animal_fat', min: 1, max: 1, chance: 0.5 }],
    spacing: 48, probability: 0.55,
  },
  boar: {
    id: 'boar', nameAr: 'خنزير بري', nameEn: 'Wild Boar', hp: 70, walk: 1.8, run: 7, domain: 'land', temperament: 'neutral', nocturnal: false,
    senses: { sight: 25, fov: 1.2, hearing: 25, smell: 40 }, damage: 14, attackRange: 1.8, attackCooldown: 1.6, alertRadius: 12,
    biomes: ['jungle', 'grass'], drops: [{ id: 'raw_meat', min: 3, max: 5, chance: 1 }, { id: 'raw_hide', min: 1, max: 2, chance: 1 }, { id: 'bone', min: 1, max: 2, chance: 0.7 }, { id: 'animal_fat', min: 1, max: 2, chance: 0.7 }],
    spacing: 60, probability: 0.5,
  },
  crab: {
    id: 'crab', nameAr: 'سلطعون', nameEn: 'Crab', hp: 6, walk: 0.8, run: 3.2, domain: 'land', temperament: 'prey', nocturnal: false,
    senses: { sight: 10, fov: 3, hearing: 8, smell: 0 }, damage: 0, attackRange: 0, attackCooldown: 0, alertRadius: 5,
    biomes: ['beach'], drops: [{ id: 'raw_crab', min: 1, max: 1, chance: 1 }, { id: 'shell', min: 0, max: 1, chance: 0.4 }],
    spacing: 14, probability: 0.45,
  },
  seagull: {
    id: 'seagull', nameAr: 'نورس', nameEn: 'Seagull', hp: 8, walk: 5, run: 9, domain: 'air', temperament: 'prey', nocturnal: false,
    senses: { sight: 60, fov: 2.6, hearing: 30, smell: 0 }, damage: 0, attackRange: 0, attackCooldown: 0, alertRadius: 15,
    biomes: ['beach', 'shallows'], drops: [{ id: 'feather', min: 2, max: 5, chance: 1 }, { id: 'raw_meat', min: 1, max: 1, chance: 0.8 }, { id: 'egg', min: 0, max: 1, chance: 0.3 }],
    spacing: 40, probability: 0.6,
  },
  shark: {
    id: 'shark', nameAr: 'قرش', nameEn: 'Shark', hp: 140, walk: 2.5, run: 9, domain: 'water', temperament: 'predator', nocturnal: false,
    senses: { sight: 45, fov: 1.5, hearing: 60, smell: 80 }, damage: 28, attackRange: 2.6, attackCooldown: 1.4, alertRadius: 40,
    biomes: ['deepSea'], drops: [{ id: 'raw_meat', min: 4, max: 7, chance: 1 }, { id: 'animal_fat', min: 2, max: 3, chance: 1 }, { id: 'bone', min: 2, max: 4, chance: 1 }],
    spacing: 120, probability: 0.8,
  },
  snake: {
    id: 'snake', nameAr: 'أفعى', nameEn: 'Snake', hp: 14, walk: 0.9, run: 4.5, domain: 'land', temperament: 'predator', nocturnal: false,
    senses: { sight: 8, fov: 2, hearing: 10, smell: 6 }, damage: 9, attackRange: 1.4, attackCooldown: 1.2, alertRadius: 2.8,
    biomes: ['jungle', 'rock', 'grass'], drops: [{ id: 'raw_meat', min: 1, max: 1, chance: 0.9 }, { id: 'raw_hide', min: 0, max: 1, chance: 0.3 }],
    spacing: 40, probability: 0.4,
  },
  jaguar: {
    id: 'jaguar', nameAr: 'نمر', nameEn: 'Jaguar', hp: 110, walk: 2.4, run: 11, domain: 'land', temperament: 'predator', nocturnal: true,
    senses: { sight: 50, fov: 1.4, hearing: 55, smell: 60 }, damage: 24, attackRange: 2, attackCooldown: 1.2, alertRadius: 45,
    biomes: ['jungle', 'rock'], drops: [{ id: 'raw_meat', min: 3, max: 5, chance: 1 }, { id: 'raw_hide', min: 2, max: 3, chance: 1 }, { id: 'bone', min: 2, max: 3, chance: 1 }],
    spacing: 150, probability: 0.7,
  },
};

/** ما تحتاجه الحيوانات من العالم */
export interface AIWorld {
  height(x: number, z: number): number;
  slope(x: number, z: number): number;
  biomeAt(x: number, z: number): string;
  hour: number;
  wind: V2;
  rnd: Random;
  player: { pos: V2; stimulus: Stimulus; inWater: boolean; alive: boolean; /** ارتفاع اللاعب فوق قاع الماء إن كان يسبح */ y: number };
  onAttackPlayer(damage: number, by: Animal): void;
}

interface Blackboard {
  self: Animal;
  w: AIWorld;
  dt: number;
}

let animalUid = 1;

export class Animal {
  readonly id = animalUid++;
  hp: number;
  pos: V2;
  y = 0;
  heading: number;
  vel: V2 = { x: 0, z: 0 };
  state: AnimalState = 'idle';
  /** ثوانٍ منذ آخر إصابة من اللاعب (للمحايدين) */
  hurtTimer = 0;
  /** يعرف موقع التهديد؟ */
  threat: V2 | null = null;
  /** مدى انتباهه 0..1 */
  alert = 0;
  attackTimer = 0;
  /** مدة بقاء الجثة */
  corpseTime = 0;
  private lastSeenTimer = 0;
  private wanderHeading: number;
  private brain: BTNode<Blackboard>;
  /** مركز المنزل: يعود إليه عند الملل */
  readonly home: V2;

  constructor(readonly species: Species, x: number, z: number, rnd: Random) {
    this.hp = species.hp;
    this.pos = { x, z };
    this.home = { x, z };
    this.heading = rnd.range(0, Math.PI * 2);
    this.wanderHeading = this.heading;
    this.brain = this.buildBrain();
  }

  get alive(): boolean {
    return this.state !== 'dead';
  }

  // ---------- أضرار ----------

  /** @returns الغنائم إن مات (مرة واحدة) */
  hurt(amount: number, from: V2, rnd: Random): Array<{ id: string; count: number }> | null {
    if (!this.alive) return null;
    this.hp -= amount;
    this.hurtTimer = 12;
    this.threat = { ...from };
    this.alert = 1;
    if (this.hp <= 0) {
      this.state = 'dead';
      this.vel = { x: 0, z: 0 };
      this.corpseTime = 120;
      const drops: Array<{ id: string; count: number }> = [];
      for (const d of this.species.drops) {
        if (rnd.next() > d.chance) continue;
        const n = d.min + Math.floor(rnd.next() * (d.max - d.min + 1));
        if (n > 0) drops.push({ id: d.id, count: n });
      }
      return drops;
    }
    return null;
  }

  // ---------- التحديث ----------

  update(dt: number, w: AIWorld): void {
    if (!this.alive) {
      this.corpseTime -= dt;
      return;
    }
    this.hurtTimer = Math.max(0, this.hurtTimer - dt);
    this.attackTimer = Math.max(0, this.attackTimer - dt);
    this.sense(dt, w);
    this.brain.tick({ self: this, w, dt }, dt);
    this.integrate(dt, w);
  }

  private sense(dt: number, w: AIWorld): void {
    const p = perceive(this.pos, this.heading, this.species.senses, w.player.stimulus, w.wind);
    // الأسماك لا ترى فوق الماء ولا تشم اللاعب على اليابسة
    const reachable = this.species.domain !== 'water' || w.player.inWater;
    if (p.detected !== 'none' && w.player.alive && reachable) {
      this.threat = { ...w.player.pos };
      this.alert = Math.min(1, this.alert + dt * (p.detected === 'see' ? 4 : 2));
      this.lastSeenTimer = 6;
    } else {
      this.lastSeenTimer = Math.max(0, this.lastSeenTimer - dt);
      if (this.lastSeenTimer === 0) {
        this.alert = Math.max(0, this.alert - dt * 0.25);
        if (this.alert === 0) this.threat = null;
      }
    }
  }

  distToThreat(): number {
    return this.threat ? len(sub(this.threat, this.pos)) : Infinity;
  }

  // ---------- الحركة ----------

  private desired: V2 = { x: 0, z: 0 };

  setDesired(v: V2): void {
    this.desired = v;
  }

  private canStand(x: number, z: number, w: AIWorld): boolean {
    const d = this.species.domain;
    if (d === 'air') return true;
    const h = w.height(x, z);
    if (d === 'water') return h < -3.5;
    // برًا: فوق الماء وبميل معقول، والسلطعون يبقى قرب الشاطئ
    if (h < 0.45 || w.slope(x, z) > 0.65) return false;
    if (this.species.id === 'crab' && h > 5) return false;
    return true;
  }

  private integrate(dt: number, w: AIWorld): void {
    // تسارع نحو السرعة المرغوبة
    const k = Math.min(1, dt * 5);
    this.vel.x += (this.desired.x - this.vel.x) * k;
    this.vel.z += (this.desired.z - this.vel.z) * k;
    const speed = len(this.vel);
    if (speed > 0.05) this.heading = turnToward(this.heading, headingOf(this.vel), dt * 6);

    let nx = this.pos.x + this.vel.x * dt;
    let nz = this.pos.z + this.vel.z * dt;
    if (!this.canStand(nx, nz, w)) {
      // نجرّب الانزلاق على محور واحد قبل التوقف
      if (this.canStand(nx, this.pos.z, w)) nz = this.pos.z;
      else if (this.canStand(this.pos.x, nz, w)) nx = this.pos.x;
      else {
        nx = this.pos.x;
        nz = this.pos.z;
        this.vel.x = this.vel.z = 0;
        // نغيّر اتجاه التجوال حتى لا نعلق
        this.wanderHeading = avoidObstacles(this.pos, this.wanderHeading, (x, z) => this.canStand(x, z, w), 3);
      }
    }
    this.pos.x = nx;
    this.pos.z = nz;
    const ground = w.height(nx, nz);
    this.y = this.species.domain === 'air' ? Math.max(ground, 0) + 8 : this.species.domain === 'water' ? -1.2 : ground;
  }

  // ---------- أدمغة الأنواع ----------

  private moveToward(target: V2, speed: number): void {
    this.setDesired(seek(this.pos, target, speed));
  }

  private stop(): void {
    this.setDesired({ x: 0, z: 0 });
  }

  /** تجوال: يتغير الاتجاه كل فترة */
  private wanderAction(speed: number): Action<Blackboard> {
    let timer = 0;
    return new Action<Blackboard>((c, dt) => {
      timer -= dt;
      if (timer <= 0) {
        timer = 2 + c.w.rnd.next() * 3;
        this.wanderHeading = wander(this.wanderHeading, c.w.rnd.next() * 2 - 1, 1.2);
        // يميل للعودة للمنزل إن ابتعد
        const d = len(sub(this.home, this.pos));
        if (d > 60) this.wanderHeading = headingOf(sub(this.home, this.pos));
      }
      this.wanderHeading = avoidObstacles(this.pos, this.wanderHeading, (x, z) => this.canStand(x, z, c.w), 3);
      this.setDesired({ x: Math.sin(this.wanderHeading) * speed, z: Math.cos(this.wanderHeading) * speed });
      this.state = 'wander';
      return 'running';
    });
  }

  private grazeAction(): Timed<Blackboard> {
    return new Timed<Blackboard>(() => 3 + Math.random() * 3, () => {
      this.stop();
      this.state = 'graze';
    });
  }

  private fleeAction(): Action<Blackboard> {
    return new Action<Blackboard>((c) => {
      if (!this.threat) return 'failure';
      const away = flee(this.pos, this.threat, this.species.run);
      // الاتجاه الهارب يتجنب العوائق
      const h = avoidObstacles(this.pos, headingOf(away), (x, z) => this.canStand(x, z, c.w), 4);
      this.setDesired({ x: Math.sin(h) * this.species.run, z: Math.cos(h) * this.species.run });
      this.state = 'flee';
      return 'running';
    });
  }

  private chaseAndAttack(): Selector<Blackboard> {
    const attack = new Cooldown<Blackboard>(
      this.species.attackCooldown,
      new Action((c) => {
        this.stop();
        this.state = 'attack';
        if (c.w.player.alive) c.w.onAttackPlayer(this.species.damage, this);
        return 'success';
      }),
    );
    return new Selector<Blackboard>([
      new Sequence<Blackboard>([new Condition((c) => this.distToPlayer(c.w) <= this.species.attackRange), attack]),
      new Action<Blackboard>((c) => {
        if (!this.threat) return 'failure';
        const target = this.distToPlayer(c.w) < 60 ? c.w.player.pos : this.threat;
        this.moveToward(target, this.species.run);
        this.state = 'chase';
        return 'running';
      }),
    ]);
  }

  private distToPlayer(w: AIWorld): number {
    return len(sub(w.player.pos, this.pos));
  }

  private isNight(w: AIWorld): boolean {
    return w.hour < 5.5 || w.hour >= 19;
  }

  private buildBrain(): BTNode<Blackboard> {
    const sp = this.species;
    const sleep = new Sequence<Blackboard>([
      new Condition((c) => (sp.nocturnal ? !this.isNight(c.w) : this.isNight(c.w)) && this.alert < 0.3),
      new Action((c) => {
        // يعود لمنزله وينام
        if (len(sub(this.home, this.pos)) > 4) this.moveToward(this.home, sp.walk);
        else this.stop();
        this.state = 'sleep';
        void c;
        return 'running';
      }),
    ]);
    const idleWander = new Selector<Blackboard>([
      new Sequence<Blackboard>([new Condition(() => Math.random() < 0.004), this.grazeAction()]),
      this.wanderAction(sp.walk),
    ]);

    switch (sp.id) {
      case 'deer':
      case 'crab':
      case 'seagull':
        return new Selector<Blackboard>([
          new Sequence<Blackboard>([new Condition(() => this.threat !== null && this.distToThreat() < sp.alertRadius && this.alert > 0.4), this.fleeAction()]),
          ...(sp.id === 'deer' ? [sleep] : []),
          idleWander,
        ]);

      case 'boar':
        return new Selector<Blackboard>([
          // يهرب إن كاد يموت
          new Sequence<Blackboard>([new Condition(() => this.hp < sp.hp * 0.25 && this.threat !== null), this.fleeAction()]),
          // محايد: يهاجم فقط إذا أُصيب مؤخرًا أو اقتُرب منه جدًا
          new Sequence<Blackboard>([new Condition((c) => (this.hurtTimer > 0 && this.distToPlayer(c.w) < 30) || (this.distToPlayer(c.w) < 4 && this.alert > 0.6)), this.chaseAndAttack()]),
          sleep,
          idleWander,
        ]);

      case 'snake':
        return new Selector<Blackboard>([
          // كمين: يهاجم فقط ضمن نصف القطر القصير
          new Sequence<Blackboard>([new Condition((c) => this.distToPlayer(c.w) <= sp.alertRadius && c.w.player.alive), this.chaseAndAttack()]),
          new Sequence<Blackboard>([new Condition(() => this.hurtTimer > 0 && this.threat !== null), this.fleeAction()]),
          new Action<Blackboard>(() => {
            this.stop();
            this.state = 'idle';
            return 'running';
          }),
        ]);

      case 'jaguar':
        return new Selector<Blackboard>([
          new Sequence<Blackboard>([new Condition(() => this.hp < sp.hp * 0.2 && this.threat !== null), this.fleeAction()]),
          // نهارًا لا يهاجم إلا إن استُفز
          new Sequence<Blackboard>([new Condition((c) => this.threat !== null && c.w.player.alive && (this.isNight(c.w) || this.hurtTimer > 0) && this.alert > 0.35), this.chaseAndAttack()]),
          sleep,
          new Action<Blackboard>((c) => {
            // دورية ليلية داخل نطاق المنزل
            const w = this.wanderAction(sp.walk);
            this.state = 'patrol';
            return w.tick(c, c.dt);
          }),
        ]);

      case 'shark':
        return new Selector<Blackboard>([
          new Sequence<Blackboard>([new Condition((c) => this.threat !== null && c.w.player.inWater && c.w.player.alive && this.alert > 0.3), this.chaseAndAttack()]),
          new Action<Blackboard>((c) => {
            const w = this.wanderAction(sp.walk);
            const r = w.tick(c, c.dt);
            this.state = 'patrol';
            return r;
          }),
        ]);
    }
  }
}
