import * as THREE from 'three';
import { CAMERA } from '../constants';
import type { EventBus, GameEvents } from '../core/EventBus';
import type { Physics } from '../core/Physics';
import type { Player } from './Player';

export type ViewMode = 'first' | 'third';

/**
 * كاميرا الشخص الأول والثالث مع انتقال سلس بينهما وتجنّب الاختراق عبر Raycast.
 */
export class CameraRig {
  readonly camera: THREE.PerspectiveCamera;
  mode: ViewMode = 'third';

  /** 0 = شخص أول، 1 = شخص ثالث (مستمر لتنعيم الانتقال) */
  private blend = 1;
  private smoothedDistance: number = CAMERA.thirdDistance;

  private tmpEye = new THREE.Vector3();
  private tmpDir = new THREE.Vector3();
  private tmpRight = new THREE.Vector3();
  private tmpTarget = new THREE.Vector3();
  private tmpPos = new THREE.Vector3();
  private euler = new THREE.Euler(0, 0, 0, 'YXZ');

  constructor(
    aspect: number,
    fov: number,
    private bus: EventBus<GameEvents>,
    private physics: Physics,
  ) {
    this.camera = new THREE.PerspectiveCamera(fov, aspect, CAMERA.near, CAMERA.far);
  }

  setAspect(aspect: number): void {
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
  }

  setFov(fov: number): void {
    this.camera.fov = fov;
    this.camera.updateProjectionMatrix();
  }

  toggle(): void {
    this.mode = this.mode === 'first' ? 'third' : 'first';
    this.bus.emit('player:viewChanged', { mode: this.mode });
  }

  get showsBody(): boolean {
    // المجسّم يظهر في الشخص الثالث أو أثناء الانتقال
    return this.blend > 0.15;
  }

  update(dt: number, player: Player): void {
    const target = this.mode === 'third' ? 1 : 0;
    this.blend += (target - this.blend) * Math.min(1, dt * CAMERA.blendSpeed);
    if (Math.abs(this.blend - target) < 0.001) this.blend = target;

    this.euler.set(player.pitch, player.yaw, 0);
    this.tmpDir.set(0, 0, -1).applyEuler(this.euler); // اتجاه النظر
    this.tmpRight.set(1, 0, 0).applyEuler(this.euler);

    player.getEyePosition(this.tmpEye);

    // موضع الشخص الأول = العينان
    const firstPos = this.tmpPos.copy(this.tmpEye);

    // موضع الشخص الثالث: خلف الكتف
    const pivot = this.tmpTarget.copy(this.tmpEye);
    pivot.y += CAMERA.thirdHeight - 1.62;
    pivot.addScaledVector(this.tmpRight, CAMERA.shoulderOffset);

    let desired: number = CAMERA.thirdDistance;
    if (this.physics.isReady) {
      const hit = this.physics.raycast(
        pivot,
        { x: -this.tmpDir.x, y: -this.tmpDir.y, z: -this.tmpDir.z },
        CAMERA.thirdDistance + 0.3,
        player.collider,
      );
      if (hit !== null) desired = Math.max(CAMERA.thirdMinDistance, hit - 0.3);
    }
    // اقتراب سريع عند الاصطدام وابتعاد بطيء عند زواله
    const k = desired < this.smoothedDistance ? 20 : 4;
    this.smoothedDistance += (desired - this.smoothedDistance) * Math.min(1, dt * k);

    const thirdPos = new THREE.Vector3().copy(pivot).addScaledVector(this.tmpDir, -this.smoothedDistance);

    this.camera.position.lerpVectors(firstPos, thirdPos, this.blend);
    this.camera.rotation.copy(this.euler);
  }
}
