import { Random } from '../core/Random';
import { Animal, SPECIES, type AIWorld, type SpeciesId } from './Animal';
import type { TerrainSampler } from '../world/ScatterGenerator';

/** نطاق التحديث حول اللاعب (الأبعد "نائم" لتوفير المعالج) */
const ACTIVE_RADIUS = 130;
const DESPAWN_NIGHT_RADIUS = 220;

/**
 * يوزّع الحيوانات حسب البيوم ويديرها: تحديث القريب فقط، ظهور المفترسات الليلي، حذف الجثث،
 * وتوزيع غنائم القتل.
 */
export class AnimalManager {
  readonly animals: Animal[] = [];
  onKilled: ((a: Animal, drops: Array<{ id: string; count: number }>) => void) | null = null;
  private nightSpawnTimer = 0;

  populate(sampler: TerrainSampler, seed: string, half: number, keepClear: Array<{ x: number; z: number; r: number }> = []): number {
    let n = 0;
    for (const sp of Object.values(SPECIES)) {
      const rnd = new Random(`${seed}:animal:${sp.id}`);
      const cells = Math.floor((half * 2) / sp.spacing);
      for (let j = 0; j < cells; j++) {
        for (let i = 0; i < cells; i++) {
          const jx = rnd.next();
          const jz = rnd.next();
          const accept = rnd.next();
          if (accept > sp.probability) continue;
          const x = -half + (i + jx) * sp.spacing;
          const z = -half + (j + jz) * sp.spacing;
          if (keepClear.some((c) => Math.hypot(c.x - x, c.z - z) < c.r)) continue;
          if (!sp.biomes.includes(sampler.biomeAt(x, z))) continue;
          if (sp.domain === 'land' && sampler.slope(x, z) > 0.6) continue;
          this.animals.push(new Animal(sp, x, z, rnd));
          n++;
        }
      }
    }
    return n;
  }

  count(id: SpeciesId, alive = true): number {
    return this.animals.filter((a) => a.species.id === id && (!alive || a.alive)).length;
  }

  /** @param w عالم الذكاء الاصطناعي الحالي */
  update(dt: number, w: AIWorld): void {
    const p = w.player.pos;
    for (const a of this.animals) {
      const d = Math.hypot(a.pos.x - p.x, a.pos.z - p.z);
      if (d <= ACTIVE_RADIUS || !a.alive) a.update(dt, w);
    }

    // حذف الجثث القديمة
    for (let i = this.animals.length - 1; i >= 0; i--) {
      const a = this.animals[i];
      if (!a.alive && a.corpseTime <= 0) this.animals.splice(i, 1);
    }

    this.nightSpawnTimer -= dt;
    if (this.nightSpawnTimer <= 0) {
      this.nightSpawnTimer = 10;
      this.manageNightPredators(w);
    }
  }

  /** نمور تظهر ليلًا قرب اللاعب في الغابة/الصخور وتختفي نهارًا حين تبتعد */
  private manageNightPredators(w: AIWorld): void {
    const night = w.hour < 5.5 || w.hour >= 19;
    const p = w.player.pos;
    const sp = SPECIES.jaguar;

    if (night && w.player.alive) {
      const near = this.animals.filter((a) => a.species.id === 'jaguar' && a.alive && Math.hypot(a.pos.x - p.x, a.pos.z - p.z) < 150).length;
      const biome = w.biomeAt(p.x, p.z);
      if (near < 2 && sp.biomes.includes(biome)) {
        const ang = w.rnd.range(0, Math.PI * 2);
        const dist = w.rnd.range(70, 100);
        const x = p.x + Math.cos(ang) * dist;
        const z = p.z + Math.sin(ang) * dist;
        if (sp.biomes.includes(w.biomeAt(x, z)) && w.slope(x, z) < 0.6) this.animals.push(new Animal(sp, x, z, w.rnd));
      }
    } else {
      for (let i = this.animals.length - 1; i >= 0; i--) {
        const a = this.animals[i];
        if (a.species.id === 'jaguar' && a.alive && Math.hypot(a.pos.x - p.x, a.pos.z - p.z) > DESPAWN_NIGHT_RADIUS * 0.5 && a.state === 'sleep') this.animals.splice(i, 1);
      }
    }
  }

  /** ضربة من اللاعب على أقرب حيوان داخل المدى والمخروط */
  playerAttack(w: AIWorld, origin: { x: number; z: number }, yaw: number, damage: number, reach = 2.6): { hit: Animal | null; killed: boolean } {
    let best: Animal | null = null;
    let bd = reach;
    const fx = -Math.sin(yaw);
    const fz = -Math.cos(yaw);
    for (const a of this.animals) {
      if (!a.alive) continue;
      const dx = a.pos.x - origin.x;
      const dz = a.pos.z - origin.z;
      const d = Math.hypot(dx, dz);
      if (d > bd) continue;
      // أمام اللاعب (cos > 0.3)
      if ((dx * fx + dz * fz) / (d || 1) < 0.3 && d > 1) continue;
      bd = d;
      best = a;
    }
    if (!best) return { hit: null, killed: false };
    const drops = best.hurt(damage, origin, w.rnd);
    if (drops) this.onKilled?.(best, drops);
    return { hit: best, killed: drops !== null };
  }
}
