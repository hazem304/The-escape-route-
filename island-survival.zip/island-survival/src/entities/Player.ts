import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import { GRAVITY, PHYSICS_STEP, PLAYER, WORLD } from '../constants';
import type { EventBus, GameEvents } from '../core/EventBus';
import type { Input } from '../core/Input';
import type { Physics } from '../core/Physics';
import { createHumanoid, HumanoidAnimator, type LocomotionState } from './HumanoidMesh';

/**
 * اللاعب: حركة بمتحكم شخصية كبسولة (Rapier KinematicCharacterController).
 * - المشي/الجري/الانحناء/القفز
 * - سباحة بسيطة عند النزول تحت منسوب الماء
 * - اتجاه النظر (yaw/pitch) تقرأه الكاميرا
 */
export class Player {
  readonly object = new THREE.Group();
  /** اتجاه النظر */
  yaw = 0;
  pitch = 0;

  readonly velocity = new THREE.Vector3();
  grounded = false;
  inWater = false;
  crouching = false;
  locomotion: LocomotionState = 'idle';
  /** مضاعِف السرعة من الحمولة والإصابات (تضبطه اللعبة كل إطار) */
  speedMul = 1;
  /** يمنع الجري (نفَس منتهٍ، ساق مكسورة...) */
  runAllowed = true;
  /** تجميد الإدخال (نوم، لوحة، قارب) */
  frozen = false;

  readonly collider: RAPIER.Collider;
  private body: RAPIER.RigidBody;
  private controller: RAPIER.KinematicCharacterController;

  private currentHeight: number = PLAYER.height;
  private wasGrounded = false;
  private lastVerticalSpeed = 0;

  private rig = createHumanoid(PLAYER.height);
  private animator = new HumanoidAnimator(this.rig);

  /** الموضع في الخطوة السابقة للاستيفاء بين خطوات الفيزياء */
  private prevPos = new THREE.Vector3();
  private currPos = new THREE.Vector3();

  constructor(
    _physics: Physics,
    private input: Input,
    private bus: EventBus<GameEvents>,
    spawn: THREE.Vector3,
  ) {
    const c = _physics.createCharacter(PLAYER.radius, PLAYER.height, {
      x: spawn.x,
      y: spawn.y + PLAYER.height / 2 + 0.05,
      z: spawn.z,
    });
    this.body = c.body;
    this.collider = c.collider;
    this.controller = c.controller;

    this.object.add(this.rig.root);
    this.currPos.copy(spawn);
    this.prevPos.copy(spawn);
    this.object.position.copy(spawn);
  }

  /** موضع القدمين (لا مركز الكبسولة) */
  get feet(): THREE.Vector3 {
    return this.currPos;
  }

  /** موضع العينين للكاميرا */
  getEyePosition(out = new THREE.Vector3()): THREE.Vector3 {
    const eye = this.crouching ? PLAYER.eyeHeight - 0.4 : PLAYER.eyeHeight;
    return out.copy(this.object.position).setY(this.object.position.y + eye);
  }

  /** يُستدعى مرة لكل إطار قبل خطوات الفيزياء: قراءة الإدخال */
  applyLook(dx: number, dy: number, sensitivity: number, invertY: boolean): void {
    this.yaw -= dx * sensitivity;
    this.pitch -= dy * sensitivity * (invertY ? -1 : 1);
    const lim = 1.35;
    this.pitch = Math.max(-lim, Math.min(lim, this.pitch));
  }

  /** خطوة فيزياء ثابتة */
  fixedUpdate(): void {
    const dt = PHYSICS_STEP;
    this.prevPos.copy(this.currPos);

    const mv = this.frozen ? { x: 0, y: 0 } : this.input.getMove();
    const wantsRun = !this.frozen && this.runAllowed && this.input.isDown('run') && mv.y > 0.1;
    const wantsCrouch = !this.frozen && this.input.isDown('crouch');
    this.crouching = wantsCrouch && !this.inWater;

    // السباحة: نعتبر اللاعب في الماء إذا غمر الماء صدره
    const chestY = this.currPos.y + 1.2;
    const nowInWater = chestY < WORLD.waterLevel;
    if (nowInWater !== this.inWater) {
      this.inWater = nowInWater;
      this.bus.emit('player:waterChanged', { inWater: nowInWater });
    }

    // اتجاه الحركة نسبةً إلى yaw
    const sin = Math.sin(this.yaw);
    const cos = Math.cos(this.yaw);
    const fx = -sin;
    const fz = -cos;
    const rx = cos;
    const rz = -sin;
    const wishX = fx * mv.y + rx * mv.x;
    const wishZ = fz * mv.y + rz * mv.x;

    let speed: number = PLAYER.walkSpeed;
    if (this.inWater) speed = PLAYER.swimSpeed;
    else if (this.crouching) speed = PLAYER.crouchSpeed;
    else if (wantsRun) speed = PLAYER.runSpeed;

    speed *= this.speedMul;
    const accel = this.grounded || this.inWater ? PLAYER.acceleration : PLAYER.acceleration * PLAYER.airControl;
    const targetVX = wishX * speed;
    const targetVZ = wishZ * speed;
    this.velocity.x = approach(this.velocity.x, targetVX, accel * dt);
    this.velocity.z = approach(this.velocity.z, targetVZ, accel * dt);

    // الرأسي
    if (this.inWater) {
      // طفو: نسحب اللاعب نحو سطح الماء ونسمح بالغوص/الصعود بالقفز والانحناء
      const targetY = (!this.frozen && this.input.isDown('jump') ? 1 : 0) - (!this.frozen && this.input.isDown('crouch') ? 1 : 0);
      this.velocity.y = approach(this.velocity.y, targetY * 1.8 - (this.currPos.y + 1.0 - WORLD.waterLevel) * 0.8, 10 * dt);
    } else {
      this.velocity.y += GRAVITY * dt;
      if (this.grounded && !this.frozen && this.input.isDown('jump') && !this.crouching) {
        this.velocity.y = PLAYER.jumpSpeed;
        this.grounded = false;
        this.bus.emit('player:jump', undefined);
      }
    }

    // الكبسولة تتقلص عند الانحناء
    const targetHeight = this.crouching ? PLAYER.height * 0.65 : PLAYER.height;
    this.currentHeight += (targetHeight - this.currentHeight) * Math.min(1, dt * 12);

    // تحريك المتحكم
    const desired = {
      x: this.velocity.x * dt,
      y: this.velocity.y * dt,
      z: this.velocity.z * dt,
    };
    this.controller.computeColliderMovement(this.collider, desired);
    const corrected = this.controller.computedMovement();
    const t = this.body.translation();
    this.body.setNextKinematicTranslation({ x: t.x + corrected.x, y: t.y + corrected.y, z: t.z + corrected.z });

    this.lastVerticalSpeed = this.velocity.y;
    this.grounded = this.controller.computedGrounded();
    if (this.grounded && this.velocity.y < 0) this.velocity.y = 0;
    // اصطدام بالسقف
    if (!this.grounded && desired.y > 0 && corrected.y < desired.y * 0.5) this.velocity.y = 0;

    if (this.grounded && !this.wasGrounded && this.lastVerticalSpeed < -4) {
      this.bus.emit('player:land', { speed: -this.lastVerticalSpeed });
    }
    this.wasGrounded = this.grounded;

    // موضع القدمين = مركز الكبسولة - نصف الارتفاع
    const nt = this.body.translation();
    this.currPos.set(nt.x + 0, nt.y - PLAYER.height / 2 - 0.0, nt.z);

    // الحالة الحركية للتحريك
    const hSpeed = Math.hypot(this.velocity.x, this.velocity.z);
    if (this.inWater) this.locomotion = 'swim';
    else if (!this.grounded) this.locomotion = 'jump';
    else if (this.crouching) this.locomotion = 'crouch';
    else if (hSpeed > PLAYER.walkSpeed + 0.8) this.locomotion = 'run';
    else if (hSpeed > 0.3) this.locomotion = 'walk';
    else this.locomotion = 'idle';
  }

  /** تحديث العرض لكل إطار: استيفاء الموضع وتحريك المجسّم */
  renderUpdate(dt: number, alpha: number, showBody: boolean): void {
    this.object.position.lerpVectors(this.prevPos, this.currPos, alpha);

    // المجسّم يدور تدريجيًا نحو اتجاه الحركة (أو اتجاه النظر في الشخص الأول)
    const hSpeed = Math.hypot(this.velocity.x, this.velocity.z);
    let targetYaw = this.yaw;
    if (hSpeed > 0.3 && showBody) targetYaw = Math.atan2(-this.velocity.x, -this.velocity.z);
    // الوجه نحو +Z محليًا ⇒ ندير 180°
    targetYaw += Math.PI;
    this.rig.root.rotation.y = lerpAngle(this.rig.root.rotation.y, targetYaw, Math.min(1, dt * 10));
    this.rig.root.visible = showBody;

    this.animator.update(dt, this.locomotion, hSpeed);
  }

  /** تموضع ابتدائي/انتقال فوري */
  teleport(p: THREE.Vector3): void {
    this.body.setTranslation({ x: p.x, y: p.y + PLAYER.height / 2 + 0.05, z: p.z }, true);
    this.currPos.copy(p);
    this.prevPos.copy(p);
    this.object.position.copy(p);
    this.velocity.set(0, 0, 0);
  }
}

function approach(current: number, target: number, maxDelta: number): number {
  if (current < target) return Math.min(current + maxDelta, target);
  return Math.max(current - maxDelta, target);
}

function lerpAngle(a: number, b: number, t: number): number {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}
