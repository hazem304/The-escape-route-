import { Schedule, type Activity, type ScheduleEntry } from '../ai/Schedule';
import type { V2 } from '../ai/Steering';
import { arrive, len, sub } from '../ai/Steering';
import type { DialogueGraph } from '../quests/Dialogue';
import { clamp } from '../core/math';

export type NPCId = 'layla' | 'omar' | 'yusuf';

export interface NPCDef {
  id: NPCId;
  nameAr: string;
  nameEn: string;
  bioAr: string;
  bioEn: string;
  schedule: ScheduleEntry[];
  dialogue: DialogueGraph;
  /** عناصر يحبها (هدية = ثقة) */
  likes: Record<string, number>;
}

/** مستويات الثقة */
export type TrustLevel = 'hostile' | 'wary' | 'neutral' | 'friendly' | 'trusted';

export function trustLevel(t: number): TrustLevel {
  if (t < -30) return 'hostile';
  if (t < 0) return 'wary';
  if (t < 30) return 'neutral';
  if (t < 70) return 'friendly';
  return 'trusted';
}

/** ناجٍ غير لاعب: جدول يومي، تنقل بين أماكن مسمّاة، ثقة تتطور بالهدايا والحوار */
export class NPC {
  pos: V2;
  trust = 0;
  readonly flags = new Set<string>();
  activity: Activity = 'idle';
  private schedule: Schedule;
  private target: V2;
  private giftsToday = 0;
  private lastDay = -1;

  constructor(readonly def: NPCDef, start: V2) {
    this.pos = { ...start };
    this.target = { ...start };
    this.schedule = new Schedule(def.schedule);
  }

  get level(): TrustLevel {
    return trustLevel(this.trust);
  }

  adjustTrust(delta: number): void {
    this.trust = clamp(this.trust + delta, -100, 100);
  }

  /** هدية: الثقة تزداد بحسب تفضيله، وبحد أقصى 3 هدايا مؤثرة في اليوم */
  gift(itemId: string, day: number): { accepted: boolean; delta: number } {
    if (day !== this.lastDay) {
      this.lastDay = day;
      this.giftsToday = 0;
    }
    if (this.giftsToday >= 3) return { accepted: false, delta: 0 };
    const like = this.def.likes[itemId] ?? 1;
    this.giftsToday++;
    this.adjustTrust(like);
    return { accepted: true, delta: like };
  }

  /** @param places أماكن العالم المسمّاة (camp, beach, forest, ...) */
  update(dt: number, hour: number, places: Record<string, V2>): void {
    const entry = this.schedule.at(hour);
    this.activity = entry.activity;
    this.target = places[entry.place] ?? places.camp ?? this.pos;
    const speed = entry.activity === 'sleep' ? 0 : 1.4;
    const v = arrive(this.pos, this.target, speed, 4);
    this.pos.x += v.x * dt;
    this.pos.z += v.z * dt;
  }

  get atTarget(): boolean {
    return len(sub(this.target, this.pos)) < 1.5;
  }

  toJSON(): { id: NPCId; trust: number; flags: string[]; pos: V2 } {
    return { id: this.def.id, trust: this.trust, flags: [...this.flags], pos: this.pos };
  }

  load(d: { trust: number; flags: string[]; pos: V2 }): void {
    this.trust = d.trust;
    this.flags.clear();
    d.flags.forEach((f) => this.flags.add(f));
    this.pos = { ...d.pos };
  }
}
