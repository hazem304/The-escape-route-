import type { SkillName } from '../survival/Skills';

export type Station = 'hand' | 'workbench' | 'campfire' | 'furnace' | 'drying_rack';

export interface Recipe {
  id: string;
  nameAr: string;
  nameEn: string;
  station: Station;
  ingredients: Array<{ id: string; count: number }>;
  /** أدوات لا تُستهلك لكن تتآكل */
  tools: string[];
  output: { id: string; count: number };
  /** ثوانٍ */
  time: number;
  skill: { name: SkillName; level: number } | null;
  toolWear: number;
  xp: number;
}

export type Missing =
  | { kind: 'ingredient'; id: string; need: number; have: number }
  | { kind: 'tool'; id: string }
  | { kind: 'station'; station: Station }
  | { kind: 'skill'; skill: SkillName; need: number; have: number }
  | { kind: 'space' };
