import type { Inventory } from '../inventory/Inventory';
import type { Recipe, Station } from './Recipe';

export type SlotState = 'processing' | 'done' | 'burnt';

export interface ProcessSlot {
  recipe: Recipe;
  /** ثوانٍ من المعالجة الفعلية (تتأثر بشدة الحرارة) */
  progress: number;
  state: SlotState;
}

export interface StationConfig {
  station: Station;
  slots: number;
  /** أدنى حرارة (0..1) ليعمل */
  minHeat: number;
  /** يحترق الطعام إن تُرك؟ (الفرن لا يحترق) */
  burns: boolean;
  /** ناتج الاحتراق */
  burntItem: string;
}

/** محطة معالجة عامة (طبخ/تدخين/صهر): خانات بمهام تتقدم مع الحرارة */
export class ProcessingStation {
  readonly slots: Array<ProcessSlot | null>;

  constructor(readonly config: StationConfig) {
    this.slots = new Array(config.slots).fill(null);
  }

  get freeSlot(): number {
    return this.slots.indexOf(null);
  }

  /** يستهلك المكونات من الحقيبة ويضعها في خانة. */
  insert(recipe: Recipe, inv: Inventory): { ok: boolean; reason?: 'wrongStation' | 'full' | 'missing' } {
    if (recipe.station !== this.config.station) return { ok: false, reason: 'wrongStation' };
    const i = this.freeSlot;
    if (i < 0) return { ok: false, reason: 'full' };
    if (!recipe.ingredients.every((g) => inv.has(g.id, g.count))) return { ok: false, reason: 'missing' };
    for (const g of recipe.ingredients) inv.remove(g.id, g.count);
    this.slots[i] = { recipe, progress: 0, state: 'processing' };
    return { ok: true };
  }

  /** @param heat شدة النار/الفرن 0..1 (0 = مطفأ) */
  update(dt: number, heat: number): void {
    if (heat < this.config.minHeat) return;
    for (const s of this.slots) {
      if (!s || s.state === 'burnt') continue;
      s.progress += dt * (0.5 + heat * 0.5);
      if (s.state === 'processing' && s.progress >= s.recipe.time) s.state = 'done';
      // الطبخ المتروك أكثر من ضعف الزمن يحترق
      if (this.config.burns && s.state === 'done' && s.progress >= s.recipe.time * 2.2) s.state = 'burnt';
    }
  }

  /** يسحب ناتج خانة (إن انتهت). الخانة تفرغ فقط إن اتسعت الحقيبة. */
  collect(index: number, inv: Inventory): { ok: boolean; item?: string; count?: number } {
    const s = this.slots[index];
    if (!s || s.state === 'processing') return { ok: false };
    const id = s.state === 'burnt' ? this.config.burntItem : s.recipe.output.id;
    const count = s.state === 'burnt' ? 1 : s.recipe.output.count;
    if (inv.add(id, count) > 0) {
      return { ok: false };
    }
    this.slots[index] = null;
    return { ok: true, item: id, count };
  }

  toJSON(): Array<{ recipeId: string; progress: number; state: SlotState } | null> {
    return this.slots.map((s) => (s ? { recipeId: s.recipe.id, progress: s.progress, state: s.state } : null));
  }

  load(data: Array<{ recipeId: string; progress: number; state: SlotState } | null>, find: (id: string) => Recipe | undefined): void {
    data.forEach((d, i) => {
      if (i >= this.slots.length) return;
      const recipe = d ? find(d.recipeId) : undefined;
      this.slots[i] = d && recipe ? { recipe, progress: d.progress, state: d.state } : null;
    });
  }

  /** إلغاء مهمة قبل نهايتها: لا تُعاد المكونات (ضاعت في النار) */
  discard(index: number): void {
    this.slots[index] = null;
  }
}
