import { ProcessingStation } from './ProcessingStation';

/** موقد: 4 خانات، يعمل بنار مشتعلة، يحترق الطعام المتروك */
export const createCampfireStation = (): ProcessingStation =>
  new ProcessingStation({ station: 'campfire', slots: 4, minHeat: 0.2, burns: true, burntItem: 'charcoal' });

/** رف تدخين: بطيء ويحتاج نارًا قريبة؛ لا يحترق */
export const createDryingRack = (): ProcessingStation =>
  new ProcessingStation({ station: 'drying_rack', slots: 3, minHeat: 0.15, burns: false, burntItem: 'charcoal' });
