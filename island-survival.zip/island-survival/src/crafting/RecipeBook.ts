import raw from '../data/recipes.json';
import type { Recipe, Station } from './Recipe';

/** مكتبة الوصفات + اكتشافها: تُفتح الوصفة حين يرى اللاعب كل مكوناتها وأدواتها */
export class RecipeBook {
  readonly all: Recipe[] = raw as unknown as Recipe[];
  private byId = new Map<string, Recipe>(this.all.map((r) => [r.id, r]));
  private seen = new Set<string>();
  private unlocked = new Set<string>();

  constructor() {
    // الوصفات اليدوية البسيطة (بلا أدوات ومكوناتها خام) متاحة من البداية
    for (const id of ['rope_fiber', 'rope_vine', 'tinder_fiber', 'stone_blade', 'thatch', 'campfire_kit', 'hat_straw', 'bandana']) {
      this.unlocked.add(id);
    }
  }

  get(id: string): Recipe | undefined {
    return this.byId.get(id);
  }

  isUnlocked(id: string): boolean {
    return this.unlocked.has(id);
  }

  list(station?: Station, onlyUnlocked = true): Recipe[] {
    return this.all.filter((r) => (!station || r.station === station) && (!onlyUnlocked || this.unlocked.has(r.id)));
  }

  /** يُستدعى عند أول مرة يحصل اللاعب فيها على عنصر. @returns الوصفات التي انفتحت الآن */
  noteItem(defId: string): Recipe[] {
    if (this.seen.has(defId)) return [];
    this.seen.add(defId);
    const opened: Recipe[] = [];
    for (const r of this.all) {
      if (this.unlocked.has(r.id)) continue;
      const needs = [...r.ingredients.map((i) => i.id), ...r.tools];
      if (needs.every((n) => this.seen.has(n))) {
        this.unlocked.add(r.id);
        opened.push(r);
      }
    }
    return opened;
  }

  unlock(id: string): void {
    if (this.byId.has(id)) this.unlocked.add(id);
  }

  toJSON(): { seen: string[]; unlocked: string[] } {
    return { seen: [...this.seen], unlocked: [...this.unlocked] };
  }

  load(data: { seen: string[]; unlocked: string[] }): void {
    this.seen = new Set(data.seen);
    this.unlocked = new Set(data.unlocked);
  }
}
