import { Grid } from '../inventory/Grid';
import type { Inventory } from '../inventory/Inventory';
import { ItemDB } from '../inventory/ItemDatabase';
import type { Skills } from '../survival/Skills';
import type { Missing, Recipe, Station } from './Recipe';

export interface CraftContext {
  /** المحطات المتاحة بالقرب من اللاعب ('hand' دائمًا متاحة) */
  stations: ReadonlySet<Station>;
  skills: Skills;
}

export interface CraftResult {
  ok: boolean;
  missing: Missing[];
  /** ما أُضيف للحقيبة */
  produced?: { id: string; count: number };
}

/** يتحقق من كل المتطلبات ويعيد قائمة النواقص (فارغة = يمكن الصنع) */
export function checkRecipe(recipe: Recipe, inv: Inventory, ctx: CraftContext): Missing[] {
  const missing: Missing[] = [];
  if (recipe.station !== 'hand' && !ctx.stations.has(recipe.station)) {
    missing.push({ kind: 'station', station: recipe.station });
  }
  if (recipe.skill) {
    const have = ctx.skills.level(recipe.skill.name);
    if (have < recipe.skill.level) missing.push({ kind: 'skill', skill: recipe.skill.name, need: recipe.skill.level, have });
  }
  for (const ing of recipe.ingredients) {
    const have = inv.count(ing.id);
    if (have < ing.count) missing.push({ kind: 'ingredient', id: ing.id, need: ing.count, have });
  }
  for (const tool of recipe.tools) {
    if (!findTool(inv, tool)) missing.push({ kind: 'tool', id: tool });
  }
  return missing;
}

/** أفضل أداة صالحة (الأعلى متانة أولًا لتقليل خسارة الأدوات الجيدة؟ لا: الأقل متانة أولًا لاستهلاكها) */
function findTool(inv: Inventory, id: string): number | null {
  const candidates = inv.grid
    .list()
    .filter((e) => e.stack.defId === id && e.stack.durability !== 0)
    .sort((a, b) => a.stack.durability - b.stack.durability);
  return candidates.length ? candidates[0].stack.uid : null;
}

/**
 * يصنع فورًا: يستهلك المكونات ويتلف الأدوات ويضيف الناتج.
 * إن لم يتسع الناتج يُلغى كل شيء (معاملة ذرّية) ويعيد النقص 'space'.
 */
export function craft(recipe: Recipe, inv: Inventory, ctx: CraftContext): CraftResult {
  const missing = checkRecipe(recipe, inv, ctx);
  if (missing.length) return { ok: false, missing };

  const snapshot = JSON.stringify(inv.grid.toJSON());
  const toolUids = recipe.tools.map((t) => findTool(inv, t)!);

  for (const ing of recipe.ingredients) inv.remove(ing.id, ing.count);
  const left = inv.add(recipe.output.id, recipe.output.count);

  if (left > 0) {
    // لا مكان للناتج: استعادة كاملة
    inv.grid = Grid.fromJSON(JSON.parse(snapshot));
    return { ok: false, missing: [{ kind: 'space' }] };
  }

  // الأدوات بعد النجاح فقط (قد تتحطم)
  toolUids.forEach((uid) => inv.damage(uid, recipe.toolWear));
  if (recipe.skill) ctx.skills.addXp(recipe.skill.name, recipe.xp);
  else ctx.skills.addXp('crafting', Math.ceil(recipe.xp / 2));
  return { ok: true, missing: [], produced: { ...recipe.output } };
}

export interface CraftJob {
  recipe: Recipe;
  remaining: number;
}

export interface CraftEvent {
  recipe: Recipe;
  added: number;
  /** ما لم يتسع في الحقيبة (يُرمى على الأرض) */
  overflow: number;
}

/** صنع مؤقّت: المكونات تُستهلك عند البدء والناتج يظهر بعد انقضاء الوقت */
export class CraftQueue {
  readonly jobs: CraftJob[] = [];

  start(recipe: Recipe, inv: Inventory, ctx: CraftContext): CraftResult {
    const missing = checkRecipe(recipe, inv, ctx);
    if (missing.length) return { ok: false, missing };
    for (const ing of recipe.ingredients) inv.remove(ing.id, ing.count);
    this.jobs.push({ recipe, remaining: recipe.time });
    return { ok: true, missing: [] };
  }

  /** يعمل على أول مهمة فقط (صنع متسلسل) */
  update(dt: number, inv: Inventory, ctx: CraftContext): CraftEvent[] {
    const events: CraftEvent[] = [];
    const job = this.jobs[0];
    if (!job) return events;
    job.remaining -= dt;
    if (job.remaining <= 0) {
      this.jobs.shift();
      const left = inv.add(job.recipe.output.id, job.recipe.output.count);
      for (const t of job.recipe.tools) {
        const uid = findTool(inv, t);
        if (uid !== null) inv.damage(uid, job.recipe.toolWear);
      }
      if (job.recipe.skill) ctx.skills.addXp(job.recipe.skill.name, job.recipe.xp);
      events.push({ recipe: job.recipe, added: job.recipe.output.count - left, overflow: left });
    }
    return events;
  }

  /** إلغاء: يعيد المكونات للحقيبة قدر الإمكان */
  cancel(index: number, inv: Inventory): void {
    const [job] = this.jobs.splice(index, 1);
    if (!job) return;
    for (const ing of job.recipe.ingredients) inv.add(ing.id, ing.count);
  }

  get progress(): number {
    const j = this.jobs[0];
    return j ? 1 - j.remaining / j.recipe.time : 0;
  }
}

/** وصف مختصر للنقص لعرضه (النصوص تُترجم في الواجهة) */
export function describeMissing(m: Missing): string {
  switch (m.kind) {
    case 'ingredient': return `${ItemDB.get(m.id).nameEn} ${m.have}/${m.need}`;
    case 'tool': return `tool: ${ItemDB.get(m.id).nameEn}`;
    case 'station': return `station: ${m.station}`;
    case 'skill': return `${m.skill} ${m.have}/${m.need}`;
    case 'space': return 'no space';
  }
}
