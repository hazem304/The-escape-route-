import { ProcessingStation } from './ProcessingStation';

/** فرن صهر: 2 خانتان، يحتاج حرارة عالية (≥ 0.5)، لا يحترق الناتج */
export const createFurnace = (): ProcessingStation =>
  new ProcessingStation({ station: 'furnace', slots: 2, minHeat: 0.5, burns: false, burntItem: 'scrap_metal' });
