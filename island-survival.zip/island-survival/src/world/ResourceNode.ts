import type { Random } from '../core/Random';

/** أنواع عقد الموارد في العالم */
export type NodeKind =
  | 'palm' | 'jungleTree' | 'boulder' | 'ironRock' | 'copperRock'
  | 'berryBush' | 'fiberPlant' | 'bamboo' | 'mushroomPatch' | 'clayBank';

export type GatherAction = 'chop' | 'mine' | 'hand' | 'dig';

export interface DropEntry {
  id: string;
  min: number;
  max: number;
  chance: number;
}

export interface NodeDef {
  kind: NodeKind;
  action: GatherAction;
  /** أدنى قوة أداة مطلوبة (0 = اليد تكفي) */
  minPower: number;
  hp: number;
  /** يُعطى عند كل ضربة (احتمال) */
  hitDrops: DropEntry[];
  /** يُعطى عند الاستنفاد/السقوط */
  finalDrops: DropEntry[];
  /** ساعات لعب حتى يعود */
  respawnHours: number;
  /** نصف قطر وارتفاع الاصطدام/الاستهداف (قبل scale) */
  radius: number;
  height: number;
  /** هل يمنع حركة اللاعب (جسم صلب) */
  solid: boolean;
}

const D = (id: string, min: number, max: number, chance = 1): DropEntry => ({ id, min, max, chance });

export const NODE_DEFS: Record<NodeKind, NodeDef> = {
  palm: {
    kind: 'palm', action: 'chop', minPower: 0.9, hp: 60,
    hitDrops: [D('palm_leaf', 1, 1, 0.3), D('coconut', 1, 1, 0.15)],
    finalDrops: [D('wood_log', 2, 3), D('palm_leaf', 3, 5), D('coconut', 1, 3, 0.7), D('plant_fiber', 2, 4)],
    respawnHours: 240, radius: 0.35, height: 9, solid: true,
  },
  jungleTree: {
    kind: 'jungleTree', action: 'chop', minPower: 0.9, hp: 90,
    hitDrops: [D('stick', 1, 2, 0.4), D('bark', 1, 1, 0.25)],
    finalDrops: [D('wood_log', 3, 5), D('stick', 3, 6), D('resin', 1, 2, 0.4), D('vine', 1, 3, 0.5)],
    respawnHours: 360, radius: 0.5, height: 12, solid: true,
  },
  boulder: {
    kind: 'boulder', action: 'mine', minPower: 0.9, hp: 70,
    hitDrops: [D('stone', 1, 2, 0.7), D('flint', 1, 1, 0.12)],
    finalDrops: [D('stone', 3, 6), D('flint', 1, 2, 0.5), D('sand', 0, 2, 0.3)],
    respawnHours: 480, radius: 0.9, height: 1.4, solid: true,
  },
  ironRock: {
    kind: 'ironRock', action: 'mine', minPower: 1.0, hp: 110,
    hitDrops: [D('stone', 1, 1, 0.4), D('iron_ore', 1, 1, 0.45)],
    finalDrops: [D('iron_ore', 2, 4), D('stone', 2, 4), D('scrap_metal', 0, 1, 0.2)],
    respawnHours: 720, radius: 1.0, height: 1.6, solid: true,
  },
  copperRock: {
    kind: 'copperRock', action: 'mine', minPower: 1.0, hp: 100,
    hitDrops: [D('stone', 1, 1, 0.4), D('copper_ore', 1, 1, 0.45)],
    finalDrops: [D('copper_ore', 2, 3), D('stone', 2, 3), D('sulfur', 0, 1, 0.15)],
    respawnHours: 720, radius: 1.0, height: 1.5, solid: true,
  },
  berryBush: {
    kind: 'berryBush', action: 'hand', minPower: 0, hp: 1,
    hitDrops: [], finalDrops: [D('berries', 2, 5), D('stick', 0, 1, 0.3)],
    respawnHours: 48, radius: 0.6, height: 1.0, solid: false,
  },
  fiberPlant: {
    kind: 'fiberPlant', action: 'hand', minPower: 0, hp: 1,
    hitDrops: [], finalDrops: [D('plant_fiber', 2, 4), D('medicinal_herb', 0, 1, 0.2), D('seeds', 0, 1, 0.15)],
    respawnHours: 36, radius: 0.5, height: 0.8, solid: false,
  },
  bamboo: {
    kind: 'bamboo', action: 'chop', minPower: 0.9, hp: 40,
    hitDrops: [], finalDrops: [D('bamboo', 2, 4), D('vine', 0, 2, 0.4)],
    respawnHours: 200, radius: 0.7, height: 6, solid: true,
  },
  mushroomPatch: {
    kind: 'mushroomPatch', action: 'hand', minPower: 0, hp: 1,
    hitDrops: [], finalDrops: [D('mushroom', 1, 3), D('edible_roots', 0, 1, 0.2)],
    respawnHours: 72, radius: 0.4, height: 0.3, solid: false,
  },
  clayBank: {
    kind: 'clayBank', action: 'dig', minPower: 0.9, hp: 30,
    hitDrops: [D('clay', 1, 2, 0.8)], finalDrops: [D('clay', 3, 6), D('sand', 1, 3)],
    respawnHours: 300, radius: 1.2, height: 0.6, solid: false,
  },
};

/** قدرات الأداة الممسوكة */
export interface ToolPower {
  chop: number;
  mine: number;
  dig: number;
  /** ضرر الضربة الأساسي */
  damage: number;
}

export const BARE_HANDS: ToolPower = { chop: 0, mine: 0, dig: 0, damage: 4 };

export function toolPowerOf(effects: Record<string, number | string> | null): ToolPower {
  if (!effects) return BARE_HANDS;
  const n = (k: string): number => (typeof effects[k] === 'number' ? (effects[k] as number) : 0);
  return { chop: n('chop'), mine: n('mine'), dig: n('dig'), damage: Math.max(4, n('damage')) };
}

export interface NodeState {
  id: number;
  kind: NodeKind;
  x: number;
  y: number;
  z: number;
  scale: number;
  rotY: number;
  hp: number;
  alive: boolean;
  /** ساعة اللعبة (تراكمية) التي يعود فيها */
  respawnAt: number;
}

export type HitFailure = 'wrongTool' | 'dead';

export interface HitResult {
  ok: boolean;
  reason?: HitFailure;
  damage: number;
  destroyed: boolean;
  drops: Array<{ id: string; count: number }>;
}

/** ينفّذ ضربة على عقدة. القوة الفعلية للأداة تحدد الضرر، واليد تعمل فقط على الأنواع اليدوية. */
export function applyHit(node: NodeState, tool: ToolPower, rnd: Random, gatherBonus = 0): HitResult {
  if (!node.alive) return { ok: false, reason: 'dead', damage: 0, destroyed: false, drops: [] };
  const def = NODE_DEFS[node.kind];

  const power = def.action === 'chop' ? tool.chop : def.action === 'mine' ? tool.mine : def.action === 'dig' ? tool.dig : 1;
  if (power < def.minPower) return { ok: false, reason: 'wrongTool', damage: 0, destroyed: false, drops: [] };

  const damage = def.action === 'hand' ? def.hp : tool.damage * Math.max(1, power) * (0.85 + rnd.next() * 0.3);
  node.hp -= damage;
  const destroyed = node.hp <= 0;
  if (destroyed) node.alive = false;

  const drops: Array<{ id: string; count: number }> = [];
  const roll = (list: DropEntry[]): void => {
    for (const d of list) {
      if (rnd.next() >= d.chance) continue;
      let n = d.min + Math.floor(rnd.next() * (d.max - d.min + 1));
      // مكافأة الجمع: جزء صحيح مضمون + كسر باحتمال
      const extra = n * gatherBonus;
      n += Math.floor(extra) + (rnd.next() < extra - Math.floor(extra) ? 1 : 0);
      if (n > 0) drops.push({ id: d.id, count: n });
    }
  };
  if (!destroyed) roll(def.hitDrops);
  else roll(def.finalDrops);

  return { ok: true, damage, destroyed, drops: mergeDrops(drops) };
}

function mergeDrops(list: Array<{ id: string; count: number }>): Array<{ id: string; count: number }> {
  const m = new Map<string, number>();
  for (const d of list) m.set(d.id, (m.get(d.id) ?? 0) + d.count);
  return [...m].map(([id, count]) => ({ id, count }));
}
