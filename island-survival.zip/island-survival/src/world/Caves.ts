import * as THREE from 'three';
import type { Physics } from '../core/Physics';
import { buildCave, type CaveData, type MeshData } from './CaveGeometry';
import type { ResourceField } from './ResourceField';
import type { CaveSite } from './TerrainGenerator';

interface CaveInstance {
  site: CaveSite;
  data: CaveData;
  group: THREE.Group;
}

/**
 * كهوف مبنية كهياكل مستقلة فوق مصاطب مسوّاة (انظر TerrainGenerator.planCaves):
 * قشرة خارجية صخرية + نفق داخلي، مع تصادم لكليهما، وخامات حديد/نحاس في العمق.
 */
export class Caves {
  readonly group = new THREE.Group();
  readonly instances: CaveInstance[] = [];

  constructor(sites: CaveSite[], seed: string, physics: Physics, field: ResourceField) {
    this.group.name = 'Caves';
    const rock = new THREE.MeshStandardMaterial({ color: 0x6c685f, roughness: 1, flatShading: true });
    const inside = new THREE.MeshStandardMaterial({ color: 0x4a463f, roughness: 1, flatShading: true });

    sites.forEach((site, i) => {
      const data = buildCave(`${seed}-cave-${i}`, site.length);
      const g = new THREE.Group();
      g.position.set(site.x, site.y, site.z);
      g.rotation.y = site.yaw;

      g.add(new THREE.Mesh(this.toGeometry(data.outer), rock), new THREE.Mesh(this.toGeometry(data.inner), inside));
      g.children.forEach((c) => {
        (c as THREE.Mesh).castShadow = true;
        (c as THREE.Mesh).receiveShadow = true;
      });
      this.group.add(g);

      // التصادم بإحداثيات العالم
      physics.createTrimesh(this.toWorld(data.inner, site), data.inner.indices);
      physics.createTrimesh(this.toWorld(data.outer, site), data.outer.indices);

      this.populate(data, site, field, i);
      this.instances.push({ site, data, group: g });
    });
  }

  private toGeometry(m: MeshData): THREE.BufferGeometry {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(m.positions, 3));
    g.setIndex(new THREE.BufferAttribute(m.indices, 1));
    g.computeVertexNormals();
    return g;
  }

  /** دوران حول Y بزاوية yaw ثم إزاحة: x' = x cosθ + z sinθ ، z' = −x sinθ + z cosθ */
  private toWorld(m: MeshData, site: CaveSite): Float32Array {
    const out = new Float32Array(m.positions.length);
    const c = Math.cos(site.yaw);
    const s = Math.sin(site.yaw);
    for (let i = 0; i < m.positions.length; i += 3) {
      const x = m.positions[i];
      const y = m.positions[i + 1];
      const z = m.positions[i + 2];
      out[i] = site.x + x * c + z * s;
      out[i + 1] = site.y + y;
      out[i + 2] = site.z - x * s + z * c;
    }
    return out;
  }

  /** خامات في العمق: حديد ونحاس وصخور على جانبي النفق */
  private populate(data: CaveData, site: CaveSite, field: ResourceField, caveIndex: number): void {
    const c = Math.cos(site.yaw);
    const s = Math.sin(site.yaw);
    const kinds = ['boulder', 'ironRock', 'copperRock', 'ironRock', 'boulder'] as const;
    for (let i = 3; i < data.path.length - 1; i += 2) {
      const p = data.path[i];
      const side = (i + caveIndex) % 2 === 0 ? 1.8 : -1.8;
      const lx = p.x + side;
      const lz = p.z;
      const wx = site.x + lx * c + lz * s;
      const wz = site.z - lx * s + lz * c;
      field.add(kinds[(i + caveIndex) % kinds.length], wx, site.y, wz, 0.85, i);
    }
  }

  /** هل النقطة داخل النفق؟ (للإضاءة والحماية من المطر/الرياح) */
  contains(x: number, y: number, z: number): boolean {
    for (const inst of this.instances) {
      const { site, data } = inst;
      const dx = x - site.x;
      const dz = z - site.z;
      const c = Math.cos(site.yaw);
      const s = Math.sin(site.yaw);
      // العكس: محلي = R(-θ)
      const lx = dx * c - dz * s;
      const lz = dx * s + dz * c;
      const ly = y - site.y;
      if (lz < 0.5 || lz > site.length || ly < -0.5 || ly > 3.2) continue;
      // أقرب نقطة على المحور
      const idx = Math.min(data.path.length - 1, Math.max(0, Math.round((lz / site.length) * (data.path.length - 1))));
      if (Math.abs(lx - data.path[idx].x) < 2.4) return true;
    }
    return false;
  }

  dispose(): void {
    this.group.traverse((o) => {
      if (o instanceof THREE.Mesh) o.geometry.dispose();
    });
  }
}
