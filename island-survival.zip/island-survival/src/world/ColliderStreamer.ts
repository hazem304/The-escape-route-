import type RAPIER from '@dimforge/rapier3d-compat';
import type { Physics } from '../core/Physics';
import { NODE_DEFS } from './ResourceNode';
import type { ResourceField } from './ResourceField';

const ADD_RADIUS = 28;
const REMOVE_RADIUS = 40;
const INTERVAL = 0.4;

/**
 * آلاف الأشجار لا تحتاج مصادمات دائمة: ننشئ أسطوانات صلبة لما يقع حول اللاعب فقط ونحذفها عند الابتعاد.
 */
export class ColliderStreamer {
  private active = new Map<number, RAPIER.Collider>();
  private timer = 0;

  constructor(private physics: Physics, private field: ResourceField) {}

  update(dt: number, px: number, pz: number): void {
    this.timer -= dt;
    if (this.timer > 0) return;
    this.timer = INTERVAL;

    // إضافة القريب الصلب الحي
    for (const n of this.field.nearby(px, pz, ADD_RADIUS)) {
      const def = NODE_DEFS[n.kind];
      if (!def.solid || this.active.has(n.id)) continue;
      const r = def.radius * n.scale;
      const halfH = (def.height * n.scale) / 2;
      this.active.set(n.id, this.physics.createStaticCylinder(n.x, n.y + halfH, n.z, halfH, r));
    }
    // حذف البعيد أو الميت
    for (const [id, col] of this.active) {
      const n = this.field.get(id);
      if (!n || !n.alive || Math.hypot(n.x - px, n.z - pz) > REMOVE_RADIUS) {
        this.physics.removeCollider(col);
        this.active.delete(id);
      }
    }
  }

  get activeCount(): number {
    return this.active.size;
  }
}
