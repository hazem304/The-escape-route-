import type { Random } from '../core/Random';
import { applyHit, NODE_DEFS, type HitResult, type NodeKind, type NodeState, type ToolPower } from './ResourceNode';

const CELL = 16;

export interface RayHit {
  node: NodeState;
  distance: number;
}

/**
 * فهرس مكاني لعقد الموارد (آلاف الأشجار والصخور) مع رمي أشعة وإعادة نمو.
 * منطق خالص بلا Three.js ليُختبر؛ العرض يشترك عبر onChanged.
 */
export class ResourceField {
  private nodes = new Map<number, NodeState>();
  private buckets = new Map<string, NodeState[]>();
  private nextId = 1;
  /** عدّاد ساعات اللعبة التراكمي */
  hours = 0;

  onChanged: ((node: NodeState) => void) | null = null;

  private static key(cx: number, cz: number): string {
    return `${cx},${cz}`;
  }

  get size(): number {
    return this.nodes.size;
  }

  all(): NodeState[] {
    return [...this.nodes.values()];
  }

  get(id: number): NodeState | undefined {
    return this.nodes.get(id);
  }

  add(kind: NodeKind, x: number, y: number, z: number, scale = 1, rotY = 0): NodeState {
    const n: NodeState = { id: this.nextId++, kind, x, y, z, scale, rotY, hp: NODE_DEFS[kind].hp, alive: true, respawnAt: 0 };
    this.nodes.set(n.id, n);
    const k = ResourceField.key(Math.floor(x / CELL), Math.floor(z / CELL));
    const b = this.buckets.get(k);
    if (b) b.push(n);
    else this.buckets.set(k, [n]);
    return n;
  }

  /** يحذف عقدة نهائيًا (لا تعود). يستخدم لموارد وُلّدت فوق مواقع محجوزة */
  remove(id: number): boolean {
    const n = this.nodes.get(id);
    if (!n) return false;
    this.nodes.delete(id);
    const b = this.buckets.get(ResourceField.key(Math.floor(n.x / CELL), Math.floor(n.z / CELL)));
    if (b) b.splice(b.indexOf(n), 1);
    return true;
  }

  /** العقد الحية ضمن نصف قطر */
  nearby(x: number, z: number, r: number, aliveOnly = true): NodeState[] {
    const out: NodeState[] = [];
    const c0x = Math.floor((x - r) / CELL);
    const c1x = Math.floor((x + r) / CELL);
    const c0z = Math.floor((z - r) / CELL);
    const c1z = Math.floor((z + r) / CELL);
    for (let cx = c0x; cx <= c1x; cx++) {
      for (let cz = c0z; cz <= c1z; cz++) {
        const b = this.buckets.get(ResourceField.key(cx, cz));
        if (!b) continue;
        for (const n of b) {
          if (aliveOnly && !n.alive) continue;
          if (Math.hypot(n.x - x, n.z - z) <= r) out.push(n);
        }
      }
    }
    return out;
  }

  /** أقرب عقدة تقطعها الأسطوانة العمودية على امتداد شعاع */
  raycast(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, maxDist: number): RayHit | null {
    const len = Math.hypot(dx, dy, dz) || 1;
    dx /= len; dy /= len; dz /= len;
    const step = 0.1;
    // العقد المرشحة: كل ما في صندوق يحيط بالشعاع
    const ex = ox + dx * maxDist;
    const ez = oz + dz * maxDist;
    const cands = this.nearby((ox + ex) / 2, (oz + ez) / 2, maxDist / 2 + 2.5);
    if (cands.length === 0) return null;

    let best: RayHit | null = null;
    for (let t = 0; t <= maxDist; t += step) {
      const px = ox + dx * t;
      const py = oy + dy * t;
      const pz = oz + dz * t;
      for (const n of cands) {
        const def = NODE_DEFS[n.kind];
        const r = def.radius * n.scale;
        const h = def.height * n.scale;
        const ddx = px - n.x;
        const ddz = pz - n.z;
        if (ddx * ddx + ddz * ddz <= r * r && py >= n.y - 0.1 && py <= n.y + h) {
          if (!best || t < best.distance) best = { node: n, distance: t };
        }
      }
      if (best) return best; // أول نقطة اصطدام على الشعاع هي الأقرب
    }
    return best;
  }

  /** ضربة على عقدة؛ تُحدّد وقت العودة عند الاستنفاد */
  hit(id: number, tool: ToolPower, rnd: Random, gatherBonus = 0): HitResult {
    const n = this.nodes.get(id);
    if (!n) return { ok: false, reason: 'dead', damage: 0, destroyed: false, drops: [] };
    const res = applyHit(n, tool, rnd, gatherBonus);
    if (res.ok && res.destroyed) {
      n.alive = false;
      n.respawnAt = this.hours + NODE_DEFS[n.kind].respawnHours;
      this.onChanged?.(n);
    }
    return res;
  }

  /** تقدّم الساعات وتعيد العقد المنتهية فترتها */
  update(dtHours: number): void {
    this.hours += dtHours;
    for (const n of this.nodes.values()) {
      if (!n.alive && this.hours >= n.respawnAt) {
        n.alive = true;
        n.hp = NODE_DEFS[n.kind].hp;
        this.onChanged?.(n);
      }
    }
  }

  toJSON(): { hours: number; dead: Array<{ id: number; respawnAt: number }> } {
    return { hours: this.hours, dead: this.all().filter((n) => !n.alive).map((n) => ({ id: n.id, respawnAt: n.respawnAt })) };
  }

  /** يطبّق حالة محفوظة على عالم مولّد بنفس البذرة (المعرّفات حتمية) */
  load(data: { hours: number; dead: Array<{ id: number; respawnAt: number }> }): void {
    this.hours = data.hours;
    // الحالة الحالية قد تختلف عن المحفوظة (عقد قُطعت بعد الحفظ): نُحيي الكل أولًا
    for (const n of this.nodes.values()) {
      if (!n.alive) {
        n.alive = true;
        n.hp = NODE_DEFS[n.kind].hp;
        this.onChanged?.(n);
      }
    }
    for (const d of data.dead) {
      const n = this.nodes.get(d.id);
      if (n) {
        n.alive = false;
        n.respawnAt = d.respawnAt;
        this.onChanged?.(n);
      }
    }
  }
}
