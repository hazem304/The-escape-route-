import * as THREE from 'three';
import type { EventBus, GameEvents } from '../core/EventBus';
import { Random } from '../core/Random';

export type WeatherType = 'clear' | 'cloudy' | 'rain' | 'storm' | 'fog';

interface WeatherParams {
  cloudCover: number; // 0..1
  rain: number; // 0..1
  fog: number; // 0..1
  wind: number; // 0..1
  storm: number; // 0..1 (يُغمّق الغيوم ويفعّل البرق)
  waveAmp: number; // مضاعِف ارتفاع الأمواج
  temperatureDelta: number; // تأثير على حرارة الجسم (°م)
  light: number; // مضاعِف الإضاءة العامة
}

const PRESETS: Record<WeatherType, WeatherParams> = {
  clear: { cloudCover: 0.2, rain: 0, fog: 0, wind: 0.15, storm: 0, waveAmp: 1, temperatureDelta: 0, light: 1 },
  cloudy: { cloudCover: 0.7, rain: 0, fog: 0.08, wind: 0.3, storm: 0.1, waveAmp: 1.2, temperatureDelta: -2, light: 0.8 },
  rain: { cloudCover: 0.9, rain: 0.7, fog: 0.25, wind: 0.45, storm: 0.4, waveAmp: 1.5, temperatureDelta: -4, light: 0.6 },
  storm: { cloudCover: 1, rain: 1, fog: 0.35, wind: 1, storm: 1, waveAmp: 2.4, temperatureDelta: -7, light: 0.42 },
  fog: { cloudCover: 0.5, rain: 0, fog: 1, wind: 0.05, storm: 0, waveAmp: 0.8, temperatureDelta: -1, light: 0.75 },
};

/** احتمالات الانتقال من طقس إلى آخر */
const TRANSITIONS: Record<WeatherType, Array<[WeatherType, number]>> = {
  clear: [['clear', 4], ['cloudy', 3], ['fog', 1]],
  cloudy: [['clear', 3], ['cloudy', 2], ['rain', 3], ['fog', 1]],
  rain: [['cloudy', 3], ['rain', 2], ['storm', 2], ['clear', 1]],
  storm: [['rain', 4], ['cloudy', 2], ['storm', 1]],
  fog: [['clear', 3], ['cloudy', 2]],
};

const RAIN_DROPS = 5000;
const RAIN_BOX = 40;

const RAIN_VERT = /* glsl */ `
  attribute float aEnd; // 0 = رأس القطرة، 1 = ذيلها
  attribute float aSeed;
  uniform vec3 uCenter;
  uniform float uTime;
  uniform vec3 uWind;
  uniform float uBox;
  uniform float uIntensity;
  varying float vAlpha;

  void main() {
    float speed = 22.0 + aSeed * 8.0;
    vec3 p = position;
    // السقوط مع الانحراف بالرياح، ثم لفّ داخل الصندوق حول اللاعب
    p.y -= uTime * speed;
    p.xz += uWind.xz * uTime * 3.0;
    p = mod(p - uCenter + uBox * 0.5, uBox) - uBox * 0.5;
    vec3 world = uCenter + p;
    vec3 tail = normalize(vec3(-uWind.x * 0.25, speed * 0.04, -uWind.z * 0.25));
    world += tail * aEnd * 0.9;
    // عدد القطرات الظاهرة يتبع الشدة
    vAlpha = step(aSeed, uIntensity) * (0.55 - 0.3 * aEnd);
    gl_Position = projectionMatrix * viewMatrix * vec4(world, 1.0);
  }
`;
const RAIN_FRAG = /* glsl */ `
  uniform vec3 uColor;
  varying float vAlpha;
  void main() { if (vAlpha <= 0.0) discard; gl_FragColor = vec4(uColor, vAlpha); }
`;

export class Weather {
  type: WeatherType = 'clear';
  /** القيم الحالية بعد المزج الناعم */
  readonly current: WeatherParams = { ...PRESETS.clear };
  /** اتجاه الرياح مضروبًا بشدتها (م/ث تقريبًا) */
  readonly wind = new THREE.Vector3(1, 0, 0.3);
  /** وميض البرق 0..1 */
  flash = 0;

  readonly rainLines: THREE.LineSegments;
  private rainMaterial: THREE.ShaderMaterial;

  private rnd: Random;
  private timeToChange: number;
  private target: WeatherParams = { ...PRESETS.clear };
  private nextLightning = 6;
  private pendingThunder: Array<{ in: number; distance: number }> = [];
  private rainTime = 0;

  constructor(private bus: EventBus<GameEvents>, seed: number | string = 'weather-1') {
    this.rnd = new Random(seed);
    this.timeToChange = this.rnd.range(120, 240);

    const pos = new Float32Array(RAIN_DROPS * 2 * 3);
    const end = new Float32Array(RAIN_DROPS * 2);
    const seedAttr = new Float32Array(RAIN_DROPS * 2);
    for (let i = 0; i < RAIN_DROPS; i++) {
      const x = this.rnd.range(-RAIN_BOX / 2, RAIN_BOX / 2);
      const y = this.rnd.range(-RAIN_BOX / 2, RAIN_BOX / 2);
      const z = this.rnd.range(-RAIN_BOX / 2, RAIN_BOX / 2);
      const s = this.rnd.next();
      for (let k = 0; k < 2; k++) {
        const o = i * 2 + k;
        pos[o * 3] = x;
        pos[o * 3 + 1] = y;
        pos[o * 3 + 2] = z;
        end[o] = k;
        seedAttr[o] = s;
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aEnd', new THREE.BufferAttribute(end, 1));
    geo.setAttribute('aSeed', new THREE.BufferAttribute(seedAttr, 1));

    this.rainMaterial = new THREE.ShaderMaterial({
      vertexShader: RAIN_VERT,
      fragmentShader: RAIN_FRAG,
      transparent: true,
      depthWrite: false,
      uniforms: {
        uCenter: { value: new THREE.Vector3() },
        uTime: { value: 0 },
        uWind: { value: new THREE.Vector3() },
        uBox: { value: RAIN_BOX },
        uIntensity: { value: 0 },
        uColor: { value: new THREE.Color(0xbcd0e0) },
      },
    });
    this.rainLines = new THREE.LineSegments(geo, this.rainMaterial);
    this.rainLines.frustumCulled = false;
    this.rainLines.visible = false;
    this.rainLines.renderOrder = 5;
  }

  /** تغيير الطقس يدويًا (للاختبار أو القصة) */
  setWeather(type: WeatherType, instant = false): void {
    this.type = type;
    this.target = { ...PRESETS[type] };
    this.timeToChange = this.rnd.range(120, 300);
    if (instant) Object.assign(this.current, this.target);
    this.bus.emit('weather:changed', { type });
  }

  /** تأثير الطقس على حرارة الجسم (يستخدمه نظام البقاء لاحقًا) */
  get temperatureDelta(): number {
    return this.current.temperatureDelta;
  }

  get isRaining(): boolean {
    return this.current.rain > 0.15;
  }

  /** كثافة الضباب لاستخدامها كـ exp2 fog density */
  get fogDensity(): number {
    return 0.0008 + this.current.fog * 0.012;
  }

  update(dt: number, camPos: THREE.Vector3, elapsed: number): void {
    // انتقال عشوائي بين الأنماط
    this.timeToChange -= dt;
    if (this.timeToChange <= 0) {
      const options = TRANSITIONS[this.type];
      const total = options.reduce((s, [, w]) => s + w, 0);
      let r = this.rnd.next() * total;
      let next = options[0][0];
      for (const [t, w] of options) {
        r -= w;
        if (r <= 0) {
          next = t;
          break;
        }
      }
      this.setWeather(next);
    }

    // مزج ناعم نحو الهدف (~20 ثانية للانتقال)
    const k = 1 - Math.exp(-dt / 8);
    const c = this.current as unknown as Record<string, number>;
    const g = this.target as unknown as Record<string, number>;
    for (const key of Object.keys(c)) c[key] += (g[key] - c[key]) * k;

    // الرياح
    const windAngle = elapsed * 0.01;
    this.wind.set(Math.cos(windAngle), 0, Math.sin(windAngle)).multiplyScalar(2 + this.current.wind * 16);

    // البرق والرعد أثناء العاصفة
    this.flash = Math.max(0, this.flash - dt * 3.5);
    if (this.current.storm > 0.6) {
      this.nextLightning -= dt;
      if (this.nextLightning <= 0) {
        this.nextLightning = this.rnd.range(4, 16) / this.current.storm;
        this.flash = 1;
        const distance = this.rnd.range(300, 3000);
        this.pendingThunder.push({ in: distance / 343, distance }); // سرعة الصوت
      }
    }
    for (let i = this.pendingThunder.length - 1; i >= 0; i--) {
      this.pendingThunder[i].in -= dt;
      if (this.pendingThunder[i].in <= 0) {
        this.bus.emit('weather:thunder', { distance: this.pendingThunder[i].distance });
        this.pendingThunder.splice(i, 1);
      }
    }

    // المطر
    this.rainTime += dt;
    const u = this.rainMaterial.uniforms;
    this.rainLines.visible = this.current.rain > 0.02;
    u.uTime.value = this.rainTime;
    u.uIntensity.value = this.current.rain;
    (u.uCenter.value as THREE.Vector3).copy(camPos);
    (u.uWind.value as THREE.Vector3).copy(this.wind).multiplyScalar(0.2);
  }

  dispose(): void {
    this.rainLines.geometry.dispose();
    this.rainMaterial.dispose();
  }
}
