/** قواعد البيوم الخالصة (بلا Three.js) لتُستخدم في التوليد والاختبارات */
export type Biome = 'deepSea' | 'shallows' | 'beach' | 'grass' | 'jungle' | 'rock' | 'volcanic';

/**
 * يحدّد البيوم من الارتفاع والميل والرطوبة.
 * @param h الارتفاع بالمتر (الماء عند 0)
 * @param slope الميل 0 (مسطح) .. 1 (عمودي)
 * @param moisture رطوبة 0..1
 */
export function classifyBiome(h: number, slope: number, moisture: number): Biome {
  if (h < -6) return 'deepSea';
  if (h < 0.4) return 'shallows';
  if (h < 2.2 && slope < 0.5) return 'beach';
  if (h > 38) return 'volcanic';
  if (slope > 0.55) return 'rock';
  if (h > 24) return 'rock';
  return moisture > 0.5 ? 'jungle' : 'grass';
}
