import * as THREE from 'three';
import { biomeColor } from './BiomeMap';
import { TERRAIN_RES, TERRAIN_SIZE, type TerrainGenerator } from './TerrainGenerator';

/** عدد القطع على كل ضلع (للـ Frustum Culling) */
const CHUNKS = 8;
const QUADS_PER_CHUNK = TERRAIN_RES / CHUNKS;

/**
 * يبني شبكة العرض (مقسّمة إلى Chunks) وبيانات التصادم من نفس الشبكة،
 * فلا يحدث غرق أو طفو للقدمين بسبب اختلاف الدقة.
 */
export class TerrainMesh {
  readonly group = new THREE.Group();
  /** رؤوس وفهارس التصادم الكاملة (تُمرَّر إلى Rapier trimesh) */
  readonly physicsVertices: Float32Array;
  readonly physicsIndices: Uint32Array;
  /** نسيج ارتفاعات (R8) يستخدمه شيدر المحيط لحساب العمق والرغوة */
  readonly heightTexture: THREE.DataTexture;

  static readonly HEIGHT_RANGE = 96; // يُرمَّز [-48, 48] في 8 بت

  constructor(private gen: TerrainGenerator) {
    this.group.name = 'Terrain';
    const material = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0 });

    for (let cz = 0; cz < CHUNKS; cz++) {
      for (let cx = 0; cx < CHUNKS; cx++) {
        const mesh = new THREE.Mesh(this.buildChunk(cx, cz), material);
        mesh.receiveShadow = true;
        mesh.castShadow = true;
        mesh.frustumCulled = true;
        this.group.add(mesh);
      }
    }

    const physics = this.buildPhysicsData();
    this.physicsVertices = physics.vertices;
    this.physicsIndices = physics.indices;
    this.heightTexture = this.buildHeightTexture();
  }

  private buildChunk(cx: number, cz: number): THREE.BufferGeometry {
    const n = QUADS_PER_CHUNK + 1;
    const positions = new Float32Array(n * n * 3);
    const normals = new Float32Array(n * n * 3);
    const colors = new Float32Array(n * n * 3);
    const nrm = new THREE.Vector3();
    const col = new THREE.Color();
    const half = TERRAIN_SIZE / 2;
    const cell = this.gen.cell;

    let p = 0;
    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        const gi = cx * QUADS_PER_CHUNK + i;
        const gj = cz * QUADS_PER_CHUNK + j;
        const x = gi * cell - half;
        const z = gj * cell - half;
        const h = this.gen.heights[gj * (TERRAIN_RES + 1) + gi];

        positions[p] = x;
        positions[p + 1] = h;
        positions[p + 2] = z;

        // قيمة طبيعية من فروق الارتفاعات (متصلة عبر حدود القطع)
        this.gen.normal(x, z, nrm);
        normals[p] = nrm.x;
        normals[p + 1] = nrm.y;
        normals[p + 2] = nrm.z;

        // تبديل بسيط للون حتى لا يبدو السطح مسطحًا
        const slope = Math.sqrt(Math.max(0, 1 - nrm.y * nrm.y)) / Math.max(0.0001, nrm.y);
        biomeColor(h, Math.min(1, slope), this.gen.moisture(x, z), col);
        const jitter = 0.94 + 0.12 * (((gi * 73856093) ^ (gj * 19349663)) >>> 0) / 4294967295;
        colors[p] = col.r * jitter;
        colors[p + 1] = col.g * jitter;
        colors[p + 2] = col.b * jitter;
        p += 3;
      }
    }

    const indices: number[] = [];
    for (let j = 0; j < QUADS_PER_CHUNK; j++) {
      for (let i = 0; i < QUADS_PER_CHUNK; i++) {
        const a = j * n + i;
        const b = a + 1;
        const c = a + n;
        const d = c + 1;
        // ترتيب اللفّ بحيث تواجه الوجوه للأعلى (+Y)
        indices.push(a, c, b, b, c, d);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.setIndex(indices);
    geo.computeBoundingSphere();
    geo.computeBoundingBox();
    return geo;
  }

  private buildPhysicsData(): { vertices: Float32Array; indices: Uint32Array } {
    const n = TERRAIN_RES + 1;
    const half = TERRAIN_SIZE / 2;
    const cell = this.gen.cell;
    const vertices = new Float32Array(n * n * 3);
    let p = 0;
    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        vertices[p++] = i * cell - half;
        vertices[p++] = this.gen.heights[j * n + i];
        vertices[p++] = j * cell - half;
      }
    }
    const indices = new Uint32Array(TERRAIN_RES * TERRAIN_RES * 6);
    let k = 0;
    for (let j = 0; j < TERRAIN_RES; j++) {
      for (let i = 0; i < TERRAIN_RES; i++) {
        const a = j * n + i;
        const b = a + 1;
        const c = a + n;
        const d = c + 1;
        indices[k++] = a;
        indices[k++] = c;
        indices[k++] = b;
        indices[k++] = b;
        indices[k++] = c;
        indices[k++] = d;
      }
    }
    return { vertices, indices };
  }

  private buildHeightTexture(): THREE.DataTexture {
    const n = TERRAIN_RES + 1;
    const data = new Uint8Array(n * n);
    const range = TerrainMesh.HEIGHT_RANGE;
    for (let i = 0; i < n * n; i++) {
      const v = this.gen.heights[i] / range + 0.5;
      data[i] = Math.round(Math.min(1, Math.max(0, v)) * 255);
    }
    const tex = new THREE.DataTexture(data, n, n, THREE.RedFormat, THREE.UnsignedByteType);
    tex.unpackAlignment = 1; // العرض 257 ليس من مضاعفات 4
    tex.minFilter = THREE.LinearFilter;
    tex.magFilter = THREE.LinearFilter;
    tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.needsUpdate = true;
    return tex;
  }

  dispose(): void {
    this.group.traverse((o) => {
      if (o instanceof THREE.Mesh) o.geometry.dispose();
    });
    this.heightTexture.dispose();
  }
}
