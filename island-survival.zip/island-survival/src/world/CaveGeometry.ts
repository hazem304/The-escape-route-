import { Noise2D } from '../core/Noise';

export interface MeshData {
  positions: Float32Array;
  indices: Uint32Array;
}

export interface CaveData {
  /** سطح الداخل: وجوهه تواجه محور النفق (للرسم والتصادم) */
  inner: MeshData;
  /** القشرة الخارجية: وجوهه تواجه الخارج */
  outer: MeshData;
  /** نقاط على محور النفق (محلية) للإضاءة وتوزيع الخامات */
  path: Array<{ x: number; y: number; z: number }>;
}

/** عدد رؤوس الحلقة: نصف قطع ناقص من اليمين فوق السقف إلى اليسار، ثم تُغلق بالأرضية */
export const RING_VERTS = 12;

/**
 * يولّد نفقًا منحنيًا بمقطع قوسي (أرضية مسطحة وسقف مقوّس) مع تشويه ضوضائي.
 * محور z للأمام (من المدخل إلى العمق). المدخل عند z=0 والأرضية عند y=0.
 */
export function buildCave(seed: number | string, length = 40, radius = 2.6): CaveData {
  const noise = new Noise2D(seed);
  const rings = Math.max(4, Math.floor(length / 2.5));
  const path: Array<{ x: number; y: number; z: number }> = [];
  for (let i = 0; i <= rings; i++) {
    const t = i / rings;
    path.push({ x: Math.sin(t * 2.2) * length * 0.12 + noise.noise(t * 3, 0.5) * 1.2, y: 0, z: t * length });
  }

  const ringVertices = (offset: number, jitterAmp: number, seedShift: number): Float32Array => {
    const out = new Float32Array((rings + 1) * RING_VERTS * 3);
    let p = 0;
    for (let i = 0; i <= rings; i++) {
      const c = path[i];
      const t = i / rings;
      // المدخل أوسع، ثم يضيق، ثم غرفة أوسع في النهاية
      const widen = 1 + (t < 0.12 ? (0.12 - t) * 4 : 0) + (t > 0.8 ? (t - 0.8) * 5 : 0);
      const r = (radius + offset) * widen;
      for (let k = 0; k < RING_VERTS; k++) {
        const a = (k / (RING_VERTS - 1)) * Math.PI;
        const j = noise.noise(i * 0.7 + seedShift, k * 0.9) * jitterAmp;
        const onFloor = k === 0 || k === RING_VERTS - 1;
        out[p++] = c.x + Math.cos(a) * r + j * 0.6;
        // الأرضية ثابتة عند y=0 لتبقى قابلة للمشي
        out[p++] = onFloor ? 0 : Math.sin(a) * r * 0.9 + Math.abs(j) * 0.5;
        out[p++] = c.z + noise.noise(k * 0.5, i * 0.5 + seedShift) * jitterAmp * 0.3;
      }
    }
    return out;
  };

  const connect = (flip: boolean): number[] => {
    const idx: number[] = [];
    for (let i = 0; i < rings; i++) {
      for (let k = 0; k < RING_VERTS; k++) {
        const a = i * RING_VERTS + k;
        const b = i * RING_VERTS + ((k + 1) % RING_VERTS); // الأخير يلتف إلى الأول فيُغلق الأرضية
        const c = a + RING_VERTS;
        const d = b + RING_VERTS;
        if (flip) idx.push(a, b, c, b, d, c);
        else idx.push(a, c, b, b, c, d);
      }
    }
    return idx;
  };

  const innerPos = ringVertices(0, 0.35, 0);
  const outerPos = ringVertices(1.6, 0.9, 50);

  // نغلق عمق النفق بقمع نحو المركز
  const last = path[rings];
  const cap = new Float32Array(innerPos.length + 3);
  cap.set(innerPos);
  const center = innerPos.length / 3;
  cap[innerPos.length] = last.x;
  cap[innerPos.length + 1] = 1.2;
  cap[innerPos.length + 2] = last.z + 1.5;
  const base = rings * RING_VERTS;
  const capIdx: number[] = [];
  for (let k = 0; k < RING_VERTS; k++) capIdx.push(base + k, base + ((k + 1) % RING_VERTS), center);

  return {
    inner: { positions: cap, indices: new Uint32Array([...connect(false), ...capIdx]) },
    outer: { positions: outerPos, indices: new Uint32Array(connect(true)) },
    path,
  };
}
