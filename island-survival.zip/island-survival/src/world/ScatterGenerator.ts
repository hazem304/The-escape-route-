import { Random } from '../core/Random';
import type { Biome } from './BiomeMap';
import type { NodeKind } from './ResourceNode';
import type { ResourceField } from './ResourceField';

/** واجهة أخذ العينات من التضاريس (يطبّقها TerrainGenerator) */
export interface TerrainSampler {
  height(x: number, z: number): number;
  slope(x: number, z: number): number;
  moisture(x: number, z: number): number;
  biomeAt(x: number, z: number): Biome;
}

interface Rule {
  kind: NodeKind;
  /** المسافة بين خلايا الشبكة المرتعشة */
  spacing: number;
  /** احتمال القبول داخل البيوم المناسب */
  probability: number;
  biomes: Biome[];
  minH: number;
  maxH: number;
  maxSlope: number;
  minMoisture?: number;
  scale: [number, number];
}

const RULES: Rule[] = [
  { kind: 'palm', spacing: 8, probability: 0.55, biomes: ['beach', 'grass'], minH: 1.4, maxH: 9, maxSlope: 0.35, scale: [0.85, 1.25] },
  { kind: 'jungleTree', spacing: 5, probability: 0.8, biomes: ['jungle', 'grass'], minH: 2.5, maxH: 28, maxSlope: 0.5, scale: [0.8, 1.4] },
  { kind: 'boulder', spacing: 12, probability: 0.55, biomes: ['beach', 'grass', 'rock', 'jungle'], minH: 1.0, maxH: 38, maxSlope: 0.7, scale: [0.7, 1.8] },
  { kind: 'ironRock', spacing: 34, probability: 0.8, biomes: ['rock', 'volcanic'], minH: 12, maxH: 45, maxSlope: 0.8, scale: [0.9, 1.3] },
  { kind: 'copperRock', spacing: 44, probability: 0.8, biomes: ['rock', 'volcanic'], minH: 10, maxH: 45, maxSlope: 0.8, scale: [0.9, 1.3] },
  { kind: 'berryBush', spacing: 11, probability: 0.55, biomes: ['grass', 'jungle'], minH: 2.5, maxH: 25, maxSlope: 0.4, scale: [0.8, 1.2] },
  { kind: 'fiberPlant', spacing: 6, probability: 0.6, biomes: ['grass', 'jungle', 'beach'], minH: 1.5, maxH: 25, maxSlope: 0.4, scale: [0.8, 1.3] },
  { kind: 'bamboo', spacing: 14, probability: 0.7, biomes: ['jungle'], minH: 3, maxH: 20, maxSlope: 0.35, minMoisture: 0.62, scale: [0.9, 1.2] },
  { kind: 'mushroomPatch', spacing: 16, probability: 0.5, biomes: ['jungle'], minH: 4, maxH: 25, maxSlope: 0.35, minMoisture: 0.55, scale: [0.9, 1.2] },
  { kind: 'clayBank', spacing: 40, probability: 0.6, biomes: ['beach', 'grass'], minH: 1.0, maxH: 4, maxSlope: 0.15, scale: [1, 1.4] },
];

export interface ScatterOptions {
  /** نصف حجم المنطقة المراد ملؤها (متر) */
  half: number;
  /** مناطق ممنوعة (مثل نقطة الظهور) */
  keepClear?: Array<{ x: number; z: number; r: number }>;
}

/**
 * يوزّع الموارد حسب البيوم بشبكة مرتعشة (jittered grid) حتمية من البذرة:
 * نفس البذرة تعطي نفس المعرّفات والمواضع (ضروري لحفظ حالة العقد).
 */
export function scatterResources(sampler: TerrainSampler, field: ResourceField, seed: number | string, opts: ScatterOptions): number {
  let count = 0;
  for (const rule of RULES) {
    const rnd = new Random(`${seed}:${rule.kind}`);
    const n = Math.floor((opts.half * 2) / rule.spacing);
    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        // نستهلك العشوائية بنفس الترتيب دائمًا حتى لا يتغير ما بعده
        const jx = rnd.next();
        const jz = rnd.next();
        const accept = rnd.next();
        const sc = rnd.range(rule.scale[0], rule.scale[1]);
        const rot = rnd.range(0, Math.PI * 2);

        const x = -opts.half + (i + jx) * rule.spacing;
        const z = -opts.half + (j + jz) * rule.spacing;
        if (accept > rule.probability) continue;

        const h = sampler.height(x, z);
        if (h < rule.minH || h > rule.maxH) continue;
        if (sampler.slope(x, z) > rule.maxSlope) continue;
        if (!rule.biomes.includes(sampler.biomeAt(x, z))) continue;
        if (rule.minMoisture !== undefined && sampler.moisture(x, z) < rule.minMoisture) continue;
        if (opts.keepClear?.some((c) => Math.hypot(c.x - x, c.z - z) < c.r)) continue;

        field.add(rule.kind, x, h, z, sc, rot);
        count++;
      }
    }
  }
  return count;
}
