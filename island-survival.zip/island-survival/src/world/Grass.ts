import * as THREE from 'three';
import { Random } from '../core/Random';
import { applyWind } from './Vegetation';
import type { TerrainSampler } from './ScatterGenerator';

const CHUNK = 24;
const RADIUS_CHUNKS = 3;
const MAX_BLADES = 900;
const BUILDS_PER_FRAME = 2;

/** شفرة عشب: ثلاث شرائح متقاطعة مدببة بتدرج لوني من الأسفل للأعلى */
function bladeGeometry(): THREE.BufferGeometry {
  const pos: number[] = [];
  const col: number[] = [];
  const base = new THREE.Color(0x35561f);
  const tip = new THREE.Color(0x9ab84e);
  for (let k = 0; k < 3; k++) {
    const a = (k / 3) * Math.PI;
    const dx = Math.cos(a) * 0.05;
    const dz = Math.sin(a) * 0.05;
    // مثلثان يكوّنان شفرة مدببة
    const v = [
      [-dx, 0, -dz], [dx, 0, dz], [-dx * 0.5, 0.45, -dz * 0.5],
      [dx, 0, dz], [dx * 0.5, 0.45, dz * 0.5], [-dx * 0.5, 0.45, -dz * 0.5],
      [-dx * 0.5, 0.45, -dz * 0.5], [dx * 0.5, 0.45, dz * 0.5], [0, 0.9, 0],
    ];
    for (const p of v) {
      pos.push(p[0], p[1], p[2]);
      const c = base.clone().lerp(tip, p[1] / 0.9);
      col.push(c.r, c.g, c.b);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.computeVertexNormals();
  // نجعل كل الناظمات للأعلى لإضاءة ناعمة موحدة مثل العشب الحقيقي
  const n = g.attributes.normal;
  for (let i = 0; i < n.count; i++) n.setXYZ(i, 0, 1, 0);
  return g;
}

/**
 * عشب كثيف حول اللاعب بالـ GPU Instancing: قطع 24م تُبنى عند الاقتراب وتُحذف عند الابتعاد.
 * الكثافة حسب البيوم والرطوبة، والمواضع حتمية من إحداثيات القطعة.
 */
export class Grass {
  readonly group = new THREE.Group();
  private geo = bladeGeometry();
  private material = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, side: THREE.DoubleSide });
  private chunks = new Map<string, THREE.InstancedMesh>();
  private wind = { time: { value: 0 }, amp: { value: 0.1 } };
  private q = new THREE.Quaternion();
  private up = new THREE.Vector3(0, 1, 0);
  private p = new THREE.Vector3();
  private s = new THREE.Vector3();
  /** مضاعِف الكثافة من جودة الرسم */
  density = 1;
  enabled = true;

  constructor(private sampler: TerrainSampler, private excluded: (x: number, z: number) => boolean = () => false) {
    this.group.name = 'Grass';
    applyWind(this.material, 0.9, this.wind);
  }

  private build(cx: number, cz: number): THREE.InstancedMesh | null {
    const rnd = new Random(`grass:${cx}:${cz}`);
    const cap = Math.floor(MAX_BLADES * this.density);
    const matrices: THREE.Matrix4[] = [];
    for (let i = 0; i < cap; i++) {
      const x = (cx + rnd.next()) * CHUNK;
      const z = (cz + rnd.next()) * CHUNK;
      const accept = rnd.next();
      const rot = rnd.next() * Math.PI * 2;
      const sc = 0.7 + rnd.next() * 0.9;
      const h = this.sampler.height(x, z);
      if (h < 1.3 || h > 26) continue;
      const biome = this.sampler.biomeAt(x, z);
      const dens = biome === 'grass' ? 1 : biome === 'jungle' ? 0.7 : biome === 'beach' ? 0.12 : 0;
      if (accept > dens || this.excluded(x, z) || this.sampler.slope(x, z) > 0.55) continue;
      this.q.setFromAxisAngle(this.up, rot);
      this.p.set(x, h - 0.02, z);
      this.s.set(sc, sc * (0.8 + rnd.next() * 0.6), sc);
      matrices.push(new THREE.Matrix4().compose(this.p, this.q, this.s));
    }
    if (matrices.length === 0) return null;
    const mesh = new THREE.InstancedMesh(this.geo, this.material, matrices.length);
    matrices.forEach((mt, i) => mesh.setMatrixAt(i, mt));
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
    mesh.receiveShadow = true;
    return mesh;
  }

  update(camPos: THREE.Vector3, elapsed: number, windStrength: number): void {
    this.group.visible = this.enabled;
    if (!this.enabled) return;
    this.wind.time.value = elapsed;
    this.wind.amp.value = 0.06 + windStrength * 0.3;

    const ccx = Math.floor(camPos.x / CHUNK);
    const ccz = Math.floor(camPos.z / CHUNK);
    const wanted = new Set<string>();
    let built = 0;
    for (let dz = -RADIUS_CHUNKS; dz <= RADIUS_CHUNKS; dz++) {
      for (let dx = -RADIUS_CHUNKS; dx <= RADIUS_CHUNKS; dx++) {
        if (dx * dx + dz * dz > RADIUS_CHUNKS * RADIUS_CHUNKS + 1) continue;
        const key = `${ccx + dx},${ccz + dz}`;
        wanted.add(key);
        if (!this.chunks.has(key) && built < BUILDS_PER_FRAME) {
          const mesh = this.build(ccx + dx, ccz + dz);
          // حتى القطع الفارغة تُسجَّل (null) كي لا تُعاد محاولتها كل إطار
          this.chunks.set(key, mesh as THREE.InstancedMesh);
          if (mesh) this.group.add(mesh);
          built++;
        }
      }
    }
    for (const [key, mesh] of this.chunks) {
      if (!wanted.has(key)) {
        if (mesh) {
          this.group.remove(mesh);
          mesh.dispose();
        }
        this.chunks.delete(key);
      }
    }
  }

  dispose(): void {
    for (const m of this.chunks.values()) m?.dispose();
    this.geo.dispose();
    this.material.dispose();
  }
}
