import * as THREE from 'three';

import { classifyBiome, type Biome } from './BiomeRules';
export { classifyBiome };
export type { Biome };

export interface BiomeInfo {
  id: Biome;
  color: THREE.Color;
  /** معامل خشونة تقريبي يُستخدم لاحقًا لأصوات الخطوات */
  roughness: number;
}

const C = (hex: number): THREE.Color => new THREE.Color(hex);

export const BIOMES: Record<Biome, BiomeInfo> = {
  deepSea: { id: 'deepSea', color: C(0x2b3b3f), roughness: 1 },
  shallows: { id: 'shallows', color: C(0xb9a97a), roughness: 1 },
  beach: { id: 'beach', color: C(0xe3d3a1), roughness: 0.95 },
  grass: { id: 'grass', color: C(0x6e8b3d), roughness: 0.95 },
  jungle: { id: 'jungle', color: C(0x3d5a2a), roughness: 0.9 },
  rock: { id: 'rock', color: C(0x76726b), roughness: 0.85 },
  volcanic: { id: 'volcanic', color: C(0x3a3633), roughness: 0.8 },
};

/** لون الرأس مع مزج ناعم بين البيومات القريبة (لا حدود حادة) */
export function biomeColor(h: number, slope: number, moisture: number, out: THREE.Color): THREE.Color {
  const sand = BIOMES.beach.color;
  const wetSand = BIOMES.shallows.color;
  const grass = BIOMES.grass.color;
  const jungle = BIOMES.jungle.color;
  const rock = BIOMES.rock.color;
  const volc = BIOMES.volcanic.color;
  const deep = BIOMES.deepSea.color;

  // قاع البحر: من رمل مبلل إلى داكن مع العمق
  if (h < 0.4) {
    const t = smooth(-14, 0, h);
    return out.copy(deep).lerp(wetSand, t);
  }

  // من الرمل إلى النبات بين 1.2 و 3.5م
  const veg = new THREE.Color().copy(grass).lerp(jungle, smooth(0.35, 0.65, moisture));
  out.copy(sand).lerp(veg, smooth(1.2, 3.5, h));

  // صخور على المنحدرات
  out.lerp(rock, smooth(0.4, 0.65, slope));
  // قمم بركانية
  out.lerp(rock, smooth(20, 28, h) * 0.6);
  out.lerp(volc, smooth(32, 42, h));
  return out;
}

function smooth(a: number, b: number, x: number): number {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}
