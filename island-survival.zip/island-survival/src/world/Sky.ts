import * as THREE from 'three';

const VERT = /* glsl */ `
  varying vec3 vDir;
  void main() {
    vDir = normalize(position);
    vec4 p = projectionMatrix * mat4(mat3(viewMatrix)) * vec4(position, 1.0);
    gl_Position = p.xyww; // العمق الأقصى دائمًا
  }
`;

const FRAG = /* glsl */ `
  uniform vec3 uSunDir;
  uniform vec3 uMoonDir;
  uniform vec3 uSunColor;
  uniform float uDaylight;
  uniform float uTime;
  uniform float uCloudCover;
  uniform float uStorm;
  uniform float uFlash;
  uniform vec3 uFogColor;
  varying vec3 vDir;

  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float hash3(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }
  float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
  }
  float fbm(vec2 p) {
    float s = 0.0, a = 0.5;
    for (int i = 0; i < 5; i++) { s += a * vnoise(p); p *= 2.03; a *= 0.5; }
    return s;
  }

  void main() {
    vec3 d = normalize(vDir);
    float sunH = uSunDir.y;
    float mu = dot(d, uSunDir);

    // ألوان السماء: تقريب لتشتت Rayleigh (أزرق في الأعلى، فاتح عند الأفق)
    vec3 zenithDay = vec3(0.16, 0.38, 0.82);
    vec3 horizonDay = vec3(0.66, 0.82, 0.95);
    vec3 zenithNight = vec3(0.01, 0.02, 0.06);
    vec3 horizonNight = vec3(0.03, 0.05, 0.10);
    vec3 duskCol = vec3(1.0, 0.45, 0.2);

    float h = clamp(d.y, 0.0, 1.0);
    float horizonMix = pow(1.0 - h, 3.0);
    vec3 zen = mix(zenithNight, zenithDay, uDaylight);
    vec3 hor = mix(horizonNight, horizonDay, uDaylight);
    vec3 sky = mix(zen, hor, horizonMix);

    // توهّج الشفق نحو الشمس عند الشروق والغروب
    float twilight = clamp(1.0 - abs(sunH) / 0.35, 0.0, 1.0);
    float sunSide = pow(max(mu, 0.0), 3.0);
    sky += duskCol * twilight * (0.25 + 0.75 * sunSide) * horizonMix * 1.2;

    // هالة الشمس (Mie) وقرصها
    sky += uSunColor * pow(max(mu, 0.0), 8.0) * 0.25 * uDaylight;
    float disc = smoothstep(0.9996, 0.9999, mu);
    sky += uSunColor * disc * 6.0 * step(-0.05, sunH);

    // القمر
    float moonMu = dot(d, uMoonDir);
    float moon = smoothstep(0.99955, 0.9998, moonMu) * (1.0 - uDaylight);
    sky += vec3(0.85, 0.9, 1.0) * moon * 1.5;

    // نجوم ليلًا (تتلاشى مع الغيوم والنهار)
    if (d.y > 0.0) {
      vec3 sp = floor(d * 380.0);
      float st = hash3(sp);
      float star = step(0.9965, st) * (0.6 + 0.4 * sin(uTime * 2.0 + st * 80.0));
      sky += vec3(star) * (1.0 - uDaylight) * (1.0 - uCloudCover * 0.9);
    }

    // الغيوم: مستوى مُسقَط مع حركة الرياح
    if (d.y > 0.02) {
      vec2 uv = d.xz / (d.y + 0.12) * 1.3 + vec2(uTime * 0.012, uTime * 0.006);
      float n = fbm(uv);
      float detail = fbm(uv * 3.0 + 13.7);
      float threshold = mix(0.68, 0.30, uCloudCover);
      float dens = smoothstep(threshold, threshold + 0.22, n * 0.8 + detail * 0.25);
      dens *= smoothstep(0.02, 0.22, d.y);

      // إضاءة الغيوم: الحواف المواجهة للشمس أفتح
      float lit = clamp(0.55 + 0.45 * dot(normalize(vec3(uSunDir.x, 0.4, uSunDir.z)), vec3(d.x, 0.4, d.z)), 0.0, 1.0);
      vec3 cloudLit = mix(vec3(0.55, 0.58, 0.64), uSunColor * 1.05, lit * clamp(uDaylight + 0.1, 0.0, 1.0));
      cloudLit = mix(cloudLit, vec3(0.28, 0.30, 0.34), uStorm);
      cloudLit *= mix(0.12, 1.0, uDaylight);
      sky = mix(sky, cloudLit, dens * 0.92);
    }

    // البرق يضيء السماء
    sky += vec3(0.7, 0.75, 1.0) * uFlash * (0.4 + 0.6 * (1.0 - h));

    // ضباب عند الأفق يطابق ضباب المشهد
    sky = mix(sky, uFogColor, pow(1.0 - h, 6.0) * 0.8);

    gl_FragColor = vec4(sky, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

export class Sky {
  readonly mesh: THREE.Mesh;
  private material: THREE.ShaderMaterial;

  constructor() {
    const geo = new THREE.SphereGeometry(900, 48, 24);
    this.material = new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        uSunDir: { value: new THREE.Vector3(0, 1, 0) },
        uMoonDir: { value: new THREE.Vector3(0, -1, 0) },
        uSunColor: { value: new THREE.Color(1, 0.95, 0.85) },
        uDaylight: { value: 1 },
        uTime: { value: 0 },
        uCloudCover: { value: 0.25 },
        uStorm: { value: 0 },
        uFlash: { value: 0 },
        uFogColor: { value: new THREE.Color(0xa9d4ee) },
      },
    });
    this.mesh = new THREE.Mesh(geo, this.material);
    this.mesh.name = 'Sky';
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = -1000;
  }

  update(
    time: number,
    camPos: THREE.Vector3,
    s: { sunDir: THREE.Vector3; moonDir: THREE.Vector3; sunColor: THREE.Color; daylight: number; cloudCover: number; storm: number; flash: number; fogColor: THREE.Color },
  ): void {
    this.mesh.position.copy(camPos);
    const u = this.material.uniforms;
    u.uTime.value = time;
    (u.uSunDir.value as THREE.Vector3).copy(s.sunDir);
    (u.uMoonDir.value as THREE.Vector3).copy(s.moonDir);
    (u.uSunColor.value as THREE.Color).copy(s.sunColor);
    u.uDaylight.value = s.daylight;
    u.uCloudCover.value = s.cloudCover;
    u.uStorm.value = s.storm;
    u.uFlash.value = s.flash;
    (u.uFogColor.value as THREE.Color).copy(s.fogColor);
  }

  dispose(): void {
    this.mesh.geometry.dispose();
    this.material.dispose();
  }
}
