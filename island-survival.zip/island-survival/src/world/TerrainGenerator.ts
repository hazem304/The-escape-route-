import { Noise2D } from '../core/Noise';
import { classifyBiome, type Biome } from './BiomeRules';

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

/** كهف مخطط: المدخل عند (x,z) بارتفاع الأرضية y، ومحور النفق نحو الداخل بزاوية yaw (راديان حول Y) */
export interface CaveSite {
  x: number;
  y: number;
  z: number;
  /** اتجاه +z المحلي للنفق في العالم = (sin yaw, cos yaw) */
  yaw: number;
  length: number;
}

export const CAVE_LENGTH = 40;
const CAVE_TERRACE_HALF_WIDTH = 8;
const CAVE_TERRACE_BLEND = 7;

/** عدد المربعات على كل ضلع وحجم العالم (متر). دقة المربع = size / resolution */
export const TERRAIN_SIZE = 512;
export const TERRAIN_RES = 256;

/**
 * مولّد الارتفاعات: جزيرة بركانية واحدة بشواطئ وغابة وقمة.
 * الدالة height(x,z) حتمية من البذرة وتُستخدم في كل مكان (عرض، فيزياء، نباتات، حيوانات).
 */
export class TerrainGenerator {
  private noise: Noise2D;
  private warp: Noise2D;
  private moistureNoise: Noise2D;

  /** شبكة الارتفاعات (RES+1)² مخزنة مسبقًا للسرعة */
  readonly heights: Float32Array;
  readonly cell = TERRAIN_SIZE / TERRAIN_RES;
  readonly half = TERRAIN_SIZE / 2;

  /** نقطة صالحة للظهور على الشاطئ */
  spawn: Vec3 = { x: 0, y: 0, z: 0 };
  /** مواقع الكهوف المخططة (بعد تسوية المصاطب) */
  caveSites: CaveSite[] = [];

  constructor(readonly seed: number | string = 'island-1') {
    this.noise = new Noise2D(seed);
    this.warp = new Noise2D(`${seed}-warp`);
    this.moistureNoise = new Noise2D(`${seed}-moist`);

    const n = TERRAIN_RES + 1;
    this.heights = new Float32Array(n * n);
    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        const x = i * this.cell - this.half;
        const z = j * this.cell - this.half;
        this.heights[j * n + i] = this.computeHeight(x, z);
      }
    }
    this.spawn = this.findBeachSpawn();
    this.planCaves(2);
  }

  /** الارتفاع الخام (بدون استيفاء) */
  private computeHeight(x: number, z: number): number {
    // التواء الإحداثيات يكسر الشكل الدائري المثالي
    const wx = x + this.warp.fbm(x * 0.006, z * 0.006, 3) * 55;
    const wz = z + this.warp.fbm(x * 0.006 + 40, z * 0.006 - 17, 3) * 55;

    const r = Math.hypot(wx, wz);
    const islandRadius = 190;
    const t = r / islandRadius;
    // قناع موقّع: موجب داخل الجزيرة، سالب خارجها
    const m = 1 - t * t;
    const m0 = 0.03; // مستوى سطح البحر
    const beachSlope = 3.8; // ~4% انحدار على الشاطئ

    const base = this.noise.fbm(x * 0.008, z * 0.008, 5) * 0.5 + 0.5; // 0..1
    const hills = this.noise.fbm(x * 0.02, z * 0.02, 4) * 3;
    const ridge = this.noise.ridged(x * 0.012 + 100, z * 0.012 + 100, 4);
    const peak = Math.exp(-(r * r) / (2 * 45 * 45)) * 26;
    const inland = base * 10 + ridge * 6 + peak + hills;

    let h: number;
    if (m >= m0) {
      // شاطئ بانحدار لطيف ثم ارتفاع تدريجي نحو الداخل
      h = beachSlope * (m - m0) + inland * smoothstep(0.12, 0.55, m);
    } else {
      // تحت الماء: ينحدر أسرع حتى قاع البحر
      h = -(m0 - m) * 8;
    }
    return Math.max(-48, h);
  }

  /** ارتفاع مستمر بالاستيفاء الثنائي من الشبكة (يطابق الشبكة المرسومة تمامًا) */
  height(x: number, z: number): number {
    const n = TERRAIN_RES + 1;
    const fx = (x + this.half) / this.cell;
    const fz = (z + this.half) / this.cell;
    if (fx < 0 || fz < 0 || fx >= TERRAIN_RES || fz >= TERRAIN_RES) return -50;
    const i = Math.floor(fx);
    const j = Math.floor(fz);
    const tx = fx - i;
    const tz = fz - j;
    const h00 = this.heights[j * n + i];
    const h10 = this.heights[j * n + i + 1];
    const h01 = this.heights[(j + 1) * n + i];
    const h11 = this.heights[(j + 1) * n + i + 1];
    return (h00 * (1 - tx) + h10 * tx) * (1 - tz) + (h01 * (1 - tx) + h11 * tx) * tz;
  }

  /** الميل 0..1 (0 مسطح) */
  slope(x: number, z: number): number {
    const e = this.cell;
    const dx = (this.height(x + e, z) - this.height(x - e, z)) / (2 * e);
    const dz = (this.height(x, z + e) - this.height(x, z - e)) / (2 * e);
    return Math.min(1, Math.hypot(dx, dz));
  }

  normal(x: number, z: number, out: Vec3 = { x: 0, y: 0, z: 0 }): Vec3 {
    const e = this.cell;
    const dx = this.height(x + e, z) - this.height(x - e, z);
    const dz = this.height(x, z + e) - this.height(x, z - e);
    const nx = -dx;
    const ny = 2 * e;
    const nz = -dz;
    const len = Math.hypot(nx, ny, nz) || 1;
    out.x = nx / len;
    out.y = ny / len;
    out.z = nz / len;
    return out;
  }

  moisture(x: number, z: number): number {
    return this.moistureNoise.fbm(x * 0.01, z * 0.01, 3) * 0.5 + 0.5;
  }

  biomeAt(x: number, z: number): Biome {
    return classifyBiome(this.height(x, z), this.slope(x, z), this.moisture(x, z));
  }

  /** يبحث على امتداد أشعة من المركز عن أول نقطة شاطئ ارتفاعها بين 0.8 و 1.6م */
  private findBeachSpawn(): Vec3 {
    for (let a = 0; a < 360; a += 5) {
      const ang = (a * Math.PI) / 180;
      for (let r = 260; r > 20; r -= 1) {
        const x = Math.cos(ang) * r;
        const z = Math.sin(ang) * r;
        const h = this.height(x, z);
        if (h > 0.8 && h < 1.6 && this.slope(x, z) < 0.25) {
          // نتأكد من أن ما خلفها نحو الداخل يرتفع (شاطئ حقيقي لا جزيرة صغيرة)
          if (this.height(Math.cos(ang) * (r - 25), Math.sin(ang) * (r - 25)) > 2) {
            return { x, y: h, z };
          }
        }
      }
    }
    return { x: 0, y: this.height(0, 0) + 1, z: 0 };
  }

  /**
   * يخطط كهوفًا على سفوح التلال: يبحث عن ميل معتدل بارتفاع 8–18م بعيدًا عن الشاطئ ونقطة الظهور،
   * ثم يسوّي مصطبة مستوية تحت النفق (خريطة الارتفاعات لا تمثل التجاويف، فالنفق يُبنى كهيكل مستقل فوقها).
   */
  private planCaves(count: number): void {
    const sites: CaveSite[] = [];
    const rnd = new Noise2D(`${this.seed}-caves`);
    // بحث حلزوني حتمي
    for (let ring = 40; ring <= 170 && sites.length < count; ring += 6) {
      for (let k = 0; k < 48 && sites.length < count; k++) {
        const a = (k / 48) * Math.PI * 2 + rnd.noise(ring, k) * 0.2;
        const x = Math.cos(a) * ring;
        const z = Math.sin(a) * ring;
        const h = this.height(x, z);
        const s = this.slope(x, z);
        if (h < 8 || h > 18 || s < 0.2 || s > 0.5) continue;
        if (Math.hypot(x - this.spawn.x, z - this.spawn.z) < 70) continue;
        if (sites.some((c) => Math.hypot(c.x - x, c.z - z) < 90)) continue;

        // اتجاه صعود التل = +z المحلي
        const e = this.cell;
        let ux = this.height(x + e, z) - this.height(x - e, z);
        let uz = this.height(x, z + e) - this.height(x, z - e);
        const ul = Math.hypot(ux, uz);
        if (ul < 1e-4) continue;
        ux /= ul;
        uz /= ul;
        // النهاية يجب أن تبقى فوق سطح البحر ومرتفعة (داخل الجبل)
        const ex = x + ux * CAVE_LENGTH;
        const ez = z + uz * CAVE_LENGTH;
        if (this.height(ex, ez) < h) continue;

        sites.push({ x, y: h, z, yaw: Math.atan2(ux, uz), length: CAVE_LENGTH });
      }
    }
    for (const c of sites) this.flattenForCave(c);
    this.caveSites = sites;
  }

  /** تسوية مصطبة مستطيلة موجّهة مع انتقال ناعم عند الحواف */
  private flattenForCave(c: CaveSite): void {
    const n = TERRAIN_RES + 1;
    const fx = Math.sin(c.yaw);
    const fz = Math.cos(c.yaw);
    // نقطة المدخل تُسحب قليلًا للخارج لتوفر ساحة أمام الفتحة
    const front = 8;
    const reach = c.length + front + CAVE_TERRACE_BLEND + CAVE_TERRACE_HALF_WIDTH + 4;
    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        const x = i * this.cell - this.half;
        const z = j * this.cell - this.half;
        const dx = x - c.x;
        const dz = z - c.z;
        if (Math.abs(dx) > reach || Math.abs(dz) > reach) continue;
        // إحداثيات محلية: along = على امتداد النفق، side = جانبي
        const along = dx * fx + dz * fz;
        const side = dx * fz - dz * fx;
        const dA = Math.max(-front - along, along - (c.length + 4), 0); // مسافة خارج الطول
        const dS = Math.max(Math.abs(side) - CAVE_TERRACE_HALF_WIDTH, 0);
        const d = Math.hypot(dA, dS);
        if (d >= CAVE_TERRACE_BLEND) continue;
        const w = 1 - smoothstep(0, CAVE_TERRACE_BLEND, d);
        const idx = j * n + i;
        this.heights[idx] = this.heights[idx] * (1 - w) + c.y * w;
      }
    }
  }

  /** هل النقطة داخل مصطبة كهف (لمنع توزيع الأشجار والصخور هناك) */
  insideCaveFootprint(x: number, z: number, margin = 4): boolean {
    for (const c of this.caveSites) {
      const fx = Math.sin(c.yaw);
      const fz = Math.cos(c.yaw);
      const dx = x - c.x;
      const dz = z - c.z;
      const along = dx * fx + dz * fz;
      const side = dx * fz - dz * fx;
      if (along > -8 - margin && along < c.length + margin && Math.abs(side) < CAVE_TERRACE_HALF_WIDTH + margin) return true;
    }
    return false;
  }
}

function smoothstep(a: number, b: number, x: number): number {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}
