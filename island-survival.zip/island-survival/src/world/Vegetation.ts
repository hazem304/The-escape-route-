import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Noise2D } from '../core/Noise';
import { NODE_DEFS, type NodeKind, type NodeState } from './ResourceNode';
import type { ResourceField } from './ResourceField';

const CHUNK = 64;

/** مسافة الرؤية لكل نوع (متر): النباتات الصغيرة تختفي أقرب */
const VIEW_DISTANCE: Record<NodeKind, number> = {
  palm: 320, jungleTree: 300, boulder: 220, ironRock: 260, copperRock: 260,
  berryBush: 110, fiberPlant: 90, bamboo: 200, mushroomPatch: 70, clayBank: 130,
};

const CASTS_SHADOW: ReadonlySet<NodeKind> = new Set(['palm', 'jungleTree', 'boulder', 'ironRock', 'copperRock', 'bamboo']);

// ---------- بناء المجسمات الإجرائية (حتى تصل ملفات GLB) ----------

/** يحوّل هندسة إلى غير مفهرسة بلون موحّد وبدون UV ليسهل دمجها */
function part(geo: THREE.BufferGeometry, color: number, m?: THREE.Matrix4): THREE.BufferGeometry {
  let g = geo.index ? geo.toNonIndexed() : geo;
  if (m) g.applyMatrix4(m);
  g.deleteAttribute('uv');
  g.computeVertexNormals();
  const c = new THREE.Color(color);
  const n = g.attributes.position.count;
  const colors = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    // تدرّج خفيف حسب الارتفاع يعطي عمقًا بلا خامات
    const y = g.attributes.position.getY(i);
    const shade = 0.85 + Math.min(0.3, Math.max(0, y * 0.03));
    colors[i * 3] = c.r * shade;
    colors[i * 3 + 1] = c.g * shade;
    colors[i * 3 + 2] = c.b * shade;
  }
  g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  g = g.clone();
  return g;
}

function bump(geo: THREE.BufferGeometry, amount: number, seed: string): THREE.BufferGeometry {
  const n = new Noise2D(seed);
  const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const d = 1 + n.noise(x * 1.7 + z, y * 1.7 - z) * amount;
    p.setXYZ(i, x * d, y * d, z * d);
  }
  p.needsUpdate = true;
  return geo;
}

const T = (x: number, y: number, z: number, rx = 0, ry = 0, rz = 0, s = 1): THREE.Matrix4 =>
  new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz)), new THREE.Vector3(s, s, s));

function buildGeometry(kind: NodeKind): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  switch (kind) {
    case 'palm': {
      // جذع منحنٍ من 8 مقاطع ثم تاج من سعف متدلٍّ
      const segs = 8;
      let px = 0;
      for (let i = 0; i < segs; i++) {
        const t = i / segs;
        const x = Math.sin(t * 1.2) * 0.9;
        const h = 9 / segs;
        const geo = new THREE.CylinderGeometry(0.22 - t * 0.08, 0.26 - t * 0.08, h * 1.05, 7, 1);
        parts.push(part(geo, 0x7a5b3a, T(x, (i + 0.5) * h, 0, 0, 0, -0.14)));
        px = x;
      }
      for (let k = 0; k < 9; k++) {
        const a = (k / 9) * Math.PI * 2;
        const leaf = new THREE.PlaneGeometry(0.9, 4.2, 1, 5);
        const p = leaf.attributes.position;
        for (let i = 0; i < p.count; i++) {
          const y = p.getY(i) + 2.1; // 0..4.2
          p.setZ(i, -(y * y) * 0.06); // تدلٍّ منحنٍ
        }
        leaf.rotateX(-Math.PI / 2 + 0.5);
        leaf.translate(0, 0, 0.3);
        const m = new THREE.Matrix4().makeRotationY(a).setPosition(px, 9, 0);
        parts.push(part(leaf, 0x3f8a3a, m));
      }
      // جوز هند
      for (let k = 0; k < 3; k++) parts.push(part(new THREE.SphereGeometry(0.18, 6, 5), 0x5b4a2a, T(px + Math.cos(k * 2.1) * 0.3, 8.8, Math.sin(k * 2.1) * 0.3)));
      break;
    }
    case 'jungleTree': {
      parts.push(part(new THREE.CylinderGeometry(0.35, 0.55, 8, 7), 0x5a4330, T(0, 4, 0)));
      parts.push(part(new THREE.CylinderGeometry(0.2, 0.3, 4, 6), 0x5a4330, T(0.9, 8.5, 0, 0, 0, -0.5)));
      for (const [x, y, z, s] of [[0, 10.5, 0, 3.4], [2.2, 10, 0.8, 2.4], [-2, 9.6, -0.8, 2.6], [0.4, 12.2, 0.4, 2.2]] as const) {
        parts.push(part(bump(new THREE.IcosahedronGeometry(s, 1), 0.35, `c${x}${z}`), 0x2f6a2c, T(x, y, z)));
      }
      break;
    }
    case 'boulder':
    case 'ironRock':
    case 'copperRock': {
      const base = kind === 'boulder' ? 0x7d7a74 : 0x6e6a66;
      parts.push(part(bump(new THREE.IcosahedronGeometry(1, 1), 0.45, `r-${kind}`).scale(1, 0.72, 0.95), base, T(0, 0.55, 0)));
      if (kind !== 'boulder') {
        const ore = kind === 'ironRock' ? 0x9b4a2e : 0x3aa393;
        for (let k = 0; k < 5; k++) parts.push(part(new THREE.IcosahedronGeometry(0.2, 0), ore, T(Math.cos(k * 1.3) * 0.75, 0.6 + (k % 3) * 0.18, Math.sin(k * 1.3) * 0.7)));
      } else {
        parts.push(part(bump(new THREE.IcosahedronGeometry(0.55, 1), 0.4, 'r2'), 0x6b6862, T(0.9, 0.28, 0.4)));
      }
      break;
    }
    case 'berryBush': {
      for (const [x, z, s] of [[0, 0, 0.62], [0.4, 0.2, 0.45], [-0.35, 0.15, 0.4]] as const) parts.push(part(bump(new THREE.IcosahedronGeometry(s, 1), 0.3, `b${x}`), 0x3a6a2a, T(x, s * 0.8, z)));
      for (let k = 0; k < 8; k++) parts.push(part(new THREE.SphereGeometry(0.05, 5, 4), 0x7a1f3d, T(Math.cos(k * 0.8) * 0.5, 0.45 + (k % 3) * 0.15, Math.sin(k * 0.8) * 0.5)));
      break;
    }
    case 'fiberPlant': {
      for (let k = 0; k < 7; k++) {
        const g = new THREE.ConeGeometry(0.06, 0.9, 3);
        parts.push(part(g, 0x6f9a3c, T(Math.cos(k * 0.9) * 0.15, 0.4, Math.sin(k * 0.9) * 0.15, Math.sin(k) * 0.35, 0, Math.cos(k) * 0.35)));
      }
      break;
    }
    case 'bamboo': {
      for (let k = 0; k < 4; k++) {
        const x = Math.cos(k * 1.6) * 0.45;
        const z = Math.sin(k * 1.6) * 0.45;
        for (let s = 0; s < 4; s++) parts.push(part(new THREE.CylinderGeometry(0.08, 0.09, 1.5, 6), s % 2 ? 0x7aa84a : 0x6a9a3e, T(x, 0.75 + s * 1.5, z, 0, 0, (k - 1.5) * 0.03)));
      }
      break;
    }
    case 'mushroomPatch': {
      for (let k = 0; k < 4; k++) {
        const x = Math.cos(k * 1.7) * 0.2;
        const z = Math.sin(k * 1.7) * 0.2;
        parts.push(part(new THREE.CylinderGeometry(0.03, 0.04, 0.16, 5), 0xe9e2c8, T(x, 0.08, z)));
        parts.push(part(new THREE.SphereGeometry(0.1, 6, 4, 0, Math.PI * 2, 0, Math.PI / 2), 0xb36b3a, T(x, 0.16, z)));
      }
      break;
    }
    case 'clayBank': {
      parts.push(part(new THREE.CylinderGeometry(1.1, 1.3, 0.35, 10), 0xa86a42, T(0, 0.17, 0)));
      break;
    }
  }
  const merged = mergeGeometries(parts, false);
  parts.forEach((g) => g.dispose());
  if (!merged) throw new Error(`Vegetation: فشل دمج مجسم ${kind}`);
  return merged;
}

/** يضيف تمايل الرياح عبر Vertex Shader: الإزاحة تتناسب مع مربع الارتفاع النسبي */
export function applyWind(material: THREE.MeshStandardMaterial, swayHeight: number, wind: { time: { value: number }; amp: { value: number } }): void {
  material.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = wind.time;
    shader.uniforms.uWindAmp = wind.amp;
    shader.uniforms.uSway = { value: swayHeight };
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nuniform float uTime;\nuniform float uWindAmp;\nuniform float uSway;')
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        #ifdef USE_INSTANCING
          float sway = pow(clamp(position.y / uSway, 0.0, 1.5), 2.0);
          float ph = uTime * 1.4 + instanceMatrix[3][0] * 0.17 + instanceMatrix[3][2] * 0.13;
          transformed.x += sin(ph) * uWindAmp * sway;
          transformed.z += cos(ph * 0.8) * uWindAmp * 0.6 * sway;
        #endif`,
      );
  };
  material.customProgramCacheKey = () => `wind-${swayHeight}`;
}

interface Slot {
  mesh: THREE.InstancedMesh;
  index: number;
}

/**
 * يرسم عقد الموارد بالـ GPU Instancing مقسّمة إلى قطع (Chunks) 64م لاستفادة Frustum Culling،
 * مع إخفاء القطع البعيدة حسب نوع النبات، وتمايل بالرياح.
 */
export class Vegetation {
  readonly group = new THREE.Group();
  private geometries = new Map<NodeKind, THREE.BufferGeometry>();
  private materials = new Map<NodeKind, THREE.MeshStandardMaterial>();
  private slots = new Map<number, Slot>();
  private chunks: Array<{ cx: number; cz: number; kind: NodeKind; mesh: THREE.InstancedMesh }> = [];
  private wind = { time: { value: 0 }, amp: { value: 0.1 } };
  private cullTimer = 0;
  private m = new THREE.Matrix4();
  private q = new THREE.Quaternion();
  private s = new THREE.Vector3();
  private p = new THREE.Vector3();
  private up = new THREE.Vector3(0, 1, 0);

  constructor(field: ResourceField, shadows: boolean) {
    this.group.name = 'Vegetation';
    const byKey = new Map<string, NodeState[]>();
    for (const n of field.all()) {
      const k = `${n.kind}|${Math.floor(n.x / CHUNK)}|${Math.floor(n.z / CHUNK)}`;
      const arr = byKey.get(k);
      if (arr) arr.push(n);
      else byKey.set(k, [n]);
    }

    for (const [key, nodes] of byKey) {
      const [kind, cx, cz] = key.split('|');
      const k = kind as NodeKind;
      const mesh = new THREE.InstancedMesh(this.geometryFor(k), this.materialFor(k), nodes.length);
      mesh.castShadow = shadows && CASTS_SHADOW.has(k);
      mesh.receiveShadow = true;
      nodes.forEach((n, i) => {
        this.slots.set(n.id, { mesh, index: i });
        this.writeMatrix(n, mesh, i);
      });
      mesh.instanceMatrix.needsUpdate = true;
      // المحيط الكروي للـ culling يجب أن يشمل كل النسخ
      mesh.computeBoundingSphere();
      this.group.add(mesh);
      this.chunks.push({ cx: Number(cx), cz: Number(cz), kind: k, mesh });
    }

    // العقد المستنفدة/العائدة تتحدث ديناميكيًا
    field.onChanged = (n) => this.refresh(n);
  }

  private geometryFor(k: NodeKind): THREE.BufferGeometry {
    let g = this.geometries.get(k);
    if (!g) {
      g = buildGeometry(k);
      this.geometries.set(k, g);
    }
    return g;
  }

  private materialFor(k: NodeKind): THREE.MeshStandardMaterial {
    let m = this.materials.get(k);
    if (!m) {
      m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, metalness: 0, side: k === 'palm' ? THREE.DoubleSide : THREE.FrontSide });
      // الصخور والموارد لا تتمايل
      const sways = k === 'palm' || k === 'jungleTree' || k === 'bamboo' || k === 'fiberPlant' || k === 'berryBush';
      if (sways) applyWind(m, NODE_DEFS[k].height, this.wind);
      this.materials.set(k, m);
    }
    return m;
  }

  private writeMatrix(n: NodeState, mesh: THREE.InstancedMesh, i: number): void {
    const scale = n.alive ? n.scale : 0.0001; // المستنفدة تختفي بتصغيرها
    this.q.setFromAxisAngle(this.up, n.rotY);
    this.p.set(n.x, n.y, n.z);
    this.s.set(scale, scale, scale);
    this.m.compose(this.p, this.q, this.s);
    mesh.setMatrixAt(i, this.m);
  }

  private refresh(n: NodeState): void {
    const slot = this.slots.get(n.id);
    if (!slot) return;
    this.writeMatrix(n, slot.mesh, slot.index);
    slot.mesh.instanceMatrix.needsUpdate = true;
  }

  /** @param windStrength 0..1 من الطقس */
  update(elapsed: number, camPos: THREE.Vector3, windStrength: number, dt: number): void {
    this.wind.time.value = elapsed;
    this.wind.amp.value = 0.05 + windStrength * 0.35;

    // إخفاء القطع البعيدة (كل ربع ثانية يكفي)
    this.cullTimer -= dt;
    if (this.cullTimer > 0) return;
    this.cullTimer = 0.25;
    for (const c of this.chunks) {
      const cx = (c.cx + 0.5) * CHUNK;
      const cz = (c.cz + 0.5) * CHUNK;
      const d = Math.hypot(camPos.x - cx, camPos.z - cz) - CHUNK * 0.71;
      c.mesh.visible = d < VIEW_DISTANCE[c.kind];
    }
  }

  dispose(): void {
    for (const c of this.chunks) c.mesh.dispose();
    this.geometries.forEach((g) => g.dispose());
    this.materials.forEach((m) => m.dispose());
  }
}
