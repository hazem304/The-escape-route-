import * as THREE from 'three';
import { TERRAIN_SIZE } from './TerrainGenerator';
import { TerrainMesh } from './TerrainMesh';

const VERT = /* glsl */ `
  uniform float uTime;
  uniform float uWaveAmp;
  varying vec3 vWorld;
  varying vec3 vNormal;
  varying float vWaveH;

  // موجة Gerstner: dir, steepness, wavelength
  vec3 gerstner(vec2 p, vec2 dir, float steep, float wl, float t, inout vec3 tangent, inout vec3 binormal) {
    float k = 6.28318 / wl;
    float c = sqrt(9.8 / k);
    vec2 d = normalize(dir);
    float f = k * (dot(d, p) - c * t);
    float a = steep / k;
    tangent  += vec3(-d.x * d.x * steep * sin(f), d.x * steep * cos(f), -d.x * d.y * steep * sin(f));
    binormal += vec3(-d.x * d.y * steep * sin(f), d.y * steep * cos(f), -d.y * d.y * steep * sin(f));
    return vec3(d.x * a * cos(f), a * sin(f), d.y * a * cos(f));
  }

  void main() {
    vec4 wp = modelMatrix * vec4(position, 1.0);
    vec3 tangent = vec3(1.0, 0.0, 0.0);
    vec3 binormal = vec3(0.0, 0.0, 1.0);
    vec3 off = vec3(0.0);
    float amp = uWaveAmp;
    off += gerstner(wp.xz, vec2(1.0, 0.3), 0.22 * amp, 38.0, uTime, tangent, binormal);
    off += gerstner(wp.xz, vec2(0.6, 1.0), 0.18 * amp, 21.0, uTime, tangent, binormal);
    off += gerstner(wp.xz, vec2(-0.4, 0.9), 0.12 * amp, 11.0, uTime, tangent, binormal);
    off += gerstner(wp.xz, vec2(0.9, -0.5), 0.08 * amp, 5.5, uTime, tangent, binormal);
    wp.xyz += off;
    vWorld = wp.xyz;
    vWaveH = off.y;
    vNormal = normalize(cross(binormal, tangent));
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`;

const FRAG = /* glsl */ `
  uniform float uTime;
  uniform sampler2D uHeightTex;
  uniform float uTerrainSize;
  uniform float uHeightRange;
  uniform vec3 uSunDir;
  uniform vec3 uSunColor;
  uniform vec3 uSkyColor;
  uniform vec3 uShallow;
  uniform vec3 uDeep;
  uniform vec3 uFogColor;
  uniform float uFogDensity;
  uniform float uLight;
  varying vec3 vWorld;
  varying vec3 vNormal;
  varying float vWaveH;

  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
  }

  void main() {
    // عمق الماء من نسيج الارتفاعات (خارج الجزيرة = عميق)
    vec2 uv = vWorld.xz / uTerrainSize + 0.5;
    float depth = 60.0;
    if (uv.x > 0.0 && uv.x < 1.0 && uv.y > 0.0 && uv.y < 1.0) {
      float h = (texture2D(uHeightTex, uv).r - 0.5) * uHeightRange;
      depth = max(0.0, -h);
    }

    // تفاصيل الأمواج الصغيرة تُضاف للناظم
    vec2 q = vWorld.xz * 0.35 + vec2(uTime * 0.05, -uTime * 0.04);
    vec3 n = normalize(vNormal + 0.12 * vec3(vnoise(q) - 0.5, 0.0, vnoise(q + 7.3) - 0.5));

    vec3 V = normalize(cameraPosition - vWorld);
    float fres = pow(1.0 - max(dot(n, V), 0.0), 4.0);
    fres = clamp(0.03 + 0.97 * fres, 0.0, 1.0);

    // لون متدرج: فيروزي ضحل ← أزرق غامق عميق
    float dT = 1.0 - exp(-depth * 0.18);
    vec3 body = mix(uShallow, uDeep, dT) * uLight;

    // انعكاس السماء + لمعان الشمس
    vec3 refl = uSkyColor * uLight;
    vec3 H = normalize(uSunDir + V);
    float spec = pow(max(dot(n, H), 0.0), 220.0) * 2.5;
    vec3 col = mix(body, refl, fres) + uSunColor * spec * step(0.0, uSunDir.y);

    // رغوة الشاطئ: خطوط تتحرك مع الموج عند العمق الضحل
    float shoreBand = 1.0 - smoothstep(0.0, 1.4, depth + vWaveH * 0.6);
    float stripes = 0.5 + 0.5 * sin(depth * 5.0 - uTime * 1.6 + vnoise(vWorld.xz * 0.8) * 4.0);
    float foamNoise = vnoise(vWorld.xz * 2.2 + uTime * 0.2);
    float foam = shoreBand * smoothstep(0.35, 0.8, stripes * 0.7 + foamNoise * 0.5);
    foam += smoothstep(0.55, 1.0, vWaveH * 1.2 + foamNoise * 0.3) * 0.25; // قمم الأمواج
    col = mix(col, vec3(0.95, 0.98, 1.0) * uLight, clamp(foam, 0.0, 1.0));

    // ضباب بالمسافة
    float dist = length(cameraPosition - vWorld);
    float fog = 1.0 - exp(-dist * dist * uFogDensity * uFogDensity);
    col = mix(col, uFogColor, clamp(fog, 0.0, 1.0));

    // شفافية: شفاف عند الشاطئ، معتم في العمق
    float alpha = clamp(0.35 + dT * 0.65 + foam * 0.4, 0.0, 1.0);
    gl_FragColor = vec4(col, alpha);
    #include <colorspace_fragment>
  }
`;

export class Ocean {
  readonly mesh: THREE.Mesh;
  private material: THREE.ShaderMaterial;
  private static readonly SIZE = 3000;
  private static readonly SEGMENTS = 300;

  constructor(heightTexture: THREE.DataTexture) {
    const geo = new THREE.PlaneGeometry(Ocean.SIZE, Ocean.SIZE, Ocean.SEGMENTS, Ocean.SEGMENTS);
    geo.rotateX(-Math.PI / 2);

    this.material = new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      transparent: true,
      depthWrite: false,
      uniforms: {
        uTime: { value: 0 },
        uWaveAmp: { value: 1 },
        uHeightTex: { value: heightTexture },
        uTerrainSize: { value: TERRAIN_SIZE },
        uHeightRange: { value: TerrainMesh.HEIGHT_RANGE },
        uSunDir: { value: new THREE.Vector3(0, 1, 0) },
        uSunColor: { value: new THREE.Color(1, 0.95, 0.85) },
        uSkyColor: { value: new THREE.Color(0x8ec9e8) },
        uShallow: { value: new THREE.Color(0x3fd0c9) },
        uDeep: { value: new THREE.Color(0x06324a) },
        uFogColor: { value: new THREE.Color(0x8ec9e8) },
        uFogDensity: { value: 0.0008 },
        uLight: { value: 1 },
      },
    });

    this.mesh = new THREE.Mesh(geo, this.material);
    this.mesh.name = 'Ocean';
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 1;
  }

  /**
   * يتبع الكاميرا بخطوات تساوي حجم خلية الشبكة حتى لا تنزلق الأمواج تحت اللاعب.
   */
  update(
    time: number,
    camPos: THREE.Vector3,
    env: { sunDir: THREE.Vector3; sunColor: THREE.Color; skyColor: THREE.Color; fogColor: THREE.Color; fogDensity: number; light: number; waveAmp: number },
  ): void {
    const cell = Ocean.SIZE / Ocean.SEGMENTS;
    this.mesh.position.x = Math.round(camPos.x / cell) * cell;
    this.mesh.position.z = Math.round(camPos.z / cell) * cell;

    const u = this.material.uniforms;
    u.uTime.value = time;
    u.uWaveAmp.value = env.waveAmp;
    (u.uSunDir.value as THREE.Vector3).copy(env.sunDir);
    (u.uSunColor.value as THREE.Color).copy(env.sunColor);
    (u.uSkyColor.value as THREE.Color).copy(env.skyColor);
    (u.uFogColor.value as THREE.Color).copy(env.fogColor);
    u.uFogDensity.value = env.fogDensity;
    u.uLight.value = env.light;
  }

  dispose(): void {
    this.mesh.geometry.dispose();
    this.material.dispose();
  }
}
