import type { ItemStack } from '../inventory/Item';
import type { Inventory } from '../inventory/Inventory';
import { ensureUidAbove } from '../inventory/Item';
import { ItemDB } from '../inventory/ItemDatabase';

export interface GroundItem {
  id: number;
  stack: ItemStack;
  x: number;
  y: number;
  z: number;
  /** عمره بالثواني */
  age: number;
}

const DESPAWN_SECONDS = 600;
const MERGE_RADIUS = 0.6;

/** عناصر ملقاة على الأرض (مرمية أو ساقطة من عقد/حيوانات) */
export class GroundItems {
  private items = new Map<number, GroundItem>();
  private nextId = 1;
  onChanged: ((item: GroundItem, removed: boolean) => void) | null = null;

  list(): GroundItem[] {
    return [...this.items.values()];
  }

  get size(): number {
    return this.items.size;
  }

  /** يرمي مكدّسًا؛ المتماثلات القريبة تندمج لتفادي تكدّس الكيانات */
  drop(stack: ItemStack, x: number, y: number, z: number): GroundItem {
    const def = ItemDB.get(stack.defId);
    if (def.stack > 1) {
      for (const it of this.items.values()) {
        if (it.stack.defId !== stack.defId || it.stack.count >= def.stack) continue;
        if (Math.hypot(it.x - x, it.z - z) > MERGE_RADIUS) continue;
        const room = def.stack - it.stack.count;
        const moved = Math.min(room, stack.count);
        it.stack.count += moved;
        stack.count -= moved;
        it.age = 0;
        this.onChanged?.(it, false);
        if (stack.count <= 0) return it;
      }
    }
    const item: GroundItem = { id: this.nextId++, stack, x, y, z, age: 0 };
    this.items.set(item.id, item);
    this.onChanged?.(item, false);
    return item;
  }

  dropNew(defId: string, count: number, x: number, y: number, z: number): GroundItem {
    return this.drop(ItemDB.create(defId, count), x, y, z);
  }

  /** أقرب عنصر ضمن مسافة */
  nearest(x: number, z: number, r: number): GroundItem | null {
    let best: GroundItem | null = null;
    let bd = r;
    for (const it of this.items.values()) {
      const d = Math.hypot(it.x - x, it.z - z);
      if (d <= bd) {
        bd = d;
        best = it;
      }
    }
    return best;
  }

  /** يلتقط عنصرًا إلى الحقيبة؛ ما لا يتسع يبقى على الأرض */
  pickup(id: number, inv: Inventory): { ok: boolean; picked: number; left: number } {
    const it = this.items.get(id);
    if (!it) return { ok: false, picked: 0, left: 0 };
    const before = it.stack.count;
    const left = inv.add(it.stack.defId, it.stack.count, { durability: it.stack.durability, spoil: it.stack.spoil });
    // العناصر ذات المتانة تُضاف كمكدّس جديد بالمتانة المحفوظة (add يستخدم الافتراضية) فنضبطها
    if (left < before && ItemDB.get(it.stack.defId).durability > 0) {
      const e = inv.grid.list().filter((g) => g.stack.defId === it.stack.defId).pop();
      if (e) e.stack.durability = it.stack.durability;
    }
    if (left === 0) {
      this.items.delete(id);
      this.onChanged?.(it, true);
    } else {
      it.stack.count = left;
      this.onChanged?.(it, false);
    }
    return { ok: left < before, picked: before - left, left };
  }

  toJSON(): GroundItem[] {
    return this.list();
  }

  load(items: GroundItem[]): void {
    this.items.clear();
    let maxUid = 0;
    for (const it of items) {
      this.items.set(it.id, it);
      this.nextId = Math.max(this.nextId, it.id + 1);
      maxUid = Math.max(maxUid, it.stack.uid);
      this.onChanged?.(it, false);
    }
    ensureUidAbove(maxUid);
  }

  /** @param dt ثواني حقيقية */
  update(dt: number): void {
    for (const it of [...this.items.values()]) {
      it.age += dt;
      if (it.age >= DESPAWN_SECONDS) {
        this.items.delete(it.id);
        this.onChanged?.(it, true);
      }
    }
  }
}
