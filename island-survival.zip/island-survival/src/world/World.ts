import * as THREE from 'three';
import type { EventBus, GameEvents } from '../core/EventBus';
import type { Physics } from '../core/Physics';
import type { GameConfig } from '../config';
import { QUALITY_PRESETS } from '../config';
import { DayNight } from './DayNight';
import { Ocean } from './Ocean';
import { Sky } from './Sky';
import { TerrainGenerator } from './TerrainGenerator';
import { TerrainMesh } from './TerrainMesh';
import { Weather } from './Weather';

/**
 * يجمع عناصر العالم (تضاريس، محيط، سماء، يوم/ليل، طقس) ويطبّق نتائجها على الإضاءة والضباب.
 */
export class World {
  readonly terrain: TerrainGenerator;
  readonly terrainMesh: TerrainMesh;
  readonly ocean: Ocean;
  readonly sky = new Sky();
  readonly dayNight = new DayNight();
  readonly weather: Weather;

  readonly sun = new THREE.DirectionalLight(0xffffff, 2);
  readonly hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 0.5);
  private fog = new THREE.FogExp2(0xa9d4ee, 0.0008);

  /** تعريض مقترح للـ Renderer */
  exposure = 1;

  private tmpColor = new THREE.Color();
  private tmpSky = new THREE.Color();

  constructor(
    readonly scene: THREE.Scene,
    physics: Physics,
    bus: EventBus<GameEvents>,
    config: GameConfig,
    seed: number | string = 'island-1',
  ) {
    this.terrain = new TerrainGenerator(seed);
    this.terrainMesh = new TerrainMesh(this.terrain);
    this.ocean = new Ocean(this.terrainMesh.heightTexture);
    this.weather = new Weather(bus, `${seed}-weather`);

    physics.createTrimesh(this.terrainMesh.physicsVertices, this.terrainMesh.physicsIndices);

    const q = QUALITY_PRESETS[config.quality];
    this.sun.castShadow = q.shadows;
    this.sun.shadow.mapSize.set(q.shadowMapSize, q.shadowMapSize);
    const sc = this.sun.shadow.camera;
    sc.left = sc.bottom = -45;
    sc.right = sc.top = 45;
    sc.near = 1;
    sc.far = 220;
    this.sun.shadow.bias = -0.0004;
    this.sun.shadow.normalBias = 0.05;

    scene.fog = this.fog;
    scene.add(this.terrainMesh.group, this.ocean.mesh, this.sky.mesh, this.sun, this.sun.target, this.hemi, this.weather.rainLines);
  }

  get spawnPoint(): THREE.Vector3 {
    const s = this.terrain.spawn;
    return new THREE.Vector3(s.x, s.y, s.z);
  }

  update(dt: number, elapsed: number, camPos: THREE.Vector3, focus: THREE.Vector3): void {
    this.dayNight.update(dt);
    this.weather.update(dt, camPos, elapsed);

    const dn = this.dayNight;
    const w = this.weather.current;

    // إضاءة: الشمس تخفت مع الغيوم والعواصف، والبرق يضيء المشهد
    const cloudDim = w.light;
    this.sun.color.copy(dn.sunColor);
    this.sun.intensity = dn.sunIntensity * cloudDim + this.weather.flash * 1.5;
    // أثناء الليل نوجّه الضوء من القمر
    const lightDir = dn.elevation > -0.02 ? dn.sunDir : dn.moonDir;
    this.sun.position.copy(focus).addScaledVector(lightDir, 120);
    this.sun.target.position.copy(focus);

    this.hemi.color.copy(dn.skyAmbient);
    this.hemi.groundColor.copy(dn.groundAmbient);
    this.hemi.intensity = dn.ambientIntensity * (0.5 + 0.5 * cloudDim) + this.weather.flash * 1.2;

    // ضباب: لون اليوم مع تغميق بالعواصف، وكثافة من الطقس
    this.tmpColor.copy(dn.fogColor).multiplyScalar(0.55 + 0.45 * cloudDim);
    this.fog.color.copy(this.tmpColor);
    this.fog.density = this.weather.fogDensity;
    this.exposure = dn.exposure;

    this.tmpSky.copy(dn.skyAmbient).multiplyScalar(0.9 * (0.4 + 0.6 * cloudDim));

    this.sky.update(elapsed, camPos, {
      sunDir: dn.sunDir,
      moonDir: dn.moonDir,
      sunColor: dn.sunColor,
      daylight: dn.daylight,
      cloudCover: w.cloudCover,
      storm: w.storm,
      flash: this.weather.flash,
      fogColor: this.tmpColor,
    });

    this.ocean.update(elapsed, camPos, {
      sunDir: lightDir,
      sunColor: dn.sunColor,
      skyColor: this.tmpSky,
      fogColor: this.tmpColor,
      fogDensity: this.weather.fogDensity,
      light: 0.25 + 0.75 * dn.daylight * (0.5 + 0.5 * cloudDim),
      waveAmp: w.waveAmp,
    });
  }

  dispose(): void {
    this.terrainMesh.dispose();
    this.ocean.dispose();
    this.sky.dispose();
    this.weather.dispose();
  }
}
