import * as THREE from 'three';

/**
 * دورة اليوم والليل. الوقت بالساعات 0..24.
 * تُنتج اتجاه الشمس والقمر وألوان الإضاءة والضباب، وتستهلكها Sky / World.
 */
export class DayNight {
  /** الساعة الحالية (0..24) */
  hour = 7.5;
  /** طول اليوم الكامل بالثواني الحقيقية */
  dayLengthSeconds = 1200;
  paused = false;

  readonly sunDir = new THREE.Vector3(0, 1, 0);
  readonly moonDir = new THREE.Vector3(0, -1, 0);
  readonly sunColor = new THREE.Color();
  readonly skyAmbient = new THREE.Color();
  readonly groundAmbient = new THREE.Color();
  readonly fogColor = new THREE.Color();

  /** ارتفاع الشمس -1..1 */
  elevation = 0;
  sunIntensity = 1;
  ambientIntensity = 0.5;
  /** 0 ليل كامل .. 1 نهار كامل */
  daylight = 1;
  /** ضبط تعريض الكاميرا */
  exposure = 1;

  private static readonly NIGHT_SKY = new THREE.Color(0x0b1430);
  private static readonly NIGHT_GROUND = new THREE.Color(0x0a0d12);
  private static readonly DAY_SKY = new THREE.Color(0xcfe8ff);
  private static readonly DAY_GROUND = new THREE.Color(0x7a6a46);
  private static readonly DAWN_SUN = new THREE.Color(0xff9a52);
  private static readonly NOON_SUN = new THREE.Color(0xfff4de);
  private static readonly NIGHT_FOG = new THREE.Color(0x0a1220);
  private static readonly DAY_FOG = new THREE.Color(0xa9d4ee);
  private static readonly DUSK_FOG = new THREE.Color(0xe0906a);

  constructor() {
    this.recompute();
  }

  get isNight(): boolean {
    return this.daylight < 0.25;
  }

  /** يعيد HH:MM للعرض */
  get clockText(): string {
    const h = Math.floor(this.hour) % 24;
    const m = Math.floor((this.hour - Math.floor(this.hour)) * 60);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  }

  setHour(h: number): void {
    this.hour = ((h % 24) + 24) % 24;
    this.recompute();
  }

  update(dt: number): void {
    if (!this.paused) {
      this.hour = (this.hour + (dt * 24) / this.dayLengthSeconds) % 24;
    }
    this.recompute();
  }

  private recompute(): void {
    // الشمس تشرق عند 6 وتغرب عند 18: زاوية 0 عند الشروق
    const a = ((this.hour - 6) / 24) * Math.PI * 2;
    // مسار مائل قليلًا (ميل 0.3 نحو الجنوب) ليكون الظل أكثر طبيعية
    this.sunDir.set(Math.cos(a), Math.sin(a), 0.3).normalize();
    this.moonDir.copy(this.sunDir).multiplyScalar(-1);
    this.elevation = this.sunDir.y;

    const day = smoothstep(-0.08, 0.25, this.elevation);
    this.daylight = day;

    // لون الشمس: برتقالي قرب الأفق، أبيض دافئ عند الظهر
    const warm = 1 - smoothstep(0.0, 0.45, this.elevation);
    this.sunColor.copy(DayNight.NOON_SUN).lerp(DayNight.DAWN_SUN, warm);

    // الشمس تخفت قبل الغروب بقليل؛ ليلًا يتولى القمر إضاءة ضعيفة
    const moonLight = 0.06 * smoothstep(-0.05, 0.3, -this.elevation);
    this.sunIntensity = 2.6 * smoothstep(-0.02, 0.3, this.elevation) + moonLight;

    this.skyAmbient.copy(DayNight.NIGHT_SKY).lerp(DayNight.DAY_SKY, day);
    this.groundAmbient.copy(DayNight.NIGHT_GROUND).lerp(DayNight.DAY_GROUND, day);
    this.ambientIntensity = 0.12 + 0.6 * day;

    // ضباب: يميل للبرتقالي عند الشروق والغروب
    const dusk = (1 - Math.abs(this.elevation - 0.05) / 0.3);
    const duskAmt = Math.max(0, Math.min(1, dusk));
    this.fogColor.copy(DayNight.NIGHT_FOG).lerp(DayNight.DAY_FOG, day).lerp(DayNight.DUSK_FOG, duskAmt * 0.55);

    this.exposure = 0.75 + 0.35 * day;
  }
}

function smoothstep(a: number, b: number, x: number): number {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}
