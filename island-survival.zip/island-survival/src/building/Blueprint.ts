/** مخططات البناء: التكلفة ونوع التثبيت */
export type PieceType = 'foundation' | 'wall' | 'doorway' | 'door' | 'roof' | 'campfire' | 'workbench' | 'storage' | 'barrel' | 'cooler' | 'bed' | 'rack' | 'furnace' | 'collector' | 'farm' | 'raft';

export type SnapKind = 'cell' | 'edge' | 'edgeDoor' | 'free';

export interface Blueprint {
  type: PieceType;
  nameAr: string;
  nameEn: string;
  snap: SnapKind;
  /** تكلفة المواد */
  cost: Record<string, number>;
  /** نصف قطر التصادم للقطع الحرّة (متر) */
  radius: number;
  /** يُبنى فوق الماء (الطوافة) */
  onWater?: boolean;
}

export const CELL_SIZE = 3;
export const WALL_HEIGHT = 2.5;

export const BLUEPRINTS: Record<PieceType, Blueprint> = {
  foundation: { type: 'foundation', nameAr: 'أساس', nameEn: 'Foundation', snap: 'cell', cost: { plank: 4, support_beam: 2 }, radius: 0 },
  wall: { type: 'wall', nameAr: 'جدار', nameEn: 'Wall', snap: 'edge', cost: { plank: 3, nails: 4 }, radius: 0 },
  doorway: { type: 'doorway', nameAr: 'إطار باب', nameEn: 'Doorway', snap: 'edge', cost: { plank: 3, nails: 4 }, radius: 0 },
  door: { type: 'door', nameAr: 'باب', nameEn: 'Door', snap: 'edgeDoor', cost: { door_wood: 1 }, radius: 0 },
  roof: { type: 'roof', nameAr: 'سقف', nameEn: 'Roof', snap: 'cell', cost: { thatch: 6, stick: 6, rope: 2 }, radius: 0 },
  campfire: { type: 'campfire', nameAr: 'موقد', nameEn: 'Campfire', snap: 'free', cost: { campfire_kit: 1 }, radius: 0.8 },
  workbench: { type: 'workbench', nameAr: 'طاولة عمل', nameEn: 'Workbench', snap: 'free', cost: { workbench_kit: 1 }, radius: 1.1 },
  barrel: { type: 'barrel', nameAr: 'برميل', nameEn: 'Barrel', snap: 'free', cost: { barrel: 1 }, radius: 0.6 },
  cooler: { type: 'cooler', nameAr: 'ثلاجة بدائية', nameEn: 'Primitive Cooler', snap: 'free', cost: { cooler: 1 }, radius: 0.7 },
  storage: { type: 'storage', nameAr: 'صندوق تخزين', nameEn: 'Storage', snap: 'free', cost: { storage_box: 1 }, radius: 0.7 },
  bed: { type: 'bed', nameAr: 'فراش', nameEn: 'Bed', snap: 'free', cost: { bed_leaf: 1 }, radius: 1.0 },
  rack: { type: 'rack', nameAr: 'رف تجفيف', nameEn: 'Drying Rack', snap: 'free', cost: { drying_rack: 1 }, radius: 0.9 },
  furnace: { type: 'furnace', nameAr: 'فرن', nameEn: 'Furnace', snap: 'free', cost: { furnace_kit: 1 }, radius: 1.0 },
  collector: { type: 'collector', nameAr: 'جامع مطر', nameEn: 'Rain Collector', snap: 'free', cost: { water_collector: 1 }, radius: 0.6 },
  farm: { type: 'farm', nameAr: 'مزرعة', nameEn: 'Farm Plot', snap: 'free', cost: { farm_plot: 1 }, radius: 1.5 },
  raft: { type: 'raft', nameAr: 'طوافة', nameEn: 'Raft', snap: 'free', cost: { raft_kit: 1 }, radius: 2.4, onWater: true },
};
