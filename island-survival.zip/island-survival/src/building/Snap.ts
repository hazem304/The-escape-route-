import type { Inventory } from '../inventory/Inventory';
import { BLUEPRINTS, CELL_SIZE, type PieceType } from './Blueprint';

export type Axis = 'h' | 'v';

/** مفتاح القطعة: خلية أو حافة أو موضع حر */
export interface Piece {
  id: number;
  type: PieceType;
  /** الخلية (للأساس/السقف) أو الخلية المالكة للحافة */
  cx: number;
  cz: number;
  /** للحواف: h = حافة شمالية للخلية (على امتداد x)، v = حافة غربية (على امتداد z) */
  axis?: Axis;
  /** الموضع في العالم (للعرض والقطع الحرة) */
  x: number;
  y: number;
  z: number;
  /** دوران حول Y بالراديان */
  yaw: number;
}

export type BuildError = 'noSupport' | 'occupied' | 'badGround' | 'overlap' | 'noMaterials' | 'noDoorway' | 'needsWalls' | 'notOnWater';

export type SnapTarget =
  | { kind: 'cell'; cx: number; cz: number }
  | { kind: 'edge'; cx: number; cz: number; axis: Axis }
  | { kind: 'free'; x: number; z: number; yaw: number };

export interface GroundQuery {
  /** ارتفاع الأرض عند النقطة */
  height(x: number, z: number): number;
  /** ميل 0..1 */
  slope(x: number, z: number): number;
  waterLevel: number;
}

/**
 * شبكة البناء المعياري (Snap): أساسات على شبكة 3م، جدران على الحواف، أسقف فوق الخلايا،
 * وقطع حرة (موقد، صندوق...) بمنع التداخل. الإزالة متتالية (cascade) إن فقدت القطع دعمها.
 */
export class BuildingGrid {
  private pieces = new Map<number, Piece>();
  private nextId = 1;
  /** فهارس سريعة */
  private cells = new Map<string, Piece>(); // foundation / roof
  private edges = new Map<string, Piece[]>(); // wall/doorway/door

  constructor(private ground: GroundQuery) {}

  list(): Piece[] {
    return [...this.pieces.values()];
  }

  get(id: number): Piece | undefined {
    return this.pieces.get(id);
  }

  // ---------- مفاتيح ----------
  private static cellKey(type: 'foundation' | 'roof', cx: number, cz: number): string {
    return `${type}:${cx},${cz}`;
  }
  private static edgeKey(axis: Axis, cx: number, cz: number): string {
    return `${axis}:${cx},${cz}`;
  }

  static cellOf(x: number, z: number): { cx: number; cz: number } {
    return { cx: Math.floor(x / CELL_SIZE), cz: Math.floor(z / CELL_SIZE) };
  }

  /** الخليتان المتجاورتان لحافة */
  static edgeCells(axis: Axis, cx: number, cz: number): Array<[number, number]> {
    return axis === 'h' ? [[cx, cz], [cx, cz - 1]] : [[cx, cz], [cx - 1, cz]];
  }

  /** حواف خلية */
  static cellEdges(cx: number, cz: number): Array<{ axis: Axis; cx: number; cz: number }> {
    return [
      { axis: 'h', cx, cz },
      { axis: 'h', cx, cz: cz + 1 },
      { axis: 'v', cx, cz },
      { axis: 'v', cx: cx + 1, cz },
    ];
  }

  /** تحت سقف؟ (خلية فيها أساس وسقف) */
  isSheltered(x: number, z: number): boolean {
    const { cx, cz } = BuildingGrid.cellOf(x, z);
    return this.cells.has(BuildingGrid.cellKey('roof', cx, cz)) && this.hasFoundation(cx, cz);
  }

  hasFoundation(cx: number, cz: number): boolean {
    return this.cells.has(BuildingGrid.cellKey('foundation', cx, cz));
  }

  edgeSet(axis: Axis, cx: number, cz: number): Piece[] {
    return this.edges.get(BuildingGrid.edgeKey(axis, cx, cz)) ?? [];
  }

  /** أقرب هدف تثبيت لنقطة في العالم */
  snapFromWorld(type: PieceType, x: number, z: number, yaw = 0): SnapTarget {
    const bp = BLUEPRINTS[type];
    if (bp.snap === 'cell') {
      const { cx, cz } = BuildingGrid.cellOf(x, z);
      return { kind: 'cell', cx, cz };
    }
    if (bp.snap === 'edge' || bp.snap === 'edgeDoor') {
      const { cx, cz } = BuildingGrid.cellOf(x, z);
      // المسافة لكل حافة من الخلية الحالية
      let best: { axis: Axis; cx: number; cz: number; d: number } | null = null;
      for (const e of BuildingGrid.cellEdges(cx, cz)) {
        const mx = e.axis === 'h' ? (e.cx + 0.5) * CELL_SIZE : e.cx * CELL_SIZE;
        const mz = e.axis === 'h' ? e.cz * CELL_SIZE : (e.cz + 0.5) * CELL_SIZE;
        const d = Math.hypot(x - mx, z - mz);
        if (!best || d < best.d) best = { ...e, d };
      }
      return { kind: 'edge', cx: best!.cx, cz: best!.cz, axis: best!.axis };
    }
    return { kind: 'free', x, z, yaw };
  }

  /** هل يمكن وضع القطعة؟ (بدون استهلاك مواد) */
  validate(type: PieceType, t: SnapTarget): { ok: true } | { ok: false; error: BuildError } {
    const bp = BLUEPRINTS[type];

    if (bp.snap === 'cell' && t.kind === 'cell') {
      if (type === 'foundation') {
        if (this.cells.has(BuildingGrid.cellKey('foundation', t.cx, t.cz))) return { ok: false, error: 'occupied' };
        const g = this.groundOkForCell(t.cx, t.cz);
        return g ? { ok: true } : { ok: false, error: 'badGround' };
      }
      // سقف
      if (!this.hasFoundation(t.cx, t.cz)) return { ok: false, error: 'noSupport' };
      if (this.cells.has(BuildingGrid.cellKey('roof', t.cx, t.cz))) return { ok: false, error: 'occupied' };
      const walls = BuildingGrid.cellEdges(t.cx, t.cz).filter((e) => this.edgeSet(e.axis, e.cx, e.cz).length > 0).length;
      return walls >= 2 ? { ok: true } : { ok: false, error: 'needsWalls' };
    }

    if ((bp.snap === 'edge' || bp.snap === 'edgeDoor') && t.kind === 'edge') {
      const here = this.edgeSet(t.axis, t.cx, t.cz);
      const supported = BuildingGrid.edgeCells(t.axis, t.cx, t.cz).some(([a, b]) => this.hasFoundation(a, b));
      if (type === 'door') {
        if (!here.some((p) => p.type === 'doorway')) return { ok: false, error: 'noDoorway' };
        if (here.some((p) => p.type === 'door')) return { ok: false, error: 'occupied' };
        return { ok: true };
      }
      if (!supported) return { ok: false, error: 'noSupport' };
      if (here.length > 0) return { ok: false, error: 'occupied' };
      return { ok: true };
    }

    if (bp.snap === 'free' && t.kind === 'free') {
      const h = this.ground.height(t.x, t.z);
      if (bp.onWater) {
        // الطوافة: على الماء بعمق كافٍ (الأرض تحت السطح)
        if (h > this.ground.waterLevel - 0.6) return { ok: false, error: 'notOnWater' };
      } else {
        if (h < this.ground.waterLevel + 0.2 || this.ground.slope(t.x, t.z) > 0.45) return { ok: false, error: 'badGround' };
      }
      for (const p of this.pieces.values()) {
        const pr = BLUEPRINTS[p.type].radius;
        if (pr > 0 && Math.hypot(p.x - t.x, p.z - t.z) < pr + bp.radius) return { ok: false, error: 'overlap' };
        // لا قطع حرة داخل خلايا الأساس غير المسقوفة؟ مسموح (أثاث داخلي)
      }
      return { ok: true };
    }
    return { ok: false, error: 'occupied' };
  }

  /**
   * يبني قطعة: يتحقق ثم يستهلك المواد من الحقيبة.
   * @param inv إن مُرّر تُستهلك التكلفة (وإلا بناء مجاني للاختبار/وضع الإبداع)
   */
  build(type: PieceType, t: SnapTarget, inv?: Inventory): { ok: true; piece: Piece } | { ok: false; error: BuildError } {
    const v = this.validate(type, t);
    if (!v.ok) return v;
    const bp = BLUEPRINTS[type];
    if (inv) {
      for (const [id, n] of Object.entries(bp.cost)) if (!inv.has(id, n)) return { ok: false, error: 'noMaterials' };
      for (const [id, n] of Object.entries(bp.cost)) inv.remove(id, n);
    }
    const piece = this.create(type, t);
    this.pieces.set(piece.id, piece);
    this.index(piece);
    return { ok: true, piece };
  }

  private create(type: PieceType, t: SnapTarget): Piece {
    const id = this.nextId++;
    if (t.kind === 'cell') {
      const x = (t.cx + 0.5) * CELL_SIZE;
      const z = (t.cz + 0.5) * CELL_SIZE;
      // الأساس يُرفع إلى أعلى نقطة في زواياه حتى يبقى مستويًا
      const y = this.cellTop(t.cx, t.cz);
      return { id, type, cx: t.cx, cz: t.cz, x, y: type === 'roof' ? this.foundationY(t.cx, t.cz) + 2.5 : y, z, yaw: 0 };
    }
    if (t.kind === 'edge') {
      const x = t.axis === 'h' ? (t.cx + 0.5) * CELL_SIZE : t.cx * CELL_SIZE;
      const z = t.axis === 'h' ? t.cz * CELL_SIZE : (t.cz + 0.5) * CELL_SIZE;
      const y = this.edgeBase(t.axis, t.cx, t.cz);
      return { id, type, cx: t.cx, cz: t.cz, axis: t.axis, x, y, z, yaw: t.axis === 'h' ? 0 : Math.PI / 2 };
    }
    const y = BLUEPRINTS[type].onWater ? this.ground.waterLevel : this.ground.height(t.x, t.z);
    const { cx, cz } = BuildingGrid.cellOf(t.x, t.z);
    return { id, type, cx, cz, x: t.x, y, z: t.z, yaw: t.yaw };
  }

  private index(p: Piece): void {
    if (p.type === 'foundation' || p.type === 'roof') this.cells.set(BuildingGrid.cellKey(p.type, p.cx, p.cz), p);
    else if (p.axis) {
      const k = BuildingGrid.edgeKey(p.axis, p.cx, p.cz);
      const arr = this.edges.get(k) ?? [];
      arr.push(p);
      this.edges.set(k, arr);
    }
  }

  private unindex(p: Piece): void {
    if (p.type === 'foundation' || p.type === 'roof') this.cells.delete(BuildingGrid.cellKey(p.type, p.cx, p.cz));
    else if (p.axis) {
      const k = BuildingGrid.edgeKey(p.axis, p.cx, p.cz);
      const arr = (this.edges.get(k) ?? []).filter((q) => q.id !== p.id);
      if (arr.length) this.edges.set(k, arr);
      else this.edges.delete(k);
    }
  }

  /**
   * يزيل قطعة وكل ما فقد دعمه نتيجة ذلك.
   * @returns القطع المزالة (للاسترجاع الجزئي للمواد أو الإسقاط)
   */
  remove(id: number): Piece[] {
    const root = this.pieces.get(id);
    if (!root) return [];
    const removed: Piece[] = [];
    const drop = (p: Piece): void => {
      if (!this.pieces.delete(p.id)) return;
      this.unindex(p);
      removed.push(p);
    };
    drop(root);

    // تكرار حتى الاستقرار: أي قطعة فقدت دعمها تسقط
    let changed = true;
    while (changed) {
      changed = false;
      for (const p of [...this.pieces.values()]) {
        if (!this.isSupported(p)) {
          drop(p);
          changed = true;
        }
      }
    }
    return removed;
  }

  private isSupported(p: Piece): boolean {
    switch (p.type) {
      case 'wall':
      case 'doorway':
        return BuildingGrid.edgeCells(p.axis!, p.cx, p.cz).some(([a, b]) => this.hasFoundation(a, b));
      case 'door':
        return this.edgeSet(p.axis!, p.cx, p.cz).some((q) => q.type === 'doorway');
      case 'roof':
        return this.hasFoundation(p.cx, p.cz);
      default:
        return true; // الأساس والقطع الحرة مستقلة
    }
  }

  /** تكلفة الاسترجاع (50% من المواد الخام للقطع المعيارية) */
  static refund(p: Piece): Record<string, number> {
    const out: Record<string, number> = {};
    for (const [id, n] of Object.entries(BLUEPRINTS[p.type].cost)) {
      const back = Math.floor(n / 2);
      if (back > 0) out[id] = back;
    }
    return out;
  }

  // ---------- ارتفاعات ----------
  private cellCorners(cx: number, cz: number): number[] {
    const x0 = cx * CELL_SIZE;
    const z0 = cz * CELL_SIZE;
    return [
      this.ground.height(x0, z0),
      this.ground.height(x0 + CELL_SIZE, z0),
      this.ground.height(x0, z0 + CELL_SIZE),
      this.ground.height(x0 + CELL_SIZE, z0 + CELL_SIZE),
    ];
  }

  private cellTop(cx: number, cz: number): number {
    return Math.max(...this.cellCorners(cx, cz));
  }

  private foundationY(cx: number, cz: number): number {
    return this.cells.get(BuildingGrid.cellKey('foundation', cx, cz))?.y ?? this.cellTop(cx, cz);
  }

  private edgeBase(axis: Axis, cx: number, cz: number): number {
    const ys = BuildingGrid.edgeCells(axis, cx, cz)
      .filter(([a, b]) => this.hasFoundation(a, b))
      .map(([a, b]) => this.foundationY(a, b));
    return ys.length ? Math.max(...ys) : this.ground.height(cx * CELL_SIZE, cz * CELL_SIZE);
  }

  /** الأرض صالحة للأساس: فوق الماء وميل طفيف في كل الزوايا وفرق ارتفاع محدود */
  private groundOkForCell(cx: number, cz: number): boolean {
    const c = this.cellCorners(cx, cz);
    const lo = Math.min(...c);
    const hi = Math.max(...c);
    if (lo < this.ground.waterLevel + 0.3) return false;
    return hi - lo <= 1.2;
  }

  toJSON(): Piece[] {
    return this.list();
  }

  load(pieces: Piece[]): void {
    this.pieces.clear();
    this.cells.clear();
    this.edges.clear();
    for (const p of pieces) {
      this.pieces.set(p.id, p);
      this.index(p);
      this.nextId = Math.max(this.nextId, p.id + 1);
    }
  }
}
