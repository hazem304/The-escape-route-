/** ثوابت اللعبة العامة (وحدات القياس: متر / ثانية) */

export const PHYSICS_STEP = 1 / 60;
export const MAX_FRAME_DT = 0.1;
export const MAX_SUBSTEPS = 5;

export const GRAVITY = -20;

export const PLAYER = {
  height: 1.75,
  eyeHeight: 1.62,
  radius: 0.35,
  walkSpeed: 3.2,
  runSpeed: 6.0,
  crouchSpeed: 1.6,
  swimSpeed: 2.2,
  jumpSpeed: 7.0,
  acceleration: 28,
  airControl: 0.35,
  stepHeight: 0.4,
  maxSlopeDeg: 50,
} as const;

export const CAMERA = {
  fov: 70,
  near: 0.1,
  far: 2000,
  thirdDistance: 3.6,
  thirdMinDistance: 1.2,
  thirdHeight: 1.5,
  shoulderOffset: 0.45,
  mouseSensitivity: 0.0022,
  touchSensitivity: 0.0045,
  pitchMin: -1.35,
  pitchMax: 1.35,
  blendSpeed: 8,
} as const;

export const WORLD = {
  size: 1024,
  waterLevel: 0,
} as const;

export type QualityLevel = 'low' | 'medium' | 'high';
