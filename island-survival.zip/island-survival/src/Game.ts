import * as THREE from 'three';
import { AmbienceInput, mixAmbience } from './audio/AmbienceMix';
import { AudioManager, type SfxName } from './audio/AudioManager';
import { StrideTimer, STEP_VOLUME, surfaceFor } from './audio/Footsteps';
import { BLUEPRINTS, CELL_SIZE, type PieceType } from './building/Blueprint';
import type { SnapTarget } from './building/Snap';
import { loadConfig, QUALITY_PRESETS, saveConfig, type GameConfig } from './config';
import { CAMERA, WORLD } from './constants';
import { enterImmersive } from './mobile';
import { CropViews } from './render/CropViews';
import { HeldItemView } from './render/HeldItemView';
import { EventBus, type GameEvents } from './core/EventBus';
import { GameSession, type EnvironmentSnapshot, type PlayerSnapshot } from './core/GameSession';
import { Input } from './core/Input';
import { applyToDom, getLanguage, pick, setLanguage, t } from './core/i18n';
import { Physics } from './core/Physics';
import { SaveSystem } from './core/SaveSystem';
import { Time } from './core/Time';
import { Boat } from './entities/Boat';
import { CameraRig } from './entities/CameraRig';
import { Player } from './entities/Player';
import { Fire } from './survival/Fire';
import type { Difficulty } from './survival/Stats';
import { FXManager, Fireflies } from './fx/Particles';
import { ItemDB } from './inventory/ItemDatabase';
import { AssetLoader } from './render/AssetLoader';
import { AnimalViews, BuildingViews, GroundViews, makeGhost, NPCViews, tintGhost } from './render/EntityViews';
import { PostFX } from './render/PostFX';
import type { ToastKind } from './ui/Notifications';
import type { GameUIHost } from './ui/UIHost';
import { UIManager } from './ui/UIManager';
import { Caves } from './world/Caves';
import { ColliderStreamer } from './world/ColliderStreamer';
import { Grass } from './world/Grass';
import { Vegetation } from './world/Vegetation';
import { World } from './world/World';

const SEED = 'island-1';
const PENDING_KEY = 'island-survival:pending';
const AUTOSAVE_SECONDS = 120;
const INTERACT_RANGE = 2.6;
const FUELS = ['firewood', 'wood_log', 'stick', 'charcoal', 'bark', 'thatch'] as const;
const SLEEP_REFUSAL_KEY = { notTired: 'cannot_sleep_energy', danger: 'cannot_sleep_hostile', tooCold: 'cannot_sleep_cold', tooHungry: 'cannot_sleep_hunger' } as const;

interface Interactable {
  prompt: string;
  run: () => void;
}

interface BuildMode {
  type: PieceType;
  yaw: number;
  ghost: THREE.Object3D;
  target: SnapTarget | null;
  ok: boolean;
}

type Pending = { load: number } | { new: Difficulty } | null;

/**
 * الحلقة الرئيسية: تجمع العالم والفيزياء واللاعب والجلسة (منطق اللعبة الخالص) والواجهة والصوت والمؤثرات.
 * بدء لعبة جديدة أو تحميل حفظ يُعيد تحميل الصفحة بحالة معلّقة (sessionStorage) فتبدأ كل المنظومات نظيفة.
 */
export class Game implements GameUIHost {
  readonly bus = new EventBus<GameEvents>();
  readonly time = new Time();
  readonly physics = new Physics();
  readonly saves = new SaveSystem();
  readonly audio = new AudioManager();
  config: GameConfig = loadConfig();

  session!: GameSession;

  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private input: Input;
  private cameraRig!: CameraRig;
  private avatar!: Player;
  private world!: World;
  private ui!: UIManager;
  private postfx: PostFX | null = null;
  private assets!: AssetLoader;
  private fx = new FXManager();
  private fireflies = new Fireflies();
  private vegetation!: Vegetation;
  private grass!: Grass;
  private caves!: Caves;
  private colliders!: ColliderStreamer;
  private animalViews!: AnimalViews;
  private npcViews!: NPCViews;
  private groundViews = new GroundViews();
  private buildingViews!: BuildingViews;
  private cropViews = new CropViews();
  private heldView = new HeldItemView();
  private bobber = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 8), new THREE.MeshStandardMaterial({ color: 0xff3b30, emissive: 0x551008 }));

  private strides = new StrideTimer();
  private lastPos = new THREE.Vector3();
  private boats = new Map<number, Boat>();
  private boarded: Boat | null = null;
  private boardedId = -1;

  private build: BuildMode | null = null;
  private demolish = false;
  private interact: Interactable | null = null;

  private running = false;
  private started = false;
  private autosaveTimer = AUTOSAVE_SECONDS;
  private ambienceTimer = 0;
  private shoreDist = 200;
  private swingAnim = 0;
  private tmpDir = new THREE.Vector3();
  private overlay = document.getElementById('overlay');
  private hudDebug = document.getElementById('debug');

  constructor(private canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
    this.input = new Input(canvas);
    this.applyQuality();
    window.addEventListener('resize', this.onResize);
  }

  // ====================== تهيئة ======================
  async start(): Promise<void> {
    setLanguage(this.config.language);
    const help = document.getElementById('controlsHelp');
    if (help) help.textContent = t(this.input.isTouch ? 'controls_touch' : 'controls_desktop');
    applyToDom();

    const pending = this.takePending();
    await this.physics.init();
    this.world = new World(this.scene, this.physics, this.bus, this.config, SEED);
    const terrain = this.world.terrain;

    const difficulty: Difficulty = pending && 'new' in pending ? pending.new : 'normal';
    this.session = new GameSession(SEED, terrain, difficulty);

    this.assets = new AssetLoader(this.renderer);
    await this.assets.loadManifest();
    // ننتظر التحميل قبل بناء المشاهد ليعمل الاستبدال التلقائي؛ الأصول غير المولّدة لا تُطلب أصلًا
    await this.assets.loadAll();
    for (const v of this.assets.budgetViolations()) console.warn('[assets]', v);

    // الكهوف تضيف عقد موارد إلى الحقل، فتسبق التحميل (معرّفات العقد حتمية) والنباتات
    this.caves = new Caves(terrain.caveSites, SEED, this.physics, this.session.resources);
    let loadedPose: { x: number; y: number; z: number; yaw: number } | null = null;
    if (pending && 'load' in pending) {
      const r = await this.saves.load(pending.load);
      if (r.ok && r.data.seed === SEED) {
        this.session.load(r.data);
        loadedPose = r.data.player;
      }
    }

    const q = QUALITY_PRESETS[this.config.quality];
    this.vegetation = new Vegetation(this.session.resources, q.shadows);
    this.grass = new Grass(terrain, (x, z) => terrain.insideCaveFootprint(x, z));
    this.colliders = new ColliderStreamer(this.physics, this.session.resources);
    this.animalViews = new AnimalViews(this.assets);
    this.npcViews = new NPCViews(this.session.npcs, (x, z) => terrain.height(x, z), this.assets);
    this.buildingViews = new BuildingViews(this.assets);

    const spawn = loadedPose ? new THREE.Vector3(loadedPose.x, loadedPose.y, loadedPose.z) : this.world.spawnPoint;
    this.avatar = new Player(this.physics, this.input, this.bus, spawn);
    this.cameraRig = new CameraRig(window.innerWidth / window.innerHeight, this.config.fov, this.bus, this.physics);
    this.scene.add(
      this.vegetation.group, this.grass.group, this.caves.group, this.fx.group, this.fireflies.points,
      this.animalViews.group, this.npcViews.group, this.groundViews.group, this.buildingViews.group, this.cropViews.group, this.bobber, this.avatar.object, this.cameraRig.camera,
    );
    this.cameraRig.camera.add(this.heldView.root);
    // المواجهة نحو البحر عند البداية، أو الاتجاه المحفوظ
    const sp = this.world.spawnPoint;
    this.avatar.yaw = loadedPose ? loadedPose.yaw : Math.atan2(sp.x, sp.z);

    this.lastPos.copy(spawn);

    this.setupPostFX();
    this.fx.setViewport(window.innerHeight, this.config.fov);
    this.fireflies.setViewport(window.innerHeight, this.config.fov);
    this.audio.setVolumes(this.volumes());
    this.audio.onCaption = (key) => { if (this.config.subtitles) this.ui.hud.showCaption(t(key)); };

    if (this.input.isTouch) this.input.bindTouchControls();
    this.ui = new UIManager(this, document.getElementById('uiMount') ?? document.body);
    this.bindEvents();
    this.bindOverlay();

    // إطار أول قبل شاشة البدء
    this.cameraRig.update(0, this.avatar);
    this.world.update(0, 0, this.cameraRig.camera.position, this.avatar.object.position);
    this.renderer.toneMappingExposure = this.world.exposure;

    this.running = true;
    this.time.start(performance.now());
    requestAnimationFrame(this.loop);
  }

  private takePending(): Pending {
    try {
      const raw = sessionStorage.getItem(PENDING_KEY);
      if (!raw) return null;
      sessionStorage.removeItem(PENDING_KEY);
      return JSON.parse(raw) as Pending;
    } catch {
      return null;
    }
  }

  private setPending(p: Pending): boolean {
    try {
      sessionStorage.setItem(PENDING_KEY, JSON.stringify(p));
      return true;
    } catch {
      return false;
    }
  }

  private setupPostFX(): void {
    this.postfx?.dispose();
    this.postfx = null;
    if (!this.config.postfx) return;
    try {
      this.postfx = new PostFX(this.renderer, this.scene, this.cameraRig.camera, this.config.quality);
      this.postfx.setSize(window.innerWidth, window.innerHeight);
    } catch (e) {
      console.warn('PostFX غير متاح، العرض المباشر بدلًا منه', e);
      this.postfx = null;
    }
  }

  private volumes() {
    const c = this.config;
    return { master: c.masterVolume, sfx: c.sfxVolume, music: c.musicVolume, ambient: c.ambientVolume };
  }

  private bindOverlay(): void {
    const begin = (): void => {
      void this.audio.unlock();
      if (this.input.isTouch) void enterImmersive();
      this.started = true;
      this.overlay?.classList.add('hidden');
      this.input.requestLock();
    };
    this.overlay?.addEventListener('click', begin);
    this.canvas.addEventListener('click', () => {
      if (this.started && !this.input.pointerLocked && !this.ui.anyOpen && !this.input.isTouch) this.input.requestLock();
      void this.audio.unlock();
    });
    this.input.onLockChange = (locked) => {
      // فقدان القفل بلا لوحة مفتوحة (Esc) = قائمة الإيقاف
      if (!locked && this.started && !this.ui.anyOpen && !this.input.isTouch && !this.session.ending) this.openPause();
    };
  }

  private bindEvents(): void {
    this.bus.on('player:jump', () => this.audio.sfx('jump'));
    this.bus.on('player:land', ({ speed }) => {
      const dmg = this.session.survival.fallDamage(speed);
      const p = this.avatar.object.position;
      if (dmg > 0) {
        this.audio.sfx('hurt');
      } else {
        this.audio.sfx('land', { volume: Math.min(1, speed / 8) });
      }
      this.fx.dust(p.x, p.y, p.z, Math.min(10, Math.round(speed)));
    });
    this.bus.on('player:waterChanged', ({ inWater }) => {
      const p = this.avatar.object.position;
      this.fx.splash(p.x, 0, p.z, inWater ? 1.2 : 0.6);
      this.audio.sfx('splash');
    });
    this.bus.on('weather:thunder', ({ distance }) => {
      window.setTimeout(() => this.audio.sfx('thunder', { volume: Math.max(0.3, 1 - distance / 1500) }), Math.min(5000, distance * 6));
    });
    this.bus.on('player:viewChanged', () => this.audio.sfx('click'));
    this.bus.on('weather:changed', () => undefined);
    // اختصارات المطوّر
    if (location.hash === '#dev') {
      window.addEventListener('keydown', (e) => {
        if (e.repeat || !this.started) return;
        if (e.code === 'KeyT') this.session.totalHours += 1;
        else if (e.code === 'KeyY') {
          const order = ['clear', 'cloudy', 'rain', 'storm', 'fog'] as const;
          this.world.weather.setWeather(order[(order.indexOf(this.world.weather.type as (typeof order)[number]) + 1) % order.length]);
        }
      });
    }
  }

  // ====================== GameUIHost ======================
  player(): { x: number; y: number; z: number; yaw: number } {
    const p = this.avatar.object.position;
    return { x: p.x, y: p.y, z: p.z, yaw: this.avatar.yaw };
  }

  notify(text: string, kind: ToastKind = 'info'): void {
    this.ui.hud.notifications.push(text, kind);
  }

  sfx(name: SfxName): void {
    this.audio.sfx(name);
  }

  setConfig(patch: Partial<GameConfig>): void {
    const prev = this.config;
    this.config = { ...prev, ...patch };
    saveConfig(this.config);
    if (patch.language && patch.language !== prev.language) {
      setLanguage(patch.language);
    }
    if (patch.quality && patch.quality !== prev.quality) {
      this.applyQuality();
      this.postfx?.setQuality(patch.quality);
      this.world.sun.castShadow = QUALITY_PRESETS[patch.quality].shadows;
    }
    if (patch.postfx !== undefined && patch.postfx !== prev.postfx) this.setupPostFX();
    if (patch.fov !== undefined) {
      this.cameraRig.setFov(patch.fov);
      this.fx.setViewport(window.innerHeight, patch.fov);
      this.fireflies.setViewport(window.innerHeight, patch.fov);
    }
    this.audio.setVolumes(this.volumes());
    this.bus.emit('config:changed', undefined);
  }

  async saveTo(slot: number): Promise<boolean> {
    try {
      await this.saves.save(slot, this.session.toJSON(this.player()));
      return true;
    } catch (e) {
      console.warn('فشل الحفظ', e);
      return false;
    }
  }

  async loadFrom(slot: number): Promise<boolean> {
    const r = await this.saves.load(slot);
    if (!r.ok || r.data.seed !== SEED) return false;
    if (!this.setPending({ load: slot })) return false;
    location.reload();
    return true;
  }

  newGame(difficulty: Difficulty): void {
    if (this.setPending({ new: difficulty })) location.reload();
  }

  resume(): void {
    this.ui.closeAll();
    void this.audio.unlock();
    this.input.requestLock();
  }

  startBuild(type: PieceType): void {
    this.cancelBuild();
    this.demolish = false;
    const ghost = makeGhost(type);
    ghost.visible = false;
    this.scene.add(ghost);
    this.build = { type, yaw: 0, ghost, target: null, ok: false };
    this.notify(t('build_hint'));
  }

  setDemolish(on: boolean): void {
    this.cancelBuild();
    this.demolish = on;
    if (on) this.notify(t('build_mode_remove'));
  }

  panelClosed(): void {
    if (!this.input.isTouch && this.started) this.input.requestLock();
  }

  private cancelBuild(): void {
    if (this.build) {
      this.scene.remove(this.build.ghost);
      this.build = null;
    }
  }

  private openPause(): void {
    this.cancelBuild();
    this.demolish = false;
    this.ui.open('pause');
    this.audio.suspend();
  }

  // ====================== جودة وعرض ======================
  private applyQuality(): void {
    const q = QUALITY_PRESETS[this.config.quality];
    this.renderer.setPixelRatio(q.pixelRatio);
    this.renderer.shadowMap.enabled = q.shadows;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
  }

  private onResize = (): void => {
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.cameraRig?.setAspect(window.innerWidth / window.innerHeight);
    this.postfx?.setSize(window.innerWidth, window.innerHeight);
    this.fx.setViewport(window.innerHeight, this.config.fov);
    this.fireflies.setViewport(window.innerHeight, this.config.fov);
  };

  // ====================== الحلقة ======================
  private loop = (now: number): void => {
    if (!this.running) return;
    requestAnimationFrame(this.loop);

    this.input.pollGamepad();
    const steps = this.time.tick(now);
    const dt = this.time.delta;
    const s = this.session;

    if (!this.started) {
      this.input.consumeLook(0);
      this.renderFrame(dt);
      this.input.endFrame();
      return;
    }

    const pauseOpen = this.ui.pause.isOpen;
    if (pauseOpen) {
      // الإيقاف الكامل: لا محاكاة ولا صوت
      this.input.consumeLook(0);
      this.ui.update(dt);
      this.renderFrame(0);
      this.input.endFrame();
      return;
    }

    const uiOpen = this.ui.anyOpen;
    if (uiOpen && this.input.pointerLocked) this.input.exitLock();

    this.handleActions(uiOpen);

    // تجميد اللاعب: لوحة، نوم، قارب، نهاية
    const frozen = uiOpen || s.sleeping || !!this.boarded || !!s.ending;
    this.avatar.frozen = frozen;
    const burden = s.inventory.burden;
    this.avatar.speedMul = s.survival.speedMultiplier * burden.speedMultiplier;
    this.avatar.runAllowed = s.survival.canRun && s.survival.stats.stamina > 3 && !burden.immobilized;

    if (!frozen) {
      const look = this.input.consumeLook(dt);
      const sens = (this.input.isTouch ? CAMERA.touchSensitivity : CAMERA.mouseSensitivity) * this.config.mouseSensitivity;
      this.avatar.applyLook(look.dx, look.dy, sens, this.config.invertY);
    } else {
      this.input.consumeLook(0);
    }

    for (let i = 0; i < steps; i++) {
      this.avatar.fixedUpdate();
      this.physics.step();
    }

    // القارب يحرّك اللاعب
    if (this.boarded) this.updateBoat(dt);

    this.avatar.renderUpdate(dt, this.time.alpha, this.cameraRig.showsBody);
    this.cameraRig.update(dt, this.avatar);
    {
      const hs = this.session.inventory.held;
      const hd = hs ? ItemDB.get(hs.defId) : null;
      this.heldView.update(hd ? hd.id : null, hd ? hd.type : '', !this.cameraRig.showsBody && !this.build, this.swingAnim > 0 ? 1 - this.swingAnim / 0.4 : 0, this.time.elapsed);
    }

    // العالم: الزمن من الجلسة
    this.world.dayNight.paused = true;
    this.world.dayNight.setHour(s.hour);
    this.world.update(dt, this.time.elapsed, this.cameraRig.camera.position, this.avatar.object.position);
    this.renderer.toneMappingExposure = this.world.exposure;

    const pos = this.avatar.object.position;
    const snap = this.snapshot();
    const env = this.environment(pos);
    s.update(dt, snap, env);

    this.colliders.update(dt, pos.x, pos.z);
    this.vegetation.update(this.time.elapsed, this.cameraRig.camera.position, this.world.weather.current.wind, dt);
    this.grass.update(this.cameraRig.camera.position, this.time.elapsed, this.world.weather.current.wind);
    this.animalViews.update(s.animals.animals, dt, this.cameraRig.camera.position);
    this.npcViews.update(s.npcs, dt, (x, z) => this.world.terrain.height(x, z));
    this.groundViews.update(s, dt, this.time.elapsed);
    this.buildingViews.sync(s);
    this.cropViews.sync(s);
    this.bobber.visible = !!s.castPos && (s.fishing.state === 'waiting' || s.fishing.state === 'bite');
    if (this.bobber.visible && s.castPos) {
      const dip = s.fishing.state === 'bite' ? -0.12 + Math.sin(this.time.elapsed * 30) * 0.05 : Math.sin(this.time.elapsed * 2) * 0.03;
      this.bobber.position.set(s.castPos.x, WORLD.waterLevel + 0.05 + dip, s.castPos.z);
    }
    this.updateFX(dt, pos, env);
    this.updateBuildMode();
    this.interact = uiOpen || s.sleeping ? null : this.findInteract();
    this.ui.hud.setPrompt(this.interact?.prompt ?? null);
    this.updateAudio(dt, pos, env, snap);
    this.ui.hud.setDark(s.sleeping);
    this.ui.update(dt);

    // حفظ تلقائي
    this.autosaveTimer -= dt;
    if (this.autosaveTimer <= 0 && !s.survival.dead && !s.ending) {
      this.autosaveTimer = AUTOSAVE_SECONDS;
      void this.saveTo(0).then((ok) => { if (ok) this.notify(t('autosaved')); });
    }

    this.renderFrame(dt);
    this.updateDebug();
    this.input.endFrame();
  };

  private renderFrame(dt: number): void {
    const cam = this.cameraRig.camera;
    if (this.postfx) {
      const st = this.session.survival.stats;
      const underwater = cam.position.y < WORLD.waterLevel;
      this.postfx.setState(
        {
          desaturate: Math.max(0, (35 - st.health) / 35) * 0.7 + (st.bodyTemp < 35 ? 0.25 : 0),
          vignette: Math.max(0, (40 - st.health) / 40) * 0.6 + (this.session.sleeping ? 0.5 : 0),
          warmTint: st.bodyTemp > 38.5 ? Math.min(1, (st.bodyTemp - 38.5) / 2) : 0,
          coolTint: underwater ? 0.8 : st.bodyTemp < 35.5 ? Math.min(1, (35.5 - st.bodyTemp) / 3) : 0,
        },
        this.time.elapsed,
        8,
      );
      this.postfx.render(dt);
    } else {
      this.renderer.render(this.scene, cam);
    }
  }

  // ====================== لقطات الحالة ======================
  private snapshot(): PlayerSnapshot {
    const p = this.avatar.object.position;
    return {
      x: p.x, y: p.y, z: p.z, yaw: this.avatar.yaw,
      loco: this.avatar.locomotion,
      inWater: this.avatar.inWater,
      working: this.swingAnim > 0,
    };
  }

  private environment(pos: THREE.Vector3): EnvironmentSnapshot {
    const w = this.world.weather;
    const c = w.current;
    return {
      weatherTempDelta: w.temperatureDelta,
      rainIntensity: c.rain,
      windX: w.wind.x * c.wind,
      windZ: w.wind.z * c.wind,
      waveAmp: c.waveAmp,
      inCave: this.caves.contains(pos.x, pos.y, pos.z),
    };
  }

  // ====================== الإدخال والأفعال ======================
  private handleActions(uiOpen: boolean): void {
    const inp = this.input;
    const s = this.session;
    this.swingAnim = Math.max(0, this.swingAnim - this.time.delta);

    // أزرار اللوحات تعمل دائمًا؛ تبديل لوحة تغلق غيرها
    const togg: Array<[Parameters<Input['wasPressed']>[0], Parameters<UIManager['toggle']>[0]]> = [
      ['inventory', 'backpack'], ['craft', 'craft'], ['map', 'map'], ['journal', 'journal'], ['build', 'build'],
    ];
    for (const [a, p] of togg) if (inp.wasPressed(a) && !s.ending) {
      if (p !== 'build') this.cancelBuild();
      this.ui.toggle(p);
      if (p === 'backpack' && this.ui.backpack.isOpen) this.ui.backpack.openContainer(null);
    }
    if (inp.wasPressed('pause')) {
      if (this.build) this.cancelBuild();
      else if (this.demolish) this.demolish = false;
      else if (uiOpen && this.ui.current !== 'ending') this.ui.close();
    }
    if (uiOpen) return;

    // الشريط السريع
    for (let i = 1; i <= 8; i++) if (inp.wasPressed(`slot${i}` as 'slot1')) s.inventory.hotbar.select(i - 1);
    const wheel = inp.consumeWheel();
    if (wheel) s.inventory.hotbar.scroll(wheel);

    if (inp.wasPressed('toggleView')) this.cameraRig.toggle();
    if (inp.wasPressed('rotate') && this.build) this.build.yaw += Math.PI / 2;
    if (inp.wasPressed('sleep')) this.trySleep();

    if (this.boarded) {
      if (inp.wasPressed('interact')) this.leaveBoat();
      return;
    }
    if (s.sleeping) {
      if (inp.wasPressed('interact') || inp.wasPressed('jump')) s.sleeping = false;
      return;
    }
    if (inp.wasPressed('interact') && this.interact) this.interact.run();

    if (inp.wasPressed('attack')) this.primaryAction();
    else if (inp.isDown('attack') && !this.build && this.swingAnim <= 0) this.primaryAction(true);
  }

  private trySleep(): void {
    const p = this.avatar.object.position;
    const r = this.session.trySleep(p);
    if (r.ok) {
      this.notify('Zzz', 'info');
    } else if (r.reason) {
      this.notify(t(SLEEP_REFUSAL_KEY[r.reason]), 'bad');
    }
  }

  private camDir(): THREE.Vector3 {
    return this.cameraRig.camera.getWorldDirection(this.tmpDir);
  }

  /** نقر/ضغط الهجوم: بناء، هدم، استعمال عنصر ممسوك، قتال أو جمع */
  private primaryAction(held = false): void {
    const s = this.session;
    const p = this.avatar.object.position;
    if (this.build) {
      if (!held) this.placeBuild();
      return;
    }
    if (this.demolish) {
      if (!held) this.demolishAt();
      return;
    }
    const stack = s.inventory.held;
    const def = stack ? ItemDB.get(stack.defId) : null;
    // طعام/شراب/دواء/قصة: يُستعمل بالنقر
    if (stack && def && ['food', 'drink', 'medicine', 'story'].includes(def.type) || (def && (def.id === 'bottle_empty' || def.id === 'canteen_empty'))) {
      if (held) return;
      const r = s.useItem(stack!.uid, p);
      if (def!.type === 'food') this.audio.sfx('eat');
      else if (def!.type === 'drink') this.audio.sfx('drink');
      else this.audio.sfx('pickup');
      if ((r as { ok?: boolean; reason?: string }).reason === 'noWater') this.notify(t('no_water'), 'bad');
      return;
    }
    if (def && (def.id === 'fishing_rod' || def.id === 'fishing_net')) {
      if (held) return;
      this.fishAction();
      return;
    }
    this.swingAnim = 0.4;
    const eye = this.avatar.getEyePosition(new THREE.Vector3());
    const dir = this.camDir().clone();

    // قتال: حيوان أمامنا ضمن المدى
    if (def?.type === 'weapon' || this.animalInFront(p, 2.6)) {
      const r = s.attack({ x: p.x, z: p.z, yaw: this.avatar.yaw }, this.environment(p));
      if (r.hit) {
        this.audio.sfx('hit', { pos: { x: r.hit.pos.x, y: r.hit.y, z: r.hit.pos.z } });
        this.fx.hit(r.hit.pos.x, r.hit.y + 0.6, r.hit.pos.z, 'leaf');
        if (r.killed) this.audio.sfx('growl', { pos: { x: r.hit.pos.x, y: r.hit.y, z: r.hit.pos.z }, volume: 0.6 });
        return;
      }
      if (def?.type === 'weapon') return;
    }
    const out = s.swing(eye, dir, { x: p.x, y: p.y, z: p.z });
    switch (out.kind) {
      case 'hit':
      case 'destroyed': {
        const n = out.node;
        const kind = n.kind.includes('tree') || n.kind.includes('palm') || n.kind.includes('log') ? 'wood' : n.kind.includes('rock') || n.kind.includes('ore') || n.kind.includes('stone') ? 'rock' : 'leaf';
        this.fx.hit(n.x, n.y + 1, n.z, kind);
        this.audio.sfx(kind === 'rock' ? 'mine' : 'chop', { pos: { x: n.x, y: n.y + 1, z: n.z } });
        if (out.toolBroke) this.notify(t('tool_broke', { name: def ? pick({ ar: def.nameAr, en: def.nameEn }) : '' }), 'bad');
        if (out.dropped > 0) this.notify(t('inv_full'), 'bad');
        else if (out.kind === 'destroyed') for (const d of out.drops) this.notify(t('got_item', { name: pick({ ar: ItemDB.get(d.id).nameAr, en: ItemDB.get(d.id).nameEn }), n: d.count }), 'good');
        break;
      }
      case 'wrongTool': this.notify(t('wrong_tool'), 'bad'); break;
      case 'tired': this.notify(t('too_tired'), 'bad'); break;
      case 'miss': if (!held) this.notify(t('hit_nothing')); break;
      case 'cooldown': break;
    }
  }

  /** رمي الصنارة نحو الماء أو سحب الخيط عند اللدغة */
  private fishAction(): void {
    const s = this.session;
    if (s.fishing.state === 'bite' || s.fishing.state === 'waiting') {
      const c = s.reelLine();
      if (c) this.audio.sfx('pickup');
      return;
    }
    const g = this.groundPointAhead();
    const depth = WORLD.waterLevel - this.world.terrain.height(g.x, g.z);
    this.swingAnim = 0.4;
    const r = s.castLine(g, depth);
    if (!r.ok) this.notify(t(r.reason === 'shallow' ? 'fish_shallow' : 'fish_no_rod'), 'bad');
    else this.audio.sfx('swing');
  }

  private farmInteract(id: number): Interactable | null {
    const s = this.session;
    const mode = s.farmMode(id);
    if (!mode) return null;
    const key = mode === 'harvest' ? 'prompt_harvest' : mode === 'plant' ? 'prompt_plant' : mode === 'water' ? 'prompt_water' : 'prompt_farm_info';
    return { prompt: `E · ${t(key)}`, run: () => this.runFarm(id) };
  }

  private runFarm(id: number): void {
    const s = this.session;
    const plot = s.farms.get(id);
    const r = s.farmAction(id);
    if (!r || !plot) return;
    if (r.action === 'harvest') {
      this.audio.sfx('pickup');
      for (const d of r.drops ?? []) this.notify(t('farm_harvested', { name: pick({ ar: ItemDB.get(d.id).nameAr, en: ItemDB.get(d.id).nameEn }), n: d.count }), 'good');
    } else if (r.action === 'plant') {
      this.audio.sfx('pickup');
      this.notify(t('farm_planted'), 'good');
    } else if (r.action === 'water') {
      this.audio.sfx('drink');
      this.notify(t('farm_watered'), 'good');
    } else if (plot.plantedCount === 0) this.notify(t('farm_empty'));
    else if (plot.thirsty) this.notify(t('farm_thirsty'));
    else this.notify(t('farm_growing', { n: plot.plantedCount, h: Math.ceil(plot.hoursToRipe() ?? 0) }));
  }

  private animalInFront(p: THREE.Vector3, range: number): boolean {
    const fx = -Math.sin(this.avatar.yaw);
    const fz = -Math.cos(this.avatar.yaw);
    for (const a of this.session.animals.animals) {
      if (!a.alive) continue;
      const dx = a.pos.x - p.x;
      const dz = a.pos.z - p.z;
      const d = Math.hypot(dx, dz);
      if (d < range && (d < 0.8 || (dx * fx + dz * fz) / d > 0.4)) return true;
    }
    return false;
  }

  // ====================== التفاعل ======================
  private findInteract(): Interactable | null {
    const s = this.session;
    const p = this.avatar.object.position;
    const fx = -Math.sin(this.avatar.yaw);
    const fz = -Math.cos(this.avatar.yaw);
    const facing = (x: number, z: number, range: number): boolean => {
      const dx = x - p.x;
      const dz = z - p.z;
      const d = Math.hypot(dx, dz);
      return d <= range && (d < 1.2 || (dx * fx + dz * fz) / d > 0.3);
    };

    if (this.boarded) return { prompt: `E · ${t('prompt_leave')}`, run: () => this.leaveBoat() };
    if (this.build || this.demolish) return null;

    const npc = this.npcViews.nearest(s.npcs, p.x, p.z, 3.4);
    if (npc) return { prompt: `E · ${t('prompt_talk', { name: pick({ ar: npc.def.nameAr, en: npc.def.nameEn }) })}`, run: () => { this.ui.open('dialogue'); this.ui.dialogue.start(npc.def.id); } };

    const gi = s.ground.nearest(p.x, p.z, 2.4);
    if (gi) {
      return {
        prompt: `E · ${this.ui.groundPrompt(gi.stack.defId)}`,
        run: () => {
          const r = s.ground.pickup(gi.id, s.inventory);
          if (r.picked > 0) {
            this.audio.sfx('pickup');
            this.notify(t('got_item', { name: pick({ ar: ItemDB.get(gi.stack.defId).nameAr, en: ItemDB.get(gi.stack.defId).nameEn }), n: r.picked }), 'good');
          } else this.notify(t('inv_full'), 'bad');
        },
      };
    }

    for (const sp of s.story) {
      if (!sp.taken && facing(sp.x, sp.z, INTERACT_RANGE)) {
        return { prompt: `E · ${t('prompt_story')}`, run: () => { const r = s.takeStoryPickup(p, INTERACT_RANGE + 0.4); if (r.ok) this.audio.sfx('pickup'); } };
      }
    }

    for (const piece of s.buildings.list()) {
      if (!facing(piece.x, piece.z, INTERACT_RANGE + (piece.type === 'raft' ? 1.8 : 0))) continue;
      const id = piece.id;
      switch (piece.type) {
        case 'campfire':
        case 'furnace': {
          const f = s.fires.get(id);
          if (!f) break;
          if (f.fuel <= 0) return { prompt: `E · ${t('prompt_fire_add')}`, run: () => this.addFuel(id) };
          if (!f.burning) return { prompt: `E · ${t('prompt_fire_light')}`, run: () => this.lightFire(id) };
          return { prompt: `E · ${t('prompt_cook')}`, run: () => this.useFire(id, f) };
        }
        case 'rack':
        case 'workbench':
          return { prompt: `E · ${t(piece.type === 'rack' ? 'prompt_cook' : 'crafting')}`, run: () => this.ui.open('craft') };
        case 'storage':
        case 'barrel':
        case 'cooler': {
          const c = s.containers.get(id);
          if (c) return { prompt: `E · ${t('prompt_open')}`, run: () => { this.ui.open('backpack'); this.ui.backpack.openContainer(c); } };
          break;
        }
        case 'farm':
          return this.farmInteract(id);
        case 'bed':
          return { prompt: `E · ${t('prompt_sleep')}`, run: () => this.trySleep() };
        case 'raft':
          return { prompt: `E · ${t('prompt_board')}`, run: () => this.boardRaft(id) };
        default:
          break;
      }
    }
    return null;
  }

  private addFuel(id: number): void {
    const s = this.session;
    for (const f of FUELS) {
      if (s.inventory.has(f)) {
        s.addFuel(id, f, Math.min(3, s.inventory.count(f)));
        this.audio.sfx('pickup');
        return;
      }
    }
    this.notify(t('no_fuel'), 'bad');
  }

  private lightFire(id: number): void {
    const r = this.session.ignite(id, this.world.weather.current.rain);
    if (r.ok) {
      this.audio.sfx('fire_light');
      this.notify(t('fire_lit'), 'good');
    } else if (r.reason === 'noTool') this.notify(t('no_tool_fire'), 'bad');
    else if (r.reason === 'noFuel') this.notify(t('no_fuel'), 'bad');
    else this.notify(t('fire_failed'), 'bad');
  }

  /** نار مشتعلة: وقود في اليد يُضاف، وإلا تُفتح الصناعة (طهي) */
  private useFire(id: number, f: Fire): void {
    const held = this.session.inventory.held;
    if (held && Fire.isFuel(held.defId) && f.fuel < 200) {
      this.session.addFuel(id, held.defId, 1);
      this.audio.sfx('pickup');
    } else this.ui.open('craft');
  }

  // ====================== البناء ======================
  private groundPointAhead(): { x: number; z: number } {
    const eye = this.avatar.getEyePosition(new THREE.Vector3());
    const d = this.camDir();
    const terrain = this.world.terrain;
    let x = eye.x;
    let z = eye.z;
    for (let i = 1; i <= 14; i++) {
      const k = i * 0.5;
      const px = eye.x + d.x * k;
      const pz = eye.z + d.z * k;
      const py = eye.y + d.y * k;
      x = px;
      z = pz;
      if (py <= Math.max(WORLD.waterLevel, terrain.height(px, pz)) + 0.05) break;
    }
    // الحد الأقصى 6م أفقيًا من اللاعب
    const p = this.avatar.object.position;
    const dx = x - p.x;
    const dz = z - p.z;
    const l = Math.hypot(dx, dz);
    if (l > 6) return { x: p.x + (dx / l) * 6, z: p.z + (dz / l) * 6 };
    return { x, z };
  }

  private updateBuildMode(): void {
    const b = this.build;
    if (!b) return;
    const g = this.groundPointAhead();
    const grid = this.session.buildings;
    const target = grid.snapFromWorld(b.type, g.x, g.z, b.yaw);
    b.target = target;
    b.ok = grid.validate(b.type, target).ok && Object.entries(BLUEPRINTS[b.type].cost).every(([id, n]) => this.session.inventory.count(id) >= n);
    const terrain = this.world.terrain;
    let x = g.x, z = g.z, yaw = b.yaw;
    if (target.kind === 'cell') {
      x = (target.cx + 0.5) * CELL_SIZE;
      z = (target.cz + 0.5) * CELL_SIZE;
    } else if (target.kind === 'edge') {
      x = target.axis === 'h' ? (target.cx + 0.5) * CELL_SIZE : target.cx * CELL_SIZE;
      z = target.axis === 'h' ? target.cz * CELL_SIZE : (target.cz + 0.5) * CELL_SIZE;
      yaw = target.axis === 'h' ? 0 : Math.PI / 2;
    }
    const y = BLUEPRINTS[b.type].onWater ? WORLD.waterLevel : terrain.height(x, z);
    b.ghost.position.set(x, y, z);
    b.ghost.rotation.y = yaw;
    b.ghost.visible = true;
    tintGhost(b.ghost, b.ok);
  }

  private placeBuild(): void {
    const b = this.build;
    if (!b || !b.target) return;
    const r = this.session.place(b.type, b.target);
    if (r.ok) {
      this.audio.sfx('build');
      // نبقى في وضع البناء ما دامت المواد تكفي
      const affordable = Object.entries(BLUEPRINTS[b.type].cost).every(([id, n]) => this.session.inventory.count(id) >= n);
      if (!affordable) this.cancelBuild();
    } else {
      this.notify(t(`err_${r.error}`), 'bad');
    }
  }

  private demolishAt(): void {
    const g = this.groundPointAhead();
    let best: { id: number; d: number } | null = null;
    for (const piece of this.session.buildings.list()) {
      const d = Math.hypot(piece.x - g.x, piece.z - g.z);
      if (d < 2.2 && (!best || d < best.d)) best = { id: piece.id, d };
    }
    if (best) {
      if (this.boardedId === best.id) this.leaveBoat();
      this.session.removePiece(best.id);
      this.boats.delete(best.id);
      this.audio.sfx('break');
    }
  }

  // ====================== الطوافة ======================
  private boardRaft(id: number): void {
    const piece = this.session.buildings.get(id);
    if (!piece) return;
    let boat = this.boats.get(id);
    if (!boat) {
      boat = new Boat(piece.x, piece.z, piece.yaw);
      this.boats.set(id, boat);
    }
    boat.boarded = true;
    this.boarded = boat;
    this.boardedId = id;
    this.notify(t('raft_boarded'));
  }

  private leaveBoat(): void {
    if (this.boarded) this.boarded.boarded = false;
    this.boarded = null;
    this.boardedId = -1;
  }

  private updateBoat(dt: number): void {
    const boat = this.boarded!;
    const mv = this.input.getMove();
    const w = this.world.weather;
    boat.update(
      dt,
      { steer: mv.x, paddle: Math.max(0, mv.y), sail: this.input.isDown('run') },
      { height: (x, z) => this.world.terrain.height(x, z), wind: { x: w.wind.x * w.current.wind * 6, z: w.wind.z * w.current.wind * 6 }, waveAmp: w.current.waveAmp },
    );
    const piece = this.session.buildings.get(this.boardedId);
    if (piece) {
      piece.x = boat.pos.x;
      piece.z = boat.pos.z;
      piece.yaw = boat.heading;
      const o = this.buildingViews.object(this.boardedId);
      if (o) {
        o.position.set(piece.x, WORLD.waterLevel + Math.sin(this.time.elapsed * 1.3) * 0.04, piece.z);
        o.rotation.y = boat.heading;
      }
    }
    this.avatar.teleport(new THREE.Vector3(boat.pos.x, WORLD.waterLevel + 0.55, boat.pos.z));
  }

  // ====================== مؤثرات وصوت ======================
  private updateFX(dt: number, pos: THREE.Vector3, env: EnvironmentSnapshot): void {
    this.fx.wind.x = env.windX;
    this.fx.wind.z = env.windZ;
    const s = this.session;
    for (const [id, f] of s.fires) {
      const piece = s.buildings.get(id);
      if (!piece) continue;
      this.fx.fire(piece.x, piece.y, piece.z, f.burning ? f.strength : 0, dt);
      if (f.burning && Math.hypot(piece.x - pos.x, piece.z - pos.z) < 20) this.audio.crackle({ x: piece.x, y: piece.y, z: piece.z }, f.strength);
    }
    this.fx.update(dt);
    this.fireflies.update(this.time.elapsed, pos, 1 - this.world.dayNight.daylight, env.rainIntensity, (x, z) => this.world.terrain.height(x, z));
    if (this.avatar.inWater && this.avatar.locomotion === 'swim' && Math.hypot(this.avatar.velocity.x, this.avatar.velocity.z) > 0.8 && this.time.frame % 20 === 0) this.fx.splash(pos.x, WORLD.waterLevel, pos.z, 0.3);
  }

  private updateAudio(dt: number, pos: THREE.Vector3, env: EnvironmentSnapshot, snap: PlayerSnapshot): void {
    const s = this.session;
    const terrain = this.world.terrain;
    // أقرب شاطئ (تقدير تقريبي كل نصف ثانية)
    this.ambienceTimer -= dt;
    if (this.ambienceTimer <= 0) {
      this.ambienceTimer = 0.5;
      let best = 150;
      for (let a = 0; a < 8; a++) {
        const ang = (a / 8) * Math.PI * 2;
        for (let r = 6; r < best; r += 8) {
          if (terrain.height(pos.x + Math.cos(ang) * r, pos.z + Math.sin(ang) * r) < 0.2) { best = Math.min(best, r); break; }
        }
      }
      this.shoreDist = pos.y < 0.5 ? 0 : best;
    }
    const w = this.world.weather.current;
    const danger = s.animals.animals.some((a) => a.alive && a.species.temperament !== 'prey' && Math.hypot(a.pos.x - pos.x, a.pos.z - pos.z) < 30 && (a.state === 'chase' || a.state === 'attack'));
    const input: AmbienceInput = {
      hour: s.hour,
      weather: { rain: w.rain, wind: w.wind, storm: w.storm },
      biome: terrain.biomeAt(pos.x, pos.z),
      inCave: env.inCave,
      underwater: this.cameraRig.camera.position.y < WORLD.waterLevel,
      shoreDist: this.shoreDist,
      health: s.survival.stats.health,
      danger,
    };
    this.audio.setAmbience(mixAmbience(input));
    const cam = this.cameraRig.camera;
    const fwd = cam.getWorldDirection(this.tmpDir);
    this.audio.setListener(cam.position, fwd);
    this.audio.update(dt, input.health < 35 ? (35 - input.health) / 35 : 0);

    // خطوات
    const dx = pos.x - this.lastPos.x;
    const dz = pos.z - this.lastPos.z;
    this.lastPos.copy(pos);
    if (!this.boarded && dt > 0) {
      const step = this.strides.advance(Math.hypot(dx, dz), snap.loco, this.avatar.grounded);
      if (step) {
        const onBuilding = s.buildings.isSheltered(pos.x, pos.z);
        this.audio.step(surfaceFor(input.biome, snap.inWater, onBuilding, terrain.height(pos.x, pos.z) < 0.35), step.volume * (STEP_VOLUME[snap.loco] ? 1 : 0.5));
      }
    }
  }

  private updateDebug(): void {
    if (!this.hudDebug || location.hash !== '#dev' || this.time.frame % 10 !== 0) return;
    const p = this.avatar.object.position;
    this.hudDebug.textContent =
      `FPS ${this.time.fps}\npos ${p.x.toFixed(1)}, ${p.y.toFixed(1)}, ${p.z.toFixed(1)}\n` +
      `${this.avatar.locomotion} · ${this.world.weather.type} · ${getLanguage()}\n` +
      `animals ${this.session.animals.animals.length} · colliders ${this.colliders.activeCount}`;
  }

  dispose(): void {
    this.running = false;
    window.removeEventListener('resize', this.onResize);
    this.input.dispose();
    this.audio.dispose();
    this.postfx?.dispose();
    this.fx.dispose();
    this.renderer.dispose();
  }
}
