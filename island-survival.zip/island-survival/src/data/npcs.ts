import type { NPCDef } from '../entities/NPC';

/**
 * الناجون الثلاثة: كل واحد بملامح وقصة وجدول وحوار متفرع.
 * الإجراءات (action) تُنفَّذ في QuestManager: give_item:ID[:N]، flag:NAME، quest:ID
 */
export const NPC_DEFS: NPCDef[] = [
  {
    id: 'layla',
    nameAr: 'ليلى', nameEn: 'Layla',
    bioAr: 'طبيبة في الأربعين كانت على متن الرحلة. هادئة ودقيقة، تحمل حقيبة إسعاف وتخفي ألمًا على ابنها المفقود.',
    bioEn: 'A doctor in her forties who was on the flight. Calm and precise, she carries a first-aid kit and hides grief over a missing son.',
    likes: { honey: 6, herbal_tea: 5, medicinal_herb: 4, aloe: 4, cooked_fish: 3, bandage: 2 },
    schedule: [
      { from: 22, to: 6, activity: 'sleep', place: 'camp' },
      { from: 6, to: 11, activity: 'forage', place: 'forest' },
      { from: 11, to: 17, activity: 'work', place: 'camp' },
      { from: 17, to: 22, activity: 'camp', place: 'camp' },
    ],
    dialogue: {
      start: 'hello',
      nodes: {
        hello: {
          id: 'hello',
          textAr: 'لا تقترب بسرعة... أنت جريح؟ أرني ذراعك. أنا ليلى، كنت طبيبة قبل كل هذا.',
          textEn: "Don't rush at me... are you hurt? Let me see your arm. I'm Layla — I was a doctor before all this.",
          variants: [
            { when: { hasFlags: ['layla_gave_kit'] }, node: 'return_kit' },
            { when: { minTrust: 25 }, node: 'friendly' },
            { when: { hasFlags: ['layla_met'] }, node: 'again' },
          ],
          choices: [
            { textAr: 'أنا بخير، شكرًا. هل رأيتِ ناجين آخرين؟', textEn: "I'm fine, thanks. Have you seen other survivors?", next: 'others', trust: 3, setFlags: ['layla_met'] },
            { textAr: 'ابتعدي عني.', textEn: 'Stay away from me.', next: null, trust: -6, setFlags: ['layla_met'] },
            { textAr: 'نعم، ذراعي تنزف.', textEn: 'Yes, my arm is bleeding.', next: 'treat', trust: 5, setFlags: ['layla_met'], action: 'give_item:bandage:2' },
          ],
        },
        again: {
          id: 'again',
          textAr: 'عدتَ. هل وجدت ماءً نظيفًا؟ الغليان وحده ينقذ الأرواح هنا.',
          textEn: 'You came back. Have you found clean water? Boiling alone saves lives here.',
          choices: [
            { textAr: 'سأغليه من الآن.', textEn: "I'll boil it from now on.", next: null, trust: 2 },
            { textAr: 'هل تحتاجين شيئًا؟', textEn: 'Do you need anything?', next: 'needs', trust: 1 },
          ],
        },
        others: {
          id: 'others',
          textAr: 'رأيت شابًا اسمه عمر عند حطام الطائرة، وعجوزًا يدعى يوسف يعيش قرب الكهف. احذرهما قليلًا، كلاهما يخفي شيئًا.',
          textEn: 'I saw a young man named Omar at the wreck, and an old man named Yusuf living near the cave. Be careful — both are hiding something.',
          choices: [
            { textAr: 'سأبحث عنهما.', textEn: "I'll look for them.", next: null, setFlags: ['know_omar', 'know_yusuf'] },
            { textAr: 'هل تحتاجين مساعدة؟', textEn: 'Do you need help?', next: 'needs', trust: 2 },
          ],
        },
        treat: {
          id: 'treat',
          textAr: 'ثبّت الضمادة جيدًا ولا تدعها تبتل. الجرح المفتوح هنا يتحول إلى عدوى خلال ساعات.',
          textEn: "Keep the bandage tight and dry. An open wound turns infected within hours here.",
          choices: [{ textAr: 'شكرًا لكِ.', textEn: 'Thank you.', next: null, trust: 2 }],
        },
        needs: {
          id: 'needs',
          textAr: 'أحتاج عشرة أعشاب طبية وعسلًا إن وجدت. سأعطيك ما يفيدك في المقابل.',
          textEn: 'I need ten medicinal herbs, and honey if you find any. I will repay you with something useful.',
          choices: [
            { textAr: 'هذه الأعشاب.', textEn: 'Here are the herbs.', next: 'thanks', requires: { hasItems: [{ id: 'medicinal_herb', count: 10 }] }, trust: 12, setFlags: ['layla_herbs'], action: 'take_item:medicinal_herb:10' },
            { textAr: 'سأعود بها.', textEn: "I'll bring them.", next: null },
          ],
        },
        thanks: {
          id: 'thanks',
          textAr: 'هذا ما كنت أحتاجه. خذ مضادًا حيويًا من مخزوني، فلن تعرف متى ستحتاجه.',
          textEn: "Exactly what I needed. Take an antibiotic from my stock — you never know when you'll need it.",
          choices: [{ textAr: 'ممتن جدًا.', textEn: 'Very grateful.', next: null, trust: 4, action: 'give_item:antibiotic:1' }],
        },
        friendly: {
          id: 'friendly',
          textAr: 'صرتَ أقرب إلي من أن أخفي عنك الأمر: ابني كان معي في الرحلة. لا أعرف إن كان حيًا. إن وجدت شيئًا يخصه...',
          textEn: "You've earned the truth: my son was on the flight with me. I don't know if he's alive. If you find anything of his...",
          choices: [
            { textAr: 'سأبحث في الحطام. أعدك.', textEn: "I'll search the wreck. I promise.", next: 'kit', trust: 10, setFlags: ['layla_gave_kit'], action: 'give_item:first_aid_kit:1' },
            { textAr: 'ليس الآن.', textEn: 'Not now.', next: null },
          ],
        },
        kit: {
          id: 'kit',
          textAr: 'خذ حقيبة الإسعاف هذه. إن بقيت حيًا حتى الإنقاذ فهذا يكفيني.',
          textEn: "Take this first-aid kit. If you survive until the rescue, that's enough for me.",
          choices: [{ textAr: '...', textEn: '...', next: null }],
        },
        return_kit: {
          id: 'return_kit',
          textAr: 'أتمنى أن تكون الحقيبة قد نفعتك. هل وجدت شيئًا في الحطام؟',
          textEn: 'I hope the kit has helped. Did you find anything at the wreck?',
          choices: [
            { textAr: 'وجدت هذه الصورة القديمة.', textEn: 'I found this old photo.', next: 'photo', requires: { hasItems: [{ id: 'old_photo', count: 1 }] }, trust: 30, setFlags: ['layla_photo'], action: 'take_item:old_photo:1' },
            { textAr: 'ليس بعد.', textEn: 'Not yet.', next: null },
          ],
        },
        photo: {
          id: 'photo',
          textAr: '...إنه هو. شكرًا لك. سأخبرك بشيء: الراديو الذي يبحث عنه عمر يحتاج بطارية، وقد رأيتها عند يوسف.',
          textEn: "...It's him. Thank you. Let me tell you something: Omar's radio needs a battery — I saw one with Yusuf.",
          choices: [{ textAr: 'سأسأل يوسف.', textEn: "I'll ask Yusuf.", next: null, setFlags: ['know_battery_yusuf'] }],
        },
      },
    },
  },
  {
    id: 'omar',
    nameAr: 'عمر', nameEn: 'Omar',
    bioAr: 'مهندس اتصالات شاب، متحمس ومتهور. يعمل ليل نهار على إصلاح راديو الطائرة وهو مقتنع أن الإنقاذ قريب.',
    bioEn: 'A young telecom engineer, eager and reckless. He works day and night repairing the plane radio, convinced rescue is near.',
    likes: { energy_bar: 6, canned_beans: 5, scrap_metal: 4, copper_ingot: 5, iron_ingot: 4, nails: 3, cooked_meat: 3 },
    schedule: [
      { from: 23, to: 7, activity: 'sleep', place: 'wreck' },
      { from: 7, to: 19, activity: 'work', place: 'wreck' },
      { from: 19, to: 23, activity: 'camp', place: 'camp' },
    ],
    dialogue: {
      start: 'hello',
      nodes: {
        hello: {
          id: 'hello',
          textAr: 'واو! بشري آخر! أنا عمر. اسمع، أنا قريب من تشغيل الراديو، أحتاج قطعًا فقط!',
          textEn: "Wow — another human! I'm Omar. Listen, I'm close to getting this radio running — I just need parts!",
          variants: [
            { when: { hasFlags: ['radio_done'] }, node: 'done' },
            { when: { hasFlags: ['omar_battery_given'], notFlags: ['radio_done'] }, node: 'battery_in' },
            { when: { hasFlags: ['omar_met'] }, node: 'again' },
          ],
          choices: [
            { textAr: 'ما الذي تحتاجه بالضبط؟', textEn: 'What exactly do you need?', next: 'needs', trust: 3, setFlags: ['omar_met'], action: 'quest:repair_radio' },
            { textAr: 'هل تعرف طريقًا للخروج من الجزيرة؟', textEn: 'Do you know a way off the island?', next: 'ways', setFlags: ['omar_met'] },
          ],
        },
        again: {
          id: 'again',
          textAr: 'هل جلبت القطع؟ كل ساعة تأخير تعني فرصة أقل لتحديد موقعنا.',
          textEn: 'Did you bring the parts? Every hour of delay is a smaller chance of fixing our position.',
          choices: [
            { textAr: 'هذه خردة معدن ونحاس.', textEn: 'Here is scrap metal and copper.', next: 'parts', requires: { hasItems: [{ id: 'scrap_metal', count: 3 }, { id: 'copper_ingot', count: 1 }], }, trust: 10, setFlags: ['omar_parts'], action: 'take_item:scrap_metal:3' },
            { textAr: 'ليس بعد.', textEn: 'Not yet.', next: null },
          ],
        },
        needs: {
          id: 'needs',
          textAr: 'ثلاث قطع خردة معدن، سبيكة نحاس، وبطارية. البطارية هي الأصعب... سمعت أن شيخًا قرب الكهف يملك واحدة.',
          textEn: "Three scrap metal pieces, a copper ingot, and a battery. The battery's the hard part... I heard an old man near the cave has one.",
          choices: [{ textAr: 'سأتولى الأمر.', textEn: "I'll handle it.", next: null, trust: 2, setFlags: ['know_battery_yusuf'] }],
        },
        ways: {
          id: 'ways',
          textAr: 'الطوافة ممكنة لكنها خطيرة. الإشارة عبر الراديو أأمن بكثير. ساعدني.',
          textEn: 'A raft is possible but dangerous. Signaling by radio is far safer. Help me.',
          choices: [{ textAr: 'حسنًا.', textEn: 'Alright.', next: 'needs', trust: 3 }],
        },
        parts: {
          id: 'parts',
          textAr: 'ممتاز! بقيت البطارية فقط. عندما تحصل عليها عد إلي فورًا.',
          textEn: 'Excellent! Only the battery left. When you get it, come straight back.',
          choices: [{ textAr: 'سأعود.', textEn: "I'll be back.", next: null }],
        },
        battery_in: {
          id: 'battery_in',
          textAr: 'إنه يعمل!... أنا أسمع تشويشًا. أحتاج بضع دقائق لأرسل نداء الاستغاثة.',
          textEn: "It's working!... I hear static. I need a few minutes to send the distress call.",
          choices: [{ textAr: 'أرسله الآن!', textEn: 'Send it now!', next: null, trust: 10, setFlags: ['radio_done'], action: 'flag:radio_done' }],
        },
        done: {
          id: 'done',
          textAr: 'أرسلتُ النداء. الآن علينا أن نبقى أحياء ونُشعل إشارة عند اقترابهم. شكرًا لك، حقًا.',
          textEn: "The call is sent. Now we must stay alive and light a signal when they come close. Thank you — truly.",
          choices: [{ textAr: 'سننجو.', textEn: "We'll make it.", next: null, trust: 5 }],
        },
      },
    },
  },
  {
    id: 'yusuf',
    nameAr: 'يوسف', nameEn: 'Yusuf',
    bioAr: 'صياد سبعيني يعيش على الجزيرة منذ سنوات بعد غرق قاربه. يعرف أسرارها لكنه لا يثق بسهولة.',
    bioEn: 'A seventy-year-old fisherman living on the island for years since his boat sank. He knows its secrets but trusts slowly.',
    likes: { cooked_fish: 5, salted_fish: 5, honey: 4, herbal_tea: 4, fishing_net: 6, fish_hook: 3, rope: 2 },
    schedule: [
      { from: 20, to: 5, activity: 'sleep', place: 'cave' },
      { from: 5, to: 12, activity: 'work', place: 'beach' },
      { from: 12, to: 16, activity: 'camp', place: 'cave' },
      { from: 16, to: 20, activity: 'patrol', place: 'beach' },
    ],
    dialogue: {
      start: 'hello',
      nodes: {
        hello: {
          id: 'hello',
          textAr: '... ماذا تريد؟ هذه أرضي وأنا لم أدعُ أحدًا.',
          textEn: '... What do you want? This is my ground, and I invited no one.',
          variants: [
            { when: { hasFlags: ['yusuf_secret'] }, node: 'after_secret' },
            { when: { minTrust: 40 }, node: 'secret' },
            { when: { hasFlags: ['yusuf_met'] }, node: 'again' },
          ],
          choices: [
            { textAr: 'أبحث عن ناجين فقط.', textEn: 'Just looking for survivors.', next: 'gruff', trust: 1, setFlags: ['yusuf_met'] },
            { textAr: 'أحمل سمكًا طازجًا لك.', textEn: 'I brought you fresh fish.', next: 'fish', requires: { hasItems: [{ id: 'cooked_fish', count: 1 }] }, trust: 8, setFlags: ['yusuf_met'], action: 'take_item:cooked_fish:1' },
          ],
        },
        gruff: {
          id: 'gruff',
          textAr: 'ناجين... كلنا نحاول ألا نموت. ابتعد عن كهفي ولن يصيبك أذى.',
          textEn: "Survivors... we're all trying not to die. Stay away from my cave and you won't get hurt.",
          choices: [{ textAr: 'حسنًا.', textEn: 'Fine.', next: null }],
        },
        fish: {
          id: 'fish',
          textAr: 'همم... سمك مشوي جيدًا. قلّما أرى من يحسن الطبخ. اجلس إن أردت.',
          textEn: "Hmm... well grilled. Few here can cook. Sit, if you like.",
          choices: [{ textAr: 'شكرًا.', textEn: 'Thanks.', next: null, trust: 4 }],
        },
        again: {
          id: 'again',
          textAr: 'أنت مجددًا. الصيد جيد عند الفجر على الشاطئ الشرقي، إن كنت تهتم.',
          textEn: "You again. Fishing is good at dawn on the east beach, if you care.",
          choices: [
            { textAr: 'هل لديك بطارية؟ عمر يحتاجها.', textEn: 'Do you have a battery? Omar needs one.', next: 'battery_ask', requires: { hasFlags: ['know_battery_yusuf'] } },
            { textAr: 'سأعود لاحقًا.', textEn: "I'll come back later.", next: null },
          ],
        },
        battery_ask: {
          id: 'battery_ask',
          textAr: 'لن أعطي شيئًا لغريب. اكسب ثقتي أولًا، وأحضر لي شبكة صيد جيدة.',
          textEn: "I give nothing to strangers. Earn my trust first — and bring me a good fishing net.",
          choices: [
            { textAr: 'هذه شبكة صيد.', textEn: 'Here is a fishing net.', next: 'battery_ok', requires: { hasItems: [{ id: 'fishing_net', count: 1 }] }, trust: 20, action: 'take_item:fishing_net:1', setFlags: ['yusuf_net'] },
            { textAr: 'سأعود بها.', textEn: "I'll bring it.", next: null },
          ],
        },
        battery_ok: {
          id: 'battery_ok',
          textAr: 'شبكة متقنة الصنع. خذ البطارية، لكن لا تخبر عمر أنني تساهلت.',
          textEn: "A finely made net. Take the battery — but don't tell Omar I went soft.",
          choices: [{ textAr: 'شكرًا يا عم يوسف.', textEn: 'Thank you, Yusuf.', next: null, trust: 6, action: 'give_item:radio_battery:1', setFlags: ['yusuf_battery'] }],
        },
        secret: {
          id: 'secret',
          textAr: 'ثقتي بك كبيرة الآن. هذه الجزيرة ليست كما تبدو: تحت البركان مخبأ قديم، مفتاحه معي. ما بداخله قد يغيّر كل شيء.',
          textEn: "I trust you now. This island is not what it seems: under the volcano lies an old bunker — I hold its key. What's inside could change everything.",
          choices: [
            { textAr: 'أريد أن أراه.', textEn: 'I want to see it.', next: 'key', trust: 8, setFlags: ['yusuf_secret'], action: 'give_item:bunker_key:1' },
            { textAr: 'لا أريد التورط.', textEn: "I don't want to get involved.", next: null },
          ],
        },
        key: {
          id: 'key',
          textAr: 'خذ المفتاح. عند فوهة البركان، خلف الصخرة المتشققة. احذر من النمور ليلًا.',
          textEn: 'Take the key. At the crater, behind the cracked rock. Beware the jaguars at night.',
          choices: [{ textAr: 'شكرًا.', textEn: 'Thanks.', next: null }],
        },
        after_secret: {
          id: 'after_secret',
          textAr: 'ما زلت حيًا؟ جيد. القبو فيه أكثر من راديو... ابحث عن الهاتف الفضائي.',
          textEn: "Still alive? Good. The bunker holds more than a radio... look for the satellite phone.",
          choices: [{ textAr: 'سأفعل.', textEn: 'I will.', next: null }],
        },
      },
    },
  },
];
