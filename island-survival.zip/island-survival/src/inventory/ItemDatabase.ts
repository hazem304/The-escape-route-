import raw from '../data/items.json';
import type { ItemDef, ItemStack, ItemType } from './Item';
import { nextUid } from './Item';

class ItemDatabaseImpl {
  private map = new Map<string, ItemDef>();

  constructor() {
    for (const r of raw as unknown as ItemDef[]) this.map.set(r.id, r);
  }

  get(id: string): ItemDef {
    const d = this.map.get(id);
    if (!d) throw new Error(`ItemDatabase: unknown item "${id}"`);
    return d;
  }

  has(id: string): boolean {
    return this.map.has(id);
  }

  all(): ItemDef[] {
    return [...this.map.values()];
  }

  byType(type: ItemType): ItemDef[] {
    return this.all().filter((d) => d.type === type);
  }

  /** ينشئ مكدّسًا جديدًا بمتانة كاملة */
  create(id: string, count = 1, opts: Partial<Pick<ItemStack, 'durability' | 'spoil'>> = {}): ItemStack {
    const d = this.get(id);
    return {
      uid: nextUid(),
      defId: id,
      count: Math.min(count, d.stack),
      durability: opts.durability ?? d.durability,
      spoil: opts.spoil ?? 0,
    };
  }
}

export const ItemDB = new ItemDatabaseImpl();
