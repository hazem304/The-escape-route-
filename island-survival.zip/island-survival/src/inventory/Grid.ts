import type { ItemDef, ItemStack } from './Item';
import { ItemDB } from './ItemDatabase';

export interface GridEntry {
  stack: ItemStack;
  x: number;
  y: number;
  rotated: boolean;
}

/** شبكة خانات: كل عنصر يشغل w×h ويمكن تدويره */
export class Grid {
  private entries = new Map<number, GridEntry>(); // uid -> entry
  /** خريطة الإشغال: uid أو 0 */
  private cells: Int32Array;

  constructor(public width: number, public height: number) {
    this.cells = new Int32Array(width * height);
  }

  static dims(def: ItemDef, rotated: boolean): [number, number] {
    return rotated ? [def.size[1], def.size[0]] : [def.size[0], def.size[1]];
  }

  list(): GridEntry[] {
    return [...this.entries.values()];
  }

  get size(): number {
    return this.entries.size;
  }

  get(uid: number): GridEntry | undefined {
    return this.entries.get(uid);
  }

  at(x: number, y: number): GridEntry | undefined {
    if (x < 0 || y < 0 || x >= this.width || y >= this.height) return undefined;
    const uid = this.cells[y * this.width + x];
    return uid ? this.entries.get(uid) : undefined;
  }

  /** هل يمكن وضع العنصر؟ ignoreUid لتجاهل عنصر معيّن (عند التحريك) */
  canPlace(def: ItemDef, x: number, y: number, rotated: boolean, ignoreUid = 0): boolean {
    const [w, h] = Grid.dims(def, rotated);
    if (x < 0 || y < 0 || x + w > this.width || y + h > this.height) return false;
    for (let j = y; j < y + h; j++) {
      for (let i = x; i < x + w; i++) {
        const c = this.cells[j * this.width + i];
        if (c !== 0 && c !== ignoreUid) return false;
      }
    }
    return true;
  }

  /** العناصر التي تتداخل مع مستطيل معيّن (بدون تكرار) */
  overlapping(def: ItemDef, x: number, y: number, rotated: boolean): GridEntry[] {
    const [w, h] = Grid.dims(def, rotated);
    const seen = new Set<number>();
    const out: GridEntry[] = [];
    for (let j = y; j < y + h; j++) {
      for (let i = x; i < x + w; i++) {
        const e = this.at(i, j);
        if (e && !seen.has(e.stack.uid)) {
          seen.add(e.stack.uid);
          out.push(e);
        }
      }
    }
    return out;
  }

  place(stack: ItemStack, x: number, y: number, rotated = false): boolean {
    const def = ItemDB.get(stack.defId);
    if (!this.canPlace(def, x, y, rotated)) return false;
    const [w, h] = Grid.dims(def, rotated);
    for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) this.cells[j * this.width + i] = stack.uid;
    this.entries.set(stack.uid, { stack, x, y, rotated });
    return true;
  }

  remove(uid: number): GridEntry | undefined {
    const e = this.entries.get(uid);
    if (!e) return undefined;
    const def = ItemDB.get(e.stack.defId);
    const [w, h] = Grid.dims(def, e.rotated);
    for (let j = e.y; j < e.y + h; j++) for (let i = e.x; i < e.x + w; i++) this.cells[j * this.width + i] = 0;
    this.entries.delete(uid);
    return e;
  }

  /** أول مكان يتسع للعنصر (يجرّب بدون تدوير ثم بتدوير) */
  findSpot(def: ItemDef): { x: number; y: number; rotated: boolean } | null {
    const variants: boolean[] = def.size[0] === def.size[1] ? [false] : [false, true];
    for (const rotated of variants) {
      for (let y = 0; y < this.height; y++) {
        for (let x = 0; x < this.width; x++) {
          if (this.canPlace(def, x, y, rotated)) return { x, y, rotated };
        }
      }
    }
    return null;
  }

  /**
   * يضيف عددًا من عنصر: يملأ المكدّسات الحالية أولًا ثم ينشئ جديدة.
   * @returns العدد المتبقي الذي لم يتسع
   */
  add(defId: string, count: number, opts: { durability?: number; spoil?: number } = {}): number {
    const def = ItemDB.get(defId);
    let left = count;

    if (def.stack > 1) {
      for (const e of this.entries.values()) {
        if (left <= 0) break;
        if (e.stack.defId !== defId || e.stack.count >= def.stack) continue;
        const room = def.stack - e.stack.count;
        const moved = Math.min(room, left);
        // الفساد يُمزج بمتوسط مرجّح حتى لا يُخفى فساد الدفعة القديمة
        const incomingSpoil = opts.spoil ?? 0;
        e.stack.spoil = (e.stack.spoil * e.stack.count + incomingSpoil * moved) / (e.stack.count + moved);
        e.stack.count += moved;
        left -= moved;
      }
    }

    while (left > 0) {
      const spot = this.findSpot(def);
      if (!spot) break;
      const n = Math.min(def.stack, left);
      const stack = ItemDB.create(defId, n, opts);
      this.place(stack, spot.x, spot.y, spot.rotated);
      left -= n;
    }
    return left;
  }

  /** يدمج مكدّسًا موجودًا (بكامل خصائصه) في الشبكة؛ يعيد ما تبقّى منه (0 = تم الكل) */
  addStack(stack: ItemStack): number {
    const def = ItemDB.get(stack.defId);
    if (def.stack === 1 || def.durability > 0) {
      const spot = this.findSpot(def);
      if (!spot) return stack.count;
      this.place(stack, spot.x, spot.y, spot.rotated);
      return 0;
    }
    return this.add(stack.defId, stack.count, { durability: stack.durability, spoil: stack.spoil });
  }

  count(defId: string): number {
    let n = 0;
    for (const e of this.entries.values()) if (e.stack.defId === defId) n += e.stack.count;
    return n;
  }

  /** يغيّر الأبعاد؛ يفشل (false) إن خرج أي عنصر عن الحدود الجديدة ولا يغيّر شيئًا */
  resize(newW: number, newH: number): boolean {
    for (const e of this.entries.values()) {
      const def = ItemDB.get(e.stack.defId);
      const [w, h] = Grid.dims(def, e.rotated);
      if (e.x + w > newW || e.y + h > newH) return false;
    }
    const old = this.list();
    this.width = newW;
    this.height = newH;
    this.cells = new Int32Array(newW * newH);
    this.entries.clear();
    for (const e of old) this.place(e.stack, e.x, e.y, e.rotated);
    return true;
  }

  clear(): void {
    this.entries.clear();
    this.cells.fill(0);
  }

  toJSON(): { width: number; height: number; entries: GridEntry[] } {
    return { width: this.width, height: this.height, entries: this.list() };
  }

  static fromJSON(data: { width: number; height: number; entries: GridEntry[] }): Grid {
    const g = new Grid(data.width, data.height);
    for (const e of data.entries) g.place(e.stack, e.x, e.y, e.rotated);
    return g;
  }
}
