export const HOTBAR_SIZE = 8;

/** شريط سريع: يشير إلى uid لعناصر موجودة في الحقيبة (لا يملكها) */
export class Hotbar {
  readonly slots: Array<number | null> = new Array(HOTBAR_SIZE).fill(null);
  selected = 0;

  select(i: number): void {
    this.selected = ((i % HOTBAR_SIZE) + HOTBAR_SIZE) % HOTBAR_SIZE;
  }

  /** عجلة الماوس: dir = +1 أو -1 */
  scroll(dir: number): void {
    this.select(this.selected + (dir > 0 ? 1 : -1));
  }

  assign(slot: number, uid: number | null): void {
    if (slot < 0 || slot >= HOTBAR_SIZE) return;
    // العنصر الواحد لا يظهر في خانتين
    if (uid !== null) for (let i = 0; i < HOTBAR_SIZE; i++) if (this.slots[i] === uid) this.slots[i] = null;
    this.slots[slot] = uid;
  }

  clearUid(uid: number): void {
    for (let i = 0; i < HOTBAR_SIZE; i++) if (this.slots[i] === uid) this.slots[i] = null;
  }

  get heldUid(): number | null {
    return this.slots[this.selected];
  }

  /** أول خانة فارغة أو -1 */
  firstFree(): number {
    return this.slots.indexOf(null);
  }
}
