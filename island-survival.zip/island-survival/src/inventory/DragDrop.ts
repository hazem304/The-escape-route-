import { Grid } from './Grid';
import type { ItemStack } from './Item';
import { ItemDB } from './ItemDatabase';

export type DropResult = 'placed' | 'merged' | 'swapped' | 'rejected';

interface Origin {
  grid: Grid;
  x: number;
  y: number;
  rotated: boolean;
}

/**
 * منطق السحب والإفلات (مستقل عن الـ DOM ليُختبر وحدويًا).
 * الواجهة تستدعي pickup / rotate / drop / cancel فقط.
 */
export class DragController {
  held: { stack: ItemStack; rotated: boolean } | null = null;
  private origin: Origin | null = null;

  get active(): boolean {
    return this.held !== null;
  }

  /** يلتقط عنصرًا (أو جزءًا منه) من شبكة */
  pickup(grid: Grid, uid: number, amount?: number): boolean {
    if (this.held) return false;
    const e = grid.get(uid);
    if (!e) return false;

    if (amount !== undefined && amount > 0 && amount < e.stack.count) {
      // تقسيم (Shift): نلتقط جزءًا فقط ويبقى الباقي
      const part = ItemDB.create(e.stack.defId, amount, { durability: e.stack.durability, spoil: e.stack.spoil });
      e.stack.count -= amount;
      this.held = { stack: part, rotated: e.rotated };
      this.origin = { grid, x: e.x, y: e.y, rotated: e.rotated };
      return true;
    }
    grid.remove(uid);
    this.held = { stack: e.stack, rotated: e.rotated };
    this.origin = { grid, x: e.x, y: e.y, rotated: e.rotated };
    return true;
  }

  rotate(): void {
    if (this.held) this.held.rotated = !this.held.rotated;
  }

  /** يفلت العنصر عند الخلية (x,y) في شبكة؛ يدمج أو يبدّل إن لزم */
  drop(grid: Grid, x: number, y: number): DropResult {
    if (!this.held) return 'rejected';
    const { stack, rotated } = this.held;
    const def = ItemDB.get(stack.defId);

    if (grid.canPlace(def, x, y, rotated)) {
      grid.place(stack, x, y, rotated);
      return this.finish('placed');
    }

    const overlap = grid.overlapping(def, x, y, rotated);
    if (overlap.length === 1) {
      const target = overlap[0];
      const td = ItemDB.get(target.stack.defId);

      // دمج المتماثلات القابلة للتكديس
      if (target.stack.defId === stack.defId && td.stack > 1 && target.stack.count < td.stack) {
        const room = td.stack - target.stack.count;
        const moved = Math.min(room, stack.count);
        target.stack.spoil = (target.stack.spoil * target.stack.count + stack.spoil * moved) / (target.stack.count + moved);
        target.stack.count += moved;
        stack.count -= moved;
        if (stack.count <= 0) return this.finish('merged');
        return 'merged'; // بقي جزء في اليد
      }

      // تبديل: نضع المحمول مكان الهدف ونلتقط الهدف
      grid.remove(target.stack.uid);
      if (grid.canPlace(def, x, y, rotated)) {
        grid.place(stack, x, y, rotated);
        this.held = { stack: target.stack, rotated: target.rotated };
        // أصل العنصر الملتقط الجديد = مكانه الأصلي في هذه الشبكة
        this.origin = { grid, x: target.x, y: target.y, rotated: target.rotated };
        return 'swapped';
      }
      grid.place(target.stack, target.x, target.y, target.rotated);
    }
    return 'rejected';
  }

  /** إلغاء: إعادة العنصر لمكانه الأصلي أو أقرب مكان متاح في نفس الشبكة */
  cancel(): boolean {
    if (!this.held || !this.origin) return false;
    const { stack } = this.held;
    const { grid, x, y, rotated } = this.origin;
    const def = ItemDB.get(stack.defId);

    // التقاط جزئي: إن كان الأصل ما زال موجودًا ندمج العدد فيه
    const at = grid.at(x, y);
    if (at && at.stack.defId === stack.defId && ItemDB.get(stack.defId).stack > 1) {
      at.stack.count += stack.count;
    } else if (grid.canPlace(def, x, y, rotated)) {
      grid.place(stack, x, y, rotated);
    } else if (grid.addStack(stack) > 0) {
      return false; // لا مكان إطلاقًا
    }
    this.held = null;
    this.origin = null;
    return true;
  }

  private finish(r: DropResult): DropResult {
    this.held = null;
    this.origin = null;
    return r;
  }
}
