import { Container } from './Container';
import { Equipment } from './Equipment';
import { Grid, type GridEntry } from './Grid';
import { Hotbar } from './Hotbar';
import { EQUIP_SLOTS, ensureUidAbove, spoilState, type EquipSlot, type ItemStack, type SpoilState } from './Item';
import { ItemDB } from './ItemDatabase';
import { loadEffect, type LoadEffect } from './Weight';

export interface InventorySave {
  grid: { width: number; height: number; entries: GridEntry[] };
  equipment: Array<{ slot: EquipSlot; stack: ItemStack }>;
  hotbar: { slots: Array<number | null>; selected: number };
}

const EQUIP_SLOTS_ALL: readonly EquipSlot[] = EQUIP_SLOTS;

/** بدون حقيبة: جيوب صغيرة فقط */
export const POCKET_GRID = { w: 4, h: 2, maxWeight: 20 } as const;

export interface UseResult {
  ok: boolean;
  reason?: 'notFound' | 'notUsable';
  defId?: string;
  effects: Record<string, number | string>;
  state: SpoilState;
}

/** الحقيبة الكاملة: شبكة + تجهيز + شريط سريع + وزن + فساد + متانة */
export class Inventory {
  grid = new Grid(POCKET_GRID.w, POCKET_GRID.h);
  readonly equipment = new Equipment();
  readonly hotbar = new Hotbar();

  onChange: (() => void) | null = null;

  get maxWeight(): number {
    const bp = this.equipment.get('backpack');
    return bp ? Number(ItemDB.get(bp.defId).effects.maxWeight ?? POCKET_GRID.maxWeight) : POCKET_GRID.maxWeight;
  }

  get totalWeight(): number {
    let w = 0;
    for (const e of this.grid.list()) w += ItemDB.get(e.stack.defId).weight * e.stack.count;
    for (const { stack } of this.equipment.list()) w += ItemDB.get(stack.defId).weight * stack.count;
    return Math.round(w * 100) / 100;
  }

  get burden(): LoadEffect {
    return loadEffect(this.totalWeight, this.maxWeight);
  }

  private changed(): void {
    this.onChange?.();
  }

  // ---------- إضافة / إزالة ----------

  /** @returns العدد الذي لم يتسع (0 = أُضيف الكل) */
  add(defId: string, count = 1, opts: { durability?: number; spoil?: number } = {}): number {
    const left = this.grid.add(defId, count, opts);
    if (left < count) this.changed();
    return left;
  }

  addStack(stack: ItemStack): number {
    const left = this.grid.addStack(stack);
    if (left === 0) this.changed();
    return left;
  }

  count(defId: string): number {
    return this.grid.count(defId);
  }

  has(defId: string, n = 1): boolean {
    return this.count(defId) >= n;
  }

  /**
   * يزيل عددًا من عنصر. يبدأ من الأكثر تلفًا/فسادًا (الأقل قيمة) فيبقى الأفضل.
   * @returns العدد الذي أُزيل فعلًا
   */
  remove(defId: string, count = 1): number {
    const entries = this.grid
      .list()
      .filter((e) => e.stack.defId === defId)
      .sort((a, b) => a.stack.durability - b.stack.durability || b.stack.spoil - a.stack.spoil);
    let left = count;
    for (const e of entries) {
      if (left <= 0) break;
      const take = Math.min(left, e.stack.count);
      e.stack.count -= take;
      left -= take;
      if (e.stack.count <= 0) this.removeEntry(e.stack.uid);
    }
    if (left < count) this.changed();
    return count - left;
  }

  private removeEntry(uid: number): void {
    this.grid.remove(uid);
    this.hotbar.clearUid(uid);
  }

  /** يزيل مكدّسًا كاملًا أو جزءًا منه ويعيد المزال (للرمي/النقل) */
  take(uid: number, count?: number): ItemStack | null {
    const e = this.grid.get(uid);
    if (!e) return null;
    const n = count === undefined ? e.stack.count : Math.min(count, e.stack.count);
    if (n >= e.stack.count) {
      this.removeEntry(uid);
      this.changed();
      return e.stack;
    }
    e.stack.count -= n;
    this.changed();
    return { ...e.stack, uid: ItemDB.create(e.stack.defId, 1).uid, count: n };
  }

  /** تقسيم مكدّس إلى مكدّسين (الجزء الجديد يوضع في أول مكان متاح) */
  split(uid: number, amount: number): boolean {
    const e = this.grid.get(uid);
    if (!e || amount <= 0 || amount >= e.stack.count) return false;
    const def = ItemDB.get(e.stack.defId);
    const spot = this.grid.findSpot(def);
    if (!spot) return false;
    const part = ItemDB.create(e.stack.defId, amount, { durability: e.stack.durability, spoil: e.stack.spoil });
    e.stack.count -= amount;
    this.grid.place(part, spot.x, spot.y, spot.rotated);
    this.changed();
    return true;
  }

  /** ترتيب تلقائي: الأكبر أولًا ثم حسب النوع. إن فشل التعبئة يُستعاد الترتيب الأصلي */
  sort(): boolean {
    const before = this.grid.list().map((e) => ({ ...e }));
    const stacks = before.map((e) => e.stack);
    stacks.sort((a, b) => {
      const da = ItemDB.get(a.defId);
      const db = ItemDB.get(b.defId);
      return db.size[0] * db.size[1] - da.size[0] * da.size[1] || da.type.localeCompare(db.type) || da.id.localeCompare(db.id);
    });
    this.grid.clear();
    // دمج المتشابه أولًا
    let ok = true;
    for (const s of stacks) {
      if (this.grid.addStack(s) > 0) {
        ok = false;
        break;
      }
    }
    if (!ok) {
      this.grid.clear();
      for (const e of before) this.grid.place(e.stack, e.x, e.y, e.rotated);
      return false;
    }
    this.changed();
    return true;
  }

  // ---------- تجهيز ----------

  /** يجهّز عنصرًا من الحقيبة. يبدّل مع القطعة المجهزة سابقًا. يفشل إن لم تتسع الحقيبة بعد تبديل حقيبة الظهر */
  equip(uid: number): { ok: boolean; reason?: string } {
    const e = this.grid.get(uid);
    if (!e) return { ok: false, reason: 'notFound' };
    const slot = Equipment.slotFor(e.stack.defId);
    if (!slot) return { ok: false, reason: 'notEquippable' };

    const previous = this.equipment.get(slot);

    if (slot === 'backpack') return this.swapBackpack(uid, e.stack, previous);

    this.grid.remove(uid);
    this.hotbar.clearUid(uid);
    if (previous && this.grid.addStack(previous) > 0) {
      // لا مكان للقطعة القديمة: نتراجع
      this.grid.place(e.stack, e.x, e.y, e.rotated);
      return { ok: false, reason: 'noSpace' };
    }
    this.equipment.set(slot, e.stack);
    this.changed();
    return { ok: true };
  }

  private swapBackpack(uid: number, next: ItemStack, previous: ItemStack | null): { ok: boolean; reason?: string } {
    const nd = ItemDB.get(next.defId);
    const newW = Number(nd.effects.gridW);
    const newH = Number(nd.effects.gridH);
    const entry = this.grid.get(uid);
    if (!entry) return { ok: false, reason: 'notFound' };
    const oldW = this.grid.width;
    const oldH = this.grid.height;
    this.grid.remove(uid);

    // الأبعاد الجديدة يجب أن تتسع لكل العناصر الموجودة في أماكنها
    if (!this.grid.resize(newW, newH)) {
      this.grid.place(entry.stack, entry.x, entry.y, entry.rotated);
      return { ok: false, reason: 'itemsWouldNotFit' };
    }
    // الحقيبة القديمة تعود إلى الشبكة الجديدة
    if (previous && this.grid.addStack(previous) > 0) {
      this.grid.resize(oldW, oldH);
      this.grid.place(entry.stack, entry.x, entry.y, entry.rotated);
      return { ok: false, reason: 'noSpace' };
    }
    this.equipment.set('backpack', next);
    this.hotbar.clearUid(uid);
    this.changed();
    return { ok: true };
  }

  /** يخلع قطعة ويعيدها للحقيبة */
  unequip(slot: EquipSlot): { ok: boolean; reason?: string } {
    const s = this.equipment.get(slot);
    if (!s) return { ok: false, reason: 'empty' };

    if (slot === 'backpack') {
      // العودة للجيوب تتطلب أن تتسع العناصر في 4×2
      if (!this.grid.resize(POCKET_GRID.w, POCKET_GRID.h)) return { ok: false, reason: 'itemsWouldNotFit' };
      this.equipment.set('backpack', null);
      if (this.grid.addStack(s) > 0) {
        // لا مكان لها في الجيوب: نعيد كل شيء
        const bd = ItemDB.get(s.defId);
        this.grid.resize(Number(bd.effects.gridW), Number(bd.effects.gridH));
        this.equipment.set('backpack', s);
        return { ok: false, reason: 'noSpace' };
      }
      this.changed();
      return { ok: true };
    }

    if (this.grid.addStack(s) > 0) return { ok: false, reason: 'noSpace' };
    this.equipment.set(slot, null);
    this.changed();
    return { ok: true };
  }

  // ---------- استخدام ----------

  /** يستهلك وحدة من طعام/شراب/دواء ويعيد تأثيرها مُعدَّلًا بحالة الفساد */
  use(uid: number): UseResult {
    const e = this.grid.get(uid);
    if (!e) return { ok: false, reason: 'notFound', effects: {}, state: 'none' };
    const def = ItemDB.get(e.stack.defId);
    if (def.type !== 'food' && def.type !== 'drink' && def.type !== 'medicine') {
      return { ok: false, reason: 'notUsable', effects: {}, state: 'none' };
    }
    const state = spoilState(def, e.stack);
    const effects: Record<string, number | string> = { ...def.effects };
    if (state === 'stale') {
      // طعام قديم: قيمة أقل وخطر مرض أعلى
      for (const k of ['hunger', 'thirst', 'health', 'energy']) {
        if (typeof effects[k] === 'number') effects[k] = Math.round((effects[k] as number) * 0.6);
      }
      effects.sick = Math.min(1, Number(effects.sick ?? 0) + 0.25);
    } else if (state === 'rotten') {
      effects.hunger = 1;
      effects.sick = 0.95;
    }
    e.stack.count -= 1;
    if (e.stack.count <= 0) this.removeEntry(uid);
    this.changed();
    return { ok: true, defId: def.id, effects, state };
  }

  // ---------- متانة ----------

  /** ينقص متانة عنصر. @returns true إذا تحطّم وأُزيل */
  damage(uid: number, amount: number): boolean {
    const e = this.grid.get(uid);
    if (!e) return false;
    const def = ItemDB.get(e.stack.defId);
    if (def.durability <= 0) return false;
    e.stack.durability = Math.max(0, e.stack.durability - amount);
    if (e.stack.durability === 0) {
      this.removeEntry(uid);
      this.changed();
      return true;
    }
    this.changed();
    return false;
  }

  /** إصلاح: يعيد المتانة جزئيًا دون تجاوز الحد الأقصى. @returns المضاف فعليًا */
  repair(uid: number, amount: number): number {
    const e = this.grid.get(uid);
    if (!e) return 0;
    const max = ItemDB.get(e.stack.defId).durability;
    if (max <= 0) return 0;
    const before = e.stack.durability;
    e.stack.durability = Math.min(max, before + amount);
    this.changed();
    return e.stack.durability - before;
  }

  /** ينقص متانة القطعة المجهزة في خانة (مثلًا الحذاء أثناء المشي) */
  damageEquipped(slot: EquipSlot, amount: number): void {
    const s = this.equipment.get(slot);
    if (!s || ItemDB.get(s.defId).durability <= 0) return;
    s.durability = Math.max(0, s.durability - amount);
  }

  // ---------- زمن ----------

  /** تقدّم الفساد في الحقيبة (بالساعات داخل اللعبة) */
  updateSpoil(dtHours: number): void {
    for (const e of this.grid.list()) {
      const def = ItemDB.get(e.stack.defId);
      if (def.spoilTime > 0) e.stack.spoil += dtHours;
    }
    Container.convertRotten(this.grid);
  }

  /** العنصر المحمول في اليد (الخانة المحددة في الشريط السريع) */
  get held(): ItemStack | null {
    const uid = this.hotbar.heldUid;
    return uid === null ? null : this.grid.get(uid)?.stack ?? null;
  }

  toJSON(): InventorySave {
    return {
      grid: this.grid.toJSON(),
      equipment: this.equipment.list(),
      hotbar: { slots: [...this.hotbar.slots], selected: this.hotbar.selected },
    };
  }

  /** يستعيد الحالة المحفوظة ويضمن ألا تتكرر معرّفات المكدّسات الجديدة */
  load(d: InventorySave): void {
    this.grid = Grid.fromJSON(d.grid);
    for (const slot of EQUIP_SLOTS_ALL) this.equipment.set(slot, null);
    let maxUid = 0;
    for (const { slot, stack } of d.equipment) {
      this.equipment.set(slot, stack);
      maxUid = Math.max(maxUid, stack.uid);
    }
    for (const e of this.grid.list()) maxUid = Math.max(maxUid, e.stack.uid);
    ensureUidAbove(maxUid);
    d.hotbar.slots.forEach((u, i) => this.hotbar.assign(i, u));
    this.hotbar.select(d.hotbar.selected);
    this.changed();
  }
}
