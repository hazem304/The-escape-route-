import { Grid } from './Grid';
import { ItemDB } from './ItemDatabase';

/** حاوية تخزين (صندوق، برميل، ثلاجة) بحجم وحفظ مختلفين */
export class Container {
  readonly grid: Grid;
  /** مضاعِف إبطاء الفساد (1 = عادي) */
  readonly preserve: number;

  constructor(public readonly id: string, public readonly defId: string) {
    const d = ItemDB.get(defId);
    const w = Number(d.effects.gridW ?? 4);
    const h = Number(d.effects.gridH ?? 4);
    this.grid = new Grid(w, h);
    this.preserve = Number(d.effects.preserve ?? 1);
  }

  toJSON(): { id: string; defId: string; grid: ReturnType<Grid['toJSON']> } {
    return { id: this.id, defId: this.defId, grid: this.grid.toJSON() };
  }

  static fromJSON(d: { id: string; defId: string; grid: ReturnType<Grid['toJSON']> }): Container {
    const c = new Container(d.id, d.defId);
    const loaded = Grid.fromJSON(d.grid);
    for (const e of loaded.list()) c.grid.place(e.stack, e.x, e.y, e.rotated);
    return c;
  }

  /** يقدّم الفساد داخل الحاوية */
  updateSpoil(dtHours: number): void {
    for (const e of this.grid.list()) {
      const def = ItemDB.get(e.stack.defId);
      if (def.spoilTime > 0) e.stack.spoil += dtHours / this.preserve;
    }
    Container.convertRotten(this.grid);
  }

  /** يحوّل الأطعمة التي تجاوزت زمن فسادها إلى "طعام فاسد" */
  static convertRotten(grid: Grid): void {
    for (const e of grid.list()) {
      const def = ItemDB.get(e.stack.defId);
      if (def.spoilTime > 0 && def.type === 'food' && e.stack.spoil >= def.spoilTime && def.id !== 'rotten_food') {
        e.stack.defId = 'rotten_food';
        e.stack.spoil = 0;
        // الفاسد يتكدس حتى حده الأقصى فقط
        e.stack.count = Math.min(e.stack.count, ItemDB.get('rotten_food').stack);
      }
    }
  }
}
