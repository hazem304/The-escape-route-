import { EQUIP_SLOTS, type EquipSlot, type ItemStack } from './Item';
import { ItemDB } from './ItemDatabase';

/** خانات التجهيز: رأس، صدر، ساقان، قدمان، يدان، أداة، حقيبة ظهر */
export class Equipment {
  private slots = new Map<EquipSlot, ItemStack | null>();

  constructor() {
    for (const s of EQUIP_SLOTS) this.slots.set(s, null);
  }

  get(slot: EquipSlot): ItemStack | null {
    return this.slots.get(slot) ?? null;
  }

  set(slot: EquipSlot, stack: ItemStack | null): void {
    this.slots.set(slot, stack);
  }

  /** الخانة التي يناسبها العنصر أو null إن لم يكن قابلًا للتجهيز */
  static slotFor(defId: string): EquipSlot | null {
    const d = ItemDB.get(defId);
    if (d.type === 'clothing' || d.type === 'backpack') {
      const s = d.effects.slot;
      return typeof s === 'string' && (EQUIP_SLOTS as readonly string[]).includes(s) ? (s as EquipSlot) : null;
    }
    // الفانوس/البوصلة/المنظار تُجهَّز في خانة الأداة
    if (d.type === 'tool' && (d.effects.light || d.effects.compass || d.effects.zoom)) return 'tool';
    return null;
  }

  list(): Array<{ slot: EquipSlot; stack: ItemStack }> {
    const out: Array<{ slot: EquipSlot; stack: ItemStack }> = [];
    for (const [slot, stack] of this.slots) if (stack) out.push({ slot, stack });
    return out;
  }

  private sum(key: string): number {
    let total = 0;
    for (const { stack } of this.list()) {
      const v = ItemDB.get(stack.defId).effects[key];
      // قطعة تالفة تمامًا لا تحمي
      if (typeof v === 'number' && stack.durability !== 0) total += v;
    }
    return total;
  }

  /** عزل حراري إجمالي (يقلل فقدان حرارة الجسم) */
  get warmth(): number {
    return this.sum('warmth');
  }
  get defense(): number {
    return this.sum('defense');
  }
  get sunProtection(): number {
    return Math.min(1, this.sum('sunProtect'));
  }
  get rainProof(): boolean {
    return this.sum('rainProof') > 0;
  }
  get gatherBonus(): number {
    return this.sum('gatherBonus');
  }
  get lightLevel(): number {
    return this.sum('light');
  }
}
