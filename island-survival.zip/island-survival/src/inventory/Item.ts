/** تعريفات العناصر ومثيلاتها (المكدّسات) */

export type ItemType =
  | 'resource' | 'food' | 'drink' | 'medicine' | 'tool' | 'weapon'
  | 'clothing' | 'backpack' | 'container' | 'building' | 'story';

export type Rarity = 'common' | 'uncommon' | 'rare' | 'epic';

export type EquipSlot = 'head' | 'chest' | 'legs' | 'feet' | 'hands' | 'tool' | 'backpack';
export const EQUIP_SLOTS: readonly EquipSlot[] = ['head', 'chest', 'legs', 'feet', 'hands', 'tool', 'backpack'];

/** ألوان الندرة للعرض */
export const RARITY_COLORS: Record<Rarity, string> = {
  common: '#d0d0d0',
  uncommon: '#5fd068',
  rare: '#4aa3ff',
  epic: '#c77dff',
};

export interface ItemDef {
  id: string;
  nameAr: string;
  nameEn: string;
  type: ItemType;
  /** أقصى عدد في الخانة الواحدة */
  stack: number;
  /** [عرض, ارتفاع] بالخانات */
  size: [number, number];
  weight: number;
  rarity: Rarity;
  /** 0 = لا يتلف */
  durability: number;
  /** بالساعات داخل اللعبة؛ 0 = لا يفسد */
  spoilTime: number;
  effects: Record<string, number | string>;
  model: string;
  icon: string;
}

/** مثيل عنصر (أو مكدّس منه) في العالم/الحقيبة */
export interface ItemStack {
  uid: number;
  defId: string;
  count: number;
  /** المتانة الحالية (للعناصر ذات durability>0) */
  durability: number;
  /** الساعات المنقضية منذ الفساد (للعناصر القابلة للفساد) */
  spoil: number;
}

let uidCounter = 1;
export function nextUid(): number {
  return uidCounter++;
}
/** بعد تحميل حفظ نضمن ألا تتكرر المعرّفات */
export function ensureUidAbove(n: number): void {
  if (uidCounter <= n) uidCounter = n + 1;
}

export type SpoilState = 'fresh' | 'stale' | 'rotten' | 'none';

export function spoilState(def: ItemDef, stack: ItemStack): SpoilState {
  if (def.spoilTime <= 0) return 'none';
  const r = stack.spoil / def.spoilTime;
  if (r >= 1) return 'rotten';
  if (r >= 0.6) return 'stale';
  return 'fresh';
}
