/** تأثير الحمولة على الحركة والتعب */
export interface LoadEffect {
  ratio: number;
  speedMultiplier: number;
  staminaDrainMultiplier: number;
  overloaded: boolean;
  /** حمل مفرط جدًا: لا يستطيع الجري أو القفز */
  immobilized: boolean;
}

export function loadEffect(weight: number, maxWeight: number): LoadEffect {
  const ratio = maxWeight > 0 ? weight / maxWeight : 0;
  const over = Math.max(0, ratio - 1);
  return {
    ratio,
    // حتى 100% لا عقوبة، بعدها تنخفض السرعة تدريجيًا حتى 30%
    speedMultiplier: ratio <= 1 ? 1 - Math.max(0, ratio - 0.8) * 0.25 : Math.max(0.3, 0.95 - over * 1.2),
    staminaDrainMultiplier: 1 + over * 3,
    overloaded: ratio > 1,
    immobilized: ratio > 1.6,
  };
}
