import { DIFFICULTY, newStats, type Condition, type ConditionId, type Difficulty, type Stats } from './Stats';

export type Activity = 'rest' | 'idle' | 'walk' | 'run' | 'work' | 'swim';

/** مدخلات البيئة لكل تحديث */
export interface SurvivalContext {
  ambientTemp: number; // °م
  isRaining: boolean;
  inWater: boolean;
  /** دفء النار القريبة 0..1 */
  fireHeat: number;
  inShelter: boolean;
  activity: Activity;
  sleeping: boolean;
  /** ساعة اليوم (للشمس) */
  hour: number;
  /** من الملابس */
  warmth: number;
  sunProtection: number;
  rainProof: boolean;
  /** مضاعِف استهلاك النفَس من الحمولة */
  staminaDrainMult: number;
}

export const DEFAULT_CTX: SurvivalContext = {
  ambientTemp: 28, isRaining: false, inWater: false, fireHeat: 0, inShelter: false, activity: 'idle',
  sleeping: false, hour: 12, warmth: 0, sunProtection: 0, rainProof: false, staminaDrainMult: 1,
};

/** مصادر الضرر */
export type DamageSource = 'fall' | 'animal' | 'cut' | 'fire' | 'drown';

export type Rng = () => number;

/** مدة المرض الأساسية بالساعات */
const FOOD_POISON_HOURS = 8;
const INFECTION_DELAY_HOURS = 6;
const BROKEN_LEG_HEAL_HOURS = 48;

export class SurvivalSystem {
  stats: Stats = newStats();
  conditions = new Map<ConditionId, Condition>();
  difficulty: Difficulty = 'normal';
  dead = false;
  deathCause: string | null = null;

  /** ساعات منذ بدء النزيف/الجرح غير المعالج (لحساب العدوى) */
  private woundHours = 0;

  constructor(private rng: Rng = Math.random) {}

  has(id: ConditionId): boolean {
    return this.conditions.has(id);
  }

  addCondition(id: ConditionId, hours: number, severity = 0.5): void {
    const cur = this.conditions.get(id);
    if (cur) {
      cur.remaining = Math.max(cur.remaining, hours);
      cur.severity = Math.min(1, Math.max(cur.severity, severity));
    } else {
      this.conditions.set(id, { id, remaining: hours, severity });
    }
  }

  cure(id: ConditionId): boolean {
    if (id === 'bleeding') this.woundHours = 0;
    return this.conditions.delete(id);
  }

  /** مضاعِف سرعة الحركة بسبب الإصابات */
  get speedMultiplier(): number {
    let m = 1;
    if (this.has('brokenLeg')) m *= 0.45;
    if (this.stats.energy < 15) m *= 0.8;
    if (this.has('hypothermia')) m *= 0.85;
    return m;
  }

  get canRun(): boolean {
    return this.stats.stamina > 8 && !this.has('brokenLeg');
  }

  /** يطبّق تأثيرات عنصر مستهلك (من Inventory.use) */
  consume(effects: Record<string, number | string>): { gotSick: boolean } {
    const n = (k: string): number => (typeof effects[k] === 'number' ? (effects[k] as number) : 0);
    const s = this.stats;
    s.hunger = clamp(s.hunger + n('hunger'), 0, 100);
    s.thirst = clamp(s.thirst + n('thirst'), 0, 100);
    s.health = clamp(s.health + n('health'), 0, 100);
    s.energy = clamp(s.energy + n('energy'), 0, 100);

    if (n('stopBleeding')) this.cure('bleeding');
    if (n('cureInfection')) this.cure('infection');
    if (n('healBone')) {
      const leg = this.conditions.get('brokenLeg');
      if (leg) leg.remaining = Math.min(leg.remaining, 12); // الجبيرة تسرّع الشفاء
    }
    if (n('cureFoodPoison')) this.cure('foodPoisoning');
    if (n('cureSunburn')) this.cure('sunburn');
    if (n('painRelief')) this.cure('pain');
    if (n('preventInfection') && this.has('bleeding')) this.woundHours = Math.max(0, this.woundHours - 6);

    let gotSick = false;
    const sick = n('sick');
    if (sick > 0 && this.rng() < sick) {
      this.addCondition('foodPoisoning', FOOD_POISON_HOURS, Math.min(1, 0.3 + sick * 0.5));
      gotSick = true;
    }
    return { gotSick };
  }

  /** ضرر مباشر مع احتمال نزيف/كسر */
  damage(amount: number, source: DamageSource, defense = 0): void {
    const d = DIFFICULTY[this.difficulty];
    const final = Math.max(0, amount * d.damage * (1 - Math.min(0.7, defense * 0.05)));
    this.stats.health -= final;

    if (source === 'cut' || source === 'animal') {
      if (this.rng() < 0.35 + final * 0.01) this.addCondition('bleeding', Infinity, Math.min(1, final / 40));
    }
    if (source === 'fall' && final >= 15 && this.rng() < Math.min(0.9, final / 40)) {
      this.addCondition('brokenLeg', BROKEN_LEG_HEAL_HOURS, 0.8);
    }
    if (final >= 10) this.addCondition('pain', 2, 0.5);
    this.checkDeath(source);
  }

  /** ضرر السقوط من سرعة هبوط (م/ث) */
  fallDamage(speed: number): number {
    const safe = 9; // أقل من ~4م ارتفاع
    if (speed <= safe) return 0;
    const dmg = (speed - safe) * 9;
    this.damage(dmg, 'fall');
    return dmg;
  }

  /** @param dt ثواني حقيقية  @param gameHours ساعات اللعبة المقابلة */
  update(dt: number, gameHours: number, ctx: SurvivalContext): void {
    if (this.dead) return;
    const s = this.stats;
    const diff = DIFFICULTY[this.difficulty];

    this.updateStamina(dt, ctx);
    this.updateWetness(gameHours, ctx);
    this.updateTemperature(gameHours, ctx);

    // ---- جوع وعطش ----
    const actMul = { rest: 0.5, idle: 1, walk: 1.3, run: 2, work: 1.8, swim: 2.2 }[ctx.activity];
    const sleepMul = ctx.sleeping ? 0.35 : 1;
    const heatMul = ctx.ambientTemp > 32 ? 1.6 : 1;
    const sickMul = this.has('foodPoisoning') ? 2 : 1;

    s.hunger = clamp(s.hunger - 3.5 * gameHours * actMul * sleepMul * diff.drain, 0, 100);
    s.thirst = clamp(s.thirst - 5.5 * gameHours * actMul * sleepMul * heatMul * sickMul * diff.drain, 0, 100);

    // ---- تعب طويل ----
    if (ctx.sleeping) {
      s.energy = clamp(s.energy + (ctx.inShelter ? 14 : 8) * gameHours, 0, 100);
    } else {
      const drain = { rest: -2, idle: 1.2, walk: 2, run: 3.5, work: 3, swim: 4 }[ctx.activity];
      s.energy = clamp(s.energy - drain * gameHours * diff.drain, 0, 100);
    }

    // ---- العقل ----
    const night = ctx.hour < 5 || ctx.hour > 19.5;
    let sanityRate = 0.5;
    if (night && ctx.fireHeat === 0) sanityRate -= 3;
    if (s.hunger < 20 || s.thirst < 20) sanityRate -= 2;
    if (ctx.fireHeat > 0 || ctx.inShelter) sanityRate += 1.5;
    s.sanity = clamp(s.sanity + sanityRate * gameHours, 0, 100);

    this.updateConditions(gameHours, ctx);

    // ---- صحة: ضرر وتجدد ----
    let dps = 0; // نقطة صحة لكل ساعة لعبة
    if (s.hunger <= 0) dps += 3;
    if (s.thirst <= 0) dps += 6;
    for (const c of this.conditions.values()) dps += conditionDamage(c) ;
    dps *= diff.damage;

    if (dps > 0) {
      s.health -= dps * gameHours;
    } else if (this.conditions.size === 0 && s.hunger > 50 && s.thirst > 50 && s.bodyTemp > 35.5 && s.bodyTemp < 38.5) {
      s.health = clamp(s.health + (ctx.sleeping ? 4 : 1.5) * gameHours, 0, 100);
    }
    s.health = Math.min(100, s.health);

    let cause: string | null = null;
    if (s.thirst <= 0) cause = 'dehydration';
    else if (s.hunger <= 0) cause = 'starvation';
    else if (this.has('hypothermia')) cause = 'hypothermia';
    else if (this.has('heatstroke')) cause = 'heatstroke';
    else if (this.has('infection')) cause = 'infection';
    else if (this.has('bleeding')) cause = 'bleeding';
    this.checkDeath(cause ?? 'unknown');
  }

  private updateStamina(dt: number, ctx: SurvivalContext): void {
    const s = this.stats;
    if (ctx.activity === 'run') s.stamina -= 14 * dt * ctx.staminaDrainMult;
    else if (ctx.activity === 'swim') s.stamina -= 4 * dt * ctx.staminaDrainMult;
    else s.stamina += (ctx.activity === 'rest' || ctx.sleeping ? 25 : 14) * dt * (s.energy / 100 + 0.3);
    s.stamina = clamp(s.stamina, 0, 100);
    // الغرق: نفَس منتهٍ في الماء يؤذي
    if (ctx.inWater && s.stamina <= 0) this.damage(6 * dt, 'drown');
  }

  private updateWetness(h: number, ctx: SurvivalContext): void {
    const s = this.stats;
    let rate = -0.12; // جفاف طبيعي
    if (ctx.isRaining) rate += ctx.rainProof ? 0.08 : 0.5;
    if (ctx.inWater) rate += 3;
    if (ctx.fireHeat > 0) rate -= 0.5 * ctx.fireHeat;
    if (ctx.inShelter && !ctx.isRaining) rate -= 0.1;
    s.wetness = clamp(s.wetness + rate * h, 0, 1);
  }

  private updateTemperature(h: number, ctx: SurvivalContext): void {
    const s = this.stats;
    // درجة الحرارة "المحسوسة"
    let eff = ctx.ambientTemp;
    eff += ctx.warmth * 0.9;
    eff += ctx.fireHeat * 16;
    if (ctx.inShelter) eff += 4;
    eff -= s.wetness * (ctx.rainProof ? 4 : 10);
    if (ctx.inWater) eff -= 6;
    if (ctx.activity === 'run' || ctx.activity === 'work') eff += 3; // الحركة تولّد حرارة
    // الشمس المباشرة نهارًا
    const sunny = ctx.hour > 9 && ctx.hour < 16 && !ctx.inShelter && !ctx.isRaining;
    if (sunny) eff += 4 * (1 - ctx.sunProtection * 0.6);

    // الجسم يميل نحو توازن حراري يتناسب مع المحسوس (الراحة عند ~24م)
    const targetBody = clamp(37 + (eff - 24) * 0.12, 30, 42);
    const speed = 0.35; // °م/ساعة لكل °م فرق (تقريبًا)
    s.bodyTemp += (targetBody - s.bodyTemp) * Math.min(1, speed * h * 2);
    s.bodyTemp = clamp(s.bodyTemp, 28, 43);
  }

  private updateConditions(h: number, ctx: SurvivalContext): void {
    const s = this.stats;

    // حالات تُشتق من المؤشرات
    this.setDerived('hypothermia', s.bodyTemp < 35, clamp((35 - s.bodyTemp) / 5, 0.2, 1));
    this.setDerived('heatstroke', s.bodyTemp > 39, clamp((s.bodyTemp - 39) / 3, 0.2, 1));
    this.setDerived('dehydration', s.thirst < 10, clamp((10 - s.thirst) / 10, 0.2, 1));

    // حروق شمس: تعرّض طويل بدون حماية
    if (ctx.hour > 10 && ctx.hour < 15 && !ctx.inShelter && !ctx.isRaining && ctx.sunProtection < 0.5 && ctx.ambientTemp > 30) {
      if (this.rng() < 0.02 * h * 10) this.addCondition('sunburn', 12, 0.3);
    }

    // الجرح المفتوح يتحول لعدوى بعد ساعات
    if (this.has('bleeding')) {
      this.woundHours += h;
      if (this.woundHours > INFECTION_DELAY_HOURS && !this.has('infection')) this.addCondition('infection', Infinity, 0.5);
    }

    // الإصابات الزمنية تنقضي
    for (const [id, c] of this.conditions) {
      if (!Number.isFinite(c.remaining)) continue;
      if (id === 'hypothermia' || id === 'heatstroke' || id === 'dehydration') continue; // مشتقة
      c.remaining -= h;
      if (c.remaining <= 0) this.conditions.delete(id);
    }
  }

  private setDerived(id: ConditionId, active: boolean, severity: number): void {
    if (active) this.addCondition(id, Infinity, severity);
    else this.conditions.delete(id);
  }

  private checkDeath(cause: string): void {
    if (this.stats.health <= 0 && !this.dead) {
      this.stats.health = 0;
      this.dead = true;
      this.deathCause = cause;
    }
  }

  get permadeath(): boolean {
    return DIFFICULTY[this.difficulty].permadeath;
  }

  load(d: { stats: Stats; conditions: Condition[]; difficulty: Difficulty; woundHours?: number }): void {
    this.stats = { ...newStats(), ...d.stats };
    this.conditions.clear();
    // JSON لا يحمل Infinity: null تعني "حتى العلاج"
    for (const c of d.conditions) this.conditions.set(c.id, { ...c, remaining: c.remaining === null || c.remaining === undefined ? Infinity : c.remaining });
    this.difficulty = d.difficulty;
    this.woundHours = d.woundHours ?? 0;
    this.dead = this.stats.health <= 0;
  }

  toJSON(): { stats: Stats; conditions: Condition[]; difficulty: Difficulty; woundHours: number; dead: boolean; deathCause: string | null } {
    return { stats: { ...this.stats }, conditions: [...this.conditions.values()].map((c) => ({ ...c })), difficulty: this.difficulty, woundHours: this.woundHours, dead: this.dead, deathCause: this.deathCause };
  }
}

/** ضرر الحالة بالنقاط لكل ساعة لعبة */
function conditionDamage(c: Condition): number {
  switch (c.id) {
    case 'bleeding': return 3 * (0.5 + c.severity);
    case 'infection': return 2 * (0.5 + c.severity);
    case 'foodPoisoning': return 1.5 * c.severity * 2;
    case 'heatstroke': return 4 * c.severity;
    case 'hypothermia': return 3 * c.severity;
    case 'dehydration': return 1 * c.severity;
    case 'sunburn': return 0.4;
    default: return 0;
  }
}

function clamp(v: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, v));
}
