import { clamp } from '../core/math';

/**
 * درجة حرارة الهواء (°م): دورة يومية (أبرد قرب الفجر، أحر عند ~14)،
 * تأثير الطقس، وانخفاض بالارتفاع (~0.65°م لكل 100م).
 */
export function ambientTemperature(hour: number, weatherDelta: number, altitude: number): number {
  const daily = Math.sin(((hour - 8) / 24) * Math.PI * 2); // أعلى قيمة عند 14
  const base = 26 + daily * 6; // 20..32
  return base + weatherDelta - Math.max(0, altitude) * 0.0065 * 3; // نضاعف التأثير لأن الجزيرة صغيرة
}

/** أيام/ساعات من عدّاد الساعات الكلي */
export const HOURS_PER_REAL_SECOND = 24 / 1200; // يوم كامل = 20 دقيقة
export const dayOf = (totalHours: number): number => Math.floor(totalHours / 24);
export const hourOf = (totalHours: number): number => ((totalHours % 24) + 24) % 24;

/** يختار نشاط الجسم لحساب الاستهلاك */
export function activityFrom(loco: 'idle' | 'walk' | 'run' | 'crouch' | 'jump' | 'swim', working: boolean, sleeping: boolean): 'rest' | 'idle' | 'walk' | 'run' | 'work' | 'swim' {
  if (sleeping) return 'rest';
  if (working) return 'work';
  switch (loco) {
    case 'run': return 'run';
    case 'walk': return 'walk';
    case 'swim': return 'swim';
    case 'crouch': return 'idle';
    case 'jump': return 'walk';
    default: return 'idle';
  }
}

export const clampTemp = (t: number): number => clamp(t, -10, 50);
