/** شجرة المهارات: ترتفع بالممارسة */
export type SkillName = 'survival' | 'hunting' | 'crafting' | 'building';
export const SKILL_NAMES: readonly SkillName[] = ['survival', 'hunting', 'crafting', 'building'];
export const MAX_SKILL_LEVEL = 10;

export class Skills {
  readonly xp: Record<SkillName, number> = { survival: 0, hunting: 0, crafting: 0, building: 0 };
  onLevelUp: ((skill: SkillName, level: number) => void) | null = null;

  /** المستوى = floor(sqrt(xp/10)): 10xp⇒1، 40⇒2، 90⇒3 ... */
  level(name: SkillName): number {
    return Math.min(MAX_SKILL_LEVEL, Math.floor(Math.sqrt(this.xp[name] / 10)));
  }

  addXp(name: SkillName, amount: number): void {
    const before = this.level(name);
    this.xp[name] += amount;
    const after = this.level(name);
    if (after > before) this.onLevelUp?.(name, after);
  }

  /** تقدّم المستوى الحالي 0..1 (لشريط التقدم) */
  progress(name: SkillName): number {
    const lv = this.level(name);
    if (lv >= MAX_SKILL_LEVEL) return 1;
    const a = lv * lv * 10;
    const b = (lv + 1) * (lv + 1) * 10;
    return (this.xp[name] - a) / (b - a);
  }

  /** مكافأة تتحسن مع المستوى (مثلًا نسبة جمع إضافية) */
  bonus(name: SkillName, perLevel = 0.05): number {
    return this.level(name) * perLevel;
  }

  toJSON(): Record<SkillName, number> {
    return { ...this.xp };
  }

  load(data: Partial<Record<SkillName, number>>): void {
    for (const k of SKILL_NAMES) this.xp[k] = data[k] ?? 0;
  }
}
