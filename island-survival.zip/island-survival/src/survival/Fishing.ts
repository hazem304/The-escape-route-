import type { Random } from '../core/Random';

export type FishingState = 'idle' | 'waiting' | 'bite' | 'caught' | 'escaped';

export interface FishCatch {
  id: string;
  count: number;
}

export interface CastInfo {
  /** عمق الماء عند نقطة الرمي (متر) */
  depth: number;
  /** معرّف الطُّعم أو null */
  bait: string | null;
  /** مستوى مهارة الصيد 0..10 */
  skill: number;
  /** ساعة اليوم (الفجر والغروب أفضل) */
  hour: number;
  /** صنارة (1) أو شبكة (2) */
  rodPower: number;
}

const BAITS = new Set(['berries', 'raw_fish', 'raw_crab', 'seaweed', 'plant_fiber', 'mushroom']);
export const BITE_WINDOW = 1.6; // ثوانٍ للتفاعل بعد اللدغة

/** يحسب جدول الأنواع بحسب العمق: ضحل = صغير/سلطعون، عميق = أكبر وأندر */
export function catchTable(depth: number): Array<{ id: string; count: number; weight: number }> {
  if (depth < 0.6) return [];
  if (depth < 3) return [{ id: 'raw_fish', count: 1, weight: 6 }, { id: 'raw_crab', count: 1, weight: 3 }, { id: 'seaweed', count: 1, weight: 2 }, { id: 'shell', count: 1, weight: 1 }];
  if (depth < 8) return [{ id: 'raw_fish', count: 1, weight: 7 }, { id: 'raw_fish', count: 2, weight: 3 }, { id: 'raw_crab', count: 1, weight: 1 }, { id: 'scrap_metal', count: 1, weight: 0.2 }];
  return [{ id: 'raw_fish', count: 2, weight: 5 }, { id: 'raw_fish', count: 3, weight: 2 }, { id: 'glass_shard', count: 1, weight: 0.3 }];
}

/** آلة حالات الصيد: رمي ← انتظار ← لدغة ← سحب في نافذة قصيرة */
export class Fishing {
  state: FishingState = 'idle';
  private timer = 0;
  private cast: CastInfo | null = null;
  lastCatch: FishCatch | null = null;
  /** ما يستهلكه الصيد من الطُّعم عند اللدغة */
  consumedBait: string | null = null;

  constructor(private rnd: Random) {}

  static isBait(id: string): boolean {
    return BAITS.has(id);
  }

  start(info: CastInfo): boolean {
    if (this.state !== 'idle' && this.state !== 'caught' && this.state !== 'escaped') return false;
    if (info.depth < 0.6) return false; // لا سمك في المياه الضحلة جدًا
    this.cast = info;
    this.state = 'waiting';
    this.lastCatch = null;
    this.consumedBait = null;
    this.timer = this.waitTime(info);
    return true;
  }

  /** زمن الانتظار قبل اللدغة: أقصر مع المهارة والطُّعم والفجر/الغروب */
  private waitTime(i: CastInfo): number {
    let t = 8 + this.rnd.next() * 10;
    t *= 1 - i.skill * 0.04;
    if (i.bait) t *= 0.6;
    const dawnDusk = Math.min(Math.abs(i.hour - 6), Math.abs(i.hour - 18)) < 1.5;
    if (dawnDusk) t *= 0.7;
    return t / Math.max(1, i.rodPower);
  }

  update(dt: number): void {
    if (this.state === 'waiting') {
      this.timer -= dt;
      if (this.timer <= 0) {
        this.state = 'bite';
        this.timer = BITE_WINDOW;
        this.consumedBait = this.cast!.bait;
      }
    } else if (this.state === 'bite') {
      this.timer -= dt;
      if (this.timer <= 0) this.state = 'escaped'; // تأخرت
    }
  }

  /** يسحب الصنارة: ينجح فقط أثناء اللدغة */
  reel(): FishCatch | null {
    if (this.state === 'waiting') {
      this.state = 'idle'; // سحب مبكر يفسد الرمية
      return null;
    }
    if (this.state !== 'bite' || !this.cast) return null;
    const table = catchTable(this.cast.depth);
    if (!table.length) {
      this.state = 'escaped';
      return null;
    }
    const total = table.reduce((s, e) => s + e.weight, 0);
    let r = this.rnd.next() * total;
    let pick = table[0];
    for (const e of table) {
      r -= e.weight;
      if (r <= 0) {
        pick = e;
        break;
      }
    }
    // الشبكة تضاعف المحصول
    const count = pick.count * (this.cast.rodPower >= 2 ? 2 : 1);
    this.lastCatch = { id: pick.id, count };
    this.state = 'caught';
    return this.lastCatch;
  }

  cancel(): void {
    this.state = 'idle';
    this.cast = null;
  }
}
