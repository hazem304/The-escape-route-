/** نار المخيم: وقود، إشعال، إطفاء بالمطر، حرارة بالمسافة */
export type FuelItem = 'firewood' | 'wood_log' | 'stick' | 'charcoal' | 'bark' | 'thatch';

/** دقائق احتراق لكل وحدة وقود */
export const FUEL_MINUTES: Record<FuelItem, number> = {
  wood_log: 90,
  firewood: 60,
  charcoal: 75,
  stick: 12,
  bark: 8,
  thatch: 6,
};

const MAX_FUEL_MINUTES = 240;

export class Fire {
  /** دقائق الوقود المتبقية (زمن اللعبة) */
  fuel = 0;
  burning = false;
  /** 0..1 */
  strength = 0;
  /** رطوبة الوقود: ترتفع تحت المطر وتصعّب الإشعال */
  dampness = 0;
  /** الحد الأقصى لتأثير الدفء بالمتر */
  readonly warmRadius = 5;

  constructor(public readonly x = 0, public readonly y = 0, public readonly z = 0, public covered = false) {}

  addFuel(item: FuelItem, count = 1): void {
    this.fuel = Math.min(MAX_FUEL_MINUTES, this.fuel + FUEL_MINUTES[item] * count);
  }

  static isFuel(id: string): id is FuelItem {
    return id in FUEL_MINUTES;
  }

  /**
   * محاولة الإشعال.
   * @param method احتمال نجاح الأداة (مثلًا ولّاعة 0.98، مثقاب 0.35)
   * @param rnd رقم عشوائي [0,1)
   * @param rainIntensity 0..1 (المطر يقلل النجاح إن كانت النار مكشوفة)
   */
  ignite(method: number, rnd: number, rainIntensity = 0): boolean {
    if (this.fuel <= 0) return false;
    const rainPenalty = this.covered ? 0.1 : 0.85;
    const p = method * (1 - rainIntensity * rainPenalty) * (1 - this.dampness * 0.6);
    if (rnd < p) {
      this.burning = true;
      this.strength = Math.max(this.strength, 0.35);
      return true;
    }
    return false;
  }

  /** @param dtMinutes دقائق زمن اللعبة */
  update(dtMinutes: number, rainIntensity: number, windSpeed = 0): void {
    const exposed = this.covered ? 0.1 : 1;
    this.dampness = clamp01(this.dampness + (rainIntensity * exposed * 0.02 - 0.004) * dtMinutes);

    if (!this.burning) return;

    this.fuel = Math.max(0, this.fuel - dtMinutes * (1 + windSpeed * 0.02));

    // المطر يُضعف النار؛ العاصفة المكشوفة تُطفئها خلال دقائق
    const rainDamage = rainIntensity * exposed * 0.15 * dtMinutes;
    // الوقود القليل يعني لهبًا ضعيفًا
    const targetStrength = Math.min(1, this.fuel / 60) * (1 - this.dampness * 0.4);
    this.strength += (targetStrength - this.strength) * Math.min(1, dtMinutes * 0.1);
    this.strength -= rainDamage;

    if (this.fuel <= 0 || this.strength <= 0.04) {
      this.burning = false;
      this.strength = 0;
    }
  }

  /** الدفء الذي يشعر به من يبعد d متر (0..1) */
  heatAt(d: number): number {
    if (!this.burning) return 0;
    if (d >= this.warmRadius) return 0;
    return this.strength * (1 - d / this.warmRadius);
  }

  /** نصف قطر ضوء النار */
  get lightRadius(): number {
    return this.burning ? 6 + this.strength * 12 : 0;
  }

  toJSON(): { x: number; y: number; z: number; covered: boolean; fuel: number; burning: boolean; strength: number; dampness: number } {
    return { x: this.x, y: this.y, z: this.z, covered: this.covered, fuel: this.fuel, burning: this.burning, strength: this.strength, dampness: this.dampness };
  }

  static fromJSON(d: ReturnType<Fire['toJSON']>): Fire {
    const f = new Fire(d.x, d.y, d.z, d.covered);
    f.fuel = d.fuel;
    f.burning = d.burning;
    f.strength = d.strength;
    f.dampness = d.dampness;
    return f;
  }

  extinguish(): void {
    this.burning = false;
    this.strength = 0;
  }
}

function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}
