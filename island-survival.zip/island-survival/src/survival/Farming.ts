import type { Random } from '../core/Random';

export const SLOTS_PER_PLOT = 4;
/** مدة نمو المحصول بساعات اللعبة (3 أيام) */
export const GROW_HOURS = 72;
/** يجف الماء بعد هذه الساعات */
export const WATER_HOURS = 30;
export const WATER_ITEMS = ['rainwater', 'water_boiled', 'water_dirty'] as const;

export interface Crop {
  /** ساعات نمو متراكمة (لا تتقدم بلا ماء) */
  growth: number;
  /** 0..1 */
  water: number;
}

export type Stage = 0 | 1 | 2 | 3;

export interface FarmDrop {
  id: string;
  count: number;
}

/** قطعة أرض زراعية بأربع خانات: بذرة ← سقي ← نمو (3 مراحل) ← حصاد */
export class FarmPlot {
  slots: Array<Crop | null> = Array.from({ length: SLOTS_PER_PLOT }, () => null);

  freeSlot(): number {
    return this.slots.findIndex((s) => s === null);
  }

  plant(slot = this.freeSlot()): boolean {
    if (slot < 0 || slot >= SLOTS_PER_PLOT || this.slots[slot]) return false;
    this.slots[slot] = { growth: 0, water: 0 };
    return true;
  }

  /** يسقي كل المحاصيل. @returns كم نبتة سُقيت */
  water(): number {
    let n = 0;
    for (const c of this.slots) if (c && c.water < 1) { c.water = 1; n++; }
    return n;
  }

  stage(slot: number): Stage | null {
    const c = this.slots[slot];
    if (!c) return null;
    const f = c.growth / GROW_HOURS;
    return f >= 1 ? 3 : f >= 0.66 ? 2 : f >= 0.25 ? 1 : 0;
  }

  get ripeCount(): number {
    return this.slots.filter((_, i) => this.stage(i) === 3).length;
  }

  get plantedCount(): number {
    return this.slots.filter(Boolean).length;
  }

  get thirsty(): boolean {
    return this.slots.some((c) => c && c.water <= 0 && c.growth < GROW_HOURS);
  }

  /** أقل ساعات متبقية لنضج نبتة غير ناضجة، أو null */
  hoursToRipe(): number | null {
    let best: number | null = null;
    for (const c of this.slots) if (c && c.growth < GROW_HOURS) best = Math.min(best ?? Infinity, GROW_HOURS - c.growth);
    return best;
  }

  /** @param dh ساعات اللعبة @param rain شدة المطر 0..1: المطر الغزير يسقي */
  update(dh: number, rain: number): void {
    for (const c of this.slots) {
      if (!c) continue;
      if (rain > 0.3) c.water = 1;
      if (c.water > 0) {
        c.growth = Math.min(GROW_HOURS, c.growth + dh);
        c.water = Math.max(0, c.water - dh / WATER_HOURS);
      }
    }
  }

  /** يحصد كل الناضج: يامس 2–3 وبذور 1–2 لكل نبتة */
  harvest(rnd: Random): FarmDrop[] {
    const out = new Map<string, number>();
    for (let i = 0; i < SLOTS_PER_PLOT; i++) {
      if (this.stage(i) !== 3) continue;
      this.slots[i] = null;
      out.set('yam', (out.get('yam') ?? 0) + 2 + Math.floor(rnd.next() * 2));
      out.set('seeds', (out.get('seeds') ?? 0) + 1 + Math.floor(rnd.next() * 2));
    }
    return [...out].map(([id, count]) => ({ id, count }));
  }

  toJSON(): Array<Crop | null> {
    return this.slots.map((c) => (c ? { ...c } : null));
  }

  static fromJSON(d: Array<Crop | null>): FarmPlot {
    const p = new FarmPlot();
    d.slice(0, SLOTS_PER_PLOT).forEach((c, i) => {
      p.slots[i] = c ? { growth: Math.max(0, Math.min(GROW_HOURS, Number(c.growth) || 0)), water: Math.max(0, Math.min(1, Number(c.water) || 0)) } : null;
    });
    return p;
  }
}
