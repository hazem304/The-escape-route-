/** المؤشرات الحيوية للاعب (كلها 0..100 عدا الحرارة) */
export interface Stats {
  health: number;
  hunger: number; // 100 = شبعان
  thirst: number; // 100 = مرتوٍ
  energy: number; // تعب طويل المدى (النوم)
  stamina: number; // نفَس قصير المدى (الجري)
  sanity: number;
  bodyTemp: number; // °م
  wetness: number; // 0..1
}

export function newStats(): Stats {
  return { health: 100, hunger: 85, thirst: 85, energy: 100, stamina: 100, sanity: 100, bodyTemp: 37, wetness: 0 };
}

export type ConditionId =
  | 'foodPoisoning' | 'dehydration' | 'heatstroke' | 'hypothermia'
  | 'infection' | 'bleeding' | 'brokenLeg' | 'sunburn' | 'pain';

/** حالة مرضية/إصابة نشطة */
export interface Condition {
  id: ConditionId;
  /** الساعات المتبقية؛ Infinity = حتى العلاج */
  remaining: number;
  /** 0..1 */
  severity: number;
}

export type Difficulty = 'easy' | 'normal' | 'hard' | 'realistic';

export const DIFFICULTY: Record<Difficulty, { drain: number; damage: number; permadeath: boolean }> = {
  easy: { drain: 0.6, damage: 0.6, permadeath: false },
  normal: { drain: 1, damage: 1, permadeath: false },
  hard: { drain: 1.35, damage: 1.4, permadeath: false },
  realistic: { drain: 1.6, damage: 1.8, permadeath: true },
};
