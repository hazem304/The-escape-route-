/** منطق النوم: متى يمكن النوم وسرعة مرور الوقت أثناءه */
export interface SleepContext {
  energy: number;
  hostileNearby: boolean;
  inShelterOrBed: boolean;
  bodyTemp: number;
  hunger: number;
  thirst: number;
}

export type SleepRefusal = 'notTired' | 'danger' | 'tooCold' | 'tooHungry';

export const SLEEP_TIME_SCALE = 12; // كل ثانية حقيقية = 12 ثانية لعبة تقريبًا

export function canSleep(c: SleepContext): { ok: true } | { ok: false; reason: SleepRefusal } {
  if (c.hostileNearby) return { ok: false, reason: 'danger' };
  if (c.energy > 85) return { ok: false, reason: 'notTired' };
  if (c.bodyTemp < 34.5) return { ok: false, reason: 'tooCold' };
  if (c.hunger < 5 || c.thirst < 5) return { ok: false, reason: 'tooHungry' };
  return { ok: true };
}

/** هل يستيقظ اللاعب تلقائيًا؟ */
export function shouldWake(c: SleepContext & { damaged: boolean }): boolean {
  return c.damaged || c.hostileNearby || c.energy >= 100 || c.hunger < 5 || c.thirst < 5 || c.bodyTemp < 34;
}
