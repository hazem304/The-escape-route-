# بدائل لموصل Higgsfield (غير متاح في هذه الجلسة)

الكود يستبدل المجسمات الإجرائية تلقائيًا بأي ملف GLB موجود في `public/assets/models/<id>.glb` لمعرّفات
`animal_<species>` و`npc_<id>` و`piece_<type>` (انظر `art_pipeline/README_pipeline.md`). أي مصدر أدناه يصلح، المهم أن ينتهي الملف باسم المعرّف
وتحدَّث حالته في `asset_manifest.json` إلى `integrated` ثم `npm run assets:check`.

## 1) مكتبات جاهزة (بلا توليد)
- **Kenney** (CC0، حزم GLB واسعة وأسلوب موحّد) — الأنسب لأشجار وصخور وأدوات وقطع بناء. 
- **Quaternius** (أسلوب low-poly؛ تأكد من الترخيص في صفحة كل حزمة قبل الاستعمال).
- **Poly Haven** (CC0، نماذج وخامات PBR وHDRI؛ الصيغة glTF لا GLB، حوّلها بـ`gltf-pack`/Blender) — مناسبة لخامات 2K والسماء.
  الجدول المنشور أن الجدول لا يؤكد وجود كل الفئات (حيوانات/ناجون)؛ تحقق من الكتالوج مباشرة.

## 2) توليد بالذكاء الاصطناعي (نص/صورة ← 3D)
- **Meshy / Tripo**: رصيد مجاني شهري، تجاري على الرصيد المجاني بحسب مواقعها (تحقق من الشروط الحالية).
- **3D AI Studio**: يذكر تصدير GLB وواجهة API.
- **Hunyuan3D / Trellis 2** (مفتوحة المصدر): مجانية بلا حد إن شغّلتها محليًا على GPU مناسب.
  المراجع: https://www.3daistudio.com/blog/best-free-ai-3d-model-generators-2026 ·
  https://app.cinevva.com/guides/sketchfab-polyhaven-kenney (مقالات تسويقية؛ قارن بنفسك).
استعمل البرومبتات الجاهزة في `higgsfield_prompts.md` كنصوص مدخلة (احذف سطر التنسيق الخاص بـHiggsfield إن لزم).

## 3) بعد الحصول على الملف
1. قلّص المضلعات حسب ميزانية `asset_manifest.json`، وصدّر GLB بخامات مضغوطة.
2. ضعه في `public/assets/models/<id>.glb`.
3. غيّر حالته إلى `integrated` وشغّل `npm run assets:check`.
