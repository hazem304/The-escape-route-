# برومبتات Higgsfield

> **مولَّد آليًا** بواسطة `tools/gen_art_pipeline.py` — لا تعدّله يدويًا؛ غيّر السكربت ثم أعد التوليد.

الصيغة الثابتة لكل برومبت مجسم:

```
[الموضوع] , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

استثناء مقصود: في أوراق الشخصيات (Character Sheets) يُستبدل `3/4 view` بـ `front view` أو `side view` أو `back view` فقط، وباقي الصيغة كما هي.

Higgsfield يولّد صورًا وفيديو فقط، لا مجسمات 3D. الناتج صور مرجعية تُحوَّل لاحقًا إلى 3D (انظر `README_pipeline.md`).

## الشخصيات

### #1 `player_hero` — بطل اللعبة / Hero castaway
- الملف المتوقع: `public/assets/models/characters/player_hero.glb` · الميزانية: 25,000–40,000 مضلع · مهيّأ للتحريك
- الربط: يحتاج ربطًا في الكود بعد توليده
```
full-body adult male castaway survivor in his thirties, athletic lean build, sunburnt weathered face with short stubble, tattered blue airline-uniform shirt with rolled sleeves, dirty khaki cargo pants, worn leather boots, relaxed A-pose with arms slightly away from the body , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #2 `npc_layla` — ليلى / Layla
- الملف المتوقع: `public/assets/models/characters/npc_layla.glb` · الميزانية: 25,000–40,000 مضلع · مهيّأ للتحريك
- الربط: تلقائي عبر المحمّل
```
full-body woman doctor in her forties, calm precise expression, dark hair tied back, dirty light-blue blouse under a salvaged paramedic vest, canvas trousers, worn sandals, small first-aid pouch on her belt, relaxed A-pose , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #3 `npc_omar` — عمر / Omar
- الملف المتوقع: `public/assets/models/characters/npc_omar.glb` · الميزانية: 25,000–40,000 مضلع · مهيّأ للتحريك
- الربط: تلقائي عبر المحمّل
```
full-body young telecom engineer in his late twenties, eager restless expression, messy black hair, sunburnt nose, grease-stained gray t-shirt, rolled cargo shorts, tool belt with pliers and screwdrivers, mismatched sneakers, relaxed A-pose , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #4 `npc_yusuf` — يوسف / Yusuf
- الملف المتوقع: `public/assets/models/characters/npc_yusuf.glb` · الميزانية: 25,000–40,000 مضلع · مهيّأ للتحريك
- الربط: تلقائي عبر المحمّل
```
full-body seventy-year-old fisherman, deeply tanned lined face, short white beard, woven straw hat, faded patched linen shirt, rope belt, rolled canvas trousers, barefoot, slight stoop but strong forearms, relaxed A-pose , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

## الحيوانات

### #5 `animal_deer` — غزال / Deer
- الملف المتوقع: `public/assets/models/animals/animal_deer.glb` · الميزانية: 8,000–15,000 مضلع · مهيّأ للتحريك
- الربط: تلقائي عبر المحمّل
```
tropical island deer, slender legs, light brown coat with faint spots, small antlers, alert standing pose , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #6 `animal_boar` — خنزير بري / Wild boar
- الملف المتوقع: `public/assets/models/animals/animal_boar.glb` · الميزانية: 8,000–15,000 مضلع · مهيّأ للتحريك
- الربط: تلقائي عبر المحمّل
```
wild boar, bristly dark gray-brown coat, short curved tusks, heavy shoulders, standing pose , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #7 `animal_crab` — سلطعون / Crab
- الملف المتوقع: `public/assets/models/animals/animal_crab.glb` · الميزانية: 8,000–15,000 مضلع · مهيّأ للتحريك
- الربط: تلقائي عبر المحمّل
```
large orange-red beach crab, two raised claws, segmented legs, textured shell , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #8 `animal_seagull` — نورس / Seagull
- الملف المتوقع: `public/assets/models/animals/animal_seagull.glb` · الميزانية: 8,000–15,000 مضلع · مهيّأ للتحريك
- الربط: تلقائي عبر المحمّل
```
seagull with wings folded, white and gray plumage, yellow beak with red spot, standing on one leg , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #9 `animal_shark` — قرش / Shark
- الملف المتوقع: `public/assets/models/animals/animal_shark.glb` · الميزانية: 8,000–15,000 مضلع · مهيّأ للتحريك
- الربط: تلقائي عبر المحمّل
```
reef shark, sleek gray body, pale underbelly, visible gills, dorsal fin, swimming pose seen from the side , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #10 `animal_snake` — أفعى / Snake
- الملف المتوقع: `public/assets/models/animals/animal_snake.glb` · الميزانية: 8,000–15,000 مضلع · مهيّأ للتحريك
- الربط: تلقائي عبر المحمّل
```
venomous jungle viper coiled in a striking posture, olive green with dark diamond pattern , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #11 `animal_jaguar` — نمر / Jaguar
- الملف المتوقع: `public/assets/models/animals/animal_jaguar.glb` · الميزانية: 8,000–15,000 مضلع · مهيّأ للتحريك
- الربط: تلقائي عبر المحمّل
```
jaguar, muscular body, golden coat with black rosettes, low stalking pose , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

## الأشجار والصخور والنباتات

### #12 `tree_palm_a` — نخلة طويلة / Tall coconut palm
- الملف المتوقع: `public/assets/models/nature/tree_palm_a.glb` · الميزانية: 3,000–8,000 مضلع · مع LOD
- الربط: يحتاج ربطًا في الكود بعد توليده
```
tall coconut palm tree with a slightly curved trunk, full crown of long fronds and a cluster of coconuts , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #13 `tree_palm_b` — نخلة مائلة / Leaning palm
- الملف المتوقع: `public/assets/models/nature/tree_palm_b.glb` · الميزانية: 3,000–8,000 مضلع · مع LOD
- الربط: يحتاج ربطًا في الكود بعد توليده
```
leaning beach palm tree with a thick ringed trunk and drooping fronds , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #14 `tree_jungle_a` — شجرة غابة / Jungle tree
- الملف المتوقع: `public/assets/models/nature/tree_jungle_a.glb` · الميزانية: 3,000–8,000 مضلع · مع LOD
- الربط: يحتاج ربطًا في الكود بعد توليده
```
tall tropical jungle tree with buttress roots, dense dark-green canopy and hanging vines , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #15 `tree_jungle_b` — تين خانق / Strangler fig
- الملف المتوقع: `public/assets/models/nature/tree_jungle_b.glb` · الميزانية: 3,000–8,000 مضلع · مع LOD
- الربط: يحتاج ربطًا في الكود بعد توليده
```
strangler fig tree with tangled aerial roots wrapping a hollow trunk , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #16 `tree_stump` — جذع شجرة / Tree stump
- الملف المتوقع: `public/assets/models/nature/tree_stump.glb` · الميزانية: 1,000–3,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
weathered tree stump with exposed roots and moss , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #17 `fallen_log` — جذع ساقط / Fallen log
- الملف المتوقع: `public/assets/models/nature/fallen_log.glb` · الميزانية: 1,500–4,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
large fallen jungle log with bark peeling and small mushrooms , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #18 `bamboo` — خيزران / Bamboo cluster
- الملف المتوقع: `public/assets/models/nature/bamboo.glb` · الميزانية: 3,000–8,000 مضلع · مع LOD
- الربط: يحتاج ربطًا في الكود بعد توليده
```
dense cluster of green bamboo stalks with leaves , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #19 `rock_boulder` — صخرة كبيرة / Boulder
- الملف المتوقع: `public/assets/models/nature/rock_boulder.glb` · الميزانية: 2,000–6,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
large rounded gray boulder with lichen and cracks , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #20 `rock_flat` — صخرة مسطحة / Flat rock
- الملف المتوقع: `public/assets/models/nature/rock_flat.glb` · الميزانية: 2,000–6,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
flat shoreline rock slab with barnacles and wet streaks , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #21 `rock_spire` — برج بركاني / Volcanic spire
- الملف المتوقع: `public/assets/models/nature/rock_spire.glb` · الميزانية: 2,000–6,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
dark volcanic rock spire, porous basalt, sharp edges , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #22 `rock_iron` — صخرة حديد / Iron ore rock
- الملف المتوقع: `public/assets/models/nature/rock_iron.glb` · الميزانية: 2,000–6,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
gray rock with rust-orange iron ore veins visible , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #23 `rock_copper` — صخرة نحاس / Copper ore rock
- الملف المتوقع: `public/assets/models/nature/rock_copper.glb` · الميزانية: 2,000–6,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
dark rock with bright green-blue copper ore veins , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #24 `bush_berry` — شجيرة توت / Berry bush
- الملف المتوقع: `public/assets/models/nature/bush_berry.glb` · الميزانية: 1,000–4,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
small tropical bush with clusters of red berries and green leaves , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #25 `plant_fiber` — نبات ألياف / Fiber plant
- الملف المتوقع: `public/assets/models/nature/plant_fiber.glb` · الميزانية: 1,000–4,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
tall fibrous agave-like plant with long strap leaves , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #26 `mushroom_patch` — فطر / Mushroom patch
- الملف المتوقع: `public/assets/models/nature/mushroom_patch.glb` · الميزانية: 1,000–4,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
cluster of tan edible mushrooms on a mossy patch of soil , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #27 `clay_bank` — ضفة طين / Clay bank
- الملف المتوقع: `public/assets/models/nature/clay_bank.glb` · الميزانية: 1,000–4,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
small bank of wet reddish-brown clay with finger marks , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #28 `fern` — سرخس / Fern
- الملف المتوقع: `public/assets/models/nature/fern.glb` · الميزانية: 1,000–4,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
large tropical fern with arching fronds , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

## الحقائب والأدوات والأسلحة

### #29 `item_backpack_cloth` — حقيبة قماش / Cloth backpack
- الملف المتوقع: `public/assets/models/items/item_backpack_cloth.glb` · الميزانية: 2,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
small worn canvas backpack, frayed straps, patched, level 1 , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #30 `item_backpack_leather` — حقيبة جلد / Leather backpack
- الملف المتوقع: `public/assets/models/items/item_backpack_leather.glb` · الميزانية: 2,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
medium brown leather backpack with metal buckles and side pockets, level 2 , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #31 `item_backpack_military` — حقيبة عسكرية / Military backpack
- الملف المتوقع: `public/assets/models/items/item_backpack_military.glb` · الميزانية: 2,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
large olive-drab military rucksack with many pouches and a rolled sleeping mat, level 3 , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #32 `item_axe_stone` — فأس حجري / Stone axe
- الملف المتوقع: `public/assets/models/items/item_axe_stone.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
primitive stone axe, knapped gray flint head lashed to a wooden handle with cord , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #33 `item_axe_iron` — فأس حديدي / Iron axe
- الملف المتوقع: `public/assets/models/items/item_axe_iron.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
forged iron felling axe with a dark steel head and hickory handle , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #34 `item_pickaxe_stone` — معول حجري / Stone pickaxe
- الملف المتوقع: `public/assets/models/items/item_pickaxe_stone.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
primitive pickaxe with a stone head bound to a wooden shaft , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #35 `item_pickaxe_iron` — معول حديدي / Iron pickaxe
- الملف المتوقع: `public/assets/models/items/item_pickaxe_iron.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
iron pickaxe with a worn steel head and wooden shaft , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #36 `item_knife_stone` — سكين حجري / Stone knife
- الملف المتوقع: `public/assets/models/items/item_knife_stone.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
sharp flint blade knife with a wrapped bone handle , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #37 `item_knife_steel` — سكين فولاذ / Steel knife
- الملف المتوقع: `public/assets/models/items/item_knife_steel.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
survival knife with a steel blade and wrapped grip , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #38 `item_machete` — منجل / Machete
- الملف المتوقع: `public/assets/models/items/item_machete.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
long machete with a slightly curved blade and black handle , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #39 `item_fishing_rod` — صنارة / Fishing rod
- الملف المتوقع: `public/assets/models/items/item_fishing_rod.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
handmade bamboo fishing rod with line, hook and a cork float , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #40 `item_fishing_net` — شبكة صيد / Fishing net
- الملف المتوقع: `public/assets/models/items/item_fishing_net.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
small hand-woven fishing net with stone weights , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #41 `item_shovel` — مجرفة / Shovel
- الملف المتوقع: `public/assets/models/items/item_shovel.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
metal shovel with a worn wooden handle , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #42 `item_hammer` — مطرقة / Hammer
- الملف المتوقع: `public/assets/models/items/item_hammer.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
claw hammer with a wooden handle , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #43 `item_saw` — منشار / Saw
- الملف المتوقع: `public/assets/models/items/item_saw.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
hand saw with a rusted steel blade and wooden grip , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #44 `item_flint_steel` — حجر وفولاذ / Flint and steel
- الملف المتوقع: `public/assets/models/items/item_flint_steel.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
flint stone and steel striker for fire making , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #45 `item_fire_drill` — مثقاب نار / Fire drill
- الملف المتوقع: `public/assets/models/items/item_fire_drill.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
bow drill fire-starting kit: bow, spindle and fireboard , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #46 `item_lighter` — قداحة / Lighter
- الملف المتوقع: `public/assets/models/items/item_lighter.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
scratched metal lighter , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #47 `item_torch` — مشعل / Torch
- الملف المتوقع: `public/assets/models/items/item_torch.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
wooden torch wrapped with oil-soaked cloth at the top , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #48 `item_lantern` — فانوس / Lantern
- الملف المتوقع: `public/assets/models/items/item_lantern.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
old oil lantern with a glass chimney and metal handle , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #49 `item_compass` — بوصلة / Compass
- الملف المتوقع: `public/assets/models/items/item_compass.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
brass pocket compass with a glass cover , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #50 `item_binoculars` — منظار / Binoculars
- الملف المتوقع: `public/assets/models/items/item_binoculars.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
compact black binoculars with worn rubber grips , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #51 `item_waterproof_bag` — كيس مقاوم للماء / Waterproof bag
- الملف المتوقع: `public/assets/models/items/item_waterproof_bag.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
rolled-top yellow waterproof dry bag , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #52 `item_flare_gun` — مسدس إشارة / Flare gun
- الملف المتوقع: `public/assets/models/items/item_flare_gun.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
orange emergency flare gun , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #53 `item_flare` — شعلة إشارة / Flare
- الملف المتوقع: `public/assets/models/items/item_flare.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
red emergency signal flare stick , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #54 `item_signal_mirror` — مرآة إشارة / Signal mirror
- الملف المتوقع: `public/assets/models/items/item_signal_mirror.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
small rectangular metal signal mirror with a sighting hole , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #55 `item_matches` — عيدان ثقاب / Matches
- الملف المتوقع: `public/assets/models/items/item_matches.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
small box of wooden matches , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #56 `item_spear_wood` — رمح خشبي / Wooden spear
- الملف المتوقع: `public/assets/models/items/item_spear_wood.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
sharpened fire-hardened wooden spear , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #57 `item_spear_stone` — رمح بسن حجري / Stone spear
- الملف المتوقع: `public/assets/models/items/item_spear_stone.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
wooden spear with a lashed flint spearhead , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #58 `item_club` — هراوة / Club
- الملف المتوقع: `public/assets/models/items/item_club.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
heavy knotted wooden club , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #59 `item_bow` — قوس / Bow
- الملف المتوقع: `public/assets/models/items/item_bow.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
simple wooden bow with a string , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #60 `item_arrow` — سهم / Arrow
- الملف المتوقع: `public/assets/models/items/item_arrow.glb` · الميزانية: 1,000–5,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
wooden arrow with feather fletching and a stone point , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

## قطع البناء والملاجئ والطوافة

### #61 `piece_foundation` — أساس / Foundation
- الملف المتوقع: `public/assets/models/pieces/piece_foundation.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
square 3 meter timber platform foundation on short log piles, weathered planks , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #62 `piece_wall` — جدار / Wall
- الملف المتوقع: `public/assets/models/pieces/piece_wall.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
3 meter wide by 2.5 meter tall rustic wall of lashed bamboo and planks , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #63 `piece_doorway` — إطار باب / Doorway
- الملف المتوقع: `public/assets/models/pieces/piece_doorway.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
3 meter wall segment with a central doorway opening, timber frame , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #64 `piece_door` — باب / Door
- الملف المتوقع: `public/assets/models/pieces/piece_door.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
simple plank door with rope hinges and a wooden latch , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #65 `piece_roof` — سقف / Roof
- الملف المتوقع: `public/assets/models/pieces/piece_roof.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
3 meter square thatched palm-leaf roof panel on a timber frame , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #66 `piece_campfire` — موقد / Campfire
- الملف المتوقع: `public/assets/models/pieces/piece_campfire.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
campfire ring of stones with stacked logs, unlit , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #67 `piece_workbench` — طاولة عمل / Workbench
- الملف المتوقع: `public/assets/models/pieces/piece_workbench.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
sturdy rustic workbench with a vise and hanging tools , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #68 `piece_barrel` — برميل / Barrel
- الملف المتوقع: `public/assets/models/pieces/piece_barrel.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
wooden barrel with iron hoops and a lid , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #69 `piece_cooler` — صندوق تبريد / Cooler
- الملف المتوقع: `public/assets/models/pieces/piece_cooler.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
old insulated cooler box with a latch , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #70 `piece_storage` — صندوق تخزين / Storage box
- الملف المتوقع: `public/assets/models/pieces/piece_storage.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
wooden storage chest with iron corners , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #71 `piece_bed` — فراش / Bed
- الملف المتوقع: `public/assets/models/pieces/piece_bed.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
simple bed frame with a woven palm-leaf mattress and a blanket , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #72 `piece_rack` — رف تجفيف / Drying rack
- الملف المتوقع: `public/assets/models/pieces/piece_rack.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
wooden drying rack with horizontal poles , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #73 `piece_furnace` — فرن / Furnace
- الملف المتوقع: `public/assets/models/pieces/piece_furnace.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
small clay and stone smelting furnace with a chimney and fire door , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #74 `piece_collector` — جامع مطر / Rain collector
- الملف المتوقع: `public/assets/models/pieces/piece_collector.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
rain collector: a tarp stretched over poles funneling into a barrel , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #75 `piece_farm` — قطعة زراعة / Farm plot
- الملف المتوقع: `public/assets/models/pieces/piece_farm.glb` · الميزانية: 500–3,000 مضلع
- الربط: تلقائي عبر المحمّل
```
small framed garden plot with tilled soil and tiny seedlings , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #76 `piece_raft` — طوافة / Raft
- الملف المتوقع: `public/assets/models/pieces/piece_raft.glb` · الميزانية: 2,000–6,000 مضلع
- الربط: تلقائي عبر المحمّل
```
survival raft of lashed logs and planks with a small mast and a patched sail , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

## بقايا الطائرة والمخبأ

### #77 `wreck_fuselage` — جسم الطائرة / Fuselage
- الملف المتوقع: `public/assets/models/wreck/wreck_fuselage.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
broken section of a small passenger airplane fuselage, torn aluminum skin, open cabin, scorched edges , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #78 `wreck_wing` — جناح / Wing
- الملف المتوقع: `public/assets/models/wreck/wreck_wing.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
detached airplane wing, bent and torn, with one damaged propeller , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #79 `wreck_tail` — ذيل / Tail
- الملف المتوقع: `public/assets/models/wreck/wreck_tail.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
airplane tail section with vertical stabilizer half torn off , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #80 `wreck_engine` — محرك / Engine
- الملف المتوقع: `public/assets/models/wreck/wreck_engine.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
airplane engine block with twisted propeller blades, dented cowling , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #81 `wreck_seats` — صف مقاعد / Seat row
- الملف المتوقع: `public/assets/models/wreck/wreck_seats.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
row of three torn airplane passenger seats, still bolted to a floor section , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #82 `wreck_crate` — صندوق شحن / Cargo crate
- الملف المتوقع: `public/assets/models/wreck/wreck_crate.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
dented metal and wood cargo crate with stenciled markings, lid half open , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #83 `wreck_gear` — عجلة هبوط / Landing gear
- الملف المتوقع: `public/assets/models/wreck/wreck_gear.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
airplane landing gear strut with a flat rubber wheel , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #84 `wreck_cockpit` — قمرة القيادة / Cockpit
- الملف المتوقع: `public/assets/models/wreck/wreck_cockpit.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
smashed airplane cockpit with cracked windshield, pilot seats and instrument panel , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #85 `bunker_entrance` — مدخل المخبأ / Bunker entrance
- الملف المتوقع: `public/assets/models/wreck/bunker_entrance.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
concrete bunker entrance built into a rocky hillside, overgrown with vines, heavy steel door , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #86 `bunker_door` — باب المخبأ / Bunker door
- الملف المتوقع: `public/assets/models/wreck/bunker_door.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
heavy rusted steel bunker door with a wheel lock , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #87 `radio_set` — جهاز راديو / Radio set
- الملف المتوقع: `public/assets/models/wreck/radio_set.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
bulky vintage field radio with dials, a handset and a coiled cable , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #88 `satellite_phone` — هاتف فضائي / Satellite phone
- الملف المتوقع: `public/assets/models/wreck/satellite_phone.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
rugged satellite phone with a stubby antenna , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### #89 `flight_recorder` — الصندوق الأسود / Flight recorder
- الملف المتوقع: `public/assets/models/wreck/flight_recorder.glb` · الميزانية: 2,000–15,000 مضلع
- الربط: يحتاج ربطًا في الكود بعد توليده
```
orange flight data recorder box, scratched, with a stenciled label , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

## أوراق الشخصيات (Character Sheets)

لكل شخصية: ولّد أولًا الصورة 3/4 أعلاه حتى ترضى عنها، ثم ارفعها كـ**صورة مرجعية** في Higgsfield (ميزة الإبقاء على ثبات الوجه/الشخصية) وولّد الزوايا الثلاث. لا تبدّل الملابس أو الملامح بين الزوايا؛ إن اختلف الوجه أعد التوليد من الصورة المرجعية.

### `player_hero` — Hero castaway · front view
```
full-body adult male castaway survivor in his thirties, athletic lean build, sunburnt weathered face with short stubble, tattered blue airline-uniform shirt with rolled sleeves, dirty khaki cargo pants, worn leather boots, relaxed A-pose with arms slightly away from the body, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, front view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### `player_hero` — Hero castaway · side view
```
full-body adult male castaway survivor in his thirties, athletic lean build, sunburnt weathered face with short stubble, tattered blue airline-uniform shirt with rolled sleeves, dirty khaki cargo pants, worn leather boots, relaxed A-pose with arms slightly away from the body, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, side view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### `player_hero` — Hero castaway · back view
```
full-body adult male castaway survivor in his thirties, athletic lean build, sunburnt weathered face with short stubble, tattered blue airline-uniform shirt with rolled sleeves, dirty khaki cargo pants, worn leather boots, relaxed A-pose with arms slightly away from the body, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, back view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### `npc_layla` — Layla · front view
```
full-body woman doctor in her forties, calm precise expression, dark hair tied back, dirty light-blue blouse under a salvaged paramedic vest, canvas trousers, worn sandals, small first-aid pouch on her belt, relaxed A-pose, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, front view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### `npc_layla` — Layla · side view
```
full-body woman doctor in her forties, calm precise expression, dark hair tied back, dirty light-blue blouse under a salvaged paramedic vest, canvas trousers, worn sandals, small first-aid pouch on her belt, relaxed A-pose, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, side view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### `npc_layla` — Layla · back view
```
full-body woman doctor in her forties, calm precise expression, dark hair tied back, dirty light-blue blouse under a salvaged paramedic vest, canvas trousers, worn sandals, small first-aid pouch on her belt, relaxed A-pose, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, back view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### `npc_omar` — Omar · front view
```
full-body young telecom engineer in his late twenties, eager restless expression, messy black hair, sunburnt nose, grease-stained gray t-shirt, rolled cargo shorts, tool belt with pliers and screwdrivers, mismatched sneakers, relaxed A-pose, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, front view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### `npc_omar` — Omar · side view
```
full-body young telecom engineer in his late twenties, eager restless expression, messy black hair, sunburnt nose, grease-stained gray t-shirt, rolled cargo shorts, tool belt with pliers and screwdrivers, mismatched sneakers, relaxed A-pose, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, side view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### `npc_omar` — Omar · back view
```
full-body young telecom engineer in his late twenties, eager restless expression, messy black hair, sunburnt nose, grease-stained gray t-shirt, rolled cargo shorts, tool belt with pliers and screwdrivers, mismatched sneakers, relaxed A-pose, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, back view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### `npc_yusuf` — Yusuf · front view
```
full-body seventy-year-old fisherman, deeply tanned lined face, short white beard, woven straw hat, faded patched linen shirt, rope belt, rolled canvas trousers, barefoot, slight stoop but strong forearms, relaxed A-pose, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, front view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### `npc_yusuf` — Yusuf · side view
```
full-body seventy-year-old fisherman, deeply tanned lined face, short white beard, woven straw hat, faded patched linen shirt, rope belt, rolled canvas trousers, barefoot, slight stoop but strong forearms, relaxed A-pose, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, side view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

### `npc_yusuf` — Yusuf · back view
```
full-body seventy-year-old fisherman, deeply tanned lined face, short white beard, woven straw hat, faded patched linen shirt, rope belt, rolled canvas trousers, barefoot, slight stoop but strong forearms, relaxed A-pose, character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose , photorealistic, back view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background
```

## خامات قابلة للتكرار (2K)

الدقة المطلوبة 2048×2048. Higgsfield لا يُخرج خرائط PBR؛ ولّد خريطة الألبيدو ثم استخرج Normal/Roughness/AO بأداة خرائط (مثل Materialize المجانية) وتأكد من التكرار السلس (seamless) في Blender أو أي محرر قبل الاعتماد.

### `tex_wet_sand` — رمل مبلل / Wet sand
- الملف المتوقع: `public/assets/textures/wet_sand_2k.png`
```
seamless tileable texture of wet beach sand with fine grains, subtle ripples and tiny shell fragments , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture
```

### `tex_dry_sand` — رمل جاف / Dry sand
- الملف المتوقع: `public/assets/textures/dry_sand_2k.png`
```
seamless tileable texture of dry pale beach sand with fine grain and faint wind ripples , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture
```

### `tex_volcanic_rock` — صخر بركاني / Volcanic rock
- الملف المتوقع: `public/assets/textures/volcanic_rock_2k.png`
```
seamless tileable texture of dark porous volcanic basalt with small vesicles and rough surface , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture
```

### `tex_palm_bark` — لحاء نخيل / Palm bark
- الملف المتوقع: `public/assets/textures/palm_bark_2k.png`
```
seamless tileable texture of palm tree trunk bark with horizontal ring scars and fibrous texture , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture
```

### `tex_torn_cloth` — قماش ممزق / Torn cloth
- الملف المتوقع: `public/assets/textures/torn_cloth_2k.png`
```
seamless tileable texture of worn faded canvas cloth with frayed holes and stitched patches , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture
```

### `tex_leather` — جلد / Leather
- الملف المتوقع: `public/assets/textures/leather_2k.png`
```
seamless tileable texture of worn brown leather with creases, scratches and subtle stitching , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture
```

### `tex_rust` — صدأ / Rust
- الملف المتوقع: `public/assets/textures/rust_2k.png`
```
seamless tileable texture of corroded metal with orange-brown rust patches and flaking paint , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture
```

### `tex_jungle_floor` — أرضية غابة / Jungle floor
- الملف المتوقع: `public/assets/textures/jungle_floor_2k.png`
```
seamless tileable texture of jungle soil covered with leaf litter, roots and moss , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture
```

### `tex_wood_planks` — ألواح خشب / Weathered planks
- الملف المتوقع: `public/assets/textures/wood_planks_2k.png`
```
seamless tileable texture of weathered gray wooden planks with nail heads and cracks , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture
```

### `tex_thatch` — قش سقف / Thatch
- الملف المتوقع: `public/assets/textures/thatch_2k.png`
```
seamless tileable texture of dry palm-leaf thatch roofing layered in overlapping rows , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture
```

### `tex_cave_wall` — جدار كهف / Cave wall
- الملف المتوقع: `public/assets/textures/cave_wall_2k.png`
```
seamless tileable texture of damp cave wall rock with mineral streaks and small stalactite bumps , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture
```

## فيديو: مقدمات ونهايات

الفيديوهات قصيرة (5–10 ثوانٍ)، بنسبة 16:9، بلا نصوص أو شعارات. تُستخدم مقدمةً أو شاشة نهاية.

### `intro_crash` — مقدمة: تحطم الطائرة / Intro: plane crash (8s)
- الملف المتوقع: `public/assets/video/intro_crash.mp4`
```
cinematic shot of a small passenger airplane with a smoking engine descending through storm clouds toward a tropical island, ocean below, lightning in the distance, handheld camera slowly pushing in, the plane skims the water and breaks apart on the shoreline, dramatic realistic lighting, no text, no logos
```

### `intro_wake` — مقدمة: الاستيقاظ على الشاطئ / Intro: waking on the beach (6s)
- الملف المتوقع: `public/assets/video/intro_wake.mp4`
```
first-person point of view lying on wet sand at dawn, vision blurry then slowly focusing, gentle waves washing up, airplane wreckage smoking in the background, seagulls overhead, camera tilts up to the sky as the survivor sits up, soft golden light, no text, no logos
```

### `ending_rescue` — نهاية: الإنقاذ / Ending: rescue (6s)
- الملف المتوقع: `public/assets/video/ending_rescue.mp4`
```
rescue helicopter flying low over a tropical island beach at golden hour, sand blowing from the rotor wash, a lone survivor waving a flare, camera orbits around the helicopter as it lands, emotional cinematic mood, no text, no logos
```

### `ending_raft` — نهاية: الإبحار / Ending: raft (6s)
- الملف المتوقع: `public/assets/video/ending_raft.mp4`
```
handmade wooden raft with a patched sail leaving a tropical island at sunrise, calm sea, the island shrinking behind, a lone figure at the tiller, wide aerial camera pulling back, serene cinematic mood, no text, no logos
```

### `ending_secret` — نهاية: سر الجزيرة / Ending: island secret (6s)
- الملف المتوقع: `public/assets/video/ending_secret.mp4`
```
interior of a hidden concrete bunker, a lone survivor transmitting on a satellite phone beside glowing monitors, dust in the light, camera slowly pushes in on their face as the screens flicker to life, tense mysterious mood, no text, no logos
```

---
**الإجمالي:** 89 برومبت مجسم + 12 ورقة شخصية + 11 خامة + 5 فيديو = 117 برومبت.
