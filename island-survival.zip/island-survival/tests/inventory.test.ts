import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Grid } from '../src/inventory/Grid';
import { Inventory } from '../src/inventory/Inventory';
import { ItemDB } from '../src/inventory/ItemDatabase';
import { DragController } from '../src/inventory/DragDrop';
import { Container } from '../src/inventory/Container';
import { loadEffect } from '../src/inventory/Weight';

const fresh = (): Inventory => {
  const inv = new Inventory();
  // نبدأ بحقيبة قماش جاهزة 6×4
  inv.grid.resize(6, 4);
  inv.equipment.set('backpack', ItemDB.create('backpack_cloth'));
  return inv;
};

test('قاعدة البيانات: 120+ عنصر وكل الحقول موجودة', () => {
  const all = ItemDB.all();
  assert.ok(all.length >= 120, `count=${all.length}`);
  for (const d of all) {
    assert.ok(d.id && d.nameAr && d.nameEn && d.type && d.stack >= 1 && d.size.length === 2 && d.weight >= 0 && d.rarity && d.model && d.icon, d.id);
  }
});

test('الإضافة: تدمج في المكدّس ثم تنشئ مكدّسًا جديدًا', () => {
  const inv = fresh();
  assert.equal(inv.add('stick', 25), 0);
  assert.equal(inv.add('stick', 10), 0); // الحد 30 => مكدّسان
  assert.equal(inv.count('stick'), 35);
  assert.equal(inv.grid.size, 2);
});

test('الإضافة: تعيد المتبقي عند الازدحام', () => {
  const inv = new Inventory(); // جيوب 4×2 = 8 خانات
  const left = inv.add('wood_log', 100); // 1×2 لكل مكدّس 5 => 4 مكدّسات تتسع فقط
  assert.ok(left > 0);
  assert.equal(inv.count('wood_log'), 100 - left);
  assert.equal(inv.count('wood_log'), 20);
});

test('الإزالة: تبدأ من الأقل جودة وتحذف المكدّس الفارغ', () => {
  const inv = fresh();
  inv.add('stone', 5);
  assert.equal(inv.remove('stone', 3), 3);
  assert.equal(inv.count('stone'), 2);
  assert.equal(inv.remove('stone', 10), 2);
  assert.equal(inv.grid.size, 0);
});

test('الدمج: الفساد يُمزج بالمتوسط المرجّح', () => {
  const inv = fresh();
  inv.add('banana', 2, { spoil: 0 });
  inv.add('banana', 2, { spoil: 40 });
  const e = inv.grid.list()[0];
  assert.equal(e.stack.count, 4);
  assert.equal(e.stack.spoil, 20);
});

test('التقسيم', () => {
  const inv = fresh();
  inv.add('stone', 10);
  const uid = inv.grid.list()[0].stack.uid;
  assert.ok(inv.split(uid, 4));
  assert.equal(inv.grid.size, 2);
  assert.equal(inv.count('stone'), 10);
  assert.equal(inv.split(uid, 99), false);
});

test('التدوير: عنصر 1×2 يتسع أفقيًا عند التدوير', () => {
  const g = new Grid(2, 1);
  const def = ItemDB.get('axe_stone'); // 1×2
  assert.equal(g.canPlace(def, 0, 0, false), false);
  assert.equal(g.canPlace(def, 0, 0, true), true);
  const spot = g.findSpot(def);
  assert.deepEqual(spot, { x: 0, y: 0, rotated: true });
});

test('الوزن والحمل الزائد', () => {
  const inv = fresh();
  assert.equal(inv.maxWeight, 30);
  const w0 = inv.totalWeight; // الحقيبة نفسها 0.6
  inv.add('stone', 10);
  assert.equal(inv.totalWeight, Math.round((w0 + 10) * 100) / 100);
  assert.equal(loadEffect(10, 30).speedMultiplier, 1);
  const heavy = loadEffect(45, 30);
  assert.ok(heavy.overloaded && heavy.speedMultiplier < 0.9 && heavy.staminaDrainMultiplier > 1);
  assert.ok(loadEffect(60, 30).immobilized);
});

test('الازدحام: لا يتجاوز حدود الشبكة', () => {
  const g = new Grid(2, 2);
  assert.equal(g.add('storage_box', 1), 0); // 2×2
  assert.equal(g.add('stone', 1), 1); // لا مكان
});

test('تجهيز حقيبة أكبر يوسّع الشبكة ويعيد القديمة', () => {
  const inv = fresh();
  inv.add('backpack_leather', 1);
  const uid = inv.grid.list().find((e) => e.stack.defId === 'backpack_leather')!.stack.uid;
  const r = inv.equip(uid);
  assert.ok(r.ok, r.reason);
  assert.equal(inv.grid.width, 8);
  assert.equal(inv.grid.height, 5);
  assert.equal(inv.maxWeight, 45);
  assert.ok(inv.has('backpack_cloth')); // القديمة عادت للحقيبة
});

test('تجهيز حقيبة أصغر يفشل إن خرجت العناصر عن الحدود', () => {
  const inv = fresh();
  inv.equipment.set('backpack', ItemDB.create('backpack_military'));
  inv.grid.resize(10, 6);
  inv.grid.place(ItemDB.create('stone', 1), 9, 5);
  inv.add('backpack_cloth', 1);
  const uid = inv.grid.list().find((e) => e.stack.defId === 'backpack_cloth')!.stack.uid;
  const r = inv.equip(uid);
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'itemsWouldNotFit');
  assert.equal(inv.grid.width, 10);
  assert.ok(inv.has('backpack_cloth'));
});

test('تجهيز ملابس وتأثيرها على الحماية والدفء', () => {
  const inv = fresh();
  inv.add('jacket_leather', 1);
  const uid = inv.grid.list().find((e) => e.stack.defId === 'jacket_leather')!.stack.uid;
  assert.ok(inv.equip(uid).ok);
  assert.equal(inv.equipment.warmth, 8);
  assert.equal(inv.equipment.defense, 5);
  assert.ok(inv.unequip('chest').ok);
  assert.equal(inv.equipment.warmth, 0);
});

test('الشريط السريع: لا تكرار، يُمسح عند إزالة العنصر، يلفّ بالعجلة', () => {
  const inv = fresh();
  inv.add('torch', 1);
  const uid = inv.grid.list().find((e) => e.stack.defId === 'torch')!.stack.uid;
  inv.hotbar.assign(2, uid);
  inv.hotbar.assign(5, uid);
  assert.equal(inv.hotbar.slots[2], null);
  assert.equal(inv.hotbar.slots[5], uid);
  inv.hotbar.select(7);
  inv.hotbar.scroll(1);
  assert.equal(inv.hotbar.selected, 0);
  inv.hotbar.select(5);
  assert.equal(inv.held?.defId, 'torch');
  inv.remove('torch', 1);
  assert.equal(inv.hotbar.slots[5], null);
});

test('المتانة: تنقص وتتحطم وتُصلح', () => {
  const inv = fresh();
  inv.add('knife_stone', 1);
  const uid = inv.grid.list().find((e) => e.stack.defId === 'knife_stone')!.stack.uid;
  assert.equal(inv.damage(uid, 20), false);
  assert.equal(inv.grid.get(uid)!.stack.durability, 40);
  assert.equal(inv.repair(uid, 100), 20); // الحد الأقصى 60
  assert.equal(inv.damage(uid, 60), true);
  assert.equal(inv.grid.get(uid), undefined);
});

test('الفساد: طازج ← قديم ← فاسد، والملح/الحاوية يبطئان', () => {
  const inv = fresh();
  inv.add('raw_meat', 1); // 20 ساعة
  inv.updateSpoil(15);
  const uid = inv.grid.list().find((e) => e.stack.defId === 'raw_meat')!.stack.uid;
  const r1 = inv.use(uid);
  assert.equal(r1.state, 'stale');
  assert.equal(r1.effects.hunger, 5); // 8 * 0.6 تقريبًا
  inv.add('banana', 1);
  inv.updateSpoil(1000);
  assert.ok(inv.has('rotten_food'));
  assert.ok(!inv.has('banana'));

  const cooler = new Container('c1', 'cooler'); // يبطئ 3×
  cooler.grid.add('cooked_meat', 1); // 48 ساعة
  cooler.updateSpoil(90); // يعادل 30 ساعة => ما زال طازجًا/قديمًا
  assert.equal(cooler.grid.count('cooked_meat'), 1);
  cooler.updateSpoil(90); // 60 ساعة معادلة => فاسد
  assert.equal(cooler.grid.count('cooked_meat'), 0);
  assert.equal(cooler.grid.count('rotten_food'), 1);
});

test('الاستخدام: يستهلك وحدة ويعيد التأثيرات', () => {
  const inv = fresh();
  inv.add('cooked_fish', 2);
  const uid = inv.grid.list()[0].stack.uid;
  const r = inv.use(uid);
  assert.ok(r.ok);
  assert.equal(r.effects.hunger, 22);
  assert.equal(inv.count('cooked_fish'), 1);
  inv.add('axe_stone', 1);
  const ax = inv.grid.list().find((e) => e.stack.defId === 'axe_stone')!.stack.uid;
  assert.equal(inv.use(ax).reason, 'notUsable');
});

test('الترتيب التلقائي لا يفقد عناصر', () => {
  const inv = fresh();
  inv.add('stone', 7);
  inv.add('axe_stone', 1);
  inv.add('stick', 12);
  inv.add('bandage', 3);
  const before = ['stone', 'axe_stone', 'stick', 'bandage'].map((i) => inv.count(i));
  assert.ok(inv.sort());
  assert.deepEqual(['stone', 'axe_stone', 'stick', 'bandage'].map((i) => inv.count(i)), before);
});

test('السحب والإفلات: نقل وتدوير ودمج وتبديل وإلغاء', () => {
  const g = new Grid(4, 4);
  const d = new DragController();

  // نقل مع تدوير: فأس 1×2 يصبح 2×1
  g.add('axe_stone', 1);
  const axe = g.list()[0];
  assert.ok(d.pickup(g, axe.stack.uid));
  d.rotate();
  assert.equal(d.drop(g, 2, 3), 'placed');
  assert.equal(g.at(3, 3)?.stack.defId, 'axe_stone');
  assert.equal(g.at(0, 0), undefined);

  // رفض: خارج الحدود يعيد الرفض ويُبقي العنصر في اليد
  const axe2 = g.list()[0];
  d.pickup(g, axe2.stack.uid);
  assert.equal(d.drop(g, 3, 3), 'rejected'); // 1×2 عند الصف الأخير لا يتسع
  assert.ok(d.active);
  assert.ok(d.cancel()); // يعود لمكانه
  assert.equal(g.count('axe_stone'), 1);

  // دمج
  const g2 = new Grid(4, 2);
  g2.place(ItemDB.create('stone', 5), 0, 0);
  g2.place(ItemDB.create('stone', 4), 1, 0);
  const second = g2.at(1, 0)!;
  d.pickup(g2, second.stack.uid);
  assert.equal(d.drop(g2, 0, 0), 'merged');
  assert.equal(g2.count('stone'), 9);
  assert.equal(g2.size, 1);

  // دمج جزئي عند امتلاء المكدّس (الحد 15)
  const g3 = new Grid(4, 2);
  g3.place(ItemDB.create('stone', 13), 0, 0);
  g3.place(ItemDB.create('stone', 5), 1, 0);
  d.pickup(g3, g3.at(1, 0)!.stack.uid);
  assert.equal(d.drop(g3, 0, 0), 'merged');
  assert.equal(g3.at(0, 0)!.stack.count, 15);
  assert.ok(d.active); // بقيت 3 في اليد
  assert.equal(d.held!.stack.count, 3);
  assert.ok(d.cancel());
  assert.equal(g3.count('stone'), 18);

  // تبديل بين عنصرين مختلفين
  const g4 = new Grid(2, 1);
  g4.place(ItemDB.create('stone', 1), 0, 0);
  g4.place(ItemDB.create('stick', 1), 1, 0);
  d.pickup(g4, g4.at(0, 0)!.stack.uid);
  assert.equal(d.drop(g4, 1, 0), 'swapped');
  assert.equal(g4.at(1, 0)!.stack.defId, 'stone');
  assert.equal(d.held!.stack.defId, 'stick');
  assert.ok(d.cancel());
  assert.equal(g4.count('stick'), 1);

  // التقاط جزء (Shift)
  const g5 = new Grid(3, 1);
  g5.place(ItemDB.create('stone', 10), 0, 0);
  d.pickup(g5, g5.at(0, 0)!.stack.uid, 4);
  assert.equal(g5.at(0, 0)!.stack.count, 6);
  assert.equal(d.drop(g5, 2, 0), 'placed');
  assert.equal(g5.count('stone'), 10);
});
