import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CAVE_LENGTH, TERRAIN_RES, TerrainGenerator } from '../src/world/TerrainGenerator';

const gen = new TerrainGenerator('island-1');

test('الجزيرة: يابسة معقولة وشاطئ ونقطة ظهور صالحة', () => {
  let land = 0;
  for (const h of gen.heights) if (h > 0) land++;
  const pct = (100 * land) / gen.heights.length;
  assert.ok(pct > 15 && pct < 60, `land=${pct}`);
  assert.ok(gen.spawn.y > 0.7 && gen.spawn.y < 1.7, `spawn y=${gen.spawn.y}`);
  assert.equal(gen.biomeAt(gen.spawn.x, gen.spawn.z), 'beach');
  assert.ok(gen.slope(gen.spawn.x, gen.spawn.z) < 0.3);
});

test('الارتفاع متصل: الاستيفاء يطابق الشبكة عند العقد وخارج الخريطة عميق', () => {
  const n = TERRAIN_RES + 1;
  for (const [i, j] of [[10, 10], [128, 128], [200, 50]]) {
    const x = i * gen.cell - gen.half;
    const z = j * gen.cell - gen.half;
    assert.ok(Math.abs(gen.height(x, z) - gen.heights[j * n + i]) < 1e-6);
  }
  assert.ok(gen.height(10000, 0) < -10);
  const nrm = gen.normal(0, 0);
  assert.ok(Math.abs(Math.hypot(nrm.x, nrm.y, nrm.z) - 1) < 1e-6);
});

test('الكهوف: مخططة على سفوح مناسبة، والمصطبة مستوية تحت النفق', () => {
  assert.ok(gen.caveSites.length >= 1, 'no cave sites');
  for (const c of gen.caveSites) {
    assert.ok(c.y >= 8 && c.y <= 18);
    assert.ok(Math.hypot(c.x - gen.spawn.x, c.z - gen.spawn.z) >= 70);
    // على امتداد محور النفق الأرض مسطحة عند ارتفاع المدخل (لا تقطع النفق)
    const fx = Math.sin(c.yaw);
    const fz = Math.cos(c.yaw);
    for (let t = 0; t <= CAVE_LENGTH; t += 2) {
      for (const side of [-6, 0, 6]) {
        const x = c.x + fx * t + fz * side;
        const z = c.z + fz * t - fx * side;
        assert.ok(Math.abs(gen.height(x, z) - c.y) < 0.35, `t=${t} side=${side} h=${gen.height(x, z)} y=${c.y}`);
      }
    }
    assert.ok(gen.insideCaveFootprint(c.x + fx * 10, c.z + fz * 10));
    assert.ok(!gen.insideCaveFootprint(c.x + 200, c.z));
  }
  // الكهوف متباعدة
  if (gen.caveSites.length > 1) {
    const [a, b] = gen.caveSites;
    assert.ok(Math.hypot(a.x - b.x, a.z - b.z) >= 90);
  }
});

test('الحتمية: نفس البذرة نفس العالم، وبذرة مختلفة عالم مختلف', () => {
  const a = new TerrainGenerator('island-1');
  assert.deepEqual(a.spawn, gen.spawn);
  assert.deepEqual(a.caveSites, gen.caveSites);
  const b = new TerrainGenerator('another');
  assert.notDeepEqual(b.spawn, gen.spawn);
});
