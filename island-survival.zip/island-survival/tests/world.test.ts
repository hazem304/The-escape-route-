import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Random } from '../src/core/Random';
import { Noise2D } from '../src/core/Noise';
import { classifyBiome } from '../src/world/BiomeRules';
import { ResourceField } from '../src/world/ResourceField';
import { applyHit, BARE_HANDS, NODE_DEFS, toolPowerOf, type NodeState } from '../src/world/ResourceNode';
import { scatterResources, type TerrainSampler } from '../src/world/ScatterGenerator';

import { GroundItems } from '../src/world/GroundItems';
import { Fishing, catchTable, BITE_WINDOW } from '../src/survival/Fishing';
import { buildCave, RING_VERTS } from '../src/world/CaveGeometry';
import { Inventory } from '../src/inventory/Inventory';
import { ItemDB } from '../src/inventory/ItemDatabase';

/** تضاريس اصطناعية: جزيرة دائرية من ضوضاء، بنفس منطق التصنيف */
function fakeSampler(): TerrainSampler {
  const n = new Noise2D('test-island');
  const m = new Noise2D('test-moist');
  const height = (x: number, z: number): number => {
    const r = Math.hypot(x, z) / 180;
    const mask = 1 - r * r;
    return mask < 0.03 ? -(0.03 - mask) * 8 : 3.8 * (mask - 0.03) + (n.fbm(x * 0.01, z * 0.01, 4) * 0.5 + 0.5 + 0.3) * 22 * Math.min(1, Math.max(0, (mask - 0.12) / 0.43));
  };
  const slope = (x: number, z: number): number => Math.min(1, Math.hypot(height(x + 2, z) - height(x - 2, z), height(x, z + 2) - height(x, z - 2)) / 4);
  const moisture = (x: number, z: number): number => m.fbm(x * 0.01, z * 0.01, 3) * 0.5 + 0.5;
  return { height, slope, moisture, biomeAt: (x, z) => classifyBiome(height(x, z), slope(x, z), moisture(x, z)) };
}

test('التوزيع: حتمي من البذرة وضمن قواعد البيوم والارتفاع', () => {
  const s = fakeSampler();
  const a = new ResourceField();
  const b = new ResourceField();
  const na = scatterResources(s, a, 'seed-1', { half: 200 });
  const nb = scatterResources(s, b, 'seed-1', { half: 200 });
  assert.equal(na, nb);
  assert.ok(na > 100, `count=${na}`);
  assert.deepEqual(a.all().slice(0, 20).map((n) => [n.kind, n.x, n.z]), b.all().slice(0, 20).map((n) => [n.kind, n.x, n.z]));

  const c = new ResourceField();
  scatterResources(s, c, 'seed-2', { half: 200 });
  assert.notDeepEqual(a.all().slice(0, 5).map((n) => n.x), c.all().slice(0, 5).map((n) => n.x));

  for (const n of a.all()) {
    assert.ok(n.y > 0.9, `${n.kind} underwater y=${n.y}`);
    if (n.kind === 'palm') assert.ok(n.y < 9.1);
    if (n.kind === 'ironRock' || n.kind === 'copperRock') assert.ok(n.y >= 10);
  }
  const kinds = new Set(a.all().map((n) => n.kind));
  for (const k of ['palm', 'jungleTree', 'boulder', 'berryBush', 'fiberPlant']) assert.ok(kinds.has(k as never), `missing ${k}`);
});

test('التوزيع: يحترم المناطق المحظورة', () => {
  const s = fakeSampler();
  const f = new ResourceField();
  scatterResources(s, f, 'x', { half: 200, keepClear: [{ x: 0, z: 0, r: 60 }] });
  assert.ok(f.all().every((n) => Math.hypot(n.x, n.z) >= 60));
});

const mk = (kind: NodeState['kind']): NodeState => ({ id: 1, kind, x: 0, y: 0, z: 0, scale: 1, rotY: 0, hp: NODE_DEFS[kind].hp, alive: true, respawnAt: 0 });
const axe = toolPowerOf(ItemDB.get('axe_stone').effects);
const pick = toolPowerOf(ItemDB.get('pickaxe_stone').effects);

test('الضربات: اليد لا تقطع شجرة والفأس يقطعها، المعول للصخر', () => {
  const rnd = new Random(1);
  assert.equal(applyHit(mk('palm'), BARE_HANDS, rnd).reason, 'wrongTool');
  assert.equal(applyHit(mk('boulder'), axe, rnd).reason, 'wrongTool');
  assert.equal(applyHit(mk('ironRock'), BARE_HANDS, rnd).reason, 'wrongTool');

  const tree = mk('palm');
  let hits = 0;
  let final: ReturnType<typeof applyHit> | null = null;
  while (hits < 100) {
    final = applyHit(tree, axe, rnd);
    hits++;
    if (final.destroyed) break;
  }
  assert.ok(final!.destroyed && hits >= 3 && hits <= 10, `hits=${hits}`);
  assert.ok(final!.drops.some((d) => d.id === 'wood_log'));
  assert.equal(applyHit(tree, axe, rnd).reason, 'dead');

  const rock = mk('ironRock');
  let ore = 0;
  for (let i = 0; i < 40 && rock.alive; i++) {
    const r = applyHit(rock, pick, rnd);
    ore += r.drops.filter((d) => d.id === 'iron_ore').reduce((s, d) => s + d.count, 0);
    if (r.destroyed) rock.alive = false;
  }
  assert.ok(ore >= 2);
});

test('النباتات اليدوية: ضربة واحدة تُستنفد بلا أداة', () => {
  const r = applyHit(mk('berryBush'), BARE_HANDS, new Random(3));
  assert.ok(r.ok && r.destroyed);
  assert.ok(r.drops.some((d) => d.id === 'berries'));
});

test('مكافأة الجمع تزيد الغلة في المتوسط', () => {
  let base = 0;
  let boosted = 0;
  for (let i = 0; i < 200; i++) {
    base += applyHit(mk('fiberPlant'), BARE_HANDS, new Random(i), 0).drops.filter((d) => d.id === 'plant_fiber').reduce((s, d) => s + d.count, 0);
    boosted += applyHit(mk('fiberPlant'), BARE_HANDS, new Random(i), 0.5).drops.filter((d) => d.id === 'plant_fiber').reduce((s, d) => s + d.count, 0);
  }
  assert.ok(boosted > base * 1.3, `${base} vs ${boosted}`);
});

test('الحقل: رمي شعاع يصيب الشجرة الأقرب ويتجاوز الميتة، وإعادة النمو', () => {
  const f = new ResourceField();
  const near = f.add('palm', 3, 0, 0);
  f.add('palm', 6, 0, 0);
  const hit = f.raycast(0, 1.6, 0, 1, 0, 0, 5);
  assert.equal(hit?.node.id, near.id);
  assert.ok(hit!.distance > 2 && hit!.distance < 3.2);

  assert.equal(f.raycast(0, 1.6, 0, 0, 0, 1, 5), null); // اتجاه آخر
  assert.equal(f.raycast(0, 12, 0, 1, 0, 0, 5), null); // فوق الشجرة

  const changes: boolean[] = [];
  f.onChanged = (n) => changes.push(n.alive);
  const rnd = new Random(5);
  for (let i = 0; i < 30; i++) if (f.hit(near.id, axe, rnd).destroyed) break;
  assert.equal(near.alive, false);
  assert.equal(f.raycast(0, 1.6, 0, 1, 0, 0, 4)?.node.id !== near.id, true); // الميتة تُتجاهل

  f.update(NODE_DEFS.palm.respawnHours - 1);
  assert.equal(near.alive, false);
  f.update(2);
  assert.equal(near.alive, true);
  assert.deepEqual(changes, [false, true]);
});

test('الحقل: البحث القريب والحفظ/التحميل', () => {
  const f = new ResourceField();
  f.add('boulder', 10, 0, 10);
  f.add('boulder', 100, 0, 100);
  assert.equal(f.nearby(10, 10, 5).length, 1);
  assert.equal(f.nearby(55, 55, 200).length, 2);

  const n = f.all()[0];
  n.alive = false;
  n.respawnAt = 50;
  const saved = JSON.parse(JSON.stringify(f.toJSON()));
  const g = new ResourceField();
  g.add('boulder', 10, 0, 10);
  g.add('boulder', 100, 0, 100);
  g.load(saved);
  assert.equal(g.all()[0].alive, false);
  assert.equal(g.all()[1].alive, true);
});

test('عناصر الأرض: دمج المتماثل، الالتقاط الجزئي، الاختفاء بعد مدة', () => {
  const g = new GroundItems();
  g.dropNew('stone', 5, 0, 0, 0);
  g.dropNew('stone', 5, 0.2, 0, 0.1); // يندمج
  assert.equal(g.size, 1);
  assert.equal(g.list()[0].stack.count, 10);
  g.dropNew('stone', 3, 5, 0, 5);
  assert.equal(g.size, 2);

  const inv = new Inventory(); // 4×2
  const it = g.nearest(0, 0, 2)!;
  const r = g.pickup(it.id, inv);
  assert.ok(r.ok && r.left === 0);
  assert.equal(inv.count('stone'), 10);
  assert.equal(g.size, 1);

  // حقيبة ممتلئة: يبقى على الأرض
  const full = new Inventory();
  for (const id of ['axe_iron', 'axe_stone', 'pickaxe_stone', 'pickaxe_iron']) full.add(id, 1);
  const rest = g.nearest(5, 5, 1)!;
  const r2 = g.pickup(rest.id, full);
  assert.equal(r2.picked, 0);
  assert.equal(g.size, 1);

  g.update(601);
  assert.equal(g.size, 0);
});

test('الصيد: انتظار ثم لدغة ثم سحب ناجح، والتأخر يفلت السمكة', () => {
  const f = new Fishing(new Random(9));
  assert.equal(f.start({ depth: 0.2, bait: null, skill: 0, hour: 12, rodPower: 1 }), false); // ضحل جدًا
  assert.ok(f.start({ depth: 5, bait: null, skill: 0, hour: 12, rodPower: 1 }));
  assert.equal(f.reel(), null); // سحب مبكر يفسد الرمية
  assert.equal(f.state, 'idle');

  assert.ok(f.start({ depth: 5, bait: 'berries', skill: 5, hour: 6, rodPower: 1 }));
  let t = 0;
  while (f.state === 'waiting' && t < 60) {
    f.update(0.5);
    t += 0.5;
  }
  assert.equal(f.state, 'bite');
  assert.equal(f.consumedBait, 'berries');
  const c = f.reel();
  assert.ok(c && ItemDB.has(c.id) && c.count >= 1);
  assert.equal(f.state, 'caught');

  f.start({ depth: 5, bait: null, skill: 0, hour: 12, rodPower: 1 });
  while (f.state === 'waiting') f.update(0.5);
  f.update(BITE_WINDOW + 0.1);
  assert.equal(f.state, 'escaped');
});

test('الصيد: العمق يحدد الأنواع والطُّعم والمهارة يقصّران الانتظار', () => {
  assert.equal(catchTable(0.3).length, 0);
  assert.ok(catchTable(2).some((e) => e.id === 'raw_crab'));
  assert.ok(catchTable(12).every((e) => e.id !== 'raw_crab'));
  for (const d of [1, 5, 10]) for (const e of catchTable(d)) assert.ok(ItemDB.has(e.id), e.id);

  const avg = (info: Parameters<Fishing['start']>[0]): number => {
    let sum = 0;
    for (let i = 0; i < 50; i++) {
      const f = new Fishing(new Random(i));
      f.start(info);
      let t = 0;
      while (f.state === 'waiting') {
        f.update(0.1);
        t += 0.1;
      }
      sum += t;
    }
    return sum / 50;
  };
  const slow = avg({ depth: 5, bait: null, skill: 0, hour: 12, rodPower: 1 });
  const fast = avg({ depth: 5, bait: 'raw_fish', skill: 8, hour: 12, rodPower: 1 });
  assert.ok(fast < slow * 0.7, `${fast} vs ${slow}`);
});

test('الكهف: هندسة سليمة (فهارس صالحة، بلا NaN) والوجوه الداخلية تواجه المحور', () => {
  const cave = buildCave('cave-1', 40, 2.6);
  for (const m of [cave.inner, cave.outer]) {
    assert.ok(m.positions.every((v) => Number.isFinite(v)));
    const maxIdx = m.positions.length / 3;
    assert.ok(m.indices.every((i) => i < maxIdx));
    assert.equal(m.indices.length % 3, 0);
  }
  assert.ok(cave.path.length >= 5);

  // اتجاه الوجه: ناظم المثلث مقابل المتجه نحو المحور في المستوى xy
  const facing = (m: { positions: Float32Array; indices: Uint32Array }, ringsOnly: number): number => {
    let ok = 0;
    let total = 0;
    const P = m.positions;
    for (let t = 0; t < ringsOnly; t += 3) {
      const [a, b, c] = [m.indices[t] * 3, m.indices[t + 1] * 3, m.indices[t + 2] * 3];
      const u = [P[b] - P[a], P[b + 1] - P[a + 1], P[b + 2] - P[a + 2]];
      const v = [P[c] - P[a], P[c + 1] - P[a + 1], P[c + 2] - P[a + 2]];
      const n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
      const ring = Math.floor(t / (RING_VERTS * 6));
      const cx = (P[a] + P[b] + P[c]) / 3 - cave.path[ring].x; // المحور ينحني
      const cy = (P[a + 1] + P[b + 1] + P[c + 1]) / 3;
      // المحور عند x≈0 وارتفاع ~1 (تقريب)؛ المتجه نحو المحور:
      const toAxis = [-cx, 1 - cy];
      const d = n[0] * toAxis[0] + n[1] * toAxis[1];
      if (Math.abs(d) < 1e-6) continue;
      total++;
      if (d > 0) ok++;
    }
    return total ? ok / total : 0;
  };
  const rings = cave.path.length - 1;
  const innerFacing = facing(cave.inner, rings * RING_VERTS * 6);
  const outerFacing = facing(cave.outer, rings * RING_VERTS * 6);
  assert.ok(innerFacing > 0.95, `inner facing axis: ${innerFacing}`);
  assert.ok(outerFacing < 0.05, `outer facing axis: ${outerFacing}`);
});
