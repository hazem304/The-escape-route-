import test from 'node:test';
import assert from 'node:assert/strict';
import { mixAmbience, smoothMix, type AmbienceInput } from '../src/audio/AmbienceMix';
import { StrideTimer, surfaceFor } from '../src/audio/Footsteps';

const base: AmbienceInput = { hour: 12, weather: { rain: 0, wind: 0.2, storm: 0 }, biome: 'jungle', inCave: false, underwater: false, shoreDist: 200, health: 100, danger: false };

test('الطيور نهارًا والصراصير ليلًا', () => {
  const d = mixAmbience(base);
  const n = mixAmbience({ ...base, hour: 23 });
  assert.ok(d.birds > 0.5 && d.crickets < 0.05);
  assert.ok(n.crickets > 0.3 && n.birds < 0.05);
});

test('المطر يرفع صوته ويخفض الطيور؛ الكهف يكتم الطقس', () => {
  const dry = mixAmbience(base);
  const wet = mixAmbience({ ...base, weather: { rain: 1, wind: 0.5, storm: 0 } });
  assert.ok(wet.rain > 0.9 && wet.birds < dry.birds);
  const cave = mixAmbience({ ...base, inCave: true, weather: { rain: 1, wind: 1, storm: 1 } });
  assert.ok(cave.cave === 1 && cave.rain < 0.2 && cave.wind === 0 && cave.birds === 0);
});

test('الأمواج تُسمع قرب الشاطئ فقط', () => {
  assert.ok(mixAmbience({ ...base, shoreDist: 5 }).waves > 0.4);
  assert.ok(mixAmbience({ ...base, shoreDist: 300 }).waves < 0.01);
});

test('تحت الماء: قطع ترددات وكتم', () => {
  const u = mixAmbience({ ...base, underwater: true });
  assert.ok(u.lowpassHz < 1000 && u.birds === 0 && u.rain === 0);
  assert.equal(mixAmbience(base).lowpassHz, 20000);
});

test('نبض القلب عند الصحة المنخفضة والتوتر عند الخطر', () => {
  assert.equal(mixAmbience(base).heartbeat, 0);
  assert.ok(mixAmbience({ ...base, health: 10 }).heartbeat > 0.6);
  assert.ok(mixAmbience({ ...base, danger: true }).tension > mixAmbience(base).tension + 0.4);
});

test('كل القيم ضمن النطاق لعينة واسعة من الحالات', () => {
  for (let h = 0; h < 24; h += 1.5) for (const biome of ['beach', 'jungle', 'rock', 'grass', 'volcanic', 'shallows']) for (const rain of [0, 1]) {
    const m = mixAmbience({ ...base, hour: h, biome, weather: { rain, wind: rain, storm: rain }, health: h * 4 });
    for (const [k, v] of Object.entries(m)) if (k !== 'lowpassHz') assert.ok(v >= 0 && v <= 1.0001 && Number.isFinite(v), `${k}=${v}`);
  }
});

test('smoothMix يقترب من الهدف دون تجاوز', () => {
  const a = mixAmbience(base);
  const b = mixAmbience({ ...base, hour: 23 });
  let cur = a;
  for (let i = 0; i < 200; i++) cur = smoothMix(cur, b, 0.1);
  assert.ok(Math.abs(cur.crickets - b.crickets) < 0.01);
  const mid = smoothMix(a, b, 0.1);
  assert.ok(mid.crickets > a.crickets && mid.crickets < b.crickets);
});

test('الخطوات: عدد الخطوات يطابق المسافة وتتناوب الأقدام', () => {
  const s = new StrideTimer();
  let steps = 0;
  const lefts: boolean[] = [];
  for (let i = 0; i < 100; i++) {
    const r = s.advance(0.1, 'walk', true); // 10م
    if (r) { steps++; lefts.push(r.left); }
  }
  assert.equal(steps, Math.floor(10 / 0.8));
  assert.ok(lefts.every((l, i) => i === 0 || l !== lefts[i - 1]));
  assert.equal(s.advance(5, 'walk', false), null);
  assert.equal(s.advance(5, 'idle', true), null);
});

test('الأسطح حسب البيوم', () => {
  assert.equal(surfaceFor('beach', false), 'sand');
  assert.equal(surfaceFor('jungle', false), 'jungle');
  assert.equal(surfaceFor('rock', true), 'water');
  assert.equal(surfaceFor('grass', false, true), 'wood');
  assert.equal(surfaceFor('beach', false, false, true), 'wet');
});
