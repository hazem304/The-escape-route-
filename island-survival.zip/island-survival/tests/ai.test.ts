import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Action, Condition, Cooldown, Inverter, Selector, Sequence, Timed } from '../src/ai/BehaviorTree';
import { avoidObstacles, flee, seek, turnToward, headingOf, arrive } from '../src/ai/Steering';
import { perceive, playerNoise, type Senses } from '../src/ai/Perception';
import { NavGrid } from '../src/ai/Pathfinding';
import { Schedule } from '../src/ai/Schedule';
import { Random } from '../src/core/Random';
import { Animal, SPECIES, type AIWorld } from '../src/entities/Animal';
import { AnimalManager } from '../src/entities/AnimalManager';
import { NPC, trustLevel } from '../src/entities/NPC';
import { NPC_DEFS } from '../src/data/npcs';
import { checkCondition, DialogueRunner, type DialogueContext, type DialogueGraph } from '../src/quests/Dialogue';

// ---------- شجرة السلوك ----------
test('BT: Sequence يفشل عند أول فشل، Selector ينجح عند أول نجاح', () => {
  const log: string[] = [];
  const t = (n: string, r: 'success' | 'failure' | 'running') => new Action<null>(() => (log.push(n), r));
  assert.equal(new Sequence<null>([t('a', 'success'), t('b', 'failure'), t('c', 'success')]).tick(null, 0), 'failure');
  assert.deepEqual(log, ['a', 'b']);
  log.length = 0;
  assert.equal(new Selector<null>([t('a', 'failure'), t('b', 'success'), t('c', 'success')]).tick(null, 0), 'success');
  assert.deepEqual(log, ['a', 'b']);
});

test('BT: Sequence يتذكر الابن الجاري، Inverter وCooldown وTimed', () => {
  let n = 0;
  const seq = new Sequence<null>([new Action(() => 'success'), new Action(() => (++n < 3 ? 'running' : 'success'))]);
  assert.equal(seq.tick(null, 0), 'running');
  assert.equal(seq.tick(null, 0), 'running');
  assert.equal(seq.tick(null, 0), 'success');

  assert.equal(new Inverter<null>(new Condition(() => true)).tick(null, 0), 'failure');

  let fired = 0;
  const cd = new Cooldown<null>(2, new Action(() => (fired++, 'success')));
  cd.tick(null, 0.5);
  assert.equal(cd.tick(null, 0.5), 'failure'); // ما زال في التهدئة
  assert.equal(cd.tick(null, 2), 'success');
  assert.equal(fired, 2);

  const timed = new Timed<null>(() => 1, () => undefined);
  assert.equal(timed.tick(null, 0.4), 'running');
  assert.equal(timed.tick(null, 0.7), 'success');
});

// ---------- توجيه ----------
test('التوجيه: seek/flee/arrive واتجاهات وتدوير', () => {
  const s = seek({ x: 0, z: 0 }, { x: 10, z: 0 }, 2);
  assert.ok(Math.abs(s.x - 2) < 1e-9 && s.z === 0);
  const f = flee({ x: 0, z: 0 }, { x: 5, z: 0 }, 3);
  assert.ok(f.x < 0);
  assert.equal(arrive({ x: 0, z: 0 }, { x: 0.1, z: 0 }, 5).x, 0);
  assert.ok(arrive({ x: 0, z: 0 }, { x: 1.5, z: 0 }, 5, 3).x < 5);
  assert.ok(Math.abs(headingOf({ x: 1, z: 0 }) - Math.PI / 2) < 1e-9);
  assert.ok(Math.abs(turnToward(0, Math.PI * 1.9, 0.1) - -0.1) < 1e-9); // الأقصر عبر الصفر
  // تجنب عائق أمامي
  const h = avoidObstacles({ x: 0, z: 0 }, 0, (x, z) => !(z > 2 && Math.abs(x) < 1.5), 3);
  assert.notEqual(h, 0);
  assert.ok(avoidObstacles({ x: 0, z: 0 }, 0, () => true) === 0);
});

// ---------- الإدراك ----------
const senses: Senses = { sight: 30, fov: 1, hearing: 20, smell: 30 };
const still = { x: 0, z: 0 };

test('الإدراك: الرؤية بمخروط ومدى والظهور، والحاجز يمنعها', () => {
  const ahead = { pos: { x: 0, z: 20 }, noise: 0, visibility: 1 }; // heading 0 = +z
  assert.equal(perceive({ x: 0, z: 0 }, 0, senses, ahead, still).detected, 'see');
  const behind = { pos: { x: 0, z: -20 }, noise: 0, visibility: 1 };
  assert.equal(perceive({ x: 0, z: 0 }, 0, senses, behind, still).detected, 'none');
  const dim = { pos: { x: 0, z: 20 }, noise: 0, visibility: 0.4 }; // ليلًا: المدى 12
  assert.equal(perceive({ x: 0, z: 0 }, 0, senses, dim, still).detected, 'none');
  assert.equal(perceive({ x: 0, z: 0 }, 0, senses, ahead, still, true).detected, 'none');
});

test('الإدراك: السمع يتبع الضجيج (الجري يُسمع من بعيد والانحناء لا)', () => {
  const at = (noise: number) => ({ pos: { x: 0, z: -15 }, noise, visibility: 0 });
  assert.equal(perceive({ x: 0, z: 0 }, 0, senses, at(playerNoise('run')), still).detected, 'hear');
  assert.equal(perceive({ x: 0, z: 0 }, 0, senses, at(playerNoise('crouch')), still).detected, 'none');
});

test('الإدراك: الشم فقط إن هبّت الريح من اللاعب نحو الحيوان', () => {
  const target = { pos: { x: 0, z: 25 }, noise: 0, visibility: 0 };
  // الحيوان عند الأصل، اللاعب عند z=25. الريح تهب من اللاعب نحو الحيوان => باتجاه -z
  assert.equal(perceive({ x: 0, z: 0 }, Math.PI, senses, target, { x: 0, z: -1 }).detected, 'smell');
  assert.equal(perceive({ x: 0, z: 0 }, Math.PI, senses, target, { x: 0, z: 1 }).detected, 'none');
  assert.equal(perceive({ x: 0, z: 0 }, Math.PI, senses, target, still).detected, 'none');
});

// ---------- A* ----------
test('A*: يجد مسارًا حول حاجز، ويرفض المحاصر، وينعّم المسار', () => {
  const wall = (x: number, z: number) => !(Math.abs(x) < 1.5 && z > -10 && z < 10);
  const nav = new NavGrid({ half: 30, cell: 1, walkable: wall });
  const path = nav.findPath({ x: -8, z: 0 }, { x: 8, z: 0 })!;
  assert.ok(path && path.length >= 3);
  assert.ok(path.every((p) => wall(p.x, p.z)));
  assert.deepEqual(path[0], { x: -8, z: 0 });
  // المسار ملتف: يتجاوز طرف الجدار (|z|>=10)
  assert.ok(path.some((p) => Math.abs(p.z) >= 9.5));
  // التنعيم: عدد النقاط قليل مقارنة بعدد الخلايا (~40)
  assert.ok(path.length < 10, `len=${path.length}`);

  const boxed = new NavGrid({ half: 20, cell: 1, walkable: (x, z) => !(Math.hypot(x - 10, z) < 6 && Math.hypot(x - 10, z) > 3) });
  assert.equal(boxed.findPath({ x: -10, z: 0 }, { x: 10, z: 0 }), null);

  // نفس المربع: يعيد نقطة
  assert.ok(nav.findPath({ x: -8, z: 0 }, { x: -8.2, z: 0.1 }));
  // بداية داخل جدار
  assert.equal(nav.findPath({ x: 0, z: 0 }, { x: 8, z: 0 }), null);
  // هدف داخل جدار: أقرب خلية سالكة
  assert.ok(nav.findPath({ x: -8, z: 0 }, { x: 0, z: 0 }));
  // حجب ديناميكي
  const dyn = new NavGrid({ half: 20, cell: 1, walkable: () => true });
  dyn.block(0, 0, 1);
  assert.equal(dyn.isWalkableCell(...(Object.values(dyn.cellOf(0, 0)) as [number, number])), false);
  const p2 = dyn.findPath({ x: -5, z: 0 }, { x: 5, z: 0 })!;
  assert.ok(p2.every((p) => Math.hypot(p.x, p.z) > 1.2));
});

test('الجدول اليومي: لفّ منتصف الليل والاحتياطي', () => {
  const s = new Schedule([
    { from: 22, to: 6, activity: 'sleep', place: 'camp' },
    { from: 6, to: 22, activity: 'work', place: 'beach' },
  ]);
  assert.equal(s.at(23).activity, 'sleep');
  assert.equal(s.at(3).activity, 'sleep');
  assert.equal(s.at(12).activity, 'work');
  assert.equal(s.at(30).activity, 'work'); // 30 % 24 = 6 صباحًا
  assert.equal(s.at(-1).activity, 'sleep'); // -1 → 23
});

// ---------- الحيوانات ----------
const flatWorld = (over: Partial<AIWorld> = {}): AIWorld & { attacks: number[] } => {
  const attacks: number[] = [];
  return {
    height: () => 3,
    slope: () => 0.05,
    biomeAt: () => 'grass',
    hour: 12,
    wind: { x: 0, z: 0 },
    rnd: new Random(1),
    player: { pos: { x: 0, z: 0 }, stimulus: { pos: { x: 0, z: 0 }, noise: 0.1, visibility: 1 }, inWater: false, alive: true, y: 3 },
    onAttackPlayer: (d) => attacks.push(d),
    attacks,
    ...over,
  };
};

const step = (a: Animal, w: AIWorld, seconds: number): void => {
  for (let t = 0; t < seconds; t += 0.1) a.update(0.1, w);
};

test('الغزال يهرب من اللاعب القريب ويبتعد', () => {
  const w = flatWorld();
  const deer = new Animal(SPECIES.deer, 0, 15, new Random(2));
  deer.heading = Math.PI; // ينظر نحو اللاعب (−z)
  const d0 = Math.hypot(deer.pos.x, deer.pos.z);
  step(deer, w, 4);
  assert.equal(deer.state, 'flee');
  assert.ok(Math.hypot(deer.pos.x, deer.pos.z) > d0 + 8);
});

test('الغزال يرعى/يتجول بسلام بعيدًا عن اللاعب ولا يخرج إلى الماء', () => {
  const w = flatWorld({ player: { pos: { x: 500, z: 500 }, stimulus: { pos: { x: 500, z: 500 }, noise: 0.1, visibility: 1 }, inWater: false, alive: true, y: 3 }, height: (x) => (x > 12 ? -2 : 3) });
  const deer = new Animal(SPECIES.deer, 0, 0, new Random(3));
  step(deer, w, 60);
  assert.ok(['wander', 'graze', 'idle'].includes(deer.state));
  assert.ok(deer.pos.x <= 12.5, `x=${deer.pos.x}`);
});

test('الخنزير محايد: يتجاهل الهادئ ويهاجم بعد الإصابة', () => {
  const w = flatWorld();
  w.player.pos = { x: 0, z: 20 };
  w.player.stimulus = { pos: { x: 0, z: 20 }, noise: 0.05, visibility: 0.3 };
  const boar = new Animal(SPECIES.boar, 0, 0, new Random(4));
  step(boar, w, 5);
  assert.equal(w.attacks.length, 0);

  boar.hurt(5, w.player.pos, new Random(1));
  w.player.pos = { x: 0, z: 3 };
  w.player.stimulus = { pos: { x: 0, z: 3 }, noise: 0.8, visibility: 1 };
  step(boar, w, 6);
  assert.ok(w.attacks.length >= 1);
  assert.equal(w.attacks[0], SPECIES.boar.damage);
});

test('الأفعى تكمن: لا تتحرك ولا تهاجم إلا ضمن نصف قطر قصير', () => {
  const w = flatWorld();
  w.player.pos = { x: 0, z: 10 };
  w.player.stimulus = { pos: { x: 0, z: 10 }, noise: 0.9, visibility: 1 };
  const snake = new Animal(SPECIES.snake, 0, 0, new Random(5));
  step(snake, w, 3);
  assert.equal(w.attacks.length, 0);
  assert.equal(snake.state, 'idle');
  w.player.pos = { x: 0, z: 1.2 };
  step(snake, w, 3);
  assert.ok(w.attacks.length >= 1);
});

test('النمر: نهارًا ينام، ليلًا يطارد ويهاجم', () => {
  const day = flatWorld({ hour: 12 });
  day.player.pos = { x: 0, z: 30 };
  day.player.stimulus = { pos: { x: 0, z: 30 }, noise: 0.3, visibility: 1 };
  const j1 = new Animal(SPECIES.jaguar, 0, 0, new Random(6));
  step(j1, day, 5);
  assert.equal(j1.state, 'sleep');
  assert.equal(day.attacks.length, 0);

  const night = flatWorld({ hour: 23 });
  night.player.pos = { x: 0, z: 12 };
  night.player.stimulus = { pos: { x: 0, z: 12 }, noise: 0.9, visibility: 0.8 };
  const j2 = new Animal(SPECIES.jaguar, 0, 0, new Random(7));
  j2.heading = 0;
  step(j2, night, 8);
  assert.ok(night.attacks.length >= 1, `state=${j2.state}`);
  assert.equal(night.attacks[0], SPECIES.jaguar.damage);
});

test('القرش: يهاجم فقط اللاعب في الماء ويبقى في المياه العميقة', () => {
  const deep = (x: number) => (x < 40 ? -10 : 2);
  const w = flatWorld({ height: deep });
  w.player.pos = { x: 0, z: 8 };
  w.player.inWater = false;
  w.player.stimulus = { pos: { x: 0, z: 8 }, noise: 0.9, visibility: 1 };
  const shark = new Animal(SPECIES.shark, 0, 0, new Random(8));
  step(shark, w, 5);
  assert.equal(w.attacks.length, 0);
  w.player.inWater = true;
  step(shark, w, 8);
  assert.ok(w.attacks.length >= 1);
  assert.ok(shark.y < 0);
});

test('القتل: غنائم ضمن الجدول مرة واحدة، والجثة تبقى ثم تُحذف', () => {
  const w = flatWorld();
  const deer = new Animal(SPECIES.deer, 0, 2, new Random(2));
  const drops = deer.hurt(999, { x: 0, z: 0 }, new Random(11))!;
  assert.ok(drops.some((d) => d.id === 'raw_meat'));
  assert.equal(deer.hurt(5, { x: 0, z: 0 }, new Random(11)), null);
  assert.equal(deer.alive, false);

  const mgr = new AnimalManager();
  mgr.animals.push(deer);
  mgr.update(121, w);
  assert.equal(mgr.animals.length, 0);
});

test('المدير: التوزيع حسب البيوم حتمي، وهجوم اللاعب يصيب الأمامي فقط', () => {
  const sampler = {
    height: (x: number, z: number) => (Math.hypot(x, z) < 150 ? 4 : -20),
    slope: () => 0.1,
    moisture: () => 0.7,
    biomeAt: (x: number, z: number) => (Math.hypot(x, z) < 150 ? 'jungle' : 'deepSea'),
  };
  const a = new AnimalManager();
  const b = new AnimalManager();
  const na = a.populate(sampler as never, 's', 200);
  const nb = b.populate(sampler as never, 's', 200);
  assert.equal(na, nb);
  assert.ok(a.count('deer') > 0 && a.count('boar') > 0 && a.count('shark') > 0);
  assert.equal(a.count('crab'), 0); // لا شاطئ
  for (const an of a.animals) {
    const inside = Math.hypot(an.pos.x, an.pos.z) < 150;
    if (an.species.domain === 'water') assert.ok(!inside);
    if (an.species.domain === 'land') assert.ok(inside);
  }

  const m = new AnimalManager();
  const w = flatWorld();
  const front = new Animal(SPECIES.deer, 0, -2, new Random(1)); // yaw=0 ينظر نحو -z
  const behind = new Animal(SPECIES.deer, 0, 2, new Random(1));
  m.animals.push(behind, front);
  const killed: string[] = [];
  m.onKilled = (an) => killed.push(String(an.id));
  const r = m.playerAttack(w, { x: 0, z: 0 }, 0, 999);
  assert.equal(r.hit, front);
  assert.ok(r.killed);
  assert.equal(killed.length, 1);
  // الأمامي مات؛ الضربة التالية بنفس الاتجاه لا تصيب شيئًا (الآخر خلفه)
  assert.equal(m.playerAttack(w, { x: 0, z: 0 }, 0, 999).hit, null);
  // وبالالتفات 180° تصيب الخلفي
  assert.equal(m.playerAttack(w, { x: 0, z: 0 }, Math.PI, 999).hit, behind);
});

// ---------- الحوار والثقة ----------
const ctx = (trust = 0, flags: string[] = [], items: Record<string, number> = {}): DialogueContext => ({ trust, flags: new Set(flags), itemCount: (id) => items[id] ?? 0 });

test('الحوار: الشروط', () => {
  assert.ok(checkCondition(undefined, ctx()));
  assert.ok(checkCondition({ minTrust: 10 }, ctx(10)));
  assert.ok(!checkCondition({ minTrust: 10 }, ctx(9)));
  assert.ok(!checkCondition({ hasFlags: ['a'] }, ctx()));
  assert.ok(!checkCondition({ notFlags: ['a'] }, ctx(0, ['a'])));
  assert.ok(checkCondition({ hasItems: [{ id: 'x', count: 2 }] }, ctx(0, [], { x: 2 })));
});

test('الحوار: كل العقد والوجهات صالحة وثنائية اللغة في كل ناجٍ', () => {
  assert.equal(NPC_DEFS.length, 3);
  for (const def of NPC_DEFS) {
    const g = def.dialogue;
    assert.ok(g.nodes[g.start], def.id);
    for (const n of Object.values(g.nodes)) {
      assert.ok(n.textAr.length > 5 && n.textEn.length > 5, `${def.id}.${n.id}`);
      for (const v of n.variants ?? []) assert.ok(g.nodes[v.node], `${def.id}.${n.id}→${v.node}`);
      assert.ok(n.choices.length > 0, `${def.id}.${n.id} بلا خيارات`);
      for (const c of n.choices) {
        assert.ok(c.textAr && c.textEn);
        if (c.next !== null) assert.ok(g.nodes[c.next], `${def.id}.${n.id}→${c.next}`);
      }
    }
    // كل عقدة يمكن الوصول إليها
    const seen = new Set<string>();
    const visit = (id: string): void => {
      if (seen.has(id)) return;
      seen.add(id);
      const n = g.nodes[id];
      n.variants?.forEach((v) => visit(v.node));
      n.choices.forEach((c) => c.next && visit(c.next));
    };
    visit(g.start);
    assert.deepEqual(Object.keys(g.nodes).filter((k) => !seen.has(k)), [], `${def.id} unreachable`);
  }
});

test('الحوار: مسار ليلى — الثقة والأفعال والتفرع حسب العناصر والرايات', () => {
  const layla = NPC_DEFS.find((d) => d.id === 'layla')!.dialogue as DialogueGraph;
  const r = new DialogueRunner(layla, ctx());
  assert.equal(r.current()!.node.id, 'hello');
  r.choose(2); // جرح
  assert.equal(r.current()!.node.id, 'treat');
  r.choose(0);
  assert.ok(r.finished);
  assert.equal(r.log.trustDelta, 7);
  assert.deepEqual(r.log.actions, ['give_item:bandage:2']);
  assert.ok(r.log.flags.includes('layla_met'));

  // زيارة ثانية: المتغيّر 'again'
  const r2 = new DialogueRunner(layla, ctx(7, ['layla_met']));
  assert.equal(r2.current()!.node.id, 'again');
  r2.choose(1);
  // خيار الأعشاب مخفي بلا عناصر
  assert.equal(r2.current()!.choices.some((c) => c.choice.next === 'thanks'), false);
  assert.equal(new DialogueRunner(layla, ctx(7, ['layla_met'], { medicinal_herb: 10 })).current()!.node.id, 'again');

  // ثقة عالية: الحقيقة ثم الحقيبة
  const r3 = new DialogueRunner(layla, ctx(30, ['layla_met']));
  assert.equal(r3.current()!.node.id, 'friendly');
  r3.choose(0);
  assert.deepEqual(r3.log.actions, ['give_item:first_aid_kit:1']);
  assert.ok(r3.log.flags.includes('layla_gave_kit'));
});

test('الحوار: مسار عمر ويوسف حتى الراديو والمفتاح', () => {
  const omar = NPC_DEFS.find((d) => d.id === 'omar')!.dialogue;
  const o = new DialogueRunner(omar, ctx());
  o.choose(0);
  assert.ok(o.log.actions.includes('quest:repair_radio'));
  const o2 = new DialogueRunner(omar, ctx(0, ['omar_met', 'omar_battery_given']));
  assert.equal(o2.current()!.node.id, 'battery_in');
  o2.choose(0);
  assert.ok(o2.log.actions.includes('flag:radio_done'));

  const yusuf = NPC_DEFS.find((d) => d.id === 'yusuf')!.dialogue;
  const y = new DialogueRunner(yusuf, ctx(40, ['yusuf_met']));
  assert.equal(y.current()!.node.id, 'secret');
  y.choose(0);
  assert.deepEqual(y.log.actions, ['give_item:bunker_key:1']);

  // لا ظهور لخيار الشبكة بدون العنصر
  const y2 = new DialogueRunner(yusuf, ctx(0, ['yusuf_met', 'know_battery_yusuf']));
  y2.choose(0);
  assert.equal(y2.current()!.node.id, 'battery_ask');
  assert.equal(y2.current()!.choices.length, 1);
  assert.equal(new DialogueRunner(yusuf, ctx()).choose(99), false);
});

// ---------- الناجون ----------
test('الناجي: مستويات الثقة، الهدايا بحد يومي، والجدول والحركة', () => {
  assert.equal(trustLevel(-50), 'hostile');
  assert.equal(trustLevel(0), 'neutral');
  assert.equal(trustLevel(80), 'trusted');

  const layla = new NPC(NPC_DEFS[0], { x: 0, z: 0 });
  assert.equal(layla.gift('honey', 1).delta, 6);
  assert.equal(layla.gift('stone', 1).delta, 1);
  layla.gift('honey', 1);
  assert.equal(layla.gift('honey', 1).accepted, false); // الحد 3
  assert.equal(layla.gift('honey', 2).accepted, true); // يوم جديد
  assert.equal(layla.trust, 6 + 1 + 6 + 6);

  layla.adjustTrust(1000);
  assert.equal(layla.trust, 100);

  const places = { camp: { x: 30, z: 0 }, forest: { x: 0, z: 40 } };
  const n = new NPC(NPC_DEFS[0], { x: 0, z: 0 });
  for (let t = 0; t < 60; t += 0.5) n.update(0.5, 8, places); // 8 صباحًا => forest
  assert.equal(n.activity, 'forage');
  assert.ok(n.pos.z > 30 && Math.abs(n.pos.x) < 1);
  n.update(1, 23, places);
  assert.equal(n.activity, 'sleep');

  const saved = JSON.parse(JSON.stringify(n.toJSON()));
  const m = new NPC(NPC_DEFS[0], { x: 5, z: 5 });
  m.load(saved);
  assert.equal(m.trust, n.trust);
});
