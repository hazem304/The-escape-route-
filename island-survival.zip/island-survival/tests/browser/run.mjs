// تشغيل: node tests/browser/run.mjs  (يتطلب esbuild وplaywright وChromium)
import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url);
const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, '..', '..');
const esbuild = require(process.env.ESBUILD_PATH ?? '/opt/npm-tools/node_modules/esbuild');
const { chromium } = require('playwright');
const out = process.env.OUT_DIR ?? join(root, '.browser-test');
mkdirSync(out, { recursive: true });

await esbuild.build({ entryPoints: [join(here, 'harness.ts')], bundle: true, outfile: join(out, 'h.js'), format: 'iife', loader: { '.json': 'json' }, logLevel: 'error', target: 'es2022' });
writeFileSync(join(out, 'index.html'), `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><link rel="stylesheet" href="h.css"><style>body{margin:0;background:#1a3a4a;height:100vh}</style></head><body><script src="h.js"></script></body></html>`);

const browser = await chromium.launch();
const results = [];
const ok = (name, cond, extra = '') => { results.push({ name, ok: !!cond, extra }); console.log(`${cond ? 'PASS' : 'FAIL'} ${name} ${extra}`); };

async function run(viewport, tag) {
  const page = await browser.newPage({ viewport });
  const errors = [];
  page.on('pageerror', (e) => { errors.push(e.message); console.log('PAGEERR', e.message); });
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  await page.goto('file://' + join(out, 'index.html'));
  await page.waitForFunction(() => window.T, null, { timeout: 8000 });
  const T = (fn, ...a) => page.evaluate(fn, ...a);

  // --- حقيبة
  await T(() => { window.T.ui.open('backpack'); window.T.update(); });
  await page.screenshot({ path: join(out, `${tag}-backpack.png`) });
  const nItems = await T(() => document.querySelectorAll('#panel-backpack .igrid .item').length);
  ok(`${tag} الحقيبة ترسم العناصر`, nItems >= 7, `n=${nItems}`);

  // سحب حقيقي لعنصر الحجر إلى خلية فارغة
  const info = await T(() => {
    const s = window.T.session; const g = s.inventory.grid;
    const e = g.list().find((x) => x.stack.defId === 'stone');
    return { uid: e.stack.uid, x: e.x, y: e.y };
  });
  const tile = page.locator(`#panel-backpack .igrid .item[data-uid="${info.uid}"]`);
  const box = await tile.boundingBox();
  const gridBox = await page.locator('#panel-backpack .igrid').first().boundingBox();
  const cell = await T(() => parseFloat(getComputedStyle(document.getElementById('panel-backpack')).getPropertyValue('--cell')));
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width / 2 + 20, box.y + box.height / 2 + 20, { steps: 4 });
  const ghost = await T(() => !!document.querySelector('.ghost'));
  ok(`${tag} ظهور شبح السحب`, ghost);
  // إلى الخلية (6,4)
  await page.mouse.move(gridBox.x + 6.5 * cell, gridBox.y + 4.5 * cell, { steps: 6 });
  await page.mouse.up();
  const after = await T((uid) => { const e = window.T.session.inventory.grid.get(uid); return e && { x: e.x, y: e.y }; }, info.uid);
  ok(`${tag} الإفلات يغيّر الموضع`, after && (after.x !== info.x || after.y !== info.y), JSON.stringify({ from: info, to: after }));

  // نقرة = تحديد + شريط إجراءات
  const berry = await T(() => window.T.session.inventory.grid.list().find((x) => x.stack.defId === 'berries').stack.uid);
  await page.locator(`#panel-backpack .igrid .item[data-uid="${berry}"]`).click();
  const acts = await T(() => document.querySelectorAll('#panel-backpack .actions button').length);
  ok(`${tag} شريط الإجراءات يظهر عند التحديد`, acts >= 3, `n=${acts}`);
  const hungerBefore = await T(() => (window.T.session.survival.stats.hunger = 40));
  await page.locator('#panel-backpack .actions button.primary').first().click();
  const hungerAfter = await T(() => window.T.session.survival.stats.hunger);
  ok(`${tag} الاستخدام يرفع الشبع`, hungerAfter > hungerBefore, `${hungerBefore}→${hungerAfter}`);

  // سحب إلى الشريط السريع
  const axe = await T(() => window.T.session.inventory.grid.list().find((x) => x.stack.defId === 'axe_stone').stack.uid);
  const ab = await page.locator(`#panel-backpack .igrid .item[data-uid="${axe}"]`).boundingBox();
  const hb = await page.locator('.hslot[data-hslot="2"]').boundingBox();
  await page.mouse.move(ab.x + 10, ab.y + 10); await page.mouse.down();
  await page.mouse.move(ab.x + 30, ab.y + 30, { steps: 3 });
  await page.mouse.move(hb.x + hb.width / 2, hb.y + hb.height / 2, { steps: 6 });
  await page.mouse.up();
  const hot = await T(() => window.T.session.inventory.hotbar.slots[2]);
  ok(`${tag} الإفلات على الشريط السريع`, hot === axe, `slot2=${hot}`);
  const hotHtml = await T(() => document.querySelector('.hslot[data-hslot="2"]').textContent);
  await T(() => window.T.update(0.3));
  ok(`${tag} الشريط السريع يعرض الأيقونة`, (await T(() => document.querySelector('.hslot[data-hslot="2"]').textContent)).includes('🪓') || (await T(() => document.querySelector('.hslot[data-hslot="2"]').textContent)).length > 1, hotHtml);

  // رمي خارج اللوحة
  const rope = await T(() => window.T.session.inventory.grid.list().find((x) => x.stack.defId === 'rope').stack.uid);
  const rb = await page.locator(`#panel-backpack .igrid .item[data-uid="${rope}"]`).boundingBox();
  const g0 = await T(() => window.T.session.ground.size);
  await page.mouse.move(rb.x + 10, rb.y + 10); await page.mouse.down();
  await page.mouse.move(rb.x + 30, rb.y + 30, { steps: 3 });
  await page.mouse.move(5, 5, { steps: 6 });
  await page.mouse.up();
  ok(`${tag} الرمي خارج اللوحة يضيف للأرض`, (await T(() => window.T.session.ground.size)) === g0 + 1);
  await T(() => window.T.ui.close('backpack'));

  // --- صنع
  await T(() => { window.T.ui.open('craft'); });
  await page.screenshot({ path: join(out, `${tag}-craft.png`) });
  const recipes = await T(() => document.querySelectorAll('#panel-craft .recipe').length);
  ok(`${tag} قائمة الوصفات`, recipes > 0, `n=${recipes}`);
  await T(() => window.T.session.giveItem('plant_fiber', 6));
  await page.locator('#panel-craft .recipe', { hasText: /حبل|Rope/ }).first().click();
  const ropeBefore = await T(() => window.T.session.inventory.count('rope'));
  await page.locator('#panel-craft .detail button.primary').click();
  await T(() => { for (let i = 0; i < 60; i++) window.T.session.update(0.5, { x: window.T.session.spawnPoint.x, y: window.T.session.spawnPoint.y, z: window.T.session.spawnPoint.z, yaw: 0, loco: 'idle', inWater: false, working: false }, { weatherTempDelta: 0, rainIntensity: 0, windX: 0, windZ: 0, waveAmp: 0.3, inCave: false }); });
  ok(`${tag} الصنع ينتج العنصر`, (await T(() => window.T.session.inventory.count('rope'))) > ropeBefore);
  await T(() => window.T.ui.close('craft'));

  // --- خريطة
  await T(() => window.T.ui.open('map'));
  const nonBlank = await T(() => { const c = document.querySelector('canvas.map'); const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let n = 0; for (let i = 3; i < d.length; i += 4000) n += d[i] ? 1 : 0; return n; });
  ok(`${tag} الخريطة مرسومة`, nonBlank > 50, `n=${nonBlank}`);
  await page.screenshot({ path: join(out, `${tag}-map.png`) });
  await T(() => window.T.ui.close('map'));

  // --- مذكرات
  await T(() => window.T.ui.open('journal'));
  ok(`${tag} المهام تظهر`, (await T(() => document.querySelectorAll('#panel-journal .quest').length)) > 0);
  await page.screenshot({ path: join(out, `${tag}-journal.png`) });
  await T(() => window.T.ui.close('journal'));

  // --- حوار
  await T(() => window.T.ui.open('dialogue') && 0);
  await T(() => { window.T.ui.close('dialogue'); window.T.ui.dialogue.start('layla'); });
  const choices = await T(() => document.querySelectorAll('#panel-dialogue .choices button').length);
  ok(`${tag} الحوار يعرض خيارات`, choices >= 2, `n=${choices}`);
  await page.screenshot({ path: join(out, `${tag}-dialogue.png`) });
  await page.locator('#panel-dialogue .choices button').first().click();
  await T(() => window.T.ui.closeAll());

  // --- قائمة الإيقاف: حفظ وتحميل
  await T(() => window.T.ui.open('pause'));
  await page.locator('#panel-pause button', { hasText: /حفظ|Save/ }).first().click();
  await page.waitForSelector('#panel-pause .slotrow');
  const stoneBefore = await T(() => window.T.session.inventory.count('stone'));
  page.once('dialog', (d) => d.accept());
  await page.locator('#panel-pause .slotrow button.primary').first().click();
  await page.waitForTimeout(200);
  await T(() => window.T.session.inventory.remove('stone', 2));
  await T(() => window.T.ui.open('pause'));
  await page.locator('#panel-pause button', { hasText: /تحميل|Load/ }).first().click();
  await page.waitForSelector('#panel-pause .slotrow');
  await page.locator('#panel-pause .slotrow button.primary').first().click();
  await page.waitForTimeout(300);
  ok(`${tag} حفظ ثم تحميل يستعيد الحقيبة`, (await T(() => window.T.session.inventory.count('stone'))) === stoneBefore);
  await T(() => window.T.ui.open('pause'));
  await page.locator('#panel-pause button', { hasText: /الإعدادات|Settings/ }).first().click();
  await page.screenshot({ path: join(out, `${tag}-settings.png`) });
  await page.locator('#panel-pause select').first().selectOption('en');
  ok(`${tag} تبديل اللغة يقلب الاتجاه`, (await T(() => document.documentElement.dir)) === 'ltr');
  await T(() => { window.T.setLanguage('ar'); window.T.ui.closeAll(); });

  // --- HUD والإشعارات والنهاية
  await T(() => { window.T.session.survival.stats.health = 15; window.T.update(0.3); });
  ok(`${tag} HUD يعرض الصحة المنخفضة`, await T(() => document.querySelector('.bar.health').classList.contains('low')));
  await T(() => window.T.session.notify('اختبار', 'test'));
  await T(() => window.T.update(0.3));
  ok(`${tag} إشعار الجلسة يظهر`, (await T(() => document.querySelector('.toasts').textContent)).includes('اختبار'));
  await page.screenshot({ path: join(out, `${tag}-hud.png`) });
  await T(() => window.T.ui.open('ending') || window.T.ui.ending.show('rescue'));
  ok(`${tag} شاشة النهاية`, (await T(() => document.querySelector('#panel-ending h1')?.textContent ?? '')).length > 0);
  await page.screenshot({ path: join(out, `${tag}-ending.png`) });

  ok(`${tag} لا أخطاء في المتصفح`, errors.length === 0, errors.slice(0, 3).join(' | '));
  const logErr = await T(() => window.T.log.filter((l) => l.startsWith('ERROR') || l.startsWith('REJECT')));
  ok(`${tag} لا أخطاء مسجلة`, logErr.length === 0, logErr.join('|'));
  await page.close();
}
await run({ width: 1280, height: 800 }, 'desktop');
await run({ width: 390, height: 780 }, 'phone');
await browser.close();
const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
