// نقطة دخول تُجمَّع بـ esbuild وتُشغَّل في Chromium: واجهة حقيقية فوق GameSession حقيقية (بلا three).
import '../../src/ui/ui.css';
import { loadConfig, type GameConfig } from '../../src/config';
import { GameSession } from '../../src/core/GameSession';
import { setLanguage } from '../../src/core/i18n';
import { MemoryBackend, SaveSystem } from '../../src/core/SaveSystem';
import { TerrainGenerator } from '../../src/world/TerrainGenerator';
import { UIManager } from '../../src/ui/UIManager';
import type { GameUIHost } from '../../src/ui/UIHost';

const terrain = new TerrainGenerator('ui-seed');
let session = new GameSession('ui-seed', terrain);
const saves = new SaveSystem(new MemoryBackend());
const config: GameConfig = { ...loadConfig() };
const sp = session.spawnPoint;
const pl = { x: sp.x, y: sp.y, z: sp.z, yaw: 0 };
const log: string[] = [];

const host: GameUIHost = {
  get session() { return session; },
  player: () => pl,
  notify: (t, k) => { log.push(`notify:${k ?? 'info'}:${t}`); ui.hud.notifications.push(t, k); },
  sfx: (n) => { log.push(`sfx:${n}`); },
  saves, config,
  setConfig: (p) => { Object.assign(config, p); if (p.language) setLanguage(p.language); },
  saveTo: async (slot) => { await saves.save(slot, session.toJSON(pl)); return true; },
  loadFrom: async (slot) => { const r = await saves.load(slot); if (!r.ok) return false; session.load(r.data); return true; },
  newGame: () => { session = new GameSession('ui-seed', terrain); log.push('newGame'); },
  resume: () => ui.closeAll(),
  startBuild: (t) => log.push(`build:${t}`),
  setDemolish: (on) => log.push(`demolish:${on}`),
  panelClosed: () => log.push('panelClosed'),
};

setLanguage('ar');
const ui = new UIManager(host);
session.inventory.grid.resize(8, 6);
for (const [id, n] of [['stick', 8], ['stone', 5], ['plant_fiber', 6], ['wood_log', 3], ['berries', 4], ['water_boiled', 1], ['axe_stone', 1], ['campfire_kit', 1], ['rope', 3]] as Array<[string, number]>) session.giveItem(id, n);
ui.update(0.016);

(window as unknown as Record<string, unknown>).T = { ui, host, log, get session() { return session; }, terrain, config, update: (dt = 0.3) => ui.update(dt), setLanguage };
window.addEventListener('error', (e) => log.push(`ERROR:${e.message}`));
window.addEventListener('unhandledrejection', (e) => log.push(`REJECT:${String(e.reason)}`));
