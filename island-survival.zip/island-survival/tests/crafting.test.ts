import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Inventory } from '../src/inventory/Inventory';
import { ItemDB } from '../src/inventory/ItemDatabase';
import { RecipeBook } from '../src/crafting/RecipeBook';
import { CraftQueue, checkRecipe, craft, type CraftContext } from '../src/crafting/CraftingStation';
import { createCampfireStation } from '../src/crafting/Cooking';
import { createFurnace } from '../src/crafting/Smelting';
import { Skills } from '../src/survival/Skills';
import { BuildingGrid, type GroundQuery } from '../src/building/Snap';
import type { Station } from '../src/crafting/Recipe';

const book = new RecipeBook();
const rec = (id: string) => {
  const r = book.get(id);
  assert.ok(r, id);
  return r!;
};
const bag = (): Inventory => {
  const inv = new Inventory();
  inv.grid.resize(10, 6);
  return inv;
};
const ctxWith = (...st: Station[]): CraftContext => ({ stations: new Set(st), skills: new Skills() });

test('كل الوصفات صالحة ولكل عنصر ناتج تعريف', () => {
  assert.ok(book.all.length >= 60);
  for (const r of book.all) {
    assert.ok(ItemDB.has(r.output.id), r.id);
    assert.ok(r.ingredients.length > 0, r.id);
    for (const g of r.ingredients) assert.ok(ItemDB.has(g.id) && g.count > 0, `${r.id}:${g.id}`);
  }
});

test('كل عنصر قابل للصنع يمكن الوصول إليه من خامات أساسية (لا حلقات مفرغة)', () => {
  // الخامات الأولية: لا وصفة تنتجها (تُجمع من العالم)
  const produced = new Set(book.all.map((r) => r.output.id));
  const reachable = new Set<string>(ItemDB.all().map((d) => d.id).filter((id) => !produced.has(id)));
  let changed = true;
  while (changed) {
    changed = false;
    for (const r of book.all) {
      if (reachable.has(r.output.id)) continue;
      if (r.ingredients.every((g) => reachable.has(g.id)) && r.tools.every((t) => reachable.has(t))) {
        reachable.add(r.output.id);
        changed = true;
      }
    }
  }
  const stuck = book.all.filter((r) => !reachable.has(r.output.id)).map((r) => r.id);
  assert.deepEqual(stuck, []);
});

test('الصنع: يستهلك المكونات ويضيف الناتج ويكسب خبرة', () => {
  const inv = bag();
  const c = ctxWith();
  inv.add('plant_fiber', 8);
  const res = craft(rec('rope_fiber'), inv, c);
  assert.ok(res.ok);
  assert.equal(inv.count('plant_fiber'), 4);
  assert.equal(inv.count('rope'), 1);
  assert.ok(c.skills.xp.crafting > 0);
});

test('النواقص: مكونات، أداة، محطة، مهارة', () => {
  const inv = bag();
  const m1 = checkRecipe(rec('axe_stone'), inv, ctxWith());
  assert.ok(m1.some((m) => m.kind === 'ingredient'));
  const m2 = checkRecipe(rec('firewood_log'), inv, ctxWith());
  assert.ok(m2.some((m) => m.kind === 'tool'));
  const m3 = checkRecipe(rec('smelt_iron'), inv, ctxWith());
  assert.ok(m3.some((m) => m.kind === 'station'));
  const m4 = checkRecipe(rec('backpack_leather'), inv, ctxWith('workbench'));
  assert.ok(m4.some((m) => m.kind === 'skill'));
});

test('الأدوات تتآكل ولا تُستهلك، وتتحطم عند نفادها', () => {
  const inv = bag();
  inv.add('axe_stone', 1);
  const axeUid = inv.grid.list()[0].stack.uid;
  inv.grid.get(axeUid)!.stack.durability = 2;
  inv.add('wood_log', 2);
  const c = ctxWith();
  assert.ok(craft(rec('firewood_log'), inv, c).ok);
  assert.equal(inv.grid.get(axeUid)!.stack.durability, 1);
  assert.ok(craft(rec('firewood_log'), inv, c).ok);
  assert.equal(inv.count('axe_stone'), 0); // تحطم
  assert.equal(inv.count('firewood'), 6);
});

test('الصنع ذرّي: لا مكان للناتج = لا يضيع شيء', () => {
  const inv = new Inventory(); // 4×2 فقط
  inv.grid.add('wood_log', 4); // 4 جذوع 1×2 تملأ الشبكة: كل مكدّس يتسع 5 => مكدّس واحد؟ نملأ بأنواع مختلفة
  inv.grid.clear();
  for (const id of ['axe_iron', 'axe_stone', 'pickaxe_stone', 'pickaxe_iron']) inv.grid.add(id, 1); // 4 × (1×2) = 8 خانات
  inv.grid.add('plant_fiber', 4); // لا يتسع => 4 متبقية
  assert.equal(inv.count('plant_fiber'), 0);
  // نحرر خانة واحدة فقط ثم نضع مكوّنًا
  const first = inv.grid.list()[0];
  inv.grid.remove(first.stack.uid);
  inv.grid.add('plant_fiber', 4); // يأخذ خانة واحدة
  // الناتج rope 1×1 سيجد الخانة الثانية الشاغرة؟ نتأكد بملئها
  inv.grid.add('stick', 1);
  const before = JSON.stringify(inv.grid.toJSON());
  const res = craft(rec('rope_fiber'), inv, ctxWith());
  if (res.ok) {
    // وجد مكانًا بعد تحرير خانة المكون: مقبول
    assert.equal(inv.count('rope'), 1);
  } else {
    assert.deepEqual(res.missing, [{ kind: 'space' }]);
    assert.equal(JSON.stringify(inv.grid.toJSON()), before);
  }
});

test('الاكتشاف: تنفتح الوصفة حين يرى اللاعب كل المكونات', () => {
  const b = new RecipeBook();
  assert.equal(b.isUnlocked('axe_stone'), false);
  b.noteItem('stone_blade');
  b.noteItem('stick');
  assert.equal(b.isUnlocked('axe_stone'), false);
  const opened = b.noteItem('rope');
  assert.ok(opened.some((r) => r.id === 'axe_stone'));
  assert.ok(b.isUnlocked('axe_stone'));
  assert.deepEqual(b.noteItem('rope'), []);
});

test('الصنع المؤقّت: المكونات تُستهلك فورًا والناتج بعد الوقت', () => {
  const inv = bag();
  inv.add('stone', 2);
  const q = new CraftQueue();
  const c = ctxWith();
  assert.ok(q.start(rec('stone_blade'), inv, c).ok);
  assert.equal(inv.count('stone'), 0);
  assert.equal(q.update(2, inv, c).length, 0);
  assert.ok(q.progress > 0.4 && q.progress < 0.6);
  const ev = q.update(3, inv, c);
  assert.equal(ev.length, 1);
  assert.equal(inv.count('stone_blade'), 1);
  // إلغاء يعيد المكونات
  inv.add('stone', 2);
  q.start(rec('stone_blade'), inv, c);
  q.cancel(0, inv);
  assert.equal(inv.count('stone'), 2);
});

test('الطبخ: يتقدم مع الحرارة، ويحترق إن تُرك، ولا يعمل بدون نار', () => {
  const inv = bag();
  inv.add('raw_fish', 2);
  const st = createCampfireStation();
  assert.ok(st.insert(rec('cook_fish'), inv).ok);
  assert.ok(st.insert(rec('cook_fish'), inv).ok);
  assert.equal(inv.count('raw_fish'), 0);
  st.update(100, 0); // بلا نار
  assert.equal(st.slots[0]!.state, 'processing');
  st.update(22, 1); // زمن الوصفة 20 ثانية بحرارة 1
  assert.equal(st.slots[0]!.state, 'done');
  assert.ok(st.collect(0, inv).ok);
  assert.equal(inv.count('cooked_fish'), 1);
  st.update(100, 1); // المتبقي يحترق
  assert.equal(st.slots[1]!.state, 'burnt');
  assert.ok(st.collect(1, inv).ok);
  assert.equal(inv.count('charcoal'), 1);
});

test('الصهر: يحتاج حرارة عالية ويستهلك الفحم', () => {
  const inv = bag();
  inv.add('iron_ore', 2);
  inv.add('charcoal', 1);
  const f = createFurnace();
  assert.ok(f.insert(rec('smelt_iron'), inv).ok);
  assert.equal(inv.count('charcoal'), 0);
  f.update(1000, 0.3); // أقل من الحد
  assert.equal(f.slots[0]!.state, 'processing');
  f.update(60, 1);
  assert.equal(f.slots[0]!.state, 'done');
  assert.ok(f.collect(0, inv).ok);
  assert.equal(inv.count('iron_ingot'), 1);
  assert.equal(f.insert(rec('cook_fish'), inv).reason, 'wrongStation');
});

test('المهارات: المستويات والتقدم', () => {
  const s = new Skills();
  const ups: number[] = [];
  s.onLevelUp = (_n, l) => ups.push(l);
  s.addXp('crafting', 9);
  assert.equal(s.level('crafting'), 0);
  s.addXp('crafting', 1);
  assert.equal(s.level('crafting'), 1);
  s.addXp('crafting', 100);
  assert.deepEqual(ups, [1, 3]); // حدث واحد عند كل ارتفاع بالمستوى الجديد
  assert.ok(s.progress('crafting') >= 0 && s.progress('crafting') <= 1);
});

// ---------------- البناء ----------------
const flat: GroundQuery = { height: () => 2, slope: () => 0.05, waterLevel: 0 };

test('البناء: أساس ثم جدار ثم إطار باب وباب ثم سقف', () => {
  const g = new BuildingGrid(flat);
  const f = g.build('foundation', { kind: 'cell', cx: 0, cz: 0 });
  assert.ok(f.ok);
  assert.equal(g.build('foundation', { kind: 'cell', cx: 0, cz: 0 }).ok, false); // مشغول

  // جدار بلا أساس مجاور مرفوض
  assert.deepEqual(g.build('wall', { kind: 'edge', cx: 5, cz: 5, axis: 'h' }), { ok: false, error: 'noSupport' });

  assert.ok(g.build('wall', { kind: 'edge', cx: 0, cz: 0, axis: 'h' }).ok);
  assert.deepEqual(g.build('wall', { kind: 'edge', cx: 0, cz: 0, axis: 'h' }), { ok: false, error: 'occupied' });

  // الباب يحتاج إطار باب
  assert.deepEqual(g.build('door', { kind: 'edge', cx: 0, cz: 1, axis: 'h' }), { ok: false, error: 'noDoorway' });
  assert.ok(g.build('doorway', { kind: 'edge', cx: 0, cz: 1, axis: 'h' }).ok);
  assert.ok(g.build('door', { kind: 'edge', cx: 0, cz: 1, axis: 'h' }).ok);

  // الخلية (0,0) فيها الآن جدار + إطار باب => السقف مقبول
  assert.ok(g.build('roof', { kind: 'cell', cx: 0, cz: 0 }).ok);

  // السقف يحتاج جدارين على الأقل
  g.build('foundation', { kind: 'cell', cx: 5, cz: 5 });
  assert.deepEqual(g.build('roof', { kind: 'cell', cx: 5, cz: 5 }), { ok: false, error: 'needsWalls' });
  g.build('wall', { kind: 'edge', cx: 5, cz: 5, axis: 'h' });
  assert.deepEqual(g.build('roof', { kind: 'cell', cx: 5, cz: 5 }), { ok: false, error: 'needsWalls' });
  g.build('wall', { kind: 'edge', cx: 5, cz: 5, axis: 'v' });
  assert.ok(g.build('roof', { kind: 'cell', cx: 5, cz: 5 }).ok);
});

test('إزالة الأساس تُسقط كل ما عليه، وإزالة جدار لا تسقط الباقي', () => {
  const g = new BuildingGrid(flat);
  g.build('foundation', { kind: 'cell', cx: 0, cz: 0 });
  g.build('foundation', { kind: 'cell', cx: 1, cz: 0 });
  const shared = g.build('wall', { kind: 'edge', cx: 1, cz: 0, axis: 'v' }); // بين الخليتين
  g.build('wall', { kind: 'edge', cx: 0, cz: 0, axis: 'h' });
  g.build('wall', { kind: 'edge', cx: 0, cz: 0, axis: 'v' });
  g.build('roof', { kind: 'cell', cx: 0, cz: 0 });
  assert.ok(shared.ok);

  // إزالة أساس الخلية (0,0): الجدار المشترك يبقى لأن الخلية (1,0) تدعمه
  const ids = g.list().filter((p) => p.type === 'foundation' && p.cx === 0).map((p) => p.id);
  const removed = g.remove(ids[0]);
  assert.ok(removed.some((p) => p.type === 'roof'));
  assert.ok(g.list().some((p) => p.type === 'wall' && p.axis === 'v' && p.cx === 1)); // المشترك
  assert.ok(!g.list().some((p) => p.type === 'wall' && p.cx === 0 && p.cz === 0)); // سقطت غير المدعومة
});

test('البناء يستهلك المواد ويرفض عند النقص، والاسترجاع 50%', () => {
  const inv = bag();
  const g = new BuildingGrid(flat);
  inv.add('plank', 4);
  assert.deepEqual(g.build('foundation', { kind: 'cell', cx: 0, cz: 0 }, inv), { ok: false, error: 'noMaterials' });
  assert.equal(inv.count('plank'), 4); // لم يُستهلك شيء
  inv.add('support_beam', 2);
  const r = g.build('foundation', { kind: 'cell', cx: 0, cz: 0 }, inv);
  assert.ok(r.ok);
  assert.equal(inv.count('plank'), 0);
  assert.deepEqual(BuildingGrid.refund((r as { piece: never }).piece), { plank: 2, support_beam: 1 });
});

test('الأرض: لا بناء فوق الماء أو على منحدر شديد، والقطع الحرة لا تتداخل', () => {
  const sea: GroundQuery = { height: () => -3, slope: () => 0, waterLevel: 0 };
  assert.deepEqual(new BuildingGrid(sea).validate('foundation', { kind: 'cell', cx: 0, cz: 0 }), { ok: false, error: 'badGround' });

  const steep: GroundQuery = { height: (x) => x * 0.8 + 3, slope: () => 0.8, waterLevel: 0 };
  assert.equal(new BuildingGrid(steep).validate('campfire', { kind: 'free', x: 3, z: 3, yaw: 0 }).ok, false);

  const g = new BuildingGrid(flat);
  assert.ok(g.build('campfire', { kind: 'free', x: 10, z: 10, yaw: 0 }).ok);
  assert.deepEqual(g.build('storage', { kind: 'free', x: 10.5, z: 10, yaw: 0 }), { ok: false, error: 'overlap' });
  assert.ok(g.build('storage', { kind: 'free', x: 14, z: 10, yaw: 0 }).ok);
});

test('الطوافة تُبنى على الماء فقط', () => {
  const g = new BuildingGrid({ height: (x) => (x < 0 ? -5 : 2), slope: () => 0, waterLevel: 0 });
  assert.deepEqual(g.validate('raft', { kind: 'free', x: 5, z: 0, yaw: 0 }), { ok: false, error: 'notOnWater' });
  assert.ok(g.validate('raft', { kind: 'free', x: -5, z: 0, yaw: 0 }).ok);
});

test('التثبيت من نقطة عالم: خلية وأقرب حافة', () => {
  const g = new BuildingGrid(flat);
  assert.deepEqual(g.snapFromWorld('foundation', 4.2, -1), { kind: 'cell', cx: 1, cz: -1 });
  // قرب الحافة الشمالية للخلية (0,0) عند z=0
  assert.deepEqual(g.snapFromWorld('wall', 1.5, 0.2), { kind: 'edge', cx: 0, cz: 0, axis: 'h' });
  assert.deepEqual(g.snapFromWorld('wall', 0.2, 1.5), { kind: 'edge', cx: 0, cz: 0, axis: 'v' });
});
