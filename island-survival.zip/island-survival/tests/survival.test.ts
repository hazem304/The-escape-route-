import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_CTX, SurvivalSystem, type SurvivalContext } from '../src/survival/SurvivalSystem';
import { Fire } from '../src/survival/Fire';
import { canSleep, shouldWake } from '../src/survival/Sleep';
import { Inventory } from '../src/inventory/Inventory';
import { ItemDB } from '../src/inventory/ItemDatabase';

const ctx = (o: Partial<SurvivalContext> = {}): SurvivalContext => ({ ...DEFAULT_CTX, ...o });
/** يحاكي h ساعة لعبة بخطوات 0.1 ساعة */
const run = (s: SurvivalSystem, hours: number, c: SurvivalContext): void => {
  for (let t = 0; t < hours; t += 0.1) s.update(0.1 * 3, 0.1, c);
};

test('الجوع والعطش ينقصان مع الزمن والجهد أسرع', () => {
  const a = new SurvivalSystem(() => 0.99);
  const b = new SurvivalSystem(() => 0.99);
  run(a, 5, ctx({ activity: 'idle' }));
  run(b, 5, ctx({ activity: 'run' }));
  assert.ok(a.stats.hunger < 85 && a.stats.thirst < 85);
  assert.ok(b.stats.hunger < a.stats.hunger);
  assert.ok(b.stats.thirst < a.stats.thirst);
});

test('الموت بالعطش بعد نفاد الماء', () => {
  const s = new SurvivalSystem(() => 0.99);
  s.stats.thirst = 0;
  run(s, 30, ctx());
  assert.ok(s.dead);
  assert.equal(s.deathCause, 'dehydration');
});

test('تجدد الصحة عند الشبع وعدم وجود أمراض', () => {
  const s = new SurvivalSystem(() => 0.99);
  s.stats.health = 50;
  s.stats.hunger = s.stats.thirst = 90;
  run(s, 6, ctx({ ambientTemp: 24 }));
  assert.ok(s.stats.health > 50);
});

test('انخفاض الحرارة: الجو البارد بلا ملابس يسبب hypothermia، والملابس والنار تمنعانه', () => {
  const naked = new SurvivalSystem(() => 0.99);
  run(naked, 12, ctx({ ambientTemp: 5, isRaining: true }));
  assert.ok(naked.has('hypothermia'), `temp=${naked.stats.bodyTemp}`);

  const dressed = new SurvivalSystem(() => 0.99);
  run(dressed, 12, ctx({ ambientTemp: 5, warmth: 18, rainProof: true, isRaining: true }));
  assert.ok(!dressed.has('hypothermia'), `temp=${dressed.stats.bodyTemp}`);

  const byFire = new SurvivalSystem(() => 0.99);
  run(byFire, 12, ctx({ ambientTemp: 5, fireHeat: 0.9, inShelter: true }));
  assert.ok(byFire.stats.bodyTemp > 35.5);
});

test('ضربة الشمس في الحر الشديد والتعرق يزيد العطش', () => {
  const s = new SurvivalSystem(() => 0.99);
  s.stats.thirst = 100;
  run(s, 10, ctx({ ambientTemp: 44, hour: 12 }));
  assert.ok(s.has('heatstroke'), `temp=${s.stats.bodyTemp}`);
  assert.ok(s.stats.thirst < 60);
});

test('اللحم النيء يسبب تسممًا بحسب الاحتمال وفحم الأقراص يعالجه', () => {
  const inv = new Inventory();
  inv.add('raw_meat', 1);
  const uid = inv.grid.list()[0].stack.uid;
  const r = inv.use(uid);

  const unlucky = new SurvivalSystem(() => 0.1); // أقل من 0.5 => مرض
  assert.ok(unlucky.consume(r.effects).gotSick);
  assert.ok(unlucky.has('foodPoisoning'));
  assert.ok(unlucky.consume(ItemDB.get('charcoal_pill').effects).gotSick === false);
  assert.ok(!unlucky.has('foodPoisoning'));

  const lucky = new SurvivalSystem(() => 0.9);
  assert.equal(lucky.consume(r.effects).gotSick, false);
});

test('النزيف يتحول إلى عدوى إن تُرك والضمادة والمضاد يعالجان', () => {
  const s = new SurvivalSystem(() => 0); // دائمًا يقع النزيف
  s.damage(20, 'cut');
  assert.ok(s.has('bleeding'));
  run(s, 7, ctx());
  assert.ok(s.has('infection'));
  s.consume(ItemDB.get('bandage').effects);
  s.consume(ItemDB.get('antibiotic').effects);
  assert.ok(!s.has('bleeding') && !s.has('infection'));
});

test('السقوط: الارتفاع الصغير آمن والكبير يكسر الساق', () => {
  const s = new SurvivalSystem(() => 0);
  assert.equal(s.fallDamage(8), 0);
  const d = s.fallDamage(14);
  assert.ok(d > 0);
  assert.ok(s.has('brokenLeg'));
  assert.ok(s.speedMultiplier < 0.6);
  assert.equal(s.canRun, false);
  s.consume(ItemDB.get('splint').effects);
  assert.ok(s.conditions.get('brokenLeg')!.remaining <= 12);
});

test('الصعوبة: الواقعي أقسى وفيه موت دائم', () => {
  const easy = new SurvivalSystem(() => 0.99);
  const real = new SurvivalSystem(() => 0.99);
  easy.difficulty = 'easy';
  real.difficulty = 'realistic';
  run(easy, 8, ctx());
  run(real, 8, ctx());
  assert.ok(real.stats.hunger < easy.stats.hunger);
  assert.ok(real.permadeath && !easy.permadeath);
});

test('النفَس: الجري يستنزفه والراحة تعيده', () => {
  const s = new SurvivalSystem(() => 0.99);
  for (let i = 0; i < 60; i++) s.update(0.1, 0.0001, ctx({ activity: 'run' }));
  assert.ok(s.stats.stamina < 100);
  const low = s.stats.stamina;
  for (let i = 0; i < 60; i++) s.update(0.1, 0.0001, ctx({ activity: 'rest' }));
  assert.ok(s.stats.stamina > low);
});

test('النار: إشعال، وقود، المطر يطفئ المكشوفة وغير المكشوفة تصمد', () => {
  const f = new Fire();
  assert.equal(f.ignite(1, 0), false); // بلا وقود
  f.addFuel('wood_log', 2);
  assert.ok(f.ignite(0.98, 0.5));
  assert.ok(f.burning);
  assert.ok(f.heatAt(1) > f.heatAt(4));
  assert.equal(f.heatAt(6), 0);

  const exposed = new Fire();
  exposed.addFuel('wood_log', 2);
  exposed.ignite(1, 0);
  for (let i = 0; i < 20; i++) exposed.update(1, 1);
  assert.equal(exposed.burning, false);

  const covered = new Fire(0, 0, 0, true);
  covered.addFuel('wood_log', 2);
  covered.ignite(1, 0);
  for (let i = 0; i < 20; i++) covered.update(1, 1);
  assert.ok(covered.burning);

  // مطر خفيف لا يطفئ نارًا مكشوفة قوية
  const light = new Fire();
  light.addFuel('wood_log', 2);
  light.ignite(1, 0);
  for (let i = 0; i < 20; i++) light.update(1, 0.25);
  assert.ok(light.burning);

  const burnOut = new Fire();
  burnOut.addFuel('stick', 1); // 12 دقيقة
  burnOut.ignite(1, 0);
  for (let i = 0; i < 15; i++) burnOut.update(1, 0);
  assert.equal(burnOut.burning, false);
});

test('إشعال بالاحتكاك أصعب تحت المطر', () => {
  let ok = 0;
  for (let i = 0; i < 100; i++) {
    const f = new Fire();
    f.addFuel('firewood', 1);
    if (f.ignite(0.35, i / 100, 1)) ok++;
  }
  let dry = 0;
  for (let i = 0; i < 100; i++) {
    const f = new Fire();
    f.addFuel('firewood', 1);
    if (f.ignite(0.35, i / 100, 0)) dry++;
  }
  assert.ok(ok < dry);
});

test('النوم: شروط الإذن والاستيقاظ', () => {
  const base = { energy: 40, hostileNearby: false, inShelterOrBed: true, bodyTemp: 37, hunger: 60, thirst: 60 };
  assert.ok(canSleep(base).ok);
  assert.deepEqual(canSleep({ ...base, energy: 95 }), { ok: false, reason: 'notTired' });
  assert.deepEqual(canSleep({ ...base, hostileNearby: true }), { ok: false, reason: 'danger' });
  assert.ok(shouldWake({ ...base, energy: 100, damaged: false }));
  assert.ok(shouldWake({ ...base, damaged: true }));
  assert.equal(shouldWake({ ...base, damaged: false }), false);
});
