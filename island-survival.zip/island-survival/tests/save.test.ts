import test from 'node:test';
import assert from 'node:assert/strict';
import { GameSession } from '../src/core/GameSession';
import { SaveSystem, MemoryBackend, checksum, AutoSaver } from '../src/core/SaveSystem';
import { TerrainGenerator } from '../src/world/TerrainGenerator';

const env = { weatherTempDelta: 0, rainIntensity: 0, windX: 1, windZ: 0, waveAmp: 0.5, inCave: false };
const terrain = new TerrainGenerator('save-seed');
const snap = (g: GameSession) => ({ x: g.spawnPoint.x, y: g.spawnPoint.y, z: g.spawnPoint.z, yaw: 0, loco: 'idle' as const, inWater: false, working: false });

function played(): GameSession {
  const g = new GameSession('save-seed', terrain);
  g.giveItem('wood_log', 6);
  g.giveItem('stone', 3);
  g.skills.addXp('survival', 50);
  for (let i = 0; i < 200; i++) g.update(0.5, snap(g), env);
  return g;
}

test('دورة حفظ/تحميل كاملة تحافظ على الحالة', async () => {
  const g = played();
  const sys = new SaveSystem(new MemoryBackend());
  await sys.save(0, g.toJSON({ x: 1, y: 2, z: 3, yaw: 0.5 }));
  const r = await sys.load(0);
  assert.ok(r.ok);
  const g2 = new GameSession('save-seed', terrain);
  g2.load(r.ok ? r.data : (null as never));
  assert.equal(g2.inventory.count('wood_log'), g.inventory.count('wood_log'));
  assert.equal(g2.inventory.count('stone'), 3);
  assert.ok(Math.abs(g2.totalHours - g.totalHours) < 1e-9);
  assert.ok(Math.abs(g2.survival.stats.hunger - g.survival.stats.hunger) < 1e-9);
  assert.deepEqual(g2.skills.toJSON(), g.skills.toJSON());
  // حفظ ثانٍ متطابق = لا فقد
  const a = JSON.stringify(g.toJSON({ x: 1, y: 2, z: 3, yaw: 0.5 }), (k, v) => (k === 'savedAt' ? 0 : v));
  const b = JSON.stringify(g2.toJSON({ x: 1, y: 2, z: 3, yaw: 0.5 }), (k, v) => (k === 'savedAt' ? 0 : v));
  assert.equal(a, b);
});

test('الحفظ يمر عبر JSON دون خسارة (Infinity وغيره)', async () => {
  const g = played();
  const s = JSON.parse(JSON.stringify(g.toJSON({ x: 0, y: 0, z: 0, yaw: 0 })));
  const g2 = new GameSession('save-seed', terrain);
  g2.load(s);
  assert.equal(g2.inventory.count('wood_log'), 6);
});

test('بذرة مختلفة ترفض التحميل', () => {
  const g = new GameSession('save-seed', terrain);
  const d = g.toJSON({ x: 0, y: 0, z: 0, yaw: 0 });
  const other = new GameSession('other', new TerrainGenerator('other'));
  assert.throws(() => other.load(d));
});

test('بناء ومحطات ونار تُحفظ وتُستعاد', async () => {
  const g = new GameSession('save-seed', terrain);
  g.giveItem('campfire_kit', 2); g.giveItem('firewood', 12);
  g.giveItem('stone', 12);
  g.giveItem('plank', 20);
  g.giveItem('rope', 6);
  const sp = g.spawnPoint;
  const spot = { x: sp.x - 8, z: sp.z };
  void spot;
  const d0 = g.buildings.list().length;
  const r = g.place('campfire', { kind: 'free', x: sp.x, z: sp.z, yaw: 0 });
  if (r.ok) {
    g.addFuel(r.piece.id, 'firewood', 2);
    const g2 = new GameSession('save-seed', terrain);
    g2.load(JSON.parse(JSON.stringify(g.toJSON({ x: 0, y: 0, z: 0, yaw: 0 }))));
    assert.equal(g2.buildings.list().length, d0 + 1);
    assert.ok(g2.fires.has(r.piece.id));
    assert.ok(g2.stations.has(r.piece.id));
    assert.equal(g2.fires.get(r.piece.id)!.fuel, g.fires.get(r.piece.id)!.fuel);
  } else {
    assert.fail('تعذر وضع موقد: ' + JSON.stringify(r));
  }
});

test('ملف تالف يُكتشف ويُستعاد من النسخة الاحتياطية', async () => {
  const be = new MemoryBackend();
  const sys = new SaveSystem(be);
  const g = new GameSession('save-seed', terrain);
  await sys.save(1, g.toJSON({ x: 0, y: 0, z: 0, yaw: 0 }));
  g.giveItem('rope', 2);
  await sys.save(1, g.toJSON({ x: 0, y: 0, z: 0, yaw: 0 })); // الأولى تصبح .bak
  be.data.set('save.1', JSON.stringify({ ...JSON.parse(be.data.get('save.1')!), sum: 'deadbeef' }));
  const r = await sys.load(1);
  assert.ok(r.ok, 'يجب أن تنجح عبر النسخة الاحتياطية');
  be.data.set('save.1.bak', 'garbage');
  const r2 = await sys.load(1);
  assert.ok(!r2.ok && r2.error === 'corrupt');
});

test('خانات فارغة وقائمة الخانات والحذف وخانة غير صالحة', async () => {
  const sys = new SaveSystem(new MemoryBackend());
  assert.deepEqual((await sys.list()).map((s) => s.empty), [true, true, true]);
  const g = new GameSession('save-seed', terrain);
  await sys.save(2, g.toJSON({ x: 0, y: 0, z: 0, yaw: 0 }));
  const l = await sys.list();
  assert.equal(l[2].empty, false);
  await sys.delete(2);
  assert.equal((await sys.list())[2].empty, true);
  await assert.rejects(() => sys.save(3, g.toJSON({ x: 0, y: 0, z: 0, yaw: 0 })));
});

test('إصدار أحدث مرفوض بـ version', async () => {
  const be = new MemoryBackend();
  const sys = new SaveSystem(be);
  const body = JSON.stringify({ version: 99 });
  be.data.set('save.0', JSON.stringify({ v: 99, sum: checksum(body), body }));
  const r = await sys.load(0);
  assert.ok(!r.ok && r.error === 'version');
});

test('AutoSaver لا يكتب قبل الفترة ولا يتداخل', async () => {
  const be = new MemoryBackend();
  const sys = new SaveSystem(be);
  const g = new GameSession('save-seed', terrain);
  const a = new AutoSaver(sys, 0, () => g.toJSON({ x: 0, y: 0, z: 0, yaw: 0 }), 10);
  a.tick(5);
  assert.equal(be.data.size, 0);
  a.tick(6);
  await new Promise((r) => setTimeout(r, 20));
  assert.ok(be.data.has('save.0'));
});

test('المحاكاة الطويلة بلا نظام تقع بأخطاء ولا قيم NaN', () => {
  const g = new GameSession('save-seed', terrain);
  for (let i = 0; i < 3000; i++) g.update(0.5, snap(g), { ...env, rainIntensity: i % 400 < 100 ? 0.8 : 0 });
  const s = g.survival.stats;
  for (const v of [s.hunger, s.thirst, s.energy, s.health, s.bodyTemp, s.stamina]) assert.ok(Number.isFinite(v));
  assert.ok(g.totalHours > 7.5);
});

test('لا موارد فوق مصاطب الكهوف ولا تعود بالتحديث', () => {
  const g = new GameSession('save-seed', terrain);
  for (const n of g.resources.all()) assert.ok(!terrain.insideCaveFootprint(n.x, n.z));
  const before = g.resources.size;
  g.resources.update(1000);
  assert.equal(g.resources.size, before);
  assert.ok(g.resources.all().every((n) => n.alive));
});

test('الصنع المؤقت يُخطر المهام ويضيف الناتج', () => {
  const g = new GameSession('save-seed', terrain);
  g.giveItem('plant_fiber', 6);
  const rec = g.recipes.get('rope_fiber');
  assert.ok(rec, 'وصفة rope_fiber');
  const r = g.craftQueued(rec!, g.spawnPoint);
  assert.ok(r.ok);
  const before = g.inventory.count('rope');
  for (let i = 0; i < 100; i++) g.update(0.5, snap(g), env);
  assert.ok(g.inventory.count('rope') > before);
});
