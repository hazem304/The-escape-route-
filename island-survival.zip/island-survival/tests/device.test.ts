import test from 'node:test';
import assert from 'node:assert/strict';
import { defaultQuality, isPhone } from '../src/core/Device';

test('كشف الهاتف والجودة الافتراضية', () => {
  const phone = { coarsePointer: true, width: 844, height: 390, memoryGB: 4, cores: 6 };
  assert.ok(isPhone(phone));
  assert.equal(defaultQuality(phone), 'low');
  assert.equal(defaultQuality({ ...phone, memoryGB: 8, cores: 8 }), 'medium');
  const desktop = { coarsePointer: false, width: 1920, height: 1080 };
  assert.ok(!isPhone(desktop));
  assert.equal(defaultQuality(desktop), 'medium');
  assert.ok(!isPhone({ coarsePointer: true, width: 1280, height: 900 })); // لوحي كبير
});
