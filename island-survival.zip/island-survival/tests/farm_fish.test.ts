import test from 'node:test';
import assert from 'node:assert/strict';
import { GameSession } from '../src/core/GameSession';
import { TerrainGenerator } from '../src/world/TerrainGenerator';
import { FarmPlot, GROW_HOURS } from '../src/survival/Farming';
import { Random } from '../src/core/Random';

const env = (rain = 0) => ({ weatherTempDelta: 0, rainIntensity: rain, windX: 1, windZ: 0, waveAmp: 0.5, inCave: false });
const terrain = new TerrainGenerator('ff-seed');
const snap = (g: GameSession) => ({ x: g.spawnPoint.x, y: g.spawnPoint.y, z: g.spawnPoint.z, yaw: 0, loco: 'idle' as const, inWater: false, working: false });

function hold(g: GameSession, id: string): void {
  g.giveItem(id, 1);
  const e = g.inventory.grid.list().find((x) => x.stack.defId === id)!;
  g.inventory.hotbar.assign(0, e.stack.uid);
  g.inventory.hotbar.select(0);
}

test('FarmPlot: بلا ماء لا نمو، مع الماء ينضج ويُحصد', () => {
  const p = new FarmPlot();
  assert.ok(p.plant());
  p.update(100, 0);
  assert.equal(p.stage(0), 0);
  assert.ok(p.thirsty);
  p.water();
  p.update(30, 0);
  p.water();
  p.update(30, 0);
  p.water();
  p.update(GROW_HOURS, 0);
  assert.equal(p.stage(0), 3);
  assert.equal(p.ripeCount, 1);
  const drops = p.harvest(new Random(1));
  assert.ok(drops.find((d) => d.id === 'yam' && d.count >= 2));
  assert.equal(p.plantedCount, 0);
});

test('FarmPlot: المطر يسقي والحفظ يعيد الحالة', () => {
  const p = new FarmPlot();
  p.plant();
  p.update(10, 1);
  assert.ok(p.slots[0]!.growth >= 10);
  const q = FarmPlot.fromJSON(JSON.parse(JSON.stringify(p.toJSON())));
  assert.deepEqual(q.toJSON(), p.toJSON());
});

test('الجلسة: زرع وسقي وحصاد عبر farmAction وحفظها', () => {
  const g = new GameSession('ff-seed', terrain);
  g.giveItem('farm_plot', 1);
  const r = g.place('farm', { kind: 'free', x: g.spawnPoint.x + 4, z: g.spawnPoint.z, yaw: 0 });
  assert.ok(r.ok, JSON.stringify(r));
  const id = r.ok ? r.piece.id : -1;
  assert.ok(g.farms.has(id));
  g.giveItem('seeds', 2);
  hold(g, 'seeds');
  assert.equal(g.farmAction(id)?.action, 'plant');
  assert.equal(g.farms.get(id)!.plantedCount, 1);
  g.inventory.remove('seeds', 99);
  hold(g, 'rainwater');
  assert.equal(g.farmAction(id)?.action, 'water');
  assert.equal(g.inventory.count('rainwater'), 0);
  for (let i = 0; i < 400; i++) g.update(0.5, snap(g), env(1));
  const save = JSON.parse(JSON.stringify(g.toJSON({ x: 0, y: 0, z: 0, yaw: 0 })));
  const g2 = new GameSession('ff-seed', terrain);
  g2.load(save);
  assert.equal(g2.farms.get(id)?.plantedCount, 1);
  assert.deepEqual(g2.farms.get(id)!.toJSON(), g.farms.get(id)!.toJSON());
  g.removePiece(id);
  assert.ok(!g.farms.has(id));
});

test('الجلسة: الصيد يتطلب صنارة وماءً عميقًا ثم لدغة وسحب', () => {
  const g = new GameSession('ff-seed', terrain);
  const t0 = { x: g.spawnPoint.x + 5, z: g.spawnPoint.z };
  assert.deepEqual(g.castLine(t0, 3), { ok: false, reason: 'noRod' });
  hold(g, 'fishing_rod');
  assert.deepEqual(g.castLine(t0, 0.2), { ok: false, reason: 'shallow' });
  assert.deepEqual(g.castLine(t0, 3), { ok: true });
  assert.deepEqual(g.castLine(t0, 3), { ok: false, reason: 'busy' });
  const sp = snap(g);
  let bit = false;
  for (let i = 0; i < 4000 && !bit; i++) {
    g.update(0.1, sp, env());
    bit = g.fishing.state === 'bite';
  }
  assert.ok(bit, 'لدغة');
  const evs = g.drainEvents();
  assert.ok(evs.some((e) => e.type === 'fishing' && e.state === 'bite'));
  const c = g.reelLine();
  assert.ok(c);
  assert.ok(g.inventory.count(c!.id) >= c!.count);
});

test('الصيد يُلغى عند تغيير العنصر الممسوك', () => {
  const g = new GameSession('ff-seed', terrain);
  hold(g, 'fishing_rod');
  g.castLine({ x: g.spawnPoint.x, z: g.spawnPoint.z }, 3);
  g.inventory.hotbar.select(5);
  g.update(0.1, snap(g), env());
  assert.equal(g.fishing.state, 'idle');
});
