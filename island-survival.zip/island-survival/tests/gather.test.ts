import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Random } from '../src/core/Random';
import { Inventory } from '../src/inventory/Inventory';
import { ItemDB } from '../src/inventory/ItemDatabase';
import { RecipeBook } from '../src/crafting/RecipeBook';
import { Skills } from '../src/survival/Skills';
import { GroundItems } from '../src/world/GroundItems';
import { ResourceField } from '../src/world/ResourceField';
import { Gatherer, SWING_COOLDOWN } from '../src/gameplay/Gatherer';

const setup = () => {
  const field = new ResourceField();
  const ground = new GroundItems();
  const inv = new Inventory();
  inv.grid.resize(10, 6);
  const skills = new Skills();
  const recipes = new RecipeBook();
  const g = new Gatherer(field, ground, inv, skills, recipes, new Random(7));
  const feet = { x: 0, y: 0, z: 0 };
  const eye = { x: 0, y: 1.6, z: 0 };
  const fwd = { x: 1, y: 0, z: 0 };
  const hold = (id: string) => {
    inv.add(id, 1);
    const e = inv.grid.list().find((x) => x.stack.defId === id)!;
    inv.hotbar.assign(0, e.stack.uid);
    inv.hotbar.select(0);
    return e.stack;
  };
  return { field, ground, inv, skills, recipes, g, feet, eye, fwd, hold };
};

test('الجمع: اليد على شجيرة توت تعطي توتًا، والضربة التالية تواجه التهدئة', () => {
  const s = setup();
  s.field.add('berryBush', 2, 0, 0);
  const r = s.g.swing(s.eye, s.fwd, 100, s.feet);
  assert.equal(r.kind, 'destroyed');
  assert.ok(s.inv.count('berries') >= 2);
  assert.ok(s.skills.xp.survival > 0);
  assert.equal(s.g.swing(s.eye, s.fwd, 100, s.feet).kind, 'cooldown');
  s.g.update(SWING_COOLDOWN + 0.01);
  assert.equal(s.g.swing(s.eye, s.fwd, 100, s.feet).kind, 'miss'); // الشجيرة استُنفدت
});

test('الجمع: شجرة بلا فأس = أداة خاطئة، ومع الفأس تُقطع وتعطي خشبًا وتتآكل الأداة', () => {
  const s = setup();
  s.field.add('jungleTree', 3, 0, 0);
  const w = s.g.swing(s.eye, s.fwd, 100, s.feet);
  assert.equal(w.kind, 'wrongTool');
  assert.equal((w as { needs: string }).needs, 'chop');

  const axe = s.hold('axe_stone');
  const start = axe.durability;
  let last = w;
  for (let i = 0; i < 40; i++) {
    s.g.update(1);
    last = s.g.swing(s.eye, s.fwd, 100, s.feet);
    if (last.kind === 'destroyed') break;
  }
  assert.equal(last.kind, 'destroyed');
  assert.ok(s.inv.count('wood_log') >= 3);
  assert.ok(axe.durability < start);
});

test('الجمع: النفَس المنتهي يمنع الضرب، والحقيبة الممتلئة ترمي الفائض على الأرض', () => {
  const s = setup();
  s.field.add('berryBush', 2, 0, 0);
  assert.equal(s.g.swing(s.eye, s.fwd, 1, s.feet).kind, 'tired');

  // نملأ الجيوب
  const tiny = new Inventory();
  for (const id of ['axe_iron', 'axe_stone', 'pickaxe_stone', 'pickaxe_iron']) tiny.add(id, 1);
  const field = new ResourceField();
  const ground = new GroundItems();
  field.add('berryBush', 2, 0, 0);
  const g = new Gatherer(field, ground, tiny, new Skills(), new RecipeBook(), new Random(1));
  const r = g.swing({ x: 0, y: 1.6, z: 0 }, { x: 1, y: 0, z: 0 }, 100, { x: 0, y: 0, z: 0 });
  assert.equal(r.kind, 'destroyed');
  assert.ok(ground.size >= 1);
  assert.equal(tiny.count('berries'), 0);
});

test('الجمع: اكتشاف وصفات جديدة عند أول مرة يظهر فيها عنصر', () => {
  const s = setup();
  s.field.add('fiberPlant', 2, 0, 0);
  const r = s.g.swing(s.eye, s.fwd, 100, s.feet);
  assert.equal(r.kind, 'destroyed');
  assert.ok((r as { newRecipes: string[] }).newRecipes !== undefined);
  assert.ok(s.recipes.toJSON().seen.includes('plant_fiber'));
  assert.ok(ItemDB.has('plant_fiber'));
});

test('الجمع: تكسّر الأداة يعود لليدين', () => {
  const s = setup();
  s.field.add('boulder', 3, 0, 0);
  const pick = s.hold('pickaxe_stone');
  pick.durability = 1;
  s.g.update(1);
  const r = s.g.swing(s.eye, s.fwd, 100, s.feet);
  assert.ok(r.kind === 'hit' || r.kind === 'destroyed');
  assert.equal((r as { toolBroke: boolean }).toolBroke, true);
  assert.equal(s.inv.count('pickaxe_stone'), 0);
  s.g.update(1);
  assert.equal(s.g.swing(s.eye, s.fwd, 100, s.feet).kind, 'wrongTool'); // يدان فقط الآن
});
