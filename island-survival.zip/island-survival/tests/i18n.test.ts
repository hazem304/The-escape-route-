import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import ar from '../src/data/i18n_ar.json';
import en from '../src/data/i18n_en.json';
import { setLanguage, t } from '../src/core/i18n';

function walk(d: string, out: string[] = []): string[] {
  for (const f of readdirSync(d)) {
    const p = join(d, f);
    if (statSync(p).isDirectory()) walk(p, out);
    else if (p.endsWith('.ts')) out.push(p);
  }
  return out;
}

test('المفاتيح متطابقة بين العربية والإنجليزية وبلا قيم فارغة', () => {
  assert.deepEqual(Object.keys(ar).sort(), Object.keys(en).sort());
  for (const [k, v] of Object.entries({ ...ar })) assert.ok(v.trim(), `ar.${k} فارغ`);
  for (const [k, v] of Object.entries({ ...en })) assert.ok(v.trim(), `en.${k} فارغ`);
});

test('المتغيرات {x} متطابقة في اللغتين', () => {
  const vars = (s: string): string => (s.match(/\{\w+\}/g) ?? []).sort().join(',');
  for (const k of Object.keys(ar)) assert.equal(vars((ar as Record<string, string>)[k]), vars((en as Record<string, string>)[k]), k);
});

test('كل مفتاح t("…") ثابت المستخدم في الكود موجود', () => {
  const have = new Set(Object.keys(ar));
  const missing: string[] = [];
  for (const f of walk(join(import.meta.dirname, '../src'))) {
    const src = readFileSync(f, 'utf8');
    for (const m of src.matchAll(/\bt\(\s*'([a-z0-9_]+)'/gi)) if (!have.has(m[1])) missing.push(`${f}: ${m[1]}`);
  }
  assert.deepEqual(missing, []);
});

test('المفاتيح الديناميكية cond_/skill_/slot_/err_/station_ مغطاة', () => {
  const need = [
    ...['foodPoisoning', 'dehydration', 'heatstroke', 'hypothermia', 'infection', 'bleeding', 'brokenLeg', 'sunburn', 'pain'].map((x) => `cond_${x}`),
    ...['survival', 'hunting', 'crafting', 'building'].map((x) => `skill_${x}`),
    ...['head', 'chest', 'legs', 'feet', 'hands', 'tool', 'backpack'].map((x) => `slot_${x}`),
    ...['noSupport', 'occupied', 'badGround', 'overlap', 'noMaterials', 'noDoorway', 'needsWalls', 'notOnWater'].map((x) => `err_${x}`),
    ...['hand', 'workbench', 'campfire', 'furnace', 'drying_rack'].map((x) => `station_${x}`),
    ...['easy', 'normal', 'hard', 'realistic'].map((x) => `diff_${x}`),
    ...['hostile', 'wary', 'neutral', 'friendly', 'trusted'].map((x) => `trust_${x}`),
    ...['rescue', 'raft', 'secret', 'death'].flatMap((x) => [`ending_${x}`, `ending_${x}_text`]),
    ...['fresh', 'stale', 'rotten'].map((x) => `spoil_${x}`),
  ];
  const miss = need.filter((k) => !(k in ar));
  assert.deepEqual(miss, []);
});

test('t يستبدل المتغيرات ويرجع للإنجليزية ثم المفتاح', () => {
  setLanguage('en');
  assert.equal(t('day_n', { n: 3 }), 'Day 3');
  setLanguage('ar');
  assert.equal(t('day_n', { n: 3 }), 'اليوم 3');
  assert.equal(t('no_such_key_xyz'), 'no_such_key_xyz');
});
