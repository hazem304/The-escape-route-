import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { BLUEPRINTS } from '../src/building/Blueprint';
import { SPECIES } from '../src/entities/Animal';
import { NPC_DEFS } from '../src/data/npcs';

const root = join(import.meta.dirname, '..');
interface E { id: string; file: string; category: string; maxTris: number; minTris: number; status: string; integration: string; lod: boolean }
const manifest = JSON.parse(readFileSync(join(root, 'art_pipeline/asset_manifest.json'), 'utf8')) as { assets: E[]; textures: unknown[]; videos: unknown[] };
const prompts = readFileSync(join(root, 'art_pipeline/higgsfield_prompts.md'), 'utf8');
const ids = new Set(manifest.assets.map((a) => a.id));

test('المانيفست في art_pipeline مطابق لنسخة public/assets', () => {
  assert.equal(readFileSync(join(root, 'public/assets/asset_manifest.json'), 'utf8'), readFileSync(join(root, 'art_pipeline/asset_manifest.json'), 'utf8'));
});

test('معرّفات فريدة ومسارات فريدة وكلها .glb', () => {
  assert.equal(ids.size, manifest.assets.length);
  assert.equal(new Set(manifest.assets.map((a) => a.file)).size, manifest.assets.length);
  for (const a of manifest.assets) assert.ok(a.file.endsWith('.glb'), a.id);
});

test('كل نوع حيوان وناجٍ وقطعة بناء في الكود له أصل بمعرّف يبحث عنه المحمّل', () => {
  for (const id of Object.keys(SPECIES)) assert.ok(ids.has(`animal_${id}`), `animal_${id}`);
  for (const n of NPC_DEFS) assert.ok(ids.has(`npc_${n.id}`), `npc_${n.id}`);
  for (const t of Object.keys(BLUEPRINTS)) assert.ok(ids.has(`piece_${t}`), `piece_${t}`);
  assert.ok(ids.has('player_hero'));
});

test('ميزانيات المضلعات تطابق المواصفات', () => {
  const by = (c: string) => manifest.assets.filter((a) => a.category === c);
  for (const a of by('characters')) assert.deepEqual([a.minTris, a.maxTris], [25000, 40000], a.id);
  for (const a of by('animals')) assert.deepEqual([a.minTris, a.maxTris], [8000, 15000], a.id);
  for (const a of by('items')) assert.deepEqual([a.minTris, a.maxTris], a.id.includes('backpack') ? [2000, 5000] : [1000, 5000], a.id);
  for (const a of manifest.assets.filter((x) => /^tree_(palm|jungle)|^bamboo$/.test(x.id))) {
    assert.deepEqual([a.minTris, a.maxTris], [3000, 8000], a.id);
    assert.ok(a.lod, `${a.id} يحتاج LOD`);
  }
});

test('كل الحالات required الآن (لا أصل مولَّد وهميًا) والحالات صالحة', () => {
  for (const a of manifest.assets) assert.ok(['required', 'generated', 'integrated'].includes(a.status));
  assert.ok(manifest.assets.every((a) => a.status === 'required'));
});

test('البرومبتات: ≥60 مجسمًا بالصيغة الثابتة، وأوراق شخصيات لكل شخصية بثلاث زوايا', () => {
  const fixed = / , photorealistic, 3\/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background/g;
  assert.ok((prompts.match(fixed) ?? []).length >= 60);
  // +1: مثال الصيغة في رأس الملف
  assert.equal((prompts.match(fixed) ?? []).length, manifest.assets.length + 1, 'برومبت لكل أصل');
  for (const c of ['player_hero', 'npc_layla', 'npc_omar', 'npc_yusuf']) for (const v of ['front view', 'side view', 'back view']) {
    assert.ok(prompts.includes(`### \`${c}\``) && prompts.includes(`· ${v}`), `${c} ${v}`);
  }
  assert.equal((prompts.match(/, character turnaround sheet,/g) ?? []).length, 12);
});

test('خامات 2K المطلوبة موجودة، وفيديو المقدمة موجود', () => {
  for (const k of ['wet_sand', 'volcanic_rock', 'palm_bark', 'torn_cloth', 'leather', 'rust']) assert.ok(prompts.includes(`tex_${k}`), k);
  assert.ok(prompts.includes('2048x2048'));
  for (const v of ['intro_crash', 'intro_wake']) assert.ok(prompts.includes(`\`${v}\``));
});
