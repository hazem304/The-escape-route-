import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Inventory } from '../src/inventory/Inventory';
import { QuestManager } from '../src/quests/QuestManager';
import { QUESTS } from '../src/quests/Story';
import { runAction, useStoryItem, type ActionHooks } from '../src/quests/ActionRunner';
import { evaluateEnding, RESCUE_WAIT_DAYS, type EndingContext } from '../src/quests/RescueEnding';
import { Journal, JOURNAL_PAGES } from '../src/quests/Journal';
import { MapData } from '../src/quests/MapData';
import { ItemDB } from '../src/inventory/ItemDatabase';
import { RecipeBook } from '../src/crafting/RecipeBook';
import { NPC_DEFS } from '../src/data/npcs';
import { NPC } from '../src/entities/NPC';

const setup = () => {
  const inv = new Inventory();
  inv.grid.resize(10, 6);
  const rewards: unknown[] = [];
  const dropped: string[] = [];
  const msgs: string[] = [];
  const quests = new QuestManager({ itemCount: (id) => inv.count(id), giveReward: (r) => rewards.push(r) });
  const hooks: ActionHooks = { inv, quests, dropOverflow: (id, n) => dropped.push(`${id}×${n}`), notify: (ar) => msgs.push(ar) };
  return { inv, quests, rewards, dropped, msgs, hooks };
};

test('القصة: كل المراحل صالحة، المتطلبات موجودة، العناصر معرّفة، ولا حلقات', () => {
  const ids = new Set(QUESTS.map((q) => q.id));
  assert.equal(ids.size, QUESTS.length);
  const recipes = new RecipeBook();
  const places = new Set(['peak', 'cave', 'bunker', 'open_sea']);
  for (const q of QUESTS) {
    assert.ok(q.titleAr && q.titleEn && q.descAr && q.descEn && q.objectives.length > 0, q.id);
    for (const r of q.requires ?? []) assert.ok(ids.has(r), `${q.id} requires ${r}`);
    for (const o of q.objectives) {
      assert.ok(o.textAr && o.textEn, q.id);
      if (o.type === 'collect' || o.type === 'craft') assert.ok(ItemDB.has(o.item), `${q.id}:${o.item}`);
      if (o.type === 'craft') assert.ok(recipes.all.some((r) => r.output.id === o.item), `no recipe makes ${o.item}`);
      if (o.type === 'reach') assert.ok(places.has(o.place), `${q.id}:${o.place}`);
      if (o.type === 'talk') assert.ok(NPC_DEFS.some((d) => d.id === o.npc), o.npc);
    }
    for (const it of q.reward?.items ?? []) assert.ok(ItemDB.has(it.id), `${q.id} reward ${it.id}`);
  }
  // لا حلقات في المتطلبات
  const visiting = new Set<string>();
  const check = (id: string): void => {
    assert.ok(!visiting.has(id), `cycle at ${id}`);
    visiting.add(id);
    for (const r of QUESTS.find((q) => q.id === id)!.requires ?? []) check(r);
    visiting.delete(id);
  };
  QUESTS.forEach((q) => check(q.id));
});

test('المهام: التفعيل التلقائي والتسلسل والمكافآت', () => {
  const s = setup();
  assert.equal(s.quests.status('wake_up'), 'active'); // auto بلا متطلبات
  assert.equal(s.quests.status('first_tools'), 'locked');
  assert.equal(s.quests.tracked?.id, 'wake_up');

  s.inv.add('stick', 6);
  s.quests.onInventoryChanged();
  let p = s.quests.progressOf('wake_up').objectives;
  assert.ok(p[0].done && p[1].current);

  s.inv.add('plant_fiber', 4);
  s.inv.add('stone', 3);
  s.quests.onInventoryChanged();
  assert.equal(s.quests.status('wake_up'), 'completed');
  assert.equal(s.rewards.length, 1);
  assert.equal(s.quests.status('first_tools'), 'active'); // فُتحت وفُعّلت
  p = s.quests.progressOf('wake_up').objectives;
  assert.ok(p.every((o) => o.done));
});

test('المهام: أهداف الحيازة لا تضيع عند الرمي، وتتقدم متسلسلة', () => {
  const s = setup();
  s.inv.add('stick', 6);
  s.inv.add('plant_fiber', 4);
  s.quests.onInventoryChanged();
  assert.ok(s.quests.progressOf('wake_up').objectives[1].done);
  // رمي الألياف بعد إنجاز هدفها لا يتراجع
  s.inv.remove('plant_fiber', 4);
  s.quests.onInventoryChanged();
  assert.ok(s.quests.progressOf('wake_up').objectives[1].done);
  assert.equal(s.quests.progressOf('wake_up').objectives[2].current, true);
});

test('المهام: أحداث الصنع والبناء والقتل والوصول والبقاء', () => {
  const s = setup();
  // نمرّر القصة الرئيسية حتى signal_fire
  const finishWake = () => {
    s.inv.add('stick', 6); s.inv.add('plant_fiber', 4); s.inv.add('stone', 3);
    s.quests.onInventoryChanged();
  };
  finishWake();
  s.quests.notify({ type: 'crafted', item: 'knife_stone', count: 1 });
  s.quests.notify({ type: 'crafted', item: 'axe_stone', count: 1 });
  assert.equal(s.quests.status('first_tools'), 'completed');
  // الأحداث الخاطئة لا تقدم
  s.quests.notify({ type: 'crafted', item: 'campfire_kit', count: 1 });
  s.quests.notify({ type: 'built', piece: 'campfire' });
  s.quests.notify({ type: 'crafted', item: 'water_boiled', count: 1 });
  assert.equal(s.quests.status('fire_and_water'), 'completed');

  s.quests.notify({ type: 'talked', npc: 'omar' }); // ليس الدور بعد (ليلى أولًا)
  assert.equal(s.quests.progressOf('find_survivors').objectives[1].value, 0);
  s.quests.notify({ type: 'talked', npc: 'layla' });
  s.quests.notify({ type: 'talked', npc: 'omar' });
  s.quests.notify({ type: 'talked', npc: 'yusuf' });
  assert.equal(s.quests.status('find_survivors'), 'completed');
  assert.ok(s.quests.flags.has('met_all_survivors'));

  // مهام جانبية متاحة لكن غير مفعّلة
  assert.equal(s.quests.status('hunter'), 'available');
  assert.ok(s.quests.start('hunter'));
  assert.equal(s.quests.start('hunter'), false);
  s.quests.notify({ type: 'crafted', item: 'spear_wood', count: 1 });
  s.quests.notify({ type: 'killed', species: 'boar' }); // نوع خاطئ
  assert.equal(s.quests.progressOf('hunter').objectives[1].value, 0);
  s.quests.notify({ type: 'killed', species: 'deer' });
  s.quests.notify({ type: 'crafted', item: 'cooked_meat', count: 1 });
  assert.equal(s.quests.status('hunter'), 'completed');
});

test('الحوار ← الإجراءات ← الراديو: سلسلة كاملة تنتهي براية النداء', () => {
  const s = setup();
  // نفتح القصة حتى repair_radio
  s.inv.add('stick', 6); s.inv.add('plant_fiber', 4); s.inv.add('stone', 3); s.quests.onInventoryChanged();
  for (const e of [
    { type: 'crafted', item: 'knife_stone', count: 1 }, { type: 'crafted', item: 'axe_stone', count: 1 },
    { type: 'crafted', item: 'campfire_kit', count: 1 }, { type: 'built', piece: 'campfire' }, { type: 'crafted', item: 'water_boiled', count: 1 },
    { type: 'talked', npc: 'layla' }, { type: 'talked', npc: 'omar' }, { type: 'talked', npc: 'yusuf' },
  ] as const) s.quests.notify(e);
  assert.equal(s.quests.status('repair_radio'), 'available'); // ليست auto: تبدأ بحوار عمر

  assert.deepEqual(runAction('quest:repair_radio', s.hooks), { ok: true });
  assert.equal(s.quests.status('repair_radio'), 'active');
  assert.equal(runAction('take_item:scrap_metal:3', s.hooks).reason, 'notEnough');

  s.inv.add('scrap_metal', 3);
  s.inv.add('copper_ingot', 1);
  runAction('give_item:radio_battery:1', s.hooks); // من يوسف
  assert.equal(s.quests.progressOf('repair_radio').objectives[2].done, true);
  runAction('flag:radio_done', s.hooks);
  assert.equal(s.quests.status('repair_radio'), 'completed');
  assert.ok(s.quests.flags.has('distress_sent'));
  assert.equal(s.quests.status('signal_fire'), 'active');
});

test('الإجراءات: الفائض يُرمى، العناصر المجهولة ترفض، الإجراء المجهول يرفض', () => {
  const s = setup();
  const tiny = new Inventory();
  for (const id of ['axe_iron', 'axe_stone', 'pickaxe_stone', 'pickaxe_iron']) tiny.add(id, 1);
  const h2 = { ...s.hooks, inv: tiny };
  assert.ok(runAction('give_item:bandage:3', h2).ok);
  assert.deepEqual(s.dropped, ['bandage×3']);
  assert.equal(runAction('give_item:nope:1', s.hooks).reason, 'unknownItem');
  assert.equal(runAction('dance:1', s.hooks).reason, 'unknownAction');
  assert.equal(runAction('quest:not_real', s.hooks).reason, 'cannotStart');
});

const endCtx = (o: Partial<EndingContext> = {}): EndingContext => ({ flags: new Set(), place: null, has: () => false, alive: true, day: 1, signalDay: null, ...o });

test('النهايات: الإنقاذ بعد انتظار، الطوافة في البحر المفتوح، السر بالأدلة والإرسال، الموت', () => {
  assert.equal(evaluateEnding(endCtx()), null);
  assert.equal(evaluateEnding(endCtx({ alive: false })), 'death');

  const rescueFlags = new Set(['ending_rescue_ready', 'signal_lit']);
  assert.equal(evaluateEnding(endCtx({ flags: rescueFlags, signalDay: 3, day: 3 })), null);
  assert.equal(evaluateEnding(endCtx({ flags: rescueFlags, signalDay: 3, day: 3 + RESCUE_WAIT_DAYS })), 'rescue');

  assert.equal(evaluateEnding(endCtx({ flags: new Set(['ending_raft_ready']), place: 'beach' })), null);
  assert.equal(evaluateEnding(endCtx({ flags: new Set(['ending_raft_ready']), place: 'open_sea' })), 'raft');

  const sec = new Set(['ending_secret_ready']);
  const has = (i: string) => i === 'flight_recorder' || i === 'satellite_phone';
  assert.equal(evaluateEnding(endCtx({ flags: sec, has })), null); // لم يُرسل بعد
  assert.equal(evaluateEnding(endCtx({ flags: new Set([...sec, 'secret_sent']), has })), 'secret');
  // السرية تتقدم على الإنقاذ إن تحققتا معًا
  assert.equal(evaluateEnding(endCtx({ flags: new Set([...sec, 'secret_sent', ...rescueFlags]), has, signalDay: 1, day: 9 })), 'secret');
});

test('الهاتف الفضائي: يحتاج الصندوق الأسود ومكانًا فيه إشارة، ثم يضبط راية الإرسال', () => {
  const s = setup();
  s.inv.add('satellite_phone', 1);
  assert.equal(useStoryItem('satellite_phone', s.hooks, 'bunker').reason, 'needRecorder');
  s.inv.add('flight_recorder', 1);
  assert.equal(useStoryItem('satellite_phone', s.hooks, 'beach').reason, 'noSignal');
  assert.ok(useStoryItem('satellite_phone', s.hooks, 'bunker').ok);
  assert.ok(s.quests.flags.has('secret_sent'));
  assert.equal(useStoryItem('stone', s.hooks, null).reason, 'notStoryItem');
});

test('المهام: الحفظ والتحميل يحفظان الحالة والرايات واليوم', () => {
  const s = setup();
  s.inv.add('stick', 6);
  s.quests.onInventoryChanged();
  s.quests.notify({ type: 'flag', flag: 'x' });
  s.quests.notify({ type: 'dayPassed', day: 4 });
  const saved = JSON.parse(JSON.stringify(s.quests.toJSON()));
  const t = setup();
  t.quests.load(saved);
  assert.equal(t.quests.progressOf('wake_up').objectives[0].done, true);
  assert.ok(t.quests.flags.has('x'));
  assert.equal(t.quests.day, 4);
});

test('المفكرة: تسجيل بدء/إنجاز المهام دون تكرار، وصفحات المذكرات، وملاحظة الناجين', () => {
  const s = setup();
  const j = new Journal();
  j.attach(s.quests, () => 2);
  s.inv.add('stick', 6); s.inv.add('plant_fiber', 4); s.inv.add('stone', 3);
  s.quests.onInventoryChanged();
  assert.ok(j.entries.some((e) => e.id === 'wake_up:done' && e.day === 2));
  const n = j.entries.length;
  s.quests.onInventoryChanged();
  assert.equal(j.entries.length, n);

  assert.ok(j.collectPage('pilot_1', 3));
  assert.equal(j.collectPage('pilot_1', 3), false);
  assert.equal(j.collectPage('nope', 3), false);
  assert.ok(Object.keys(JOURNAL_PAGES).length >= 5);
  j.noteNPC(new NPC(NPC_DEFS[0], { x: 0, z: 0 }), 4);
  assert.ok(j.entries.some((e) => e.id === 'npc:layla'));

  const k = new Journal();
  k.load(JSON.parse(JSON.stringify(j.toJSON())));
  assert.equal(k.entries.length, j.entries.length);
  assert.ok(k.pages.has('pilot_1'));
});

test('الخريطة: اكتشاف المعالم بالاقتراب، الضباب، تحويل الإحداثيات، والأماكن المسمّاة', () => {
  const m = new MapData([
    { id: 'beach', nameAr: 'الشاطئ', nameEn: 'Beach', x: 150, z: 0, radius: 20, icon: '🏖️', known: true },
    { id: 'peak', nameAr: 'القمة', nameEn: 'Peak', x: 0, z: 0, radius: 15, icon: '⛰️' },
    { id: 'cave', nameAr: 'الكهف', nameEn: 'Cave', x: 60, z: 60, radius: 12, icon: '🕳️' },
  ]);
  assert.deepEqual(m.visibleLandmarks().map((l) => l.id), ['beach']);
  assert.equal(m.update(150, 0).length, 0);
  assert.equal(m.update(40, 40).length, 0);
  assert.deepEqual(m.update(55, 55).map((l) => l.id), ['cave']);
  assert.equal(m.update(55, 55).length, 0); // لا إعادة اكتشاف
  assert.ok(m.isExplored(55, 55));
  assert.equal(m.isExplored(-200, -200), false);
  assert.equal(m.placeAt(2, 2), 'peak');
  assert.equal(m.placeAt(300, 300), null);

  const px = MapData.worldToMap(0, 0, 256, 512);
  assert.deepEqual(px, { px: 256, py: 256 });
  const w = MapData.mapToWorld(px.px, px.py, 256, 512);
  assert.ok(Math.abs(w.x) < 1e-9 && Math.abs(w.z) < 1e-9);

  const saved = JSON.parse(JSON.stringify(m.toJSON()));
  const m2 = new MapData(m.landmarks.map((l) => ({ ...l, known: false })));
  m2.load(saved);
  assert.ok(m2.isDiscovered('cave'));
  m2.fullMapUnlocked = true;
  assert.ok(m2.isExplored(-200, -200));
  assert.equal(m2.visibleLandmarks().length, 3);
});
