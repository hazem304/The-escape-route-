import test from 'node:test';
import assert from 'node:assert/strict';
import { pickClip } from '../src/render/ClipPicker';

test('اختيار مقطع الأنيميشن بالاسم مع بدائل', () => {
  const n = ['Armature|Idle', 'Armature|Walk', 'Armature|Run', 'Armature|Death'];
  assert.equal(pickClip(n, 'idle'), 0);
  assert.equal(pickClip(n, 'walk'), 1);
  assert.equal(pickClip(n, 'run'), 2);
  assert.equal(pickClip(n, 'dead'), 3);
  assert.equal(pickClip(['Walk'], 'run'), 0);
  assert.equal(pickClip(['Walk'], 'idle'), 0);
  assert.equal(pickClip(['Wave'], 'walk'), 0);
  assert.equal(pickClip(['Wave'], 'dead'), -1);
  assert.equal(pickClip([], 'idle'), -1);
});
