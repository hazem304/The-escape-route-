#!/usr/bin/env python3
"""يولّد art_pipeline/higgsfield_prompts.md و asset_manifest.json (ونسخته في public/assets/).
المعرّفات تطابق ما يبحث عنه المحمّل في الكود: animal_<species> و npc_<id> و piece_<type>."""
import json, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SUFFIX = 'photorealistic, {view}, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background'

def prompt(subject, view='3/4 view'):
    return f'{subject} , ' + SUFFIX.format(view=view)

A = []   # الأصول المجسمة
def add(id, cat, ar, en, subject, tris, integ, lod=False, animated=False, sub='', ref=None):
    A.append(dict(id=id, category=cat, nameAr=ar, nameEn=en, subject=subject, tris=tris,
                  integration=integ, lod=lod, animated=animated, folder=sub or cat, ref=ref))

# ---------- شخصيات (25-40 ألف مضلع) ----------
CH = (25000, 40000)
add('player_hero', 'characters', 'بطل اللعبة', 'Hero castaway',
    'full-body adult male castaway survivor in his thirties, athletic lean build, sunburnt weathered face with short stubble, tattered blue airline-uniform shirt with rolled sleeves, dirty khaki cargo pants, worn leather boots, relaxed A-pose with arms slightly away from the body',
    CH, 'not_wired', animated=True)
add('npc_layla', 'characters', 'ليلى', 'Layla',
    'full-body woman doctor in her forties, calm precise expression, dark hair tied back, dirty light-blue blouse under a salvaged paramedic vest, canvas trousers, worn sandals, small first-aid pouch on her belt, relaxed A-pose',
    CH, 'auto', animated=True)
add('npc_omar', 'characters', 'عمر', 'Omar',
    'full-body young telecom engineer in his late twenties, eager restless expression, messy black hair, sunburnt nose, grease-stained gray t-shirt, rolled cargo shorts, tool belt with pliers and screwdrivers, mismatched sneakers, relaxed A-pose',
    CH, 'auto', animated=True)
add('npc_yusuf', 'characters', 'يوسف', 'Yusuf',
    'full-body seventy-year-old fisherman, deeply tanned lined face, short white beard, woven straw hat, faded patched linen shirt, rope belt, rolled canvas trousers, barefoot, slight stoop but strong forearms, relaxed A-pose',
    CH, 'auto', animated=True)

# ---------- حيوانات (8-15 ألف) ----------
AN = (8000, 15000)
for id, ar, en, s in [
    ('deer', 'غزال', 'Deer', 'tropical island deer, slender legs, light brown coat with faint spots, small antlers, alert standing pose'),
    ('boar', 'خنزير بري', 'Wild boar', 'wild boar, bristly dark gray-brown coat, short curved tusks, heavy shoulders, standing pose'),
    ('crab', 'سلطعون', 'Crab', 'large orange-red beach crab, two raised claws, segmented legs, textured shell'),
    ('seagull', 'نورس', 'Seagull', 'seagull with wings folded, white and gray plumage, yellow beak with red spot, standing on one leg'),
    ('shark', 'قرش', 'Shark', 'reef shark, sleek gray body, pale underbelly, visible gills, dorsal fin, swimming pose seen from the side'),
    ('snake', 'أفعى', 'Snake', 'venomous jungle viper coiled in a striking posture, olive green with dark diamond pattern'),
    ('jaguar', 'نمر', 'Jaguar', 'jaguar, muscular body, golden coat with black rosettes, low stalking pose'),
]:
    add(f'animal_{id}', 'animals', ar, en, s, AN, 'auto', animated=True)

# ---------- طبيعة ----------
TREE = (3000, 8000); ROCK = (2000, 6000); PLANT = (1000, 4000)
for id, ar, en, s, tr, lod in [
    ('tree_palm_a', 'نخلة طويلة', 'Tall coconut palm', 'tall coconut palm tree with a slightly curved trunk, full crown of long fronds and a cluster of coconuts', TREE, True),
    ('tree_palm_b', 'نخلة مائلة', 'Leaning palm', 'leaning beach palm tree with a thick ringed trunk and drooping fronds', TREE, True),
    ('tree_jungle_a', 'شجرة غابة', 'Jungle tree', 'tall tropical jungle tree with buttress roots, dense dark-green canopy and hanging vines', TREE, True),
    ('tree_jungle_b', 'تين خانق', 'Strangler fig', 'strangler fig tree with tangled aerial roots wrapping a hollow trunk', TREE, True),
    ('tree_stump', 'جذع شجرة', 'Tree stump', 'weathered tree stump with exposed roots and moss', (1000, 3000), False),
    ('fallen_log', 'جذع ساقط', 'Fallen log', 'large fallen jungle log with bark peeling and small mushrooms', (1500, 4000), False),
    ('bamboo', 'خيزران', 'Bamboo cluster', 'dense cluster of green bamboo stalks with leaves', TREE, True),
    ('rock_boulder', 'صخرة كبيرة', 'Boulder', 'large rounded gray boulder with lichen and cracks', ROCK, False),
    ('rock_flat', 'صخرة مسطحة', 'Flat rock', 'flat shoreline rock slab with barnacles and wet streaks', ROCK, False),
    ('rock_spire', 'برج بركاني', 'Volcanic spire', 'dark volcanic rock spire, porous basalt, sharp edges', ROCK, False),
    ('rock_iron', 'صخرة حديد', 'Iron ore rock', 'gray rock with rust-orange iron ore veins visible', ROCK, False),
    ('rock_copper', 'صخرة نحاس', 'Copper ore rock', 'dark rock with bright green-blue copper ore veins', ROCK, False),
    ('bush_berry', 'شجيرة توت', 'Berry bush', 'small tropical bush with clusters of red berries and green leaves', PLANT, False),
    ('plant_fiber', 'نبات ألياف', 'Fiber plant', 'tall fibrous agave-like plant with long strap leaves', PLANT, False),
    ('mushroom_patch', 'فطر', 'Mushroom patch', 'cluster of tan edible mushrooms on a mossy patch of soil', PLANT, False),
    ('clay_bank', 'ضفة طين', 'Clay bank', 'small bank of wet reddish-brown clay with finger marks', PLANT, False),
    ('fern', 'سرخس', 'Fern', 'large tropical fern with arching fronds', PLANT, False),
]:
    add(id, 'nature', ar, en, s, tr, 'not_wired', lod=lod)

# ---------- حقائب ----------
BAG = (2000, 5000)
add('item_backpack_cloth', 'items', 'حقيبة قماش', 'Cloth backpack', 'small worn canvas backpack, frayed straps, patched, level 1', BAG, 'not_wired')
add('item_backpack_leather', 'items', 'حقيبة جلد', 'Leather backpack', 'medium brown leather backpack with metal buckles and side pockets, level 2', BAG, 'not_wired')
add('item_backpack_military', 'items', 'حقيبة عسكرية', 'Military backpack', 'large olive-drab military rucksack with many pouches and a rolled sleeping mat, level 3', BAG, 'not_wired')

# ---------- أدوات وأسلحة (1-5 آلاف) ----------
TL = (1000, 5000)
for id, ar, en, s in [
    ('axe_stone', 'فأس حجري', 'Stone axe', 'primitive stone axe, knapped gray flint head lashed to a wooden handle with cord'),
    ('axe_iron', 'فأس حديدي', 'Iron axe', 'forged iron felling axe with a dark steel head and hickory handle'),
    ('pickaxe_stone', 'معول حجري', 'Stone pickaxe', 'primitive pickaxe with a stone head bound to a wooden shaft'),
    ('pickaxe_iron', 'معول حديدي', 'Iron pickaxe', 'iron pickaxe with a worn steel head and wooden shaft'),
    ('knife_stone', 'سكين حجري', 'Stone knife', 'sharp flint blade knife with a wrapped bone handle'),
    ('knife_steel', 'سكين فولاذ', 'Steel knife', 'survival knife with a steel blade and wrapped grip'),
    ('machete', 'منجل', 'Machete', 'long machete with a slightly curved blade and black handle'),
    ('fishing_rod', 'صنارة', 'Fishing rod', 'handmade bamboo fishing rod with line, hook and a cork float'),
    ('fishing_net', 'شبكة صيد', 'Fishing net', 'small hand-woven fishing net with stone weights'),
    ('shovel', 'مجرفة', 'Shovel', 'metal shovel with a worn wooden handle'),
    ('hammer', 'مطرقة', 'Hammer', 'claw hammer with a wooden handle'),
    ('saw', 'منشار', 'Saw', 'hand saw with a rusted steel blade and wooden grip'),
    ('flint_steel', 'حجر وفولاذ', 'Flint and steel', 'flint stone and steel striker for fire making'),
    ('fire_drill', 'مثقاب نار', 'Fire drill', 'bow drill fire-starting kit: bow, spindle and fireboard'),
    ('lighter', 'قداحة', 'Lighter', 'scratched metal lighter'),
    ('torch', 'مشعل', 'Torch', 'wooden torch wrapped with oil-soaked cloth at the top'),
    ('lantern', 'فانوس', 'Lantern', 'old oil lantern with a glass chimney and metal handle'),
    ('compass', 'بوصلة', 'Compass', 'brass pocket compass with a glass cover'),
    ('binoculars', 'منظار', 'Binoculars', 'compact black binoculars with worn rubber grips'),
    ('waterproof_bag', 'كيس مقاوم للماء', 'Waterproof bag', 'rolled-top yellow waterproof dry bag'),
    ('flare_gun', 'مسدس إشارة', 'Flare gun', 'orange emergency flare gun'),
    ('flare', 'شعلة إشارة', 'Flare', 'red emergency signal flare stick'),
    ('signal_mirror', 'مرآة إشارة', 'Signal mirror', 'small rectangular metal signal mirror with a sighting hole'),
    ('matches', 'عيدان ثقاب', 'Matches', 'small box of wooden matches'),
    ('spear_wood', 'رمح خشبي', 'Wooden spear', 'sharpened fire-hardened wooden spear'),
    ('spear_stone', 'رمح بسن حجري', 'Stone spear', 'wooden spear with a lashed flint spearhead'),
    ('club', 'هراوة', 'Club', 'heavy knotted wooden club'),
    ('bow', 'قوس', 'Bow', 'simple wooden bow with a string'),
    ('arrow', 'سهم', 'Arrow', 'wooden arrow with feather fletching and a stone point'),
]:
    add(f'item_{id}', 'items', ar, en, s, TL, 'not_wired')

# ---------- قطع البناء ----------
PC = (500, 3000)
for id, ar, en, s, tr in [
    ('foundation', 'أساس', 'Foundation', 'square 3 meter timber platform foundation on short log piles, weathered planks', PC),
    ('wall', 'جدار', 'Wall', '3 meter wide by 2.5 meter tall rustic wall of lashed bamboo and planks', PC),
    ('doorway', 'إطار باب', 'Doorway', '3 meter wall segment with a central doorway opening, timber frame', PC),
    ('door', 'باب', 'Door', 'simple plank door with rope hinges and a wooden latch', PC),
    ('roof', 'سقف', 'Roof', '3 meter square thatched palm-leaf roof panel on a timber frame', PC),
    ('campfire', 'موقد', 'Campfire', 'campfire ring of stones with stacked logs, unlit', PC),
    ('workbench', 'طاولة عمل', 'Workbench', 'sturdy rustic workbench with a vise and hanging tools', PC),
    ('barrel', 'برميل', 'Barrel', 'wooden barrel with iron hoops and a lid', PC),
    ('cooler', 'صندوق تبريد', 'Cooler', 'old insulated cooler box with a latch', PC),
    ('storage', 'صندوق تخزين', 'Storage box', 'wooden storage chest with iron corners', PC),
    ('bed', 'فراش', 'Bed', 'simple bed frame with a woven palm-leaf mattress and a blanket', PC),
    ('rack', 'رف تجفيف', 'Drying rack', 'wooden drying rack with horizontal poles', PC),
    ('furnace', 'فرن', 'Furnace', 'small clay and stone smelting furnace with a chimney and fire door', PC),
    ('collector', 'جامع مطر', 'Rain collector', 'rain collector: a tarp stretched over poles funneling into a barrel', PC),
    ('farm', 'قطعة زراعة', 'Farm plot', 'small framed garden plot with tilled soil and tiny seedlings', PC),
    ('raft', 'طوافة', 'Raft', 'survival raft of lashed logs and planks with a small mast and a patched sail', (2000, 6000)),
]:
    add(f'piece_{id}', 'pieces', ar, en, s, tr, 'auto')

# ---------- حطام الطائرة والمخبأ ----------
WK = (2000, 15000)
for id, ar, en, s in [
    ('wreck_fuselage', 'جسم الطائرة', 'Fuselage', 'broken section of a small passenger airplane fuselage, torn aluminum skin, open cabin, scorched edges'),
    ('wreck_wing', 'جناح', 'Wing', 'detached airplane wing, bent and torn, with one damaged propeller'),
    ('wreck_tail', 'ذيل', 'Tail', 'airplane tail section with vertical stabilizer half torn off'),
    ('wreck_engine', 'محرك', 'Engine', 'airplane engine block with twisted propeller blades, dented cowling'),
    ('wreck_seats', 'صف مقاعد', 'Seat row', 'row of three torn airplane passenger seats, still bolted to a floor section'),
    ('wreck_crate', 'صندوق شحن', 'Cargo crate', 'dented metal and wood cargo crate with stenciled markings, lid half open'),
    ('wreck_gear', 'عجلة هبوط', 'Landing gear', 'airplane landing gear strut with a flat rubber wheel'),
    ('wreck_cockpit', 'قمرة القيادة', 'Cockpit', 'smashed airplane cockpit with cracked windshield, pilot seats and instrument panel'),
    ('bunker_entrance', 'مدخل المخبأ', 'Bunker entrance', 'concrete bunker entrance built into a rocky hillside, overgrown with vines, heavy steel door'),
    ('bunker_door', 'باب المخبأ', 'Bunker door', 'heavy rusted steel bunker door with a wheel lock'),
    ('radio_set', 'جهاز راديو', 'Radio set', 'bulky vintage field radio with dials, a handset and a coiled cable'),
    ('satellite_phone', 'هاتف فضائي', 'Satellite phone', 'rugged satellite phone with a stubby antenna'),
    ('flight_recorder', 'الصندوق الأسود', 'Flight recorder', 'orange flight data recorder box, scratched, with a stenciled label'),
]:
    add(id, 'wreck', ar, en, s, WK, 'not_wired')

# ---------- خامات (2K) ----------
TEX = [
    ('wet_sand', 'رمل مبلل', 'Wet sand', 'wet beach sand with fine grains, subtle ripples and tiny shell fragments'),
    ('dry_sand', 'رمل جاف', 'Dry sand', 'dry pale beach sand with fine grain and faint wind ripples'),
    ('volcanic_rock', 'صخر بركاني', 'Volcanic rock', 'dark porous volcanic basalt with small vesicles and rough surface'),
    ('palm_bark', 'لحاء نخيل', 'Palm bark', 'palm tree trunk bark with horizontal ring scars and fibrous texture'),
    ('torn_cloth', 'قماش ممزق', 'Torn cloth', 'worn faded canvas cloth with frayed holes and stitched patches'),
    ('leather', 'جلد', 'Leather', 'worn brown leather with creases, scratches and subtle stitching'),
    ('rust', 'صدأ', 'Rust', 'corroded metal with orange-brown rust patches and flaking paint'),
    ('jungle_floor', 'أرضية غابة', 'Jungle floor', 'jungle soil covered with leaf litter, roots and moss'),
    ('wood_planks', 'ألواح خشب', 'Weathered planks', 'weathered gray wooden planks with nail heads and cracks'),
    ('thatch', 'قش سقف', 'Thatch', 'dry palm-leaf thatch roofing layered in overlapping rows'),
    ('cave_wall', 'جدار كهف', 'Cave wall', 'damp cave wall rock with mineral streaks and small stalactite bumps'),
]
VID = [
    ('intro_crash', 'مقدمة: تحطم الطائرة', 'Intro: plane crash', 8,
     'cinematic shot of a small passenger airplane with a smoking engine descending through storm clouds toward a tropical island, ocean below, lightning in the distance, handheld camera slowly pushing in, the plane skims the water and breaks apart on the shoreline, dramatic realistic lighting, no text, no logos'),
    ('intro_wake', 'مقدمة: الاستيقاظ على الشاطئ', 'Intro: waking on the beach', 6,
     'first-person point of view lying on wet sand at dawn, vision blurry then slowly focusing, gentle waves washing up, airplane wreckage smoking in the background, seagulls overhead, camera tilts up to the sky as the survivor sits up, soft golden light, no text, no logos'),
    ('ending_rescue', 'نهاية: الإنقاذ', 'Ending: rescue', 6,
     'rescue helicopter flying low over a tropical island beach at golden hour, sand blowing from the rotor wash, a lone survivor waving a flare, camera orbits around the helicopter as it lands, emotional cinematic mood, no text, no logos'),
    ('ending_raft', 'نهاية: الإبحار', 'Ending: raft', 6,
     'handmade wooden raft with a patched sail leaving a tropical island at sunrise, calm sea, the island shrinking behind, a lone figure at the tiller, wide aerial camera pulling back, serene cinematic mood, no text, no logos'),
    ('ending_secret', 'نهاية: سر الجزيرة', 'Ending: island secret', 6,
     'interior of a hidden concrete bunker, a lone survivor transmitting on a satellite phone beside glowing monitors, dust in the light, camera slowly pushes in on their face as the screens flicker to life, tense mysterious mood, no text, no logos'),
]

def path_for(a):
    return f"models/{a['folder']}/{a['id']}.glb"

def build():
    # ---------- المانيفست ----------
    assets, n = [], 0
    for a in A:
        n += 1
        a['n'] = n
        assets.append(dict(
            id=a['id'], file=path_for(a), category=a['category'], nameAr=a['nameAr'], nameEn=a['nameEn'],
            maxTris=a['tris'][1], minTris=a['tris'][0], scale=1, offsetY=0, rotY=0, animated=a['animated'], lod=a['lod'],
            status='required',   # required | generated | integrated  (مطلوب / مولد / مدمج)
            integration=a['integration'],  # auto = المحمّل يستبدل تلقائيًا · not_wired = يلزم ربطه في الكود بعد توليده
            prompt=f"#{a['n']}"))
    textures = [dict(id=f'tex_{i}', file=f'textures/{i}_2k.png', size=2048, nameAr=ar, nameEn=en, status='required', integration='not_wired') for i, ar, en, _ in TEX]
    videos = [dict(id=i, file=f'video/{i}.mp4', seconds=s, nameAr=ar, nameEn=en, status='required', integration='not_wired') for i, ar, en, s, _ in VID]
    manifest = dict(version=1, basePath='/assets/', statuses=['required', 'generated', 'integrated'], assets=assets, textures=textures, videos=videos)
    text = json.dumps(manifest, ensure_ascii=False, indent=1) + '\n'
    (ROOT / 'art_pipeline').mkdir(exist_ok=True)
    (ROOT / 'art_pipeline' / 'asset_manifest.json').write_text(text, encoding='utf-8')
    pub = ROOT / 'public' / 'assets'
    (pub / 'models').mkdir(parents=True, exist_ok=True)
    (pub / 'asset_manifest.json').write_text(text, encoding='utf-8')

    # ---------- ملف البرومبتات ----------
    L = ['# برومبتات Higgsfield', '',
         '> **مولَّد آليًا** بواسطة `tools/gen_art_pipeline.py` — لا تعدّله يدويًا؛ غيّر السكربت ثم أعد التوليد.', '',
         'الصيغة الثابتة لكل برومبت مجسم:', '',
         '```', '[الموضوع] , photorealistic, 3/4 view, neutral studio lighting, plain light-gray background, high detail, PBR material look, game asset concept, no shadows on background', '```', '',
         'استثناء مقصود: في أوراق الشخصيات (Character Sheets) يُستبدل `3/4 view` بـ `front view` أو `side view` أو `back view` فقط، وباقي الصيغة كما هي.', '',
         'Higgsfield يولّد صورًا وفيديو فقط، لا مجسمات 3D. الناتج صور مرجعية تُحوَّل لاحقًا إلى 3D (انظر `README_pipeline.md`).', '']
    cats = [('characters', 'الشخصيات'), ('animals', 'الحيوانات'), ('nature', 'الأشجار والصخور والنباتات'),
            ('items', 'الحقائب والأدوات والأسلحة'), ('pieces', 'قطع البناء والملاجئ والطوافة'), ('wreck', 'بقايا الطائرة والمخبأ')]
    total = 0
    for c, title in cats:
        L += [f'## {title}', '']
        for a in [x for x in A if x['category'] == c]:
            lo, hi = a['tris']
            L += [f"### #{a['n']} `{a['id']}` — {a['nameAr']} / {a['nameEn']}",
                  f"- الملف المتوقع: `public/assets/{path_for(a)}` · الميزانية: {lo:,}–{hi:,} مضلع" + (' · مع LOD' if a['lod'] else '') + (' · مهيّأ للتحريك' if a['animated'] else ''),
                  f"- الربط: {'تلقائي عبر المحمّل' if a['integration'] == 'auto' else 'يحتاج ربطًا في الكود بعد توليده'}",
                  '```', prompt(a['subject']), '```', '']
            total += 1
    # أوراق الشخصيات
    L += ['## أوراق الشخصيات (Character Sheets)', '',
          'لكل شخصية: ولّد أولًا الصورة 3/4 أعلاه حتى ترضى عنها، ثم ارفعها كـ**صورة مرجعية** في Higgsfield (ميزة الإبقاء على ثبات الوجه/الشخصية) وولّد الزوايا الثلاث. لا تبدّل الملابس أو الملامح بين الزوايا؛ إن اختلف الوجه أعد التوليد من الصورة المرجعية.', '']
    sheets = 0
    for a in [x for x in A if x['category'] == 'characters']:
        for view in ('front view', 'side view', 'back view'):
            sheets += 1
            L += [f"### `{a['id']}` — {a['nameEn']} · {view}", '```',
                  prompt(a['subject'] + ', character turnaround sheet, identical face, hair and outfit as the reference image, same proportions in every view, relaxed A-pose', view), '```', '']
    L += ['## خامات قابلة للتكرار (2K)', '',
          'الدقة المطلوبة 2048×2048. Higgsfield لا يُخرج خرائط PBR؛ ولّد خريطة الألبيدو ثم استخرج Normal/Roughness/AO بأداة خرائط (مثل Materialize المجانية) وتأكد من التكرار السلس (seamless) في Blender أو أي محرر قبل الاعتماد.', '']
    for i, ar, en, s in TEX:
        L += [f'### `tex_{i}` — {ar} / {en}', f'- الملف المتوقع: `public/assets/textures/{i}_2k.png`', '```',
              f'seamless tileable texture of {s} , top-down flat orthographic view, even diffuse lighting, no baked shadows, no perspective, 2048x2048, photorealistic, high detail, PBR albedo look, game texture', '```', '']
    L += ['## فيديو: مقدمات ونهايات', '', 'الفيديوهات قصيرة (5–10 ثوانٍ)، بنسبة 16:9، بلا نصوص أو شعارات. تُستخدم مقدمةً أو شاشة نهاية.', '']
    for i, ar, en, s, p in VID:
        L += [f'### `{i}` — {ar} / {en} ({s}s)', f'- الملف المتوقع: `public/assets/video/{i}.mp4`', '```', p, '```', '']
    L += ['---', f'**الإجمالي:** {total} برومبت مجسم + {sheets} ورقة شخصية + {len(TEX)} خامة + {len(VID)} فيديو = {total + sheets + len(TEX) + len(VID)} برومبت.']
    (ROOT / 'art_pipeline' / 'higgsfield_prompts.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
    print(f'models={total} sheets={sheets} textures={len(TEX)} videos={len(VID)} total={total + sheets + len(TEX) + len(VID)}')

if __name__ == '__main__':
    build()
