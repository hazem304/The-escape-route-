#!/usr/bin/env python3
"""يولّد src/data/recipes.json ويتحقق من أن كل المعرّفات موجودة في items.json."""
import json, os
root = os.path.join(os.path.dirname(__file__), '..')
items = {i['id'] for i in json.load(open(os.path.join(root, 'src/data/items.json'), encoding='utf-8'))}

R = []
def r(id, ar, en, station, ing, out, time=3, tools=None, skill=None, wear=1, xp=2):
    """ing: {item: count}; out: (item, count); tools: [items required & worn]; skill: (name, level)"""
    R.append(dict(
        id=id, nameAr=ar, nameEn=en, station=station,
        ingredients=[dict(id=k, count=v) for k, v in ing.items()],
        tools=tools or [], output=dict(id=out[0], count=out[1]), time=time,
        skill=dict(name=skill[0], level=skill[1]) if skill else None, toolWear=wear, xp=xp))

# ---- يدوي: أساسيات ----
r('rope_fiber','حبل من الألياف','Rope (fiber)','hand',{'plant_fiber':4},('rope',1),2,skill=('crafting',0))
r('rope_vine','حبل من الكروم','Rope (vine)','hand',{'vine':3},('rope',2),2)
r('tinder_fiber','مادة إشعال','Tinder','hand',{'plant_fiber':2},('tinder',2),1)
r('tinder_bark','إشعال من اللحاء','Tinder (bark)','hand',{'bark':1},('tinder',2),1)
r('stone_blade','نصل حجري','Stone Blade','hand',{'stone':2},('stone_blade',1),4,skill=('crafting',0))
r('arrowhead_flint','رؤوس سهام','Arrowheads','hand',{'flint':1},('arrowhead',3),3,skill=('crafting',1))
r('fish_hook_bone','خطاف من عظم','Bone Hook','hand',{'bone':1},('fish_hook',2),4,tools=['knife_stone'])
r('cloth_fiber','قماش من الألياف','Cloth (fiber)','hand',{'plant_fiber':8},('cloth',1),6,skill=('crafting',1))
r('thatch','قش سقف','Thatch','hand',{'palm_leaf':3},('thatch',2),3)
r('bandage_scrap','ضمادة','Bandage','hand',{'cloth_scrap':2},('bandage',2),3)
r('bandage_cloth','ضمادات من قماش','Bandages (cloth)','hand',{'cloth':1},('bandage',4),4)
r('splint','جبيرة','Splint','hand',{'stick':2,'rope':1},('splint',1),5)
r('charcoal_pill','أقراص فحم','Charcoal Pills','hand',{'charcoal':2},('charcoal_pill',2),3)
r('firewood_log','حطب','Firewood','hand',{'wood_log':1},('firewood',3),5,tools=['axe_stone'],wear=1)
r('firewood_log_iron','حطب (فأس حديد)','Firewood (iron axe)','hand',{'wood_log':1},('firewood',4),3,tools=['axe_iron'])
r('plank_log','ألواح','Planks','hand',{'wood_log':1},('plank',2),6,tools=['axe_stone'],skill=('crafting',1))
r('plank_saw','ألواح بالمنشار','Planks (saw)','workbench',{'wood_log':1},('plank',4),5,tools=['saw'],skill=('crafting',2))
r('support_beam','عارضة دعم','Support Beam','hand',{'wood_log':1},('support_beam',1),4,tools=['axe_stone'])
r('salted_fish','سمك مملح','Salted Fish','hand',{'raw_fish':1,'salt':1},('salted_fish',1),4,skill=('survival',1))
r('dried_meat','لحم مجفف','Dried Meat','hand',{'raw_meat':1,'salt':1},('dried_meat',2),5,skill=('survival',1))
r('canteen','قربة ماء','Canteen','hand',{'leather':2,'rope':1},('canteen_empty',1),6,skill=('crafting',2))
r('waterproof_bag','كيس مقاوم للماء','Waterproof Bag','hand',{'leather':1,'resin':2},('waterproof_bag',1),6,skill=('crafting',2))

# ---- أدوات (طاولة عمل أو يدوي) ----
r('knife_stone','سكين حجري','Stone Knife','hand',{'stone_blade':1,'stick':1,'rope':1},('knife_stone',1),5,skill=('crafting',0),xp=3)
r('axe_stone','فأس حجري','Stone Axe','hand',{'stone_blade':1,'stick':2,'rope':2},('axe_stone',1),8,skill=('crafting',0),xp=4)
r('pickaxe_stone','معول حجري','Stone Pickaxe','hand',{'stone_blade':1,'stick':2,'rope':2,'stone':1},('pickaxe_stone',1),8,skill=('crafting',1),xp=4)
r('hammer','مطرقة','Hammer','hand',{'stone':2,'stick':1,'rope':1},('hammer',1),6,skill=('crafting',1))
r('shovel','مجرفة','Shovel','workbench',{'plank':1,'stone_blade':2,'stick':1,'rope':1},('shovel',1),8,skill=('crafting',2))
r('spear_wood','رمح خشبي','Wooden Spear','hand',{'stick':3},('spear_wood',1),6,tools=['knife_stone'],skill=('hunting',0))
r('spear_stone','رمح بحجر','Stone Spear','hand',{'stick':3,'stone_blade':1,'rope':1},('spear_stone',1),8,skill=('hunting',1),xp=4)
r('club','هراوة','Club','hand',{'wood_log':1},('club',1),6,tools=['axe_stone'])
r('bow','قوس','Bow','workbench',{'stick':3,'rope':2},('bow',1),10,tools=['knife_stone'],skill=('hunting',2),xp=6)
r('arrow','سهام','Arrows','hand',{'stick':1,'feather':1,'arrowhead':1},('arrow',3),5,skill=('hunting',1))
r('fishing_rod','صنارة','Fishing Rod','hand',{'stick':2,'rope':1,'fish_hook':1},('fishing_rod',1),6,skill=('hunting',0))
r('fishing_net','شبكة صيد','Fishing Net','hand',{'rope':6,'stick':2},('fishing_net',1),12,skill=('hunting',2),xp=5)
r('torch','مشعل','Torch','hand',{'stick':1,'cloth_scrap':1,'resin':1},('torch',1),3)
r('torch_fat','مشعل بالدهن','Torch (fat)','hand',{'stick':1,'cloth_scrap':1,'animal_fat':1},('torch',1),3)
r('fire_drill','مثقاب نار','Fire Drill','hand',{'stick':2,'plant_fiber':2},('fire_drill',1),4)
r('lantern','فانوس','Lantern','workbench',{'iron_ingot':1,'glass_shard':2,'animal_fat':1},('lantern',1),10,skill=('crafting',3))
r('saw','منشار','Saw','workbench',{'iron_ingot':2,'plank':1,'rope':1},('saw',1),12,skill=('crafting',3),xp=6)
r('axe_iron','فأس حديدي','Iron Axe','workbench',{'iron_ingot':3,'stick':2,'rope':2},('axe_iron',1),14,tools=['hammer'],skill=('crafting',3),xp=8)
r('pickaxe_iron','معول حديدي','Iron Pickaxe','workbench',{'iron_ingot':3,'stick':2,'rope':2},('pickaxe_iron',1),14,tools=['hammer'],skill=('crafting',3),xp=8)
r('knife_steel','سكين فولاذ','Steel Knife','workbench',{'iron_ingot':2,'leather':1,'rope':1},('knife_steel',1),12,tools=['hammer'],skill=('crafting',3),xp=8)
r('nails','مسامير','Nails','workbench',{'iron_ingot':1},('nails',20),6,tools=['hammer'],skill=('crafting',2))
r('bottle','زجاجة','Bottle','furnace',{'glass_shard':3,'charcoal':1},('bottle_empty',1),10,skill=('crafting',3))

# ---- ملابس وحقائب ----
r('hat_straw','قبعة قش','Straw Hat','hand',{'palm_leaf':4,'plant_fiber':2},('hat_straw',1),8,skill=('crafting',0))
r('bandana','عصابة رأس','Bandana','hand',{'cloth_scrap':3},('bandana',1),4)
r('sandals','صندل','Sandals','hand',{'palm_leaf':3,'rope':2},('sandals',1),8)
r('shirt_cloth','قميص','Cloth Shirt','hand',{'cloth':4,'rope':1},('shirt_cloth',1),12,skill=('crafting',1))
r('pants_cloth','بنطال','Cloth Pants','hand',{'cloth':4,'rope':1},('pants_cloth',1),12,skill=('crafting',1))
r('gloves_cloth','قفازات قماش','Cloth Gloves','hand',{'cloth':2},('gloves_cloth',1),6)
r('raincoat','معطف مطر','Raincoat','hand',{'cloth':4,'resin':2,'palm_leaf':2},('raincoat',1),14,skill=('crafting',2),xp=5)
r('boots_leather','حذاء جلدي','Leather Boots','workbench',{'leather':4,'rope':2},('boots_leather',1),16,skill=('crafting',2),xp=6)
r('gloves_leather','قفازات جلد','Leather Gloves','workbench',{'leather':2,'rope':1},('gloves_leather',1),10,skill=('crafting',2))
r('jacket_leather','سترة جلدية','Leather Jacket','workbench',{'leather':6,'rope':3},('jacket_leather',1),20,skill=('crafting',3),xp=8)
r('backpack_cloth','حقيبة قماش','Cloth Backpack','hand',{'cloth':6,'rope':2},('backpack_cloth',1),15,skill=('crafting',1),xp=6)
r('backpack_leather','حقيبة جلد','Leather Backpack','workbench',{'leather':8,'rope':3,'nails':4},('backpack_leather',1),25,skill=('crafting',3),xp=10)

# ---- طبخ (نار المخيم) ----
r('cook_fish','سمك مشوي','Grill Fish','campfire',{'raw_fish':1},('cooked_fish',1),20)
r('cook_crab','سلطعون مطبوخ','Cook Crab','campfire',{'raw_crab':1},('cooked_crab',1),18)
r('cook_meat','لحم مشوي','Grill Meat','campfire',{'raw_meat':1},('cooked_meat',1),25)
r('cook_egg','بيضة مسلوقة','Boil Egg','campfire',{'egg':1},('cooked_egg',1),15)
r('cook_roots','جذور مطبوخة','Cook Roots','campfire',{'edible_roots':1},('cooked_roots',1),20)
r('boil_water','غلي الماء','Boil Water','campfire',{'water_dirty':1},('water_boiled',1),30)
r('boil_rain','غلي ماء المطر','Boil Rainwater','campfire',{'rainwater':1},('water_boiled',1),20)
r('herbal_tea','شاي أعشاب','Herbal Tea','campfire',{'medicinal_herb':2,'water_boiled':1},('herbal_tea',1),25,skill=('survival',2))
r('stew','يخنة','Stew','campfire',{'cooked_meat':1,'edible_roots':1,'water_boiled':1},('stew',1),40,skill=('survival',2),xp=5)
r('fruit_mix','سلطة فواكه','Fruit Mix','hand',{'banana':1,'mango':1,'berries':2},('fruit_mix',1),5)
r('smoke_meat','لحم مدخّن','Smoke Meat','drying_rack',{'raw_meat':1,'firewood':1},('smoked_meat',1),60,skill=('survival',2))
r('smoke_fish','سمك مدخّن','Smoke Fish','drying_rack',{'raw_fish':1,'firewood':1},('smoked_fish',1),50,skill=('survival',2))
r('make_charcoal','فحم','Charcoal','campfire',{'wood_log':1},('charcoal',3),60)
r('tan_leather','دباغة الجلد','Tan Leather','campfire',{'raw_hide':1,'animal_fat':1},('leather',1),45,skill=('survival',1))

# ---- صهر (فرن) ----
r('smelt_iron','سبيكة حديد','Smelt Iron','furnace',{'iron_ore':2,'charcoal':1},('iron_ingot',1),40,skill=('crafting',2),xp=5)
r('smelt_copper','سبيكة نحاس','Smelt Copper','furnace',{'copper_ore':2,'charcoal':1},('copper_ingot',1),35,skill=('crafting',2),xp=5)
r('smelt_glass','زجاج','Smelt Glass','furnace',{'sand':4,'charcoal':1},('glass_shard',3),30,skill=('crafting',2))
r('smelt_scrap','إعادة صهر الخردة','Smelt Scrap','furnace',{'scrap_metal':3,'charcoal':1},('iron_ingot',1),30)

# ---- بناء وحاويات ----
r('campfire_kit','عدة موقد','Campfire Kit','hand',{'stone':8,'stick':4,'tinder':1},('campfire_kit',1),8)
r('workbench_kit','عدة طاولة عمل','Workbench Kit','hand',{'plank':6,'rope':3,'stone':4},('workbench_kit',1),15,skill=('crafting',1),xp=6)
r('storage_box','صندوق تخزين','Storage Box','workbench',{'plank':6,'nails':4},('storage_box',1),12,tools=['hammer'],skill=('building',1))
r('barrel','برميل','Barrel','workbench',{'plank':8,'nails':6,'resin':2},('barrel',1),18,tools=['hammer'],skill=('building',2))
r('cooler','ثلاجة بدائية','Cooler','workbench',{'plank':6,'clay':4,'salt':4,'palm_leaf':4},('cooler',1),24,tools=['hammer'],skill=('building',3),xp=8)
r('door_wood','باب خشبي','Wooden Door','workbench',{'plank':4,'nails':4,'rope':1},('door_wood',1),12,tools=['hammer'],skill=('building',1))
r('bed_leaf','فراش أوراق','Leaf Bed','hand',{'palm_leaf':8,'stick':4,'plant_fiber':4},('bed_leaf',1),15)
r('drying_rack','رف تجفيف','Drying Rack','hand',{'stick':6,'rope':2},('drying_rack',1),10)
r('furnace_kit','عدة فرن','Furnace Kit','hand',{'clay':15,'stone':20,'charcoal':2},('furnace_kit',1),30,skill=('building',2),xp=8)
r('farm_plot','قطعة زراعة','Farm Plot','hand',{'stick':8,'plant_fiber':4},('farm_plot',1),10,tools=['shovel'])
r('water_collector','جامع مياه المطر','Rain Collector','hand',{'palm_leaf':4,'bamboo':2,'rope':2},('water_collector',1),10,skill=('building',1))
r('raft_kit','عدة طوافة','Raft Kit','workbench',{'wood_log':8,'bamboo':10,'rope':10,'sail_cloth':1},('raft_kit',1),60,tools=['hammer'],skill=('building',3),xp=20)

# ---- التحقق ----
ids = [x['id'] for x in R]
assert len(ids) == len(set(ids)), 'duplicate recipe ids'
for x in R:
    refs = [i['id'] for i in x['ingredients']] + x['tools'] + [x['output']['id']]
    for ref in refs:
        assert ref in items, f"{x['id']}: unknown item {ref}"
json.dump(R, open(os.path.join(root, 'src/data/recipes.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(len(R), 'recipes OK')
