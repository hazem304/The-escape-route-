// تحقق من تطابق asset_manifest.json مع الملفات الفعلية: npm run assets:check
import { existsSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';

interface Entry { id: string; file: string; status: string; integration?: string; maxTris?: number }
const root = join(import.meta.dirname, '..');
const manifest = JSON.parse(readFileSync(join(root, 'public/assets/asset_manifest.json'), 'utf8')) as { assets: Entry[]; textures: Entry[]; videos: Entry[] };

let bad = 0;
const counts: Record<string, number> = { required: 0, generated: 0, integrated: 0 };
for (const e of [...manifest.assets, ...manifest.textures, ...manifest.videos]) {
  counts[e.status] = (counts[e.status] ?? 0) + 1;
  const p = join(root, 'public/assets', e.file);
  const exists = existsSync(p);
  if (e.status !== 'required' && !exists) { console.error(`✗ ${e.id}: الحالة ${e.status} لكن الملف مفقود: ${e.file}`); bad++; }
  if (e.status === 'required' && exists) { console.warn(`! ${e.id}: الملف موجود (${(statSync(p).size / 1024).toFixed(0)}KB) لكن الحالة required — حدّثها إلى generated`); }
  if (e.status === 'integrated' && e.integration === 'not_wired') { console.error(`✗ ${e.id}: لا يمكن أن يكون integrated وهو not_wired في الكود`); bad++; }
}
console.log(`مطلوب ${counts.required} · مولّد ${counts.generated} · مدمج ${counts.integrated}`);
process.exit(bad ? 1 : 0);
