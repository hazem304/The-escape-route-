"use strict";
(() => {
  // src/config.ts
  var KEY = "island-survival:config";
  var DEFAULTS = {
    language: "ar",
    quality: "medium",
    invertY: false,
    mouseSensitivity: 1,
    fov: 70,
    masterVolume: 0.8,
    sfxVolume: 1,
    musicVolume: 0.5,
    ambientVolume: 0.8,
    postfx: true,
    subtitles: false
  };
  function loadConfig() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return { ...DEFAULTS, ...JSON.parse(raw) };
    } catch {
    }
    return { ...DEFAULTS };
  }
  var QUALITY_PRESETS = {
    low: { pixelRatio: 1, shadows: false, shadowMapSize: 512 },
    medium: { pixelRatio: Math.min(window.devicePixelRatio, 1.5), shadows: true, shadowMapSize: 1024 },
    high: { pixelRatio: Math.min(window.devicePixelRatio, 2), shadows: true, shadowMapSize: 2048 }
  };

  // src/building/Blueprint.ts
  var CELL_SIZE = 3;
  var BLUEPRINTS = {
    foundation: { type: "foundation", nameAr: "\u0623\u0633\u0627\u0633", nameEn: "Foundation", snap: "cell", cost: { plank: 4, support_beam: 2 }, radius: 0 },
    wall: { type: "wall", nameAr: "\u062C\u062F\u0627\u0631", nameEn: "Wall", snap: "edge", cost: { plank: 3, nails: 4 }, radius: 0 },
    doorway: { type: "doorway", nameAr: "\u0625\u0637\u0627\u0631 \u0628\u0627\u0628", nameEn: "Doorway", snap: "edge", cost: { plank: 3, nails: 4 }, radius: 0 },
    door: { type: "door", nameAr: "\u0628\u0627\u0628", nameEn: "Door", snap: "edgeDoor", cost: { door_wood: 1 }, radius: 0 },
    roof: { type: "roof", nameAr: "\u0633\u0642\u0641", nameEn: "Roof", snap: "cell", cost: { thatch: 6, stick: 6, rope: 2 }, radius: 0 },
    campfire: { type: "campfire", nameAr: "\u0645\u0648\u0642\u062F", nameEn: "Campfire", snap: "free", cost: { campfire_kit: 1 }, radius: 0.8 },
    workbench: { type: "workbench", nameAr: "\u0637\u0627\u0648\u0644\u0629 \u0639\u0645\u0644", nameEn: "Workbench", snap: "free", cost: { workbench_kit: 1 }, radius: 1.1 },
    barrel: { type: "barrel", nameAr: "\u0628\u0631\u0645\u064A\u0644", nameEn: "Barrel", snap: "free", cost: { barrel: 1 }, radius: 0.6 },
    cooler: { type: "cooler", nameAr: "\u062B\u0644\u0627\u062C\u0629 \u0628\u062F\u0627\u0626\u064A\u0629", nameEn: "Primitive Cooler", snap: "free", cost: { cooler: 1 }, radius: 0.7 },
    storage: { type: "storage", nameAr: "\u0635\u0646\u062F\u0648\u0642 \u062A\u062E\u0632\u064A\u0646", nameEn: "Storage", snap: "free", cost: { storage_box: 1 }, radius: 0.7 },
    bed: { type: "bed", nameAr: "\u0641\u0631\u0627\u0634", nameEn: "Bed", snap: "free", cost: { bed_leaf: 1 }, radius: 1 },
    rack: { type: "rack", nameAr: "\u0631\u0641 \u062A\u062C\u0641\u064A\u0641", nameEn: "Drying Rack", snap: "free", cost: { drying_rack: 1 }, radius: 0.9 },
    furnace: { type: "furnace", nameAr: "\u0641\u0631\u0646", nameEn: "Furnace", snap: "free", cost: { furnace_kit: 1 }, radius: 1 },
    collector: { type: "collector", nameAr: "\u062C\u0627\u0645\u0639 \u0645\u0637\u0631", nameEn: "Rain Collector", snap: "free", cost: { water_collector: 1 }, radius: 0.6 },
    farm: { type: "farm", nameAr: "\u0645\u0632\u0631\u0639\u0629", nameEn: "Farm Plot", snap: "free", cost: { farm_plot: 1 }, radius: 1.5 },
    raft: { type: "raft", nameAr: "\u0637\u0648\u0627\u0641\u0629", nameEn: "Raft", snap: "free", cost: { raft_kit: 1 }, radius: 2.4, onWater: true }
  };

  // src/building/Snap.ts
  var BuildingGrid = class _BuildingGrid {
    // wall/doorway/door
    constructor(ground) {
      this.ground = ground;
    }
    ground;
    pieces = /* @__PURE__ */ new Map();
    nextId = 1;
    /** فهارس سريعة */
    cells = /* @__PURE__ */ new Map();
    // foundation / roof
    edges = /* @__PURE__ */ new Map();
    list() {
      return [...this.pieces.values()];
    }
    get(id) {
      return this.pieces.get(id);
    }
    // ---------- مفاتيح ----------
    static cellKey(type, cx, cz) {
      return `${type}:${cx},${cz}`;
    }
    static edgeKey(axis, cx, cz) {
      return `${axis}:${cx},${cz}`;
    }
    static cellOf(x, z) {
      return { cx: Math.floor(x / CELL_SIZE), cz: Math.floor(z / CELL_SIZE) };
    }
    /** الخليتان المتجاورتان لحافة */
    static edgeCells(axis, cx, cz) {
      return axis === "h" ? [[cx, cz], [cx, cz - 1]] : [[cx, cz], [cx - 1, cz]];
    }
    /** حواف خلية */
    static cellEdges(cx, cz) {
      return [
        { axis: "h", cx, cz },
        { axis: "h", cx, cz: cz + 1 },
        { axis: "v", cx, cz },
        { axis: "v", cx: cx + 1, cz }
      ];
    }
    /** تحت سقف؟ (خلية فيها أساس وسقف) */
    isSheltered(x, z) {
      const { cx, cz } = _BuildingGrid.cellOf(x, z);
      return this.cells.has(_BuildingGrid.cellKey("roof", cx, cz)) && this.hasFoundation(cx, cz);
    }
    hasFoundation(cx, cz) {
      return this.cells.has(_BuildingGrid.cellKey("foundation", cx, cz));
    }
    edgeSet(axis, cx, cz) {
      return this.edges.get(_BuildingGrid.edgeKey(axis, cx, cz)) ?? [];
    }
    /** أقرب هدف تثبيت لنقطة في العالم */
    snapFromWorld(type, x, z, yaw = 0) {
      const bp = BLUEPRINTS[type];
      if (bp.snap === "cell") {
        const { cx, cz } = _BuildingGrid.cellOf(x, z);
        return { kind: "cell", cx, cz };
      }
      if (bp.snap === "edge" || bp.snap === "edgeDoor") {
        const { cx, cz } = _BuildingGrid.cellOf(x, z);
        let best = null;
        for (const e of _BuildingGrid.cellEdges(cx, cz)) {
          const mx = e.axis === "h" ? (e.cx + 0.5) * CELL_SIZE : e.cx * CELL_SIZE;
          const mz = e.axis === "h" ? e.cz * CELL_SIZE : (e.cz + 0.5) * CELL_SIZE;
          const d = Math.hypot(x - mx, z - mz);
          if (!best || d < best.d) best = { ...e, d };
        }
        return { kind: "edge", cx: best.cx, cz: best.cz, axis: best.axis };
      }
      return { kind: "free", x, z, yaw };
    }
    /** هل يمكن وضع القطعة؟ (بدون استهلاك مواد) */
    validate(type, t2) {
      const bp = BLUEPRINTS[type];
      if (bp.snap === "cell" && t2.kind === "cell") {
        if (type === "foundation") {
          if (this.cells.has(_BuildingGrid.cellKey("foundation", t2.cx, t2.cz))) return { ok: false, error: "occupied" };
          const g = this.groundOkForCell(t2.cx, t2.cz);
          return g ? { ok: true } : { ok: false, error: "badGround" };
        }
        if (!this.hasFoundation(t2.cx, t2.cz)) return { ok: false, error: "noSupport" };
        if (this.cells.has(_BuildingGrid.cellKey("roof", t2.cx, t2.cz))) return { ok: false, error: "occupied" };
        const walls = _BuildingGrid.cellEdges(t2.cx, t2.cz).filter((e) => this.edgeSet(e.axis, e.cx, e.cz).length > 0).length;
        return walls >= 2 ? { ok: true } : { ok: false, error: "needsWalls" };
      }
      if ((bp.snap === "edge" || bp.snap === "edgeDoor") && t2.kind === "edge") {
        const here = this.edgeSet(t2.axis, t2.cx, t2.cz);
        const supported = _BuildingGrid.edgeCells(t2.axis, t2.cx, t2.cz).some(([a, b]) => this.hasFoundation(a, b));
        if (type === "door") {
          if (!here.some((p) => p.type === "doorway")) return { ok: false, error: "noDoorway" };
          if (here.some((p) => p.type === "door")) return { ok: false, error: "occupied" };
          return { ok: true };
        }
        if (!supported) return { ok: false, error: "noSupport" };
        if (here.length > 0) return { ok: false, error: "occupied" };
        return { ok: true };
      }
      if (bp.snap === "free" && t2.kind === "free") {
        const h2 = this.ground.height(t2.x, t2.z);
        if (bp.onWater) {
          if (h2 > this.ground.waterLevel - 0.6) return { ok: false, error: "notOnWater" };
        } else {
          if (h2 < this.ground.waterLevel + 0.2 || this.ground.slope(t2.x, t2.z) > 0.45) return { ok: false, error: "badGround" };
        }
        for (const p of this.pieces.values()) {
          const pr = BLUEPRINTS[p.type].radius;
          if (pr > 0 && Math.hypot(p.x - t2.x, p.z - t2.z) < pr + bp.radius) return { ok: false, error: "overlap" };
        }
        return { ok: true };
      }
      return { ok: false, error: "occupied" };
    }
    /**
     * يبني قطعة: يتحقق ثم يستهلك المواد من الحقيبة.
     * @param inv إن مُرّر تُستهلك التكلفة (وإلا بناء مجاني للاختبار/وضع الإبداع)
     */
    build(type, t2, inv) {
      const v = this.validate(type, t2);
      if (!v.ok) return v;
      const bp = BLUEPRINTS[type];
      if (inv) {
        for (const [id, n] of Object.entries(bp.cost)) if (!inv.has(id, n)) return { ok: false, error: "noMaterials" };
        for (const [id, n] of Object.entries(bp.cost)) inv.remove(id, n);
      }
      const piece = this.create(type, t2);
      this.pieces.set(piece.id, piece);
      this.index(piece);
      return { ok: true, piece };
    }
    create(type, t2) {
      const id = this.nextId++;
      if (t2.kind === "cell") {
        const x = (t2.cx + 0.5) * CELL_SIZE;
        const z = (t2.cz + 0.5) * CELL_SIZE;
        const y2 = this.cellTop(t2.cx, t2.cz);
        return { id, type, cx: t2.cx, cz: t2.cz, x, y: type === "roof" ? this.foundationY(t2.cx, t2.cz) + 2.5 : y2, z, yaw: 0 };
      }
      if (t2.kind === "edge") {
        const x = t2.axis === "h" ? (t2.cx + 0.5) * CELL_SIZE : t2.cx * CELL_SIZE;
        const z = t2.axis === "h" ? t2.cz * CELL_SIZE : (t2.cz + 0.5) * CELL_SIZE;
        const y2 = this.edgeBase(t2.axis, t2.cx, t2.cz);
        return { id, type, cx: t2.cx, cz: t2.cz, axis: t2.axis, x, y: y2, z, yaw: t2.axis === "h" ? 0 : Math.PI / 2 };
      }
      const y = BLUEPRINTS[type].onWater ? this.ground.waterLevel : this.ground.height(t2.x, t2.z);
      const { cx, cz } = _BuildingGrid.cellOf(t2.x, t2.z);
      return { id, type, cx, cz, x: t2.x, y, z: t2.z, yaw: t2.yaw };
    }
    index(p) {
      if (p.type === "foundation" || p.type === "roof") this.cells.set(_BuildingGrid.cellKey(p.type, p.cx, p.cz), p);
      else if (p.axis) {
        const k = _BuildingGrid.edgeKey(p.axis, p.cx, p.cz);
        const arr = this.edges.get(k) ?? [];
        arr.push(p);
        this.edges.set(k, arr);
      }
    }
    unindex(p) {
      if (p.type === "foundation" || p.type === "roof") this.cells.delete(_BuildingGrid.cellKey(p.type, p.cx, p.cz));
      else if (p.axis) {
        const k = _BuildingGrid.edgeKey(p.axis, p.cx, p.cz);
        const arr = (this.edges.get(k) ?? []).filter((q) => q.id !== p.id);
        if (arr.length) this.edges.set(k, arr);
        else this.edges.delete(k);
      }
    }
    /**
     * يزيل قطعة وكل ما فقد دعمه نتيجة ذلك.
     * @returns القطع المزالة (للاسترجاع الجزئي للمواد أو الإسقاط)
     */
    remove(id) {
      const root = this.pieces.get(id);
      if (!root) return [];
      const removed = [];
      const drop = (p) => {
        if (!this.pieces.delete(p.id)) return;
        this.unindex(p);
        removed.push(p);
      };
      drop(root);
      let changed = true;
      while (changed) {
        changed = false;
        for (const p of [...this.pieces.values()]) {
          if (!this.isSupported(p)) {
            drop(p);
            changed = true;
          }
        }
      }
      return removed;
    }
    isSupported(p) {
      switch (p.type) {
        case "wall":
        case "doorway":
          return _BuildingGrid.edgeCells(p.axis, p.cx, p.cz).some(([a, b]) => this.hasFoundation(a, b));
        case "door":
          return this.edgeSet(p.axis, p.cx, p.cz).some((q) => q.type === "doorway");
        case "roof":
          return this.hasFoundation(p.cx, p.cz);
        default:
          return true;
      }
    }
    /** تكلفة الاسترجاع (50% من المواد الخام للقطع المعيارية) */
    static refund(p) {
      const out = {};
      for (const [id, n] of Object.entries(BLUEPRINTS[p.type].cost)) {
        const back = Math.floor(n / 2);
        if (back > 0) out[id] = back;
      }
      return out;
    }
    // ---------- ارتفاعات ----------
    cellCorners(cx, cz) {
      const x0 = cx * CELL_SIZE;
      const z0 = cz * CELL_SIZE;
      return [
        this.ground.height(x0, z0),
        this.ground.height(x0 + CELL_SIZE, z0),
        this.ground.height(x0, z0 + CELL_SIZE),
        this.ground.height(x0 + CELL_SIZE, z0 + CELL_SIZE)
      ];
    }
    cellTop(cx, cz) {
      return Math.max(...this.cellCorners(cx, cz));
    }
    foundationY(cx, cz) {
      return this.cells.get(_BuildingGrid.cellKey("foundation", cx, cz))?.y ?? this.cellTop(cx, cz);
    }
    edgeBase(axis, cx, cz) {
      const ys = _BuildingGrid.edgeCells(axis, cx, cz).filter(([a, b]) => this.hasFoundation(a, b)).map(([a, b]) => this.foundationY(a, b));
      return ys.length ? Math.max(...ys) : this.ground.height(cx * CELL_SIZE, cz * CELL_SIZE);
    }
    /** الأرض صالحة للأساس: فوق الماء وميل طفيف في كل الزوايا وفرق ارتفاع محدود */
    groundOkForCell(cx, cz) {
      const c = this.cellCorners(cx, cz);
      const lo = Math.min(...c);
      const hi = Math.max(...c);
      if (lo < this.ground.waterLevel + 0.3) return false;
      return hi - lo <= 1.2;
    }
    toJSON() {
      return this.list();
    }
    load(pieces) {
      this.pieces.clear();
      this.cells.clear();
      this.edges.clear();
      for (const p of pieces) {
        this.pieces.set(p.id, p);
        this.index(p);
        this.nextId = Math.max(this.nextId, p.id + 1);
      }
    }
  };

  // src/data/items.json
  var items_default = [
    {
      id: "wood_log",
      nameAr: "\u062C\u0630\u0639 \u062E\u0634\u0628",
      nameEn: "Wood Log",
      type: "resource",
      stack: 5,
      size: [
        1,
        2
      ],
      weight: 3,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "wood_log",
      icon: "\u{1FAB5}"
    },
    {
      id: "stick",
      nameAr: "\u0639\u0635\u0627",
      nameEn: "Stick",
      type: "resource",
      stack: 30,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "stick",
      icon: "\u{1F962}"
    },
    {
      id: "stone",
      nameAr: "\u062D\u062C\u0631",
      nameEn: "Stone",
      type: "resource",
      stack: 15,
      size: [
        1,
        1
      ],
      weight: 1,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "stone",
      icon: "\u{1FAA8}"
    },
    {
      id: "flint",
      nameAr: "\u0635\u0648\u0627\u0646",
      nameEn: "Flint",
      type: "resource",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "flint",
      icon: "\u{1F538}"
    },
    {
      id: "plant_fiber",
      nameAr: "\u0623\u0644\u064A\u0627\u0641 \u0646\u0628\u0627\u062A\u064A\u0629",
      nameEn: "Plant Fiber",
      type: "resource",
      stack: 60,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "plant_fiber",
      icon: "\u{1F33F}"
    },
    {
      id: "rope",
      nameAr: "\u062D\u0628\u0644",
      nameEn: "Rope",
      type: "resource",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "rope",
      icon: "\u27B0"
    },
    {
      id: "palm_leaf",
      nameAr: "\u0633\u0639\u0641 \u0646\u062E\u064A\u0644",
      nameEn: "Palm Leaf",
      type: "resource",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "palm_leaf",
      icon: "\u{1F334}"
    },
    {
      id: "bamboo",
      nameAr: "\u062E\u064A\u0632\u0631\u0627\u0646",
      nameEn: "Bamboo",
      type: "resource",
      stack: 10,
      size: [
        1,
        2
      ],
      weight: 0.8,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "bamboo",
      icon: "\u{1F38B}"
    },
    {
      id: "vine",
      nameAr: "\u0643\u0631\u0645\u0629",
      nameEn: "Vine",
      type: "resource",
      stack: 30,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "vine",
      icon: "\u{1F331}"
    },
    {
      id: "resin",
      nameAr: "\u0635\u0645\u063A \u0634\u062C\u0631",
      nameEn: "Resin",
      type: "resource",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "resin",
      icon: "\u{1F7E0}"
    },
    {
      id: "clay",
      nameAr: "\u0637\u064A\u0646",
      nameEn: "Clay",
      type: "resource",
      stack: 15,
      size: [
        1,
        1
      ],
      weight: 0.8,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "clay",
      icon: "\u{1F7E4}"
    },
    {
      id: "sand",
      nameAr: "\u0631\u0645\u0644",
      nameEn: "Sand",
      type: "resource",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.8,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "sand",
      icon: "\u{1F3D6}\uFE0F"
    },
    {
      id: "raw_hide",
      nameAr: "\u062C\u0644\u062F \u062E\u0627\u0645",
      nameEn: "Raw Hide",
      type: "resource",
      stack: 5,
      size: [
        1,
        1
      ],
      weight: 1,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "raw_hide",
      icon: "\u{1F7EB}"
    },
    {
      id: "leather",
      nameAr: "\u062C\u0644\u062F \u0645\u062F\u0628\u0648\u063A",
      nameEn: "Leather",
      type: "resource",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.6,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "leather",
      icon: "\u{1F7E4}"
    },
    {
      id: "bone",
      nameAr: "\u0639\u0638\u0645",
      nameEn: "Bone",
      type: "resource",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "bone",
      icon: "\u{1F9B4}"
    },
    {
      id: "feather",
      nameAr: "\u0631\u064A\u0634",
      nameEn: "Feather",
      type: "resource",
      stack: 50,
      size: [
        1,
        1
      ],
      weight: 0.01,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "feather",
      icon: "\u{1FAB6}"
    },
    {
      id: "animal_fat",
      nameAr: "\u062F\u0647\u0646 \u062D\u064A\u0648\u0627\u0646\u064A",
      nameEn: "Animal Fat",
      type: "resource",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "common",
      durability: 0,
      spoilTime: 240,
      effects: {},
      model: "animal_fat",
      icon: "\u{1F9C8}"
    },
    {
      id: "charcoal",
      nameAr: "\u0641\u062D\u0645",
      nameEn: "Charcoal",
      type: "resource",
      stack: 30,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "charcoal",
      icon: "\u26AB"
    },
    {
      id: "iron_ore",
      nameAr: "\u062E\u0627\u0645 \u062D\u062F\u064A\u062F",
      nameEn: "Iron Ore",
      type: "resource",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 1.5,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "iron_ore",
      icon: "\u26CF\uFE0F"
    },
    {
      id: "copper_ore",
      nameAr: "\u062E\u0627\u0645 \u0646\u062D\u0627\u0633",
      nameEn: "Copper Ore",
      type: "resource",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 1.5,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "copper_ore",
      icon: "\u{1F7E7}"
    },
    {
      id: "iron_ingot",
      nameAr: "\u0633\u0628\u064A\u0643\u0629 \u062D\u062F\u064A\u062F",
      nameEn: "Iron Ingot",
      type: "resource",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 1,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "iron_ingot",
      icon: "\u{1F529}"
    },
    {
      id: "copper_ingot",
      nameAr: "\u0633\u0628\u064A\u0643\u0629 \u0646\u062D\u0627\u0633",
      nameEn: "Copper Ingot",
      type: "resource",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 1,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "copper_ingot",
      icon: "\u{1F7E0}"
    },
    {
      id: "scrap_metal",
      nameAr: "\u062E\u0631\u062F\u0629 \u0645\u0639\u062F\u0646",
      nameEn: "Scrap Metal",
      type: "resource",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.5,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "scrap_metal",
      icon: "\u{1F527}"
    },
    {
      id: "nails",
      nameAr: "\u0645\u0633\u0627\u0645\u064A\u0631",
      nameEn: "Nails",
      type: "resource",
      stack: 100,
      size: [
        1,
        1
      ],
      weight: 0.02,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "nails",
      icon: "\u{1F4CC}"
    },
    {
      id: "cloth",
      nameAr: "\u0642\u0645\u0627\u0634",
      nameEn: "Cloth",
      type: "resource",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "cloth",
      icon: "\u{1F9F5}"
    },
    {
      id: "cloth_scrap",
      nameAr: "\u0642\u0635\u0627\u0635\u0629 \u0642\u0645\u0627\u0634",
      nameEn: "Cloth Scrap",
      type: "resource",
      stack: 40,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "cloth_scrap",
      icon: "\u{1F9F6}"
    },
    {
      id: "glass_shard",
      nameAr: "\u0634\u0638\u064A\u0629 \u0632\u062C\u0627\u062C",
      nameEn: "Glass Shard",
      type: "resource",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "glass_shard",
      icon: "\u{1F539}"
    },
    {
      id: "salt",
      nameAr: "\u0645\u0644\u062D",
      nameEn: "Salt",
      type: "resource",
      stack: 30,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "salt",
      icon: "\u{1F9C2}"
    },
    {
      id: "shell",
      nameAr: "\u0635\u062F\u0641\u0629",
      nameEn: "Shell",
      type: "resource",
      stack: 30,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "shell",
      icon: "\u{1F41A}"
    },
    {
      id: "coconut_shell",
      nameAr: "\u0642\u0634\u0631\u0629 \u062C\u0648\u0632 \u0647\u0646\u062F",
      nameEn: "Coconut Shell",
      type: "resource",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "coconut_shell",
      icon: "\u{1F965}"
    },
    {
      id: "bark",
      nameAr: "\u0644\u062D\u0627\u0621 \u0634\u062C\u0631",
      nameEn: "Bark",
      type: "resource",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "bark",
      icon: "\u{1F7EB}"
    },
    {
      id: "plank",
      nameAr: "\u0644\u0648\u062D \u062E\u0634\u0628",
      nameEn: "Wood Plank",
      type: "resource",
      stack: 20,
      size: [
        1,
        2
      ],
      weight: 1.2,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "plank",
      icon: "\u{1F7E7}"
    },
    {
      id: "thatch",
      nameAr: "\u0642\u0634 \u0644\u0644\u0633\u0642\u0641",
      nameEn: "Thatch",
      type: "resource",
      stack: 30,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "thatch",
      icon: "\u{1F33E}"
    },
    {
      id: "support_beam",
      nameAr: "\u0639\u0627\u0631\u0636\u0629 \u062F\u0639\u0645",
      nameEn: "Support Beam",
      type: "resource",
      stack: 10,
      size: [
        1,
        2
      ],
      weight: 2.5,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "support_beam",
      icon: "\u{1FAB5}"
    },
    {
      id: "sulfur",
      nameAr: "\u0643\u0628\u0631\u064A\u062A",
      nameEn: "Sulfur",
      type: "resource",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "sulfur",
      icon: "\u{1F7E1}"
    },
    {
      id: "tinder",
      nameAr: "\u0645\u0627\u062F\u0629 \u0625\u0634\u0639\u0627\u0644",
      nameEn: "Tinder",
      type: "resource",
      stack: 40,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "tinder",
      icon: "\u{1F525}"
    },
    {
      id: "firewood",
      nameAr: "\u062D\u0637\u0628",
      nameEn: "Firewood",
      type: "resource",
      stack: 10,
      size: [
        1,
        2
      ],
      weight: 1,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "firewood",
      icon: "\u{1FAB5}"
    },
    {
      id: "stone_blade",
      nameAr: "\u0646\u0635\u0644 \u062D\u062C\u0631\u064A",
      nameEn: "Stone Blade",
      type: "resource",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "stone_blade",
      icon: "\u{1F52A}"
    },
    {
      id: "arrowhead",
      nameAr: "\u0631\u0623\u0633 \u0633\u0647\u0645",
      nameEn: "Arrowhead",
      type: "resource",
      stack: 40,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "arrowhead",
      icon: "\u{1F53A}"
    },
    {
      id: "fish_hook",
      nameAr: "\u062E\u0637\u0627\u0641 \u0633\u0645\u0643",
      nameEn: "Fish Hook",
      type: "resource",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.02,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "fish_hook",
      icon: "\u{1FA9D}"
    },
    {
      id: "coconut",
      nameAr: "\u062C\u0648\u0632 \u0647\u0646\u062F",
      nameEn: "Coconut",
      type: "food",
      stack: 5,
      size: [
        1,
        1
      ],
      weight: 0.6,
      rarity: "common",
      durability: 0,
      spoilTime: 240,
      effects: {
        hunger: 12,
        thirst: 8
      },
      model: "coconut",
      icon: "\u{1F965}"
    },
    {
      id: "banana",
      nameAr: "\u0645\u0648\u0632",
      nameEn: "Banana",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 0,
      spoilTime: 96,
      effects: {
        hunger: 10,
        thirst: 1
      },
      model: "banana",
      icon: "\u{1F34C}"
    },
    {
      id: "yam",
      nameAr: "\u064A\u0627\u0645",
      nameEn: "Yam",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.4,
      rarity: "common",
      durability: 0,
      spoilTime: 144,
      effects: {
        hunger: 14,
        thirst: 1
      },
      model: "yam",
      icon: "\u{1F360}"
    },
    {
      id: "mango",
      nameAr: "\u0645\u0627\u0646\u062C\u0648",
      nameEn: "Mango",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "common",
      durability: 0,
      spoilTime: 96,
      effects: {
        hunger: 12,
        thirst: 3
      },
      model: "mango",
      icon: "\u{1F96D}"
    },
    {
      id: "berries",
      nameAr: "\u062A\u0648\u062A \u0628\u0631\u064A",
      nameEn: "Berries",
      type: "food",
      stack: 30,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "common",
      durability: 0,
      spoilTime: 48,
      effects: {
        hunger: 4,
        thirst: 2
      },
      model: "berries",
      icon: "\u{1FAD0}"
    },
    {
      id: "mushroom",
      nameAr: "\u0641\u0637\u0631",
      nameEn: "Mushroom",
      type: "food",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "common",
      durability: 0,
      spoilTime: 48,
      effects: {
        hunger: 5,
        sick: 0.15
      },
      model: "mushroom",
      icon: "\u{1F344}"
    },
    {
      id: "edible_roots",
      nameAr: "\u062C\u0630\u0648\u0631 \u0635\u0627\u0644\u062D\u0629 \u0644\u0644\u0623\u0643\u0644",
      nameEn: "Edible Roots",
      type: "food",
      stack: 15,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 0,
      spoilTime: 120,
      effects: {
        hunger: 6
      },
      model: "edible_roots",
      icon: "\u{1F955}"
    },
    {
      id: "cooked_roots",
      nameAr: "\u062C\u0630\u0648\u0631 \u0645\u0637\u0628\u0648\u062E\u0629",
      nameEn: "Cooked Roots",
      type: "food",
      stack: 15,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 0,
      spoilTime: 96,
      effects: {
        hunger: 14,
        health: 1
      },
      model: "cooked_roots",
      icon: "\u{1F360}"
    },
    {
      id: "seaweed",
      nameAr: "\u0623\u0639\u0634\u0627\u0628 \u0628\u062D\u0631\u064A\u0629",
      nameEn: "Seaweed",
      type: "food",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "common",
      durability: 0,
      spoilTime: 48,
      effects: {
        hunger: 3,
        thirst: -1
      },
      model: "seaweed",
      icon: "\u{1F96C}"
    },
    {
      id: "raw_fish",
      nameAr: "\u0633\u0645\u0643 \u0646\u064A\u0621",
      nameEn: "Raw Fish",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.5,
      rarity: "common",
      durability: 0,
      spoilTime: 24,
      effects: {
        hunger: 6,
        sick: 0.35
      },
      model: "raw_fish",
      icon: "\u{1F41F}"
    },
    {
      id: "cooked_fish",
      nameAr: "\u0633\u0645\u0643 \u0645\u0634\u0648\u064A",
      nameEn: "Cooked Fish",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.4,
      rarity: "common",
      durability: 0,
      spoilTime: 48,
      effects: {
        hunger: 22,
        health: 2
      },
      model: "cooked_fish",
      icon: "\u{1F363}"
    },
    {
      id: "salted_fish",
      nameAr: "\u0633\u0645\u0643 \u0645\u0645\u0644\u062D",
      nameEn: "Salted Fish",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.4,
      rarity: "common",
      durability: 0,
      spoilTime: 480,
      effects: {
        hunger: 18,
        thirst: -4
      },
      model: "salted_fish",
      icon: "\u{1F420}"
    },
    {
      id: "smoked_fish",
      nameAr: "\u0633\u0645\u0643 \u0645\u062F\u062E\u0651\u0646",
      nameEn: "Smoked Fish",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.4,
      rarity: "common",
      durability: 0,
      spoilTime: 720,
      effects: {
        hunger: 20
      },
      model: "smoked_fish",
      icon: "\u{1F364}"
    },
    {
      id: "raw_crab",
      nameAr: "\u0633\u0644\u0637\u0639\u0648\u0646 \u0646\u064A\u0621",
      nameEn: "Raw Crab",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.4,
      rarity: "common",
      durability: 0,
      spoilTime: 24,
      effects: {
        hunger: 5,
        sick: 0.3
      },
      model: "raw_crab",
      icon: "\u{1F980}"
    },
    {
      id: "cooked_crab",
      nameAr: "\u0633\u0644\u0637\u0639\u0648\u0646 \u0645\u0637\u0628\u0648\u062E",
      nameEn: "Cooked Crab",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.4,
      rarity: "common",
      durability: 0,
      spoilTime: 48,
      effects: {
        hunger: 18,
        health: 2
      },
      model: "cooked_crab",
      icon: "\u{1F99E}"
    },
    {
      id: "raw_meat",
      nameAr: "\u0644\u062D\u0645 \u0646\u064A\u0621",
      nameEn: "Raw Meat",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.8,
      rarity: "common",
      durability: 0,
      spoilTime: 20,
      effects: {
        hunger: 8,
        sick: 0.5
      },
      model: "raw_meat",
      icon: "\u{1F969}"
    },
    {
      id: "cooked_meat",
      nameAr: "\u0644\u062D\u0645 \u0645\u0634\u0648\u064A",
      nameEn: "Cooked Meat",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.6,
      rarity: "common",
      durability: 0,
      spoilTime: 48,
      effects: {
        hunger: 30,
        health: 3
      },
      model: "cooked_meat",
      icon: "\u{1F356}"
    },
    {
      id: "smoked_meat",
      nameAr: "\u0644\u062D\u0645 \u0645\u062F\u062E\u0651\u0646",
      nameEn: "Smoked Meat",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.5,
      rarity: "common",
      durability: 0,
      spoilTime: 720,
      effects: {
        hunger: 28,
        health: 2
      },
      model: "smoked_meat",
      icon: "\u{1F953}"
    },
    {
      id: "dried_meat",
      nameAr: "\u0644\u062D\u0645 \u0645\u062C\u0641\u0641",
      nameEn: "Dried Meat",
      type: "food",
      stack: 15,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "common",
      durability: 0,
      spoilTime: 960,
      effects: {
        hunger: 20
      },
      model: "dried_meat",
      icon: "\u{1F356}"
    },
    {
      id: "egg",
      nameAr: "\u0628\u064A\u0636\u0629",
      nameEn: "Egg",
      type: "food",
      stack: 12,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "common",
      durability: 0,
      spoilTime: 120,
      effects: {
        hunger: 4,
        sick: 0.2
      },
      model: "egg",
      icon: "\u{1F95A}"
    },
    {
      id: "cooked_egg",
      nameAr: "\u0628\u064A\u0636\u0629 \u0645\u0633\u0644\u0648\u0642\u0629",
      nameEn: "Cooked Egg",
      type: "food",
      stack: 12,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "common",
      durability: 0,
      spoilTime: 72,
      effects: {
        hunger: 10,
        health: 1
      },
      model: "cooked_egg",
      icon: "\u{1F373}"
    },
    {
      id: "honey",
      nameAr: "\u0639\u0633\u0644",
      nameEn: "Honey",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {
        hunger: 8,
        energy: 15,
        health: 3
      },
      model: "honey",
      icon: "\u{1F36F}"
    },
    {
      id: "canned_beans",
      nameAr: "\u0641\u0648\u0644 \u0645\u0639\u0644\u0651\u0628",
      nameEn: "Canned Beans",
      type: "food",
      stack: 6,
      size: [
        1,
        1
      ],
      weight: 0.4,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 8e3,
      effects: {
        hunger: 25
      },
      model: "canned_beans",
      icon: "\u{1F96B}"
    },
    {
      id: "energy_bar",
      nameAr: "\u0644\u0648\u062D \u0637\u0627\u0642\u0629",
      nameEn: "Energy Bar",
      type: "food",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 6e3,
      effects: {
        hunger: 14,
        energy: 20
      },
      model: "energy_bar",
      icon: "\u{1F36B}"
    },
    {
      id: "fruit_mix",
      nameAr: "\u0633\u0644\u0637\u0629 \u0641\u0648\u0627\u0643\u0647",
      nameEn: "Fruit Mix",
      type: "food",
      stack: 5,
      size: [
        1,
        1
      ],
      weight: 0.4,
      rarity: "common",
      durability: 0,
      spoilTime: 36,
      effects: {
        hunger: 18,
        thirst: 6
      },
      model: "fruit_mix",
      icon: "\u{1F957}"
    },
    {
      id: "stew",
      nameAr: "\u064A\u062E\u0646\u0629",
      nameEn: "Stew",
      type: "food",
      stack: 4,
      size: [
        1,
        1
      ],
      weight: 0.7,
      rarity: "common",
      durability: 0,
      spoilTime: 48,
      effects: {
        hunger: 38,
        thirst: 10,
        health: 4
      },
      model: "stew",
      icon: "\u{1F372}"
    },
    {
      id: "rotten_food",
      nameAr: "\u0637\u0639\u0627\u0645 \u0641\u0627\u0633\u062F",
      nameEn: "Rotten Food",
      type: "food",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {
        hunger: 2,
        sick: 0.9
      },
      model: "rotten_food",
      icon: "\u{1F922}"
    },
    {
      id: "bottle_empty",
      nameAr: "\u0632\u062C\u0627\u062C\u0629 \u0641\u0627\u0631\u063A\u0629",
      nameEn: "Empty Bottle",
      type: "drink",
      stack: 5,
      size: [
        1,
        2
      ],
      weight: 0.2,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "bottle_empty",
      icon: "\u{1F37C}"
    },
    {
      id: "water_dirty",
      nameAr: "\u0645\u0627\u0621 \u0645\u0644\u0648\u062B",
      nameEn: "Dirty Water",
      type: "drink",
      stack: 5,
      size: [
        1,
        2
      ],
      weight: 0.6,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {
        thirst: 25,
        sick: 0.6
      },
      model: "water_dirty",
      icon: "\u{1F964}"
    },
    {
      id: "water_boiled",
      nameAr: "\u0645\u0627\u0621 \u0645\u063A\u0644\u064A",
      nameEn: "Boiled Water",
      type: "drink",
      stack: 5,
      size: [
        1,
        2
      ],
      weight: 0.6,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {
        thirst: 40
      },
      model: "water_boiled",
      icon: "\u{1F4A7}"
    },
    {
      id: "rainwater",
      nameAr: "\u0645\u0627\u0621 \u0645\u0637\u0631",
      nameEn: "Rainwater",
      type: "drink",
      stack: 5,
      size: [
        1,
        2
      ],
      weight: 0.6,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {
        thirst: 35,
        sick: 0.1
      },
      model: "rainwater",
      icon: "\u{1F327}\uFE0F"
    },
    {
      id: "coconut_water",
      nameAr: "\u0645\u0627\u0621 \u062C\u0648\u0632 \u0627\u0644\u0647\u0646\u062F",
      nameEn: "Coconut Water",
      type: "drink",
      stack: 5,
      size: [
        1,
        1
      ],
      weight: 0.5,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {
        thirst: 20,
        hunger: 2
      },
      model: "coconut_water",
      icon: "\u{1F965}"
    },
    {
      id: "canteen_empty",
      nameAr: "\u0642\u0631\u0628\u0629 \u0641\u0627\u0631\u063A\u0629",
      nameEn: "Empty Canteen",
      type: "drink",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 0.3,
      rarity: "common",
      durability: 100,
      spoilTime: 0,
      effects: {},
      model: "canteen_empty",
      icon: "\u{1FAD9}"
    },
    {
      id: "canteen_full",
      nameAr: "\u0642\u0631\u0628\u0629 \u0645\u0627\u0621",
      nameEn: "Water Canteen",
      type: "drink",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 1.2,
      rarity: "common",
      durability: 100,
      spoilTime: 0,
      effects: {
        thirst: 60
      },
      model: "canteen_full",
      icon: "\u{1FAD7}"
    },
    {
      id: "herbal_tea",
      nameAr: "\u0634\u0627\u064A \u0623\u0639\u0634\u0627\u0628",
      nameEn: "Herbal Tea",
      type: "drink",
      stack: 5,
      size: [
        1,
        1
      ],
      weight: 0.4,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {
        thirst: 20,
        energy: 8,
        health: 2
      },
      model: "herbal_tea",
      icon: "\u{1F375}"
    },
    {
      id: "bandage",
      nameAr: "\u0636\u0645\u0627\u062F\u0629",
      nameEn: "Bandage",
      type: "medicine",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {
        stopBleeding: 1,
        health: 5
      },
      model: "bandage",
      icon: "\u{1FA79}"
    },
    {
      id: "antibiotic",
      nameAr: "\u0645\u0636\u0627\u062F \u062D\u064A\u0648\u064A",
      nameEn: "Antibiotic",
      type: "medicine",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {
        cureInfection: 1
      },
      model: "antibiotic",
      icon: "\u{1F48A}"
    },
    {
      id: "aloe",
      nameAr: "\u0635\u0628\u0651\u0627\u0631 \u0627\u0644\u0623\u0644\u0648\u0641\u064A\u0631\u0627",
      nameEn: "Aloe Vera",
      type: "medicine",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "common",
      durability: 0,
      spoilTime: 240,
      effects: {
        health: 6,
        cureSunburn: 1
      },
      model: "aloe",
      icon: "\u{1F335}"
    },
    {
      id: "painkiller",
      nameAr: "\u0645\u0633\u0643\u0651\u0646 \u0623\u0644\u0645",
      nameEn: "Painkiller",
      type: "medicine",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.02,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {
        painRelief: 1
      },
      model: "painkiller",
      icon: "\u{1F48A}"
    },
    {
      id: "antiseptic",
      nameAr: "\u0645\u0637\u0647\u0651\u0631",
      nameEn: "Antiseptic",
      type: "medicine",
      stack: 5,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {
        preventInfection: 1
      },
      model: "antiseptic",
      icon: "\u{1F9F4}"
    },
    {
      id: "splint",
      nameAr: "\u062C\u0628\u064A\u0631\u0629",
      nameEn: "Splint",
      type: "medicine",
      stack: 3,
      size: [
        1,
        1
      ],
      weight: 0.4,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {
        healBone: 1
      },
      model: "splint",
      icon: "\u{1F9AF}"
    },
    {
      id: "medicinal_herb",
      nameAr: "\u0639\u0634\u0628\u0629 \u0637\u0628\u064A\u0629",
      nameEn: "Medicinal Herb",
      type: "medicine",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "common",
      durability: 0,
      spoilTime: 120,
      effects: {
        health: 4
      },
      model: "medicinal_herb",
      icon: "\u{1F33F}"
    },
    {
      id: "charcoal_pill",
      nameAr: "\u0623\u0642\u0631\u0627\u0635 \u0641\u062D\u0645",
      nameEn: "Charcoal Pill",
      type: "medicine",
      stack: 10,
      size: [
        1,
        1
      ],
      weight: 0.02,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {
        cureFoodPoison: 1
      },
      model: "charcoal_pill",
      icon: "\u26AB"
    },
    {
      id: "first_aid_kit",
      nameAr: "\u062D\u0642\u064A\u0628\u0629 \u0625\u0633\u0639\u0627\u0641",
      nameEn: "First Aid Kit",
      type: "medicine",
      stack: 2,
      size: [
        2,
        2
      ],
      weight: 1,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {
        stopBleeding: 1,
        health: 40,
        cureInfection: 1,
        healBone: 1
      },
      model: "first_aid_kit",
      icon: "\u{1F9F0}"
    },
    {
      id: "axe_stone",
      nameAr: "\u0641\u0623\u0633 \u062D\u062C\u0631\u064A",
      nameEn: "Stone Axe",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 1.5,
      rarity: "common",
      durability: 80,
      spoilTime: 0,
      effects: {
        chop: 1,
        damage: 12
      },
      model: "axe_stone",
      icon: "\u{1FA93}"
    },
    {
      id: "axe_iron",
      nameAr: "\u0641\u0623\u0633 \u062D\u062F\u064A\u062F\u064A",
      nameEn: "Iron Axe",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 2,
      rarity: "uncommon",
      durability: 220,
      spoilTime: 0,
      effects: {
        chop: 2,
        damage: 20
      },
      model: "axe_iron",
      icon: "\u{1FA93}"
    },
    {
      id: "pickaxe_stone",
      nameAr: "\u0645\u0639\u0648\u0644 \u062D\u062C\u0631\u064A",
      nameEn: "Stone Pickaxe",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 1.8,
      rarity: "common",
      durability: 80,
      spoilTime: 0,
      effects: {
        mine: 1,
        damage: 10
      },
      model: "pickaxe_stone",
      icon: "\u26CF\uFE0F"
    },
    {
      id: "pickaxe_iron",
      nameAr: "\u0645\u0639\u0648\u0644 \u062D\u062F\u064A\u062F\u064A",
      nameEn: "Iron Pickaxe",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 2.4,
      rarity: "uncommon",
      durability: 240,
      spoilTime: 0,
      effects: {
        mine: 2,
        damage: 16
      },
      model: "pickaxe_iron",
      icon: "\u26CF\uFE0F"
    },
    {
      id: "knife_stone",
      nameAr: "\u0633\u0643\u064A\u0646 \u062D\u062C\u0631\u064A",
      nameEn: "Stone Knife",
      type: "tool",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "common",
      durability: 60,
      spoilTime: 0,
      effects: {
        cut: 1,
        damage: 8
      },
      model: "knife_stone",
      icon: "\u{1F52A}"
    },
    {
      id: "knife_steel",
      nameAr: "\u0633\u0643\u064A\u0646 \u0641\u0648\u0644\u0627\u0630",
      nameEn: "Steel Knife",
      type: "tool",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.4,
      rarity: "rare",
      durability: 250,
      spoilTime: 0,
      effects: {
        cut: 2,
        damage: 14
      },
      model: "knife_steel",
      icon: "\u{1F5E1}\uFE0F"
    },
    {
      id: "machete",
      nameAr: "\u0633\u0627\u0637\u0648\u0631",
      nameEn: "Machete",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 0.9,
      rarity: "rare",
      durability: 200,
      spoilTime: 0,
      effects: {
        chop: 1.4,
        cut: 1.5,
        damage: 18
      },
      model: "machete",
      icon: "\u{1F5E1}\uFE0F"
    },
    {
      id: "spear_wood",
      nameAr: "\u0631\u0645\u062D \u062E\u0634\u0628\u064A",
      nameEn: "Wooden Spear",
      type: "weapon",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 1.2,
      rarity: "common",
      durability: 50,
      spoilTime: 0,
      effects: {
        damage: 15,
        throwable: 1
      },
      model: "spear_wood",
      icon: "\u{1F531}"
    },
    {
      id: "spear_stone",
      nameAr: "\u0631\u0645\u062D \u0628\u062D\u062C\u0631",
      nameEn: "Stone Spear",
      type: "weapon",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 1.4,
      rarity: "uncommon",
      durability: 90,
      spoilTime: 0,
      effects: {
        damage: 22,
        throwable: 1
      },
      model: "spear_stone",
      icon: "\u{1F531}"
    },
    {
      id: "club",
      nameAr: "\u0647\u0631\u0627\u0648\u0629",
      nameEn: "Club",
      type: "weapon",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 1.8,
      rarity: "common",
      durability: 70,
      spoilTime: 0,
      effects: {
        damage: 14
      },
      model: "club",
      icon: "\u{1F3CF}"
    },
    {
      id: "bow",
      nameAr: "\u0642\u0648\u0633",
      nameEn: "Bow",
      type: "weapon",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 0.9,
      rarity: "uncommon",
      durability: 120,
      spoilTime: 0,
      effects: {
        damage: 30,
        ranged: 1
      },
      model: "bow",
      icon: "\u{1F3F9}"
    },
    {
      id: "arrow",
      nameAr: "\u0633\u0647\u0645",
      nameEn: "Arrow",
      type: "weapon",
      stack: 40,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {
        ammo: 1
      },
      model: "arrow",
      icon: "\u27B5"
    },
    {
      id: "fishing_rod",
      nameAr: "\u0635\u0646\u0627\u0631\u0629",
      nameEn: "Fishing Rod",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 0.6,
      rarity: "common",
      durability: 80,
      spoilTime: 0,
      effects: {
        fish: 1
      },
      model: "fishing_rod",
      icon: "\u{1F3A3}"
    },
    {
      id: "fishing_net",
      nameAr: "\u0634\u0628\u0643\u0629 \u0635\u064A\u062F",
      nameEn: "Fishing Net",
      type: "tool",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 0.8,
      rarity: "uncommon",
      durability: 60,
      spoilTime: 0,
      effects: {
        fish: 2
      },
      model: "fishing_net",
      icon: "\u{1F578}\uFE0F"
    },
    {
      id: "shovel",
      nameAr: "\u0645\u062C\u0631\u0641\u0629",
      nameEn: "Shovel",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 1.6,
      rarity: "common",
      durability: 100,
      spoilTime: 0,
      effects: {
        dig: 1
      },
      model: "shovel",
      icon: "\u{1FA8F}"
    },
    {
      id: "hammer",
      nameAr: "\u0645\u0637\u0631\u0642\u0629",
      nameEn: "Hammer",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 1.2,
      rarity: "common",
      durability: 150,
      spoilTime: 0,
      effects: {
        build: 1
      },
      model: "hammer",
      icon: "\u{1F528}"
    },
    {
      id: "saw",
      nameAr: "\u0645\u0646\u0634\u0627\u0631",
      nameEn: "Saw",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 1,
      rarity: "uncommon",
      durability: 140,
      spoilTime: 0,
      effects: {
        saw: 1
      },
      model: "saw",
      icon: "\u{1FA9A}"
    },
    {
      id: "flint_steel",
      nameAr: "\u0642\u062F\u0651\u0627\u062D\u0629 \u0635\u0648\u0627\u0646",
      nameEn: "Flint & Steel",
      type: "tool",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 150,
      spoilTime: 0,
      effects: {
        ignite: 0.7
      },
      model: "flint_steel",
      icon: "\u{1F525}"
    },
    {
      id: "fire_drill",
      nameAr: "\u0645\u062B\u0642\u0627\u0628 \u0646\u0627\u0631",
      nameEn: "Fire Drill",
      type: "tool",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "common",
      durability: 40,
      spoilTime: 0,
      effects: {
        ignite: 0.35
      },
      model: "fire_drill",
      icon: "\u{1FAB5}"
    },
    {
      id: "lighter",
      nameAr: "\u0648\u0644\u0651\u0627\u0639\u0629",
      nameEn: "Lighter",
      type: "tool",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "rare",
      durability: 60,
      spoilTime: 0,
      effects: {
        ignite: 0.98
      },
      model: "lighter",
      icon: "\u{1F525}"
    },
    {
      id: "torch",
      nameAr: "\u0645\u0634\u0639\u0644",
      nameEn: "Torch",
      type: "tool",
      stack: 5,
      size: [
        1,
        2
      ],
      weight: 0.5,
      rarity: "common",
      durability: 30,
      spoilTime: 0,
      effects: {
        light: 1
      },
      model: "torch",
      icon: "\u{1F526}"
    },
    {
      id: "lantern",
      nameAr: "\u0641\u0627\u0646\u0648\u0633",
      nameEn: "Lantern",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 0.8,
      rarity: "uncommon",
      durability: 200,
      spoilTime: 0,
      effects: {
        light: 2
      },
      model: "lantern",
      icon: "\u{1F3EE}"
    },
    {
      id: "compass",
      nameAr: "\u0628\u0648\u0635\u0644\u0629",
      nameEn: "Compass",
      type: "tool",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {
        compass: 1
      },
      model: "compass",
      icon: "\u{1F9ED}"
    },
    {
      id: "binoculars",
      nameAr: "\u0645\u0646\u0638\u0627\u0631",
      nameEn: "Binoculars",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 0.6,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {
        zoom: 4
      },
      model: "binoculars",
      icon: "\u{1F52D}"
    },
    {
      id: "waterproof_bag",
      nameAr: "\u0643\u064A\u0633 \u0645\u0642\u0627\u0648\u0645 \u0644\u0644\u0645\u0627\u0621",
      nameEn: "Waterproof Bag",
      type: "tool",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "waterproof_bag",
      icon: "\u{1F392}"
    },
    {
      id: "flare_gun",
      nameAr: "\u0645\u0633\u062F\u0633 \u0625\u0634\u0627\u0631\u0629",
      nameEn: "Flare Gun",
      type: "tool",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 0.6,
      rarity: "rare",
      durability: 3,
      spoilTime: 0,
      effects: {
        signal: 1
      },
      model: "flare_gun",
      icon: "\u{1F52B}"
    },
    {
      id: "flare",
      nameAr: "\u0642\u0630\u064A\u0641\u0629 \u0625\u0634\u0627\u0631\u0629",
      nameEn: "Flare",
      type: "tool",
      stack: 4,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {
        ammo: 1
      },
      model: "flare",
      icon: "\u{1F9E8}"
    },
    {
      id: "signal_mirror",
      nameAr: "\u0645\u0631\u0622\u0629 \u0625\u0634\u0627\u0631\u0629",
      nameEn: "Signal Mirror",
      type: "tool",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {
        signal: 0.5
      },
      model: "signal_mirror",
      icon: "\u{1FA9E}"
    },
    {
      id: "matches",
      nameAr: "\u0639\u064A\u062F\u0627\u0646 \u062B\u0642\u0627\u0628",
      nameEn: "Matches",
      type: "tool",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.01,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {
        ignite: 0.85
      },
      model: "matches",
      icon: "\u{1F525}"
    },
    {
      id: "hat_straw",
      nameAr: "\u0642\u0628\u0639\u0629 \u0642\u0634",
      nameEn: "Straw Hat",
      type: "clothing",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.2,
      rarity: "common",
      durability: 60,
      spoilTime: 0,
      effects: {
        slot: "head",
        warmth: 0,
        sunProtect: 1,
        defense: 0
      },
      model: "hat_straw",
      icon: "\u{1F452}"
    },
    {
      id: "bandana",
      nameAr: "\u0639\u0635\u0627\u0628\u0629 \u0631\u0623\u0633",
      nameEn: "Bandana",
      type: "clothing",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "common",
      durability: 60,
      spoilTime: 0,
      effects: {
        slot: "head",
        warmth: 1,
        sunProtect: 0.5
      },
      model: "bandana",
      icon: "\u{1F9E3}"
    },
    {
      id: "shirt_cloth",
      nameAr: "\u0642\u0645\u064A\u0635 \u0642\u0645\u0627\u0634",
      nameEn: "Cloth Shirt",
      type: "clothing",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 0.4,
      rarity: "common",
      durability: 80,
      spoilTime: 0,
      effects: {
        slot: "chest",
        warmth: 3,
        defense: 1
      },
      model: "shirt_cloth",
      icon: "\u{1F455}"
    },
    {
      id: "jacket_leather",
      nameAr: "\u0633\u062A\u0631\u0629 \u062C\u0644\u062F\u064A\u0629",
      nameEn: "Leather Jacket",
      type: "clothing",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 1.6,
      rarity: "uncommon",
      durability: 200,
      spoilTime: 0,
      effects: {
        slot: "chest",
        warmth: 8,
        defense: 5
      },
      model: "jacket_leather",
      icon: "\u{1F9E5}"
    },
    {
      id: "raincoat",
      nameAr: "\u0645\u0639\u0637\u0641 \u0645\u0637\u0631",
      nameEn: "Raincoat",
      type: "clothing",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 0.9,
      rarity: "uncommon",
      durability: 120,
      spoilTime: 0,
      effects: {
        slot: "chest",
        warmth: 4,
        rainProof: 1
      },
      model: "raincoat",
      icon: "\u{1F9E5}"
    },
    {
      id: "pants_cloth",
      nameAr: "\u0628\u0646\u0637\u0627\u0644 \u0642\u0645\u0627\u0634",
      nameEn: "Cloth Pants",
      type: "clothing",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 0.5,
      rarity: "common",
      durability: 80,
      spoilTime: 0,
      effects: {
        slot: "legs",
        warmth: 3,
        defense: 1
      },
      model: "pants_cloth",
      icon: "\u{1F456}"
    },
    {
      id: "pants_cargo",
      nameAr: "\u0628\u0646\u0637\u0627\u0644 \u0639\u0645\u0644\u064A",
      nameEn: "Cargo Pants",
      type: "clothing",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 0.8,
      rarity: "uncommon",
      durability: 160,
      spoilTime: 0,
      effects: {
        slot: "legs",
        warmth: 4,
        defense: 3
      },
      model: "pants_cargo",
      icon: "\u{1F456}"
    },
    {
      id: "boots_leather",
      nameAr: "\u062D\u0630\u0627\u0621 \u062C\u0644\u062F\u064A",
      nameEn: "Leather Boots",
      type: "clothing",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 1,
      rarity: "uncommon",
      durability: 180,
      spoilTime: 0,
      effects: {
        slot: "feet",
        warmth: 3,
        defense: 3
      },
      model: "boots_leather",
      icon: "\u{1F97E}"
    },
    {
      id: "sandals",
      nameAr: "\u0635\u0646\u062F\u0644",
      nameEn: "Sandals",
      type: "clothing",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "common",
      durability: 60,
      spoilTime: 0,
      effects: {
        slot: "feet",
        warmth: 0,
        defense: 1
      },
      model: "sandals",
      icon: "\u{1FA74}"
    },
    {
      id: "gloves_cloth",
      nameAr: "\u0642\u0641\u0627\u0632\u0627\u062A \u0642\u0645\u0627\u0634",
      nameEn: "Cloth Gloves",
      type: "clothing",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.1,
      rarity: "common",
      durability: 60,
      spoilTime: 0,
      effects: {
        slot: "hands",
        warmth: 2,
        defense: 1
      },
      model: "gloves_cloth",
      icon: "\u{1F9E4}"
    },
    {
      id: "gloves_leather",
      nameAr: "\u0642\u0641\u0627\u0632\u0627\u062A \u062C\u0644\u062F",
      nameEn: "Leather Gloves",
      type: "clothing",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "uncommon",
      durability: 150,
      spoilTime: 0,
      effects: {
        slot: "hands",
        warmth: 4,
        defense: 3,
        gatherBonus: 0.15
      },
      model: "gloves_leather",
      icon: "\u{1F9E4}"
    },
    {
      id: "backpack_cloth",
      nameAr: "\u062D\u0642\u064A\u0628\u0629 \u0642\u0645\u0627\u0634",
      nameEn: "Cloth Backpack",
      type: "backpack",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 0.6,
      rarity: "common",
      durability: 100,
      spoilTime: 0,
      effects: {
        slot: "backpack",
        gridW: 6,
        gridH: 4,
        maxWeight: 30
      },
      model: "backpack_cloth",
      icon: "\u{1F392}"
    },
    {
      id: "backpack_leather",
      nameAr: "\u062D\u0642\u064A\u0628\u0629 \u062C\u0644\u062F",
      nameEn: "Leather Backpack",
      type: "backpack",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 1,
      rarity: "uncommon",
      durability: 200,
      spoilTime: 0,
      effects: {
        slot: "backpack",
        gridW: 8,
        gridH: 5,
        maxWeight: 45
      },
      model: "backpack_leather",
      icon: "\u{1F392}"
    },
    {
      id: "backpack_military",
      nameAr: "\u062D\u0642\u064A\u0628\u0629 \u0639\u0633\u0643\u0631\u064A\u0629",
      nameEn: "Military Backpack",
      type: "backpack",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 1.4,
      rarity: "rare",
      durability: 400,
      spoilTime: 0,
      effects: {
        slot: "backpack",
        gridW: 10,
        gridH: 6,
        maxWeight: 65
      },
      model: "backpack_military",
      icon: "\u{1F392}"
    },
    {
      id: "storage_box",
      nameAr: "\u0635\u0646\u062F\u0648\u0642 \u062A\u062E\u0632\u064A\u0646",
      nameEn: "Storage Box",
      type: "container",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 8,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {
        gridW: 6,
        gridH: 4
      },
      model: "storage_box",
      icon: "\u{1F4E6}"
    },
    {
      id: "barrel",
      nameAr: "\u0628\u0631\u0645\u064A\u0644",
      nameEn: "Barrel",
      type: "container",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 12,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {
        gridW: 5,
        gridH: 6,
        preserve: 1.5
      },
      model: "barrel",
      icon: "\u{1F6E2}\uFE0F"
    },
    {
      id: "cooler",
      nameAr: "\u062B\u0644\u0627\u062C\u0629 \u0628\u062F\u0627\u0626\u064A\u0629",
      nameEn: "Primitive Cooler",
      type: "container",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 10,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {
        gridW: 5,
        gridH: 4,
        preserve: 3
      },
      model: "cooler",
      icon: "\u{1F9CA}"
    },
    {
      id: "workbench_kit",
      nameAr: "\u0639\u062F\u0629 \u0637\u0627\u0648\u0644\u0629 \u0639\u0645\u0644",
      nameEn: "Workbench Kit",
      type: "building",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 12,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "workbench_kit",
      icon: "\u{1F6E0}\uFE0F"
    },
    {
      id: "campfire_kit",
      nameAr: "\u0639\u062F\u0629 \u0645\u0648\u0642\u062F",
      nameEn: "Campfire Kit",
      type: "building",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 3,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "campfire_kit",
      icon: "\u{1F525}"
    },
    {
      id: "raft_kit",
      nameAr: "\u0639\u062F\u0629 \u0637\u0648\u0627\u0641\u0629",
      nameEn: "Raft Kit",
      type: "building",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 20,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "raft_kit",
      icon: "\u{1F6F6}"
    },
    {
      id: "door_wood",
      nameAr: "\u0628\u0627\u0628 \u062E\u0634\u0628\u064A",
      nameEn: "Wooden Door",
      type: "building",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 6,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "door_wood",
      icon: "\u{1F6AA}"
    },
    {
      id: "bed_leaf",
      nameAr: "\u0641\u0631\u0627\u0634 \u0645\u0646 \u0627\u0644\u0623\u0648\u0631\u0627\u0642",
      nameEn: "Leaf Bed",
      type: "building",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 4,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "bed_leaf",
      icon: "\u{1F6CF}\uFE0F"
    },
    {
      id: "drying_rack",
      nameAr: "\u0631\u0641 \u062A\u062C\u0641\u064A\u0641",
      nameEn: "Drying Rack",
      type: "building",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 5,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "drying_rack",
      icon: "\u{1FA9C}"
    },
    {
      id: "furnace_kit",
      nameAr: "\u0639\u062F\u0629 \u0641\u0631\u0646",
      nameEn: "Furnace Kit",
      type: "building",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 25,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "furnace_kit",
      icon: "\u{1F3ED}"
    },
    {
      id: "farm_plot",
      nameAr: "\u0642\u0637\u0639\u0629 \u0632\u0631\u0627\u0639\u0629",
      nameEn: "Farm Plot",
      type: "building",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 4,
      rarity: "common",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "farm_plot",
      icon: "\u{1F331}"
    },
    {
      id: "seeds",
      nameAr: "\u0628\u0630\u0648\u0631",
      nameEn: "Seeds",
      type: "resource",
      stack: 50,
      size: [
        1,
        1
      ],
      weight: 0.01,
      rarity: "common",
      durability: 0,
      spoilTime: 4e3,
      effects: {},
      model: "seeds",
      icon: "\u{1F330}"
    },
    {
      id: "water_collector",
      nameAr: "\u062C\u0627\u0645\u0639 \u0645\u064A\u0627\u0647 \u0627\u0644\u0645\u0637\u0631",
      nameEn: "Rain Collector",
      type: "building",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 3,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "water_collector",
      icon: "\u{1FAA3}"
    },
    {
      id: "radio",
      nameAr: "\u062C\u0647\u0627\u0632 \u0631\u0627\u062F\u064A\u0648",
      nameEn: "Radio",
      type: "story",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 1.2,
      rarity: "epic",
      durability: 100,
      spoilTime: 0,
      effects: {},
      model: "radio",
      icon: "\u{1F4FB}"
    },
    {
      id: "radio_battery",
      nameAr: "\u0628\u0637\u0627\u0631\u064A\u0629 \u0631\u0627\u062F\u064A\u0648",
      nameEn: "Radio Battery",
      type: "story",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.3,
      rarity: "epic",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "radio_battery",
      icon: "\u{1F50B}"
    },
    {
      id: "map_piece",
      nameAr: "\u0642\u0637\u0639\u0629 \u062E\u0631\u064A\u0637\u0629",
      nameEn: "Map Piece",
      type: "story",
      stack: 4,
      size: [
        1,
        1
      ],
      weight: 0.02,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "map_piece",
      icon: "\u{1F5FA}\uFE0F"
    },
    {
      id: "bunker_key",
      nameAr: "\u0645\u0641\u062A\u0627\u062D \u0627\u0644\u0642\u0628\u0648",
      nameEn: "Bunker Key",
      type: "story",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.05,
      rarity: "epic",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "bunker_key",
      icon: "\u{1F5DD}\uFE0F"
    },
    {
      id: "plane_wreckage",
      nameAr: "\u062D\u0637\u0627\u0645 \u0637\u0627\u0626\u0631\u0629",
      nameEn: "Plane Wreckage",
      type: "story",
      stack: 3,
      size: [
        2,
        2
      ],
      weight: 4,
      rarity: "uncommon",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "plane_wreckage",
      icon: "\u2708\uFE0F"
    },
    {
      id: "flight_recorder",
      nameAr: "\u0627\u0644\u0635\u0646\u062F\u0648\u0642 \u0627\u0644\u0623\u0633\u0648\u062F",
      nameEn: "Flight Recorder",
      type: "story",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 2,
      rarity: "epic",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "flight_recorder",
      icon: "\u{1F4FC}"
    },
    {
      id: "journal_page",
      nameAr: "\u0648\u0631\u0642\u0629 \u0645\u0630\u0643\u0631\u0627\u062A",
      nameEn: "Journal Page",
      type: "story",
      stack: 20,
      size: [
        1,
        1
      ],
      weight: 0.01,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "journal_page",
      icon: "\u{1F4C4}"
    },
    {
      id: "satellite_phone",
      nameAr: "\u0647\u0627\u062A\u0641 \u0641\u0636\u0627\u0626\u064A",
      nameEn: "Satellite Phone",
      type: "story",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 0.6,
      rarity: "epic",
      durability: 100,
      spoilTime: 0,
      effects: {},
      model: "satellite_phone",
      icon: "\u{1F4E1}"
    },
    {
      id: "engine_part",
      nameAr: "\u0642\u0637\u0639\u0629 \u0645\u062D\u0631\u0643",
      nameEn: "Engine Part",
      type: "story",
      stack: 2,
      size: [
        2,
        2
      ],
      weight: 3,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "engine_part",
      icon: "\u2699\uFE0F"
    },
    {
      id: "fuel_can",
      nameAr: "\u062C\u0627\u0644\u0648\u0646 \u0648\u0642\u0648\u062F",
      nameEn: "Fuel Can",
      type: "story",
      stack: 1,
      size: [
        1,
        2
      ],
      weight: 4,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "fuel_can",
      icon: "\u26FD"
    },
    {
      id: "sail_cloth",
      nameAr: "\u0642\u0645\u0627\u0634 \u0634\u0631\u0627\u0639",
      nameEn: "Sail Cloth",
      type: "story",
      stack: 1,
      size: [
        2,
        2
      ],
      weight: 1,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "sail_cloth",
      icon: "\u26F5"
    },
    {
      id: "old_photo",
      nameAr: "\u0635\u0648\u0631\u0629 \u0642\u062F\u064A\u0645\u0629",
      nameEn: "Old Photo",
      type: "story",
      stack: 1,
      size: [
        1,
        1
      ],
      weight: 0.01,
      rarity: "rare",
      durability: 0,
      spoilTime: 0,
      effects: {},
      model: "old_photo",
      icon: "\u{1F5BC}\uFE0F"
    }
  ];

  // src/inventory/Item.ts
  var EQUIP_SLOTS = ["head", "chest", "legs", "feet", "hands", "tool", "backpack"];
  var RARITY_COLORS = {
    common: "#d0d0d0",
    uncommon: "#5fd068",
    rare: "#4aa3ff",
    epic: "#c77dff"
  };
  var uidCounter = 1;
  function nextUid() {
    return uidCounter++;
  }
  function ensureUidAbove(n) {
    if (uidCounter <= n) uidCounter = n + 1;
  }
  function spoilState(def, stack) {
    if (def.spoilTime <= 0) return "none";
    const r = stack.spoil / def.spoilTime;
    if (r >= 1) return "rotten";
    if (r >= 0.6) return "stale";
    return "fresh";
  }

  // src/inventory/ItemDatabase.ts
  var ItemDatabaseImpl = class {
    map = /* @__PURE__ */ new Map();
    constructor() {
      for (const r of items_default) this.map.set(r.id, r);
    }
    get(id) {
      const d = this.map.get(id);
      if (!d) throw new Error(`ItemDatabase: unknown item "${id}"`);
      return d;
    }
    has(id) {
      return this.map.has(id);
    }
    all() {
      return [...this.map.values()];
    }
    byType(type) {
      return this.all().filter((d) => d.type === type);
    }
    /** ينشئ مكدّسًا جديدًا بمتانة كاملة */
    create(id, count = 1, opts = {}) {
      const d = this.get(id);
      return {
        uid: nextUid(),
        defId: id,
        count: Math.min(count, d.stack),
        durability: opts.durability ?? d.durability,
        spoil: opts.spoil ?? 0
      };
    }
  };
  var ItemDB = new ItemDatabaseImpl();

  // src/inventory/Grid.ts
  var Grid = class _Grid {
    constructor(width, height) {
      this.width = width;
      this.height = height;
      this.cells = new Int32Array(width * height);
    }
    width;
    height;
    entries = /* @__PURE__ */ new Map();
    // uid -> entry
    /** خريطة الإشغال: uid أو 0 */
    cells;
    static dims(def, rotated) {
      return rotated ? [def.size[1], def.size[0]] : [def.size[0], def.size[1]];
    }
    list() {
      return [...this.entries.values()];
    }
    get size() {
      return this.entries.size;
    }
    get(uid) {
      return this.entries.get(uid);
    }
    at(x, y) {
      if (x < 0 || y < 0 || x >= this.width || y >= this.height) return void 0;
      const uid = this.cells[y * this.width + x];
      return uid ? this.entries.get(uid) : void 0;
    }
    /** هل يمكن وضع العنصر؟ ignoreUid لتجاهل عنصر معيّن (عند التحريك) */
    canPlace(def, x, y, rotated, ignoreUid = 0) {
      const [w, h2] = _Grid.dims(def, rotated);
      if (x < 0 || y < 0 || x + w > this.width || y + h2 > this.height) return false;
      for (let j = y; j < y + h2; j++) {
        for (let i = x; i < x + w; i++) {
          const c = this.cells[j * this.width + i];
          if (c !== 0 && c !== ignoreUid) return false;
        }
      }
      return true;
    }
    /** العناصر التي تتداخل مع مستطيل معيّن (بدون تكرار) */
    overlapping(def, x, y, rotated) {
      const [w, h2] = _Grid.dims(def, rotated);
      const seen = /* @__PURE__ */ new Set();
      const out = [];
      for (let j = y; j < y + h2; j++) {
        for (let i = x; i < x + w; i++) {
          const e = this.at(i, j);
          if (e && !seen.has(e.stack.uid)) {
            seen.add(e.stack.uid);
            out.push(e);
          }
        }
      }
      return out;
    }
    place(stack, x, y, rotated = false) {
      const def = ItemDB.get(stack.defId);
      if (!this.canPlace(def, x, y, rotated)) return false;
      const [w, h2] = _Grid.dims(def, rotated);
      for (let j = y; j < y + h2; j++) for (let i = x; i < x + w; i++) this.cells[j * this.width + i] = stack.uid;
      this.entries.set(stack.uid, { stack, x, y, rotated });
      return true;
    }
    remove(uid) {
      const e = this.entries.get(uid);
      if (!e) return void 0;
      const def = ItemDB.get(e.stack.defId);
      const [w, h2] = _Grid.dims(def, e.rotated);
      for (let j = e.y; j < e.y + h2; j++) for (let i = e.x; i < e.x + w; i++) this.cells[j * this.width + i] = 0;
      this.entries.delete(uid);
      return e;
    }
    /** أول مكان يتسع للعنصر (يجرّب بدون تدوير ثم بتدوير) */
    findSpot(def) {
      const variants = def.size[0] === def.size[1] ? [false] : [false, true];
      for (const rotated of variants) {
        for (let y = 0; y < this.height; y++) {
          for (let x = 0; x < this.width; x++) {
            if (this.canPlace(def, x, y, rotated)) return { x, y, rotated };
          }
        }
      }
      return null;
    }
    /**
     * يضيف عددًا من عنصر: يملأ المكدّسات الحالية أولًا ثم ينشئ جديدة.
     * @returns العدد المتبقي الذي لم يتسع
     */
    add(defId, count, opts = {}) {
      const def = ItemDB.get(defId);
      let left = count;
      if (def.stack > 1) {
        for (const e of this.entries.values()) {
          if (left <= 0) break;
          if (e.stack.defId !== defId || e.stack.count >= def.stack) continue;
          const room = def.stack - e.stack.count;
          const moved = Math.min(room, left);
          const incomingSpoil = opts.spoil ?? 0;
          e.stack.spoil = (e.stack.spoil * e.stack.count + incomingSpoil * moved) / (e.stack.count + moved);
          e.stack.count += moved;
          left -= moved;
        }
      }
      while (left > 0) {
        const spot = this.findSpot(def);
        if (!spot) break;
        const n = Math.min(def.stack, left);
        const stack = ItemDB.create(defId, n, opts);
        this.place(stack, spot.x, spot.y, spot.rotated);
        left -= n;
      }
      return left;
    }
    /** يدمج مكدّسًا موجودًا (بكامل خصائصه) في الشبكة؛ يعيد ما تبقّى منه (0 = تم الكل) */
    addStack(stack) {
      const def = ItemDB.get(stack.defId);
      if (def.stack === 1 || def.durability > 0) {
        const spot = this.findSpot(def);
        if (!spot) return stack.count;
        this.place(stack, spot.x, spot.y, spot.rotated);
        return 0;
      }
      return this.add(stack.defId, stack.count, { durability: stack.durability, spoil: stack.spoil });
    }
    count(defId) {
      let n = 0;
      for (const e of this.entries.values()) if (e.stack.defId === defId) n += e.stack.count;
      return n;
    }
    /** يغيّر الأبعاد؛ يفشل (false) إن خرج أي عنصر عن الحدود الجديدة ولا يغيّر شيئًا */
    resize(newW, newH) {
      for (const e of this.entries.values()) {
        const def = ItemDB.get(e.stack.defId);
        const [w, h2] = _Grid.dims(def, e.rotated);
        if (e.x + w > newW || e.y + h2 > newH) return false;
      }
      const old = this.list();
      this.width = newW;
      this.height = newH;
      this.cells = new Int32Array(newW * newH);
      this.entries.clear();
      for (const e of old) this.place(e.stack, e.x, e.y, e.rotated);
      return true;
    }
    clear() {
      this.entries.clear();
      this.cells.fill(0);
    }
    toJSON() {
      return { width: this.width, height: this.height, entries: this.list() };
    }
    static fromJSON(data) {
      const g = new _Grid(data.width, data.height);
      for (const e of data.entries) g.place(e.stack, e.x, e.y, e.rotated);
      return g;
    }
  };

  // src/crafting/CraftingStation.ts
  function checkRecipe(recipe, inv, ctx) {
    const missing = [];
    if (recipe.station !== "hand" && !ctx.stations.has(recipe.station)) {
      missing.push({ kind: "station", station: recipe.station });
    }
    if (recipe.skill) {
      const have = ctx.skills.level(recipe.skill.name);
      if (have < recipe.skill.level) missing.push({ kind: "skill", skill: recipe.skill.name, need: recipe.skill.level, have });
    }
    for (const ing of recipe.ingredients) {
      const have = inv.count(ing.id);
      if (have < ing.count) missing.push({ kind: "ingredient", id: ing.id, need: ing.count, have });
    }
    for (const tool of recipe.tools) {
      if (!findTool(inv, tool)) missing.push({ kind: "tool", id: tool });
    }
    return missing;
  }
  function findTool(inv, id) {
    const candidates = inv.grid.list().filter((e) => e.stack.defId === id && e.stack.durability !== 0).sort((a, b) => a.stack.durability - b.stack.durability);
    return candidates.length ? candidates[0].stack.uid : null;
  }
  function craft(recipe, inv, ctx) {
    const missing = checkRecipe(recipe, inv, ctx);
    if (missing.length) return { ok: false, missing };
    const snapshot = JSON.stringify(inv.grid.toJSON());
    const toolUids = recipe.tools.map((t2) => findTool(inv, t2));
    for (const ing of recipe.ingredients) inv.remove(ing.id, ing.count);
    const left = inv.add(recipe.output.id, recipe.output.count);
    if (left > 0) {
      inv.grid = Grid.fromJSON(JSON.parse(snapshot));
      return { ok: false, missing: [{ kind: "space" }] };
    }
    toolUids.forEach((uid) => inv.damage(uid, recipe.toolWear));
    if (recipe.skill) ctx.skills.addXp(recipe.skill.name, recipe.xp);
    else ctx.skills.addXp("crafting", Math.ceil(recipe.xp / 2));
    return { ok: true, missing: [], produced: { ...recipe.output } };
  }
  var CraftQueue = class {
    jobs = [];
    start(recipe, inv, ctx) {
      const missing = checkRecipe(recipe, inv, ctx);
      if (missing.length) return { ok: false, missing };
      for (const ing of recipe.ingredients) inv.remove(ing.id, ing.count);
      this.jobs.push({ recipe, remaining: recipe.time });
      return { ok: true, missing: [] };
    }
    /** يعمل على أول مهمة فقط (صنع متسلسل) */
    update(dt, inv, ctx) {
      const events = [];
      const job = this.jobs[0];
      if (!job) return events;
      job.remaining -= dt;
      if (job.remaining <= 0) {
        this.jobs.shift();
        const left = inv.add(job.recipe.output.id, job.recipe.output.count);
        for (const t2 of job.recipe.tools) {
          const uid = findTool(inv, t2);
          if (uid !== null) inv.damage(uid, job.recipe.toolWear);
        }
        if (job.recipe.skill) ctx.skills.addXp(job.recipe.skill.name, job.recipe.xp);
        events.push({ recipe: job.recipe, added: job.recipe.output.count - left, overflow: left });
      }
      return events;
    }
    /** إلغاء: يعيد المكونات للحقيبة قدر الإمكان */
    cancel(index, inv) {
      const [job] = this.jobs.splice(index, 1);
      if (!job) return;
      for (const ing of job.recipe.ingredients) inv.add(ing.id, ing.count);
    }
    get progress() {
      const j = this.jobs[0];
      return j ? 1 - j.remaining / j.recipe.time : 0;
    }
  };

  // src/crafting/ProcessingStation.ts
  var ProcessingStation = class {
    constructor(config2) {
      this.config = config2;
      this.slots = new Array(config2.slots).fill(null);
    }
    config;
    slots;
    get freeSlot() {
      return this.slots.indexOf(null);
    }
    /** يستهلك المكونات من الحقيبة ويضعها في خانة. */
    insert(recipe, inv) {
      if (recipe.station !== this.config.station) return { ok: false, reason: "wrongStation" };
      const i = this.freeSlot;
      if (i < 0) return { ok: false, reason: "full" };
      if (!recipe.ingredients.every((g) => inv.has(g.id, g.count))) return { ok: false, reason: "missing" };
      for (const g of recipe.ingredients) inv.remove(g.id, g.count);
      this.slots[i] = { recipe, progress: 0, state: "processing" };
      return { ok: true };
    }
    /** @param heat شدة النار/الفرن 0..1 (0 = مطفأ) */
    update(dt, heat) {
      if (heat < this.config.minHeat) return;
      for (const s of this.slots) {
        if (!s || s.state === "burnt") continue;
        s.progress += dt * (0.5 + heat * 0.5);
        if (s.state === "processing" && s.progress >= s.recipe.time) s.state = "done";
        if (this.config.burns && s.state === "done" && s.progress >= s.recipe.time * 2.2) s.state = "burnt";
      }
    }
    /** يسحب ناتج خانة (إن انتهت). الخانة تفرغ فقط إن اتسعت الحقيبة. */
    collect(index, inv) {
      const s = this.slots[index];
      if (!s || s.state === "processing") return { ok: false };
      const id = s.state === "burnt" ? this.config.burntItem : s.recipe.output.id;
      const count = s.state === "burnt" ? 1 : s.recipe.output.count;
      if (inv.add(id, count) > 0) {
        return { ok: false };
      }
      this.slots[index] = null;
      return { ok: true, item: id, count };
    }
    toJSON() {
      return this.slots.map((s) => s ? { recipeId: s.recipe.id, progress: s.progress, state: s.state } : null);
    }
    load(data, find) {
      data.forEach((d, i) => {
        if (i >= this.slots.length) return;
        const recipe = d ? find(d.recipeId) : void 0;
        this.slots[i] = d && recipe ? { recipe, progress: d.progress, state: d.state } : null;
      });
    }
    /** إلغاء مهمة قبل نهايتها: لا تُعاد المكونات (ضاعت في النار) */
    discard(index) {
      this.slots[index] = null;
    }
  };

  // src/crafting/Cooking.ts
  var createCampfireStation = () => new ProcessingStation({ station: "campfire", slots: 4, minHeat: 0.2, burns: true, burntItem: "charcoal" });
  var createDryingRack = () => new ProcessingStation({ station: "drying_rack", slots: 3, minHeat: 0.15, burns: false, burntItem: "charcoal" });

  // src/crafting/Smelting.ts
  var createFurnace = () => new ProcessingStation({ station: "furnace", slots: 2, minHeat: 0.5, burns: false, burntItem: "scrap_metal" });

  // src/data/recipes.json
  var recipes_default = [
    {
      id: "rope_fiber",
      nameAr: "\u062D\u0628\u0644 \u0645\u0646 \u0627\u0644\u0623\u0644\u064A\u0627\u0641",
      nameEn: "Rope (fiber)",
      station: "hand",
      ingredients: [
        {
          id: "plant_fiber",
          count: 4
        }
      ],
      tools: [],
      output: {
        id: "rope",
        count: 1
      },
      time: 2,
      skill: {
        name: "crafting",
        level: 0
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "rope_vine",
      nameAr: "\u062D\u0628\u0644 \u0645\u0646 \u0627\u0644\u0643\u0631\u0648\u0645",
      nameEn: "Rope (vine)",
      station: "hand",
      ingredients: [
        {
          id: "vine",
          count: 3
        }
      ],
      tools: [],
      output: {
        id: "rope",
        count: 2
      },
      time: 2,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "tinder_fiber",
      nameAr: "\u0645\u0627\u062F\u0629 \u0625\u0634\u0639\u0627\u0644",
      nameEn: "Tinder",
      station: "hand",
      ingredients: [
        {
          id: "plant_fiber",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "tinder",
        count: 2
      },
      time: 1,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "tinder_bark",
      nameAr: "\u0625\u0634\u0639\u0627\u0644 \u0645\u0646 \u0627\u0644\u0644\u062D\u0627\u0621",
      nameEn: "Tinder (bark)",
      station: "hand",
      ingredients: [
        {
          id: "bark",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "tinder",
        count: 2
      },
      time: 1,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "stone_blade",
      nameAr: "\u0646\u0635\u0644 \u062D\u062C\u0631\u064A",
      nameEn: "Stone Blade",
      station: "hand",
      ingredients: [
        {
          id: "stone",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "stone_blade",
        count: 1
      },
      time: 4,
      skill: {
        name: "crafting",
        level: 0
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "arrowhead_flint",
      nameAr: "\u0631\u0624\u0648\u0633 \u0633\u0647\u0627\u0645",
      nameEn: "Arrowheads",
      station: "hand",
      ingredients: [
        {
          id: "flint",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "arrowhead",
        count: 3
      },
      time: 3,
      skill: {
        name: "crafting",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "fish_hook_bone",
      nameAr: "\u062E\u0637\u0627\u0641 \u0645\u0646 \u0639\u0638\u0645",
      nameEn: "Bone Hook",
      station: "hand",
      ingredients: [
        {
          id: "bone",
          count: 1
        }
      ],
      tools: [
        "knife_stone"
      ],
      output: {
        id: "fish_hook",
        count: 2
      },
      time: 4,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "cloth_fiber",
      nameAr: "\u0642\u0645\u0627\u0634 \u0645\u0646 \u0627\u0644\u0623\u0644\u064A\u0627\u0641",
      nameEn: "Cloth (fiber)",
      station: "hand",
      ingredients: [
        {
          id: "plant_fiber",
          count: 8
        }
      ],
      tools: [],
      output: {
        id: "cloth",
        count: 1
      },
      time: 6,
      skill: {
        name: "crafting",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "thatch",
      nameAr: "\u0642\u0634 \u0633\u0642\u0641",
      nameEn: "Thatch",
      station: "hand",
      ingredients: [
        {
          id: "palm_leaf",
          count: 3
        }
      ],
      tools: [],
      output: {
        id: "thatch",
        count: 2
      },
      time: 3,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "bandage_scrap",
      nameAr: "\u0636\u0645\u0627\u062F\u0629",
      nameEn: "Bandage",
      station: "hand",
      ingredients: [
        {
          id: "cloth_scrap",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "bandage",
        count: 2
      },
      time: 3,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "bandage_cloth",
      nameAr: "\u0636\u0645\u0627\u062F\u0627\u062A \u0645\u0646 \u0642\u0645\u0627\u0634",
      nameEn: "Bandages (cloth)",
      station: "hand",
      ingredients: [
        {
          id: "cloth",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "bandage",
        count: 4
      },
      time: 4,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "splint",
      nameAr: "\u062C\u0628\u064A\u0631\u0629",
      nameEn: "Splint",
      station: "hand",
      ingredients: [
        {
          id: "stick",
          count: 2
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "splint",
        count: 1
      },
      time: 5,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "charcoal_pill",
      nameAr: "\u0623\u0642\u0631\u0627\u0635 \u0641\u062D\u0645",
      nameEn: "Charcoal Pills",
      station: "hand",
      ingredients: [
        {
          id: "charcoal",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "charcoal_pill",
        count: 2
      },
      time: 3,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "firewood_log",
      nameAr: "\u062D\u0637\u0628",
      nameEn: "Firewood",
      station: "hand",
      ingredients: [
        {
          id: "wood_log",
          count: 1
        }
      ],
      tools: [
        "axe_stone"
      ],
      output: {
        id: "firewood",
        count: 3
      },
      time: 5,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "firewood_log_iron",
      nameAr: "\u062D\u0637\u0628 (\u0641\u0623\u0633 \u062D\u062F\u064A\u062F)",
      nameEn: "Firewood (iron axe)",
      station: "hand",
      ingredients: [
        {
          id: "wood_log",
          count: 1
        }
      ],
      tools: [
        "axe_iron"
      ],
      output: {
        id: "firewood",
        count: 4
      },
      time: 3,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "plank_log",
      nameAr: "\u0623\u0644\u0648\u0627\u062D",
      nameEn: "Planks",
      station: "hand",
      ingredients: [
        {
          id: "wood_log",
          count: 1
        }
      ],
      tools: [
        "axe_stone"
      ],
      output: {
        id: "plank",
        count: 2
      },
      time: 6,
      skill: {
        name: "crafting",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "plank_saw",
      nameAr: "\u0623\u0644\u0648\u0627\u062D \u0628\u0627\u0644\u0645\u0646\u0634\u0627\u0631",
      nameEn: "Planks (saw)",
      station: "workbench",
      ingredients: [
        {
          id: "wood_log",
          count: 1
        }
      ],
      tools: [
        "saw"
      ],
      output: {
        id: "plank",
        count: 4
      },
      time: 5,
      skill: {
        name: "crafting",
        level: 2
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "support_beam",
      nameAr: "\u0639\u0627\u0631\u0636\u0629 \u062F\u0639\u0645",
      nameEn: "Support Beam",
      station: "hand",
      ingredients: [
        {
          id: "wood_log",
          count: 1
        }
      ],
      tools: [
        "axe_stone"
      ],
      output: {
        id: "support_beam",
        count: 1
      },
      time: 4,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "salted_fish",
      nameAr: "\u0633\u0645\u0643 \u0645\u0645\u0644\u062D",
      nameEn: "Salted Fish",
      station: "hand",
      ingredients: [
        {
          id: "raw_fish",
          count: 1
        },
        {
          id: "salt",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "salted_fish",
        count: 1
      },
      time: 4,
      skill: {
        name: "survival",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "dried_meat",
      nameAr: "\u0644\u062D\u0645 \u0645\u062C\u0641\u0641",
      nameEn: "Dried Meat",
      station: "hand",
      ingredients: [
        {
          id: "raw_meat",
          count: 1
        },
        {
          id: "salt",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "dried_meat",
        count: 2
      },
      time: 5,
      skill: {
        name: "survival",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "canteen",
      nameAr: "\u0642\u0631\u0628\u0629 \u0645\u0627\u0621",
      nameEn: "Canteen",
      station: "hand",
      ingredients: [
        {
          id: "leather",
          count: 2
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "canteen_empty",
        count: 1
      },
      time: 6,
      skill: {
        name: "crafting",
        level: 2
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "waterproof_bag",
      nameAr: "\u0643\u064A\u0633 \u0645\u0642\u0627\u0648\u0645 \u0644\u0644\u0645\u0627\u0621",
      nameEn: "Waterproof Bag",
      station: "hand",
      ingredients: [
        {
          id: "leather",
          count: 1
        },
        {
          id: "resin",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "waterproof_bag",
        count: 1
      },
      time: 6,
      skill: {
        name: "crafting",
        level: 2
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "knife_stone",
      nameAr: "\u0633\u0643\u064A\u0646 \u062D\u062C\u0631\u064A",
      nameEn: "Stone Knife",
      station: "hand",
      ingredients: [
        {
          id: "stone_blade",
          count: 1
        },
        {
          id: "stick",
          count: 1
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "knife_stone",
        count: 1
      },
      time: 5,
      skill: {
        name: "crafting",
        level: 0
      },
      toolWear: 1,
      xp: 3
    },
    {
      id: "axe_stone",
      nameAr: "\u0641\u0623\u0633 \u062D\u062C\u0631\u064A",
      nameEn: "Stone Axe",
      station: "hand",
      ingredients: [
        {
          id: "stone_blade",
          count: 1
        },
        {
          id: "stick",
          count: 2
        },
        {
          id: "rope",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "axe_stone",
        count: 1
      },
      time: 8,
      skill: {
        name: "crafting",
        level: 0
      },
      toolWear: 1,
      xp: 4
    },
    {
      id: "pickaxe_stone",
      nameAr: "\u0645\u0639\u0648\u0644 \u062D\u062C\u0631\u064A",
      nameEn: "Stone Pickaxe",
      station: "hand",
      ingredients: [
        {
          id: "stone_blade",
          count: 1
        },
        {
          id: "stick",
          count: 2
        },
        {
          id: "rope",
          count: 2
        },
        {
          id: "stone",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "pickaxe_stone",
        count: 1
      },
      time: 8,
      skill: {
        name: "crafting",
        level: 1
      },
      toolWear: 1,
      xp: 4
    },
    {
      id: "hammer",
      nameAr: "\u0645\u0637\u0631\u0642\u0629",
      nameEn: "Hammer",
      station: "hand",
      ingredients: [
        {
          id: "stone",
          count: 2
        },
        {
          id: "stick",
          count: 1
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "hammer",
        count: 1
      },
      time: 6,
      skill: {
        name: "crafting",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "shovel",
      nameAr: "\u0645\u062C\u0631\u0641\u0629",
      nameEn: "Shovel",
      station: "workbench",
      ingredients: [
        {
          id: "plank",
          count: 1
        },
        {
          id: "stone_blade",
          count: 2
        },
        {
          id: "stick",
          count: 1
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "shovel",
        count: 1
      },
      time: 8,
      skill: {
        name: "crafting",
        level: 2
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "spear_wood",
      nameAr: "\u0631\u0645\u062D \u062E\u0634\u0628\u064A",
      nameEn: "Wooden Spear",
      station: "hand",
      ingredients: [
        {
          id: "stick",
          count: 3
        }
      ],
      tools: [
        "knife_stone"
      ],
      output: {
        id: "spear_wood",
        count: 1
      },
      time: 6,
      skill: {
        name: "hunting",
        level: 0
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "spear_stone",
      nameAr: "\u0631\u0645\u062D \u0628\u062D\u062C\u0631",
      nameEn: "Stone Spear",
      station: "hand",
      ingredients: [
        {
          id: "stick",
          count: 3
        },
        {
          id: "stone_blade",
          count: 1
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "spear_stone",
        count: 1
      },
      time: 8,
      skill: {
        name: "hunting",
        level: 1
      },
      toolWear: 1,
      xp: 4
    },
    {
      id: "club",
      nameAr: "\u0647\u0631\u0627\u0648\u0629",
      nameEn: "Club",
      station: "hand",
      ingredients: [
        {
          id: "wood_log",
          count: 1
        }
      ],
      tools: [
        "axe_stone"
      ],
      output: {
        id: "club",
        count: 1
      },
      time: 6,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "bow",
      nameAr: "\u0642\u0648\u0633",
      nameEn: "Bow",
      station: "workbench",
      ingredients: [
        {
          id: "stick",
          count: 3
        },
        {
          id: "rope",
          count: 2
        }
      ],
      tools: [
        "knife_stone"
      ],
      output: {
        id: "bow",
        count: 1
      },
      time: 10,
      skill: {
        name: "hunting",
        level: 2
      },
      toolWear: 1,
      xp: 6
    },
    {
      id: "arrow",
      nameAr: "\u0633\u0647\u0627\u0645",
      nameEn: "Arrows",
      station: "hand",
      ingredients: [
        {
          id: "stick",
          count: 1
        },
        {
          id: "feather",
          count: 1
        },
        {
          id: "arrowhead",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "arrow",
        count: 3
      },
      time: 5,
      skill: {
        name: "hunting",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "fishing_rod",
      nameAr: "\u0635\u0646\u0627\u0631\u0629",
      nameEn: "Fishing Rod",
      station: "hand",
      ingredients: [
        {
          id: "stick",
          count: 2
        },
        {
          id: "rope",
          count: 1
        },
        {
          id: "fish_hook",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "fishing_rod",
        count: 1
      },
      time: 6,
      skill: {
        name: "hunting",
        level: 0
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "fishing_net",
      nameAr: "\u0634\u0628\u0643\u0629 \u0635\u064A\u062F",
      nameEn: "Fishing Net",
      station: "hand",
      ingredients: [
        {
          id: "rope",
          count: 6
        },
        {
          id: "stick",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "fishing_net",
        count: 1
      },
      time: 12,
      skill: {
        name: "hunting",
        level: 2
      },
      toolWear: 1,
      xp: 5
    },
    {
      id: "torch",
      nameAr: "\u0645\u0634\u0639\u0644",
      nameEn: "Torch",
      station: "hand",
      ingredients: [
        {
          id: "stick",
          count: 1
        },
        {
          id: "cloth_scrap",
          count: 1
        },
        {
          id: "resin",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "torch",
        count: 1
      },
      time: 3,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "torch_fat",
      nameAr: "\u0645\u0634\u0639\u0644 \u0628\u0627\u0644\u062F\u0647\u0646",
      nameEn: "Torch (fat)",
      station: "hand",
      ingredients: [
        {
          id: "stick",
          count: 1
        },
        {
          id: "cloth_scrap",
          count: 1
        },
        {
          id: "animal_fat",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "torch",
        count: 1
      },
      time: 3,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "fire_drill",
      nameAr: "\u0645\u062B\u0642\u0627\u0628 \u0646\u0627\u0631",
      nameEn: "Fire Drill",
      station: "hand",
      ingredients: [
        {
          id: "stick",
          count: 2
        },
        {
          id: "plant_fiber",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "fire_drill",
        count: 1
      },
      time: 4,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "lantern",
      nameAr: "\u0641\u0627\u0646\u0648\u0633",
      nameEn: "Lantern",
      station: "workbench",
      ingredients: [
        {
          id: "iron_ingot",
          count: 1
        },
        {
          id: "glass_shard",
          count: 2
        },
        {
          id: "animal_fat",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "lantern",
        count: 1
      },
      time: 10,
      skill: {
        name: "crafting",
        level: 3
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "saw",
      nameAr: "\u0645\u0646\u0634\u0627\u0631",
      nameEn: "Saw",
      station: "workbench",
      ingredients: [
        {
          id: "iron_ingot",
          count: 2
        },
        {
          id: "plank",
          count: 1
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "saw",
        count: 1
      },
      time: 12,
      skill: {
        name: "crafting",
        level: 3
      },
      toolWear: 1,
      xp: 6
    },
    {
      id: "axe_iron",
      nameAr: "\u0641\u0623\u0633 \u062D\u062F\u064A\u062F\u064A",
      nameEn: "Iron Axe",
      station: "workbench",
      ingredients: [
        {
          id: "iron_ingot",
          count: 3
        },
        {
          id: "stick",
          count: 2
        },
        {
          id: "rope",
          count: 2
        }
      ],
      tools: [
        "hammer"
      ],
      output: {
        id: "axe_iron",
        count: 1
      },
      time: 14,
      skill: {
        name: "crafting",
        level: 3
      },
      toolWear: 1,
      xp: 8
    },
    {
      id: "pickaxe_iron",
      nameAr: "\u0645\u0639\u0648\u0644 \u062D\u062F\u064A\u062F\u064A",
      nameEn: "Iron Pickaxe",
      station: "workbench",
      ingredients: [
        {
          id: "iron_ingot",
          count: 3
        },
        {
          id: "stick",
          count: 2
        },
        {
          id: "rope",
          count: 2
        }
      ],
      tools: [
        "hammer"
      ],
      output: {
        id: "pickaxe_iron",
        count: 1
      },
      time: 14,
      skill: {
        name: "crafting",
        level: 3
      },
      toolWear: 1,
      xp: 8
    },
    {
      id: "knife_steel",
      nameAr: "\u0633\u0643\u064A\u0646 \u0641\u0648\u0644\u0627\u0630",
      nameEn: "Steel Knife",
      station: "workbench",
      ingredients: [
        {
          id: "iron_ingot",
          count: 2
        },
        {
          id: "leather",
          count: 1
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [
        "hammer"
      ],
      output: {
        id: "knife_steel",
        count: 1
      },
      time: 12,
      skill: {
        name: "crafting",
        level: 3
      },
      toolWear: 1,
      xp: 8
    },
    {
      id: "nails",
      nameAr: "\u0645\u0633\u0627\u0645\u064A\u0631",
      nameEn: "Nails",
      station: "workbench",
      ingredients: [
        {
          id: "iron_ingot",
          count: 1
        }
      ],
      tools: [
        "hammer"
      ],
      output: {
        id: "nails",
        count: 20
      },
      time: 6,
      skill: {
        name: "crafting",
        level: 2
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "bottle",
      nameAr: "\u0632\u062C\u0627\u062C\u0629",
      nameEn: "Bottle",
      station: "furnace",
      ingredients: [
        {
          id: "glass_shard",
          count: 3
        },
        {
          id: "charcoal",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "bottle_empty",
        count: 1
      },
      time: 10,
      skill: {
        name: "crafting",
        level: 3
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "hat_straw",
      nameAr: "\u0642\u0628\u0639\u0629 \u0642\u0634",
      nameEn: "Straw Hat",
      station: "hand",
      ingredients: [
        {
          id: "palm_leaf",
          count: 4
        },
        {
          id: "plant_fiber",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "hat_straw",
        count: 1
      },
      time: 8,
      skill: {
        name: "crafting",
        level: 0
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "bandana",
      nameAr: "\u0639\u0635\u0627\u0628\u0629 \u0631\u0623\u0633",
      nameEn: "Bandana",
      station: "hand",
      ingredients: [
        {
          id: "cloth_scrap",
          count: 3
        }
      ],
      tools: [],
      output: {
        id: "bandana",
        count: 1
      },
      time: 4,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "sandals",
      nameAr: "\u0635\u0646\u062F\u0644",
      nameEn: "Sandals",
      station: "hand",
      ingredients: [
        {
          id: "palm_leaf",
          count: 3
        },
        {
          id: "rope",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "sandals",
        count: 1
      },
      time: 8,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "shirt_cloth",
      nameAr: "\u0642\u0645\u064A\u0635",
      nameEn: "Cloth Shirt",
      station: "hand",
      ingredients: [
        {
          id: "cloth",
          count: 4
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "shirt_cloth",
        count: 1
      },
      time: 12,
      skill: {
        name: "crafting",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "pants_cloth",
      nameAr: "\u0628\u0646\u0637\u0627\u0644",
      nameEn: "Cloth Pants",
      station: "hand",
      ingredients: [
        {
          id: "cloth",
          count: 4
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "pants_cloth",
        count: 1
      },
      time: 12,
      skill: {
        name: "crafting",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "gloves_cloth",
      nameAr: "\u0642\u0641\u0627\u0632\u0627\u062A \u0642\u0645\u0627\u0634",
      nameEn: "Cloth Gloves",
      station: "hand",
      ingredients: [
        {
          id: "cloth",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "gloves_cloth",
        count: 1
      },
      time: 6,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "raincoat",
      nameAr: "\u0645\u0639\u0637\u0641 \u0645\u0637\u0631",
      nameEn: "Raincoat",
      station: "hand",
      ingredients: [
        {
          id: "cloth",
          count: 4
        },
        {
          id: "resin",
          count: 2
        },
        {
          id: "palm_leaf",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "raincoat",
        count: 1
      },
      time: 14,
      skill: {
        name: "crafting",
        level: 2
      },
      toolWear: 1,
      xp: 5
    },
    {
      id: "boots_leather",
      nameAr: "\u062D\u0630\u0627\u0621 \u062C\u0644\u062F\u064A",
      nameEn: "Leather Boots",
      station: "workbench",
      ingredients: [
        {
          id: "leather",
          count: 4
        },
        {
          id: "rope",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "boots_leather",
        count: 1
      },
      time: 16,
      skill: {
        name: "crafting",
        level: 2
      },
      toolWear: 1,
      xp: 6
    },
    {
      id: "gloves_leather",
      nameAr: "\u0642\u0641\u0627\u0632\u0627\u062A \u062C\u0644\u062F",
      nameEn: "Leather Gloves",
      station: "workbench",
      ingredients: [
        {
          id: "leather",
          count: 2
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "gloves_leather",
        count: 1
      },
      time: 10,
      skill: {
        name: "crafting",
        level: 2
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "jacket_leather",
      nameAr: "\u0633\u062A\u0631\u0629 \u062C\u0644\u062F\u064A\u0629",
      nameEn: "Leather Jacket",
      station: "workbench",
      ingredients: [
        {
          id: "leather",
          count: 6
        },
        {
          id: "rope",
          count: 3
        }
      ],
      tools: [],
      output: {
        id: "jacket_leather",
        count: 1
      },
      time: 20,
      skill: {
        name: "crafting",
        level: 3
      },
      toolWear: 1,
      xp: 8
    },
    {
      id: "backpack_cloth",
      nameAr: "\u062D\u0642\u064A\u0628\u0629 \u0642\u0645\u0627\u0634",
      nameEn: "Cloth Backpack",
      station: "hand",
      ingredients: [
        {
          id: "cloth",
          count: 6
        },
        {
          id: "rope",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "backpack_cloth",
        count: 1
      },
      time: 15,
      skill: {
        name: "crafting",
        level: 1
      },
      toolWear: 1,
      xp: 6
    },
    {
      id: "backpack_leather",
      nameAr: "\u062D\u0642\u064A\u0628\u0629 \u062C\u0644\u062F",
      nameEn: "Leather Backpack",
      station: "workbench",
      ingredients: [
        {
          id: "leather",
          count: 8
        },
        {
          id: "rope",
          count: 3
        },
        {
          id: "nails",
          count: 4
        }
      ],
      tools: [],
      output: {
        id: "backpack_leather",
        count: 1
      },
      time: 25,
      skill: {
        name: "crafting",
        level: 3
      },
      toolWear: 1,
      xp: 10
    },
    {
      id: "cook_fish",
      nameAr: "\u0633\u0645\u0643 \u0645\u0634\u0648\u064A",
      nameEn: "Grill Fish",
      station: "campfire",
      ingredients: [
        {
          id: "raw_fish",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "cooked_fish",
        count: 1
      },
      time: 20,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "cook_crab",
      nameAr: "\u0633\u0644\u0637\u0639\u0648\u0646 \u0645\u0637\u0628\u0648\u062E",
      nameEn: "Cook Crab",
      station: "campfire",
      ingredients: [
        {
          id: "raw_crab",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "cooked_crab",
        count: 1
      },
      time: 18,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "cook_meat",
      nameAr: "\u0644\u062D\u0645 \u0645\u0634\u0648\u064A",
      nameEn: "Grill Meat",
      station: "campfire",
      ingredients: [
        {
          id: "raw_meat",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "cooked_meat",
        count: 1
      },
      time: 25,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "cook_egg",
      nameAr: "\u0628\u064A\u0636\u0629 \u0645\u0633\u0644\u0648\u0642\u0629",
      nameEn: "Boil Egg",
      station: "campfire",
      ingredients: [
        {
          id: "egg",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "cooked_egg",
        count: 1
      },
      time: 15,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "cook_roots",
      nameAr: "\u062C\u0630\u0648\u0631 \u0645\u0637\u0628\u0648\u062E\u0629",
      nameEn: "Cook Roots",
      station: "campfire",
      ingredients: [
        {
          id: "edible_roots",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "cooked_roots",
        count: 1
      },
      time: 20,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "boil_water",
      nameAr: "\u063A\u0644\u064A \u0627\u0644\u0645\u0627\u0621",
      nameEn: "Boil Water",
      station: "campfire",
      ingredients: [
        {
          id: "water_dirty",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "water_boiled",
        count: 1
      },
      time: 30,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "boil_rain",
      nameAr: "\u063A\u0644\u064A \u0645\u0627\u0621 \u0627\u0644\u0645\u0637\u0631",
      nameEn: "Boil Rainwater",
      station: "campfire",
      ingredients: [
        {
          id: "rainwater",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "water_boiled",
        count: 1
      },
      time: 20,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "herbal_tea",
      nameAr: "\u0634\u0627\u064A \u0623\u0639\u0634\u0627\u0628",
      nameEn: "Herbal Tea",
      station: "campfire",
      ingredients: [
        {
          id: "medicinal_herb",
          count: 2
        },
        {
          id: "water_boiled",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "herbal_tea",
        count: 1
      },
      time: 25,
      skill: {
        name: "survival",
        level: 2
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "stew",
      nameAr: "\u064A\u062E\u0646\u0629",
      nameEn: "Stew",
      station: "campfire",
      ingredients: [
        {
          id: "cooked_meat",
          count: 1
        },
        {
          id: "edible_roots",
          count: 1
        },
        {
          id: "water_boiled",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "stew",
        count: 1
      },
      time: 40,
      skill: {
        name: "survival",
        level: 2
      },
      toolWear: 1,
      xp: 5
    },
    {
      id: "fruit_mix",
      nameAr: "\u0633\u0644\u0637\u0629 \u0641\u0648\u0627\u0643\u0647",
      nameEn: "Fruit Mix",
      station: "hand",
      ingredients: [
        {
          id: "banana",
          count: 1
        },
        {
          id: "mango",
          count: 1
        },
        {
          id: "berries",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "fruit_mix",
        count: 1
      },
      time: 5,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "smoke_meat",
      nameAr: "\u0644\u062D\u0645 \u0645\u062F\u062E\u0651\u0646",
      nameEn: "Smoke Meat",
      station: "drying_rack",
      ingredients: [
        {
          id: "raw_meat",
          count: 1
        },
        {
          id: "firewood",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "smoked_meat",
        count: 1
      },
      time: 60,
      skill: {
        name: "survival",
        level: 2
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "smoke_fish",
      nameAr: "\u0633\u0645\u0643 \u0645\u062F\u062E\u0651\u0646",
      nameEn: "Smoke Fish",
      station: "drying_rack",
      ingredients: [
        {
          id: "raw_fish",
          count: 1
        },
        {
          id: "firewood",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "smoked_fish",
        count: 1
      },
      time: 50,
      skill: {
        name: "survival",
        level: 2
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "make_charcoal",
      nameAr: "\u0641\u062D\u0645",
      nameEn: "Charcoal",
      station: "campfire",
      ingredients: [
        {
          id: "wood_log",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "charcoal",
        count: 3
      },
      time: 60,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "tan_leather",
      nameAr: "\u062F\u0628\u0627\u063A\u0629 \u0627\u0644\u062C\u0644\u062F",
      nameEn: "Tan Leather",
      station: "campfire",
      ingredients: [
        {
          id: "raw_hide",
          count: 1
        },
        {
          id: "animal_fat",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "leather",
        count: 1
      },
      time: 45,
      skill: {
        name: "survival",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "smelt_iron",
      nameAr: "\u0633\u0628\u064A\u0643\u0629 \u062D\u062F\u064A\u062F",
      nameEn: "Smelt Iron",
      station: "furnace",
      ingredients: [
        {
          id: "iron_ore",
          count: 2
        },
        {
          id: "charcoal",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "iron_ingot",
        count: 1
      },
      time: 40,
      skill: {
        name: "crafting",
        level: 2
      },
      toolWear: 1,
      xp: 5
    },
    {
      id: "smelt_copper",
      nameAr: "\u0633\u0628\u064A\u0643\u0629 \u0646\u062D\u0627\u0633",
      nameEn: "Smelt Copper",
      station: "furnace",
      ingredients: [
        {
          id: "copper_ore",
          count: 2
        },
        {
          id: "charcoal",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "copper_ingot",
        count: 1
      },
      time: 35,
      skill: {
        name: "crafting",
        level: 2
      },
      toolWear: 1,
      xp: 5
    },
    {
      id: "smelt_glass",
      nameAr: "\u0632\u062C\u0627\u062C",
      nameEn: "Smelt Glass",
      station: "furnace",
      ingredients: [
        {
          id: "sand",
          count: 4
        },
        {
          id: "charcoal",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "glass_shard",
        count: 3
      },
      time: 30,
      skill: {
        name: "crafting",
        level: 2
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "smelt_scrap",
      nameAr: "\u0625\u0639\u0627\u062F\u0629 \u0635\u0647\u0631 \u0627\u0644\u062E\u0631\u062F\u0629",
      nameEn: "Smelt Scrap",
      station: "furnace",
      ingredients: [
        {
          id: "scrap_metal",
          count: 3
        },
        {
          id: "charcoal",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "iron_ingot",
        count: 1
      },
      time: 30,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "campfire_kit",
      nameAr: "\u0639\u062F\u0629 \u0645\u0648\u0642\u062F",
      nameEn: "Campfire Kit",
      station: "hand",
      ingredients: [
        {
          id: "stone",
          count: 8
        },
        {
          id: "stick",
          count: 4
        },
        {
          id: "tinder",
          count: 1
        }
      ],
      tools: [],
      output: {
        id: "campfire_kit",
        count: 1
      },
      time: 8,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "workbench_kit",
      nameAr: "\u0639\u062F\u0629 \u0637\u0627\u0648\u0644\u0629 \u0639\u0645\u0644",
      nameEn: "Workbench Kit",
      station: "hand",
      ingredients: [
        {
          id: "plank",
          count: 6
        },
        {
          id: "rope",
          count: 3
        },
        {
          id: "stone",
          count: 4
        }
      ],
      tools: [],
      output: {
        id: "workbench_kit",
        count: 1
      },
      time: 15,
      skill: {
        name: "crafting",
        level: 1
      },
      toolWear: 1,
      xp: 6
    },
    {
      id: "storage_box",
      nameAr: "\u0635\u0646\u062F\u0648\u0642 \u062A\u062E\u0632\u064A\u0646",
      nameEn: "Storage Box",
      station: "workbench",
      ingredients: [
        {
          id: "plank",
          count: 6
        },
        {
          id: "nails",
          count: 4
        }
      ],
      tools: [
        "hammer"
      ],
      output: {
        id: "storage_box",
        count: 1
      },
      time: 12,
      skill: {
        name: "building",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "barrel",
      nameAr: "\u0628\u0631\u0645\u064A\u0644",
      nameEn: "Barrel",
      station: "workbench",
      ingredients: [
        {
          id: "plank",
          count: 8
        },
        {
          id: "nails",
          count: 6
        },
        {
          id: "resin",
          count: 2
        }
      ],
      tools: [
        "hammer"
      ],
      output: {
        id: "barrel",
        count: 1
      },
      time: 18,
      skill: {
        name: "building",
        level: 2
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "cooler",
      nameAr: "\u062B\u0644\u0627\u062C\u0629 \u0628\u062F\u0627\u0626\u064A\u0629",
      nameEn: "Cooler",
      station: "workbench",
      ingredients: [
        {
          id: "plank",
          count: 6
        },
        {
          id: "clay",
          count: 4
        },
        {
          id: "salt",
          count: 4
        },
        {
          id: "palm_leaf",
          count: 4
        }
      ],
      tools: [
        "hammer"
      ],
      output: {
        id: "cooler",
        count: 1
      },
      time: 24,
      skill: {
        name: "building",
        level: 3
      },
      toolWear: 1,
      xp: 8
    },
    {
      id: "door_wood",
      nameAr: "\u0628\u0627\u0628 \u062E\u0634\u0628\u064A",
      nameEn: "Wooden Door",
      station: "workbench",
      ingredients: [
        {
          id: "plank",
          count: 4
        },
        {
          id: "nails",
          count: 4
        },
        {
          id: "rope",
          count: 1
        }
      ],
      tools: [
        "hammer"
      ],
      output: {
        id: "door_wood",
        count: 1
      },
      time: 12,
      skill: {
        name: "building",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "bed_leaf",
      nameAr: "\u0641\u0631\u0627\u0634 \u0623\u0648\u0631\u0627\u0642",
      nameEn: "Leaf Bed",
      station: "hand",
      ingredients: [
        {
          id: "palm_leaf",
          count: 8
        },
        {
          id: "stick",
          count: 4
        },
        {
          id: "plant_fiber",
          count: 4
        }
      ],
      tools: [],
      output: {
        id: "bed_leaf",
        count: 1
      },
      time: 15,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "drying_rack",
      nameAr: "\u0631\u0641 \u062A\u062C\u0641\u064A\u0641",
      nameEn: "Drying Rack",
      station: "hand",
      ingredients: [
        {
          id: "stick",
          count: 6
        },
        {
          id: "rope",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "drying_rack",
        count: 1
      },
      time: 10,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "furnace_kit",
      nameAr: "\u0639\u062F\u0629 \u0641\u0631\u0646",
      nameEn: "Furnace Kit",
      station: "hand",
      ingredients: [
        {
          id: "clay",
          count: 15
        },
        {
          id: "stone",
          count: 20
        },
        {
          id: "charcoal",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "furnace_kit",
        count: 1
      },
      time: 30,
      skill: {
        name: "building",
        level: 2
      },
      toolWear: 1,
      xp: 8
    },
    {
      id: "farm_plot",
      nameAr: "\u0642\u0637\u0639\u0629 \u0632\u0631\u0627\u0639\u0629",
      nameEn: "Farm Plot",
      station: "hand",
      ingredients: [
        {
          id: "stick",
          count: 8
        },
        {
          id: "plant_fiber",
          count: 4
        }
      ],
      tools: [
        "shovel"
      ],
      output: {
        id: "farm_plot",
        count: 1
      },
      time: 10,
      skill: null,
      toolWear: 1,
      xp: 2
    },
    {
      id: "water_collector",
      nameAr: "\u062C\u0627\u0645\u0639 \u0645\u064A\u0627\u0647 \u0627\u0644\u0645\u0637\u0631",
      nameEn: "Rain Collector",
      station: "hand",
      ingredients: [
        {
          id: "palm_leaf",
          count: 4
        },
        {
          id: "bamboo",
          count: 2
        },
        {
          id: "rope",
          count: 2
        }
      ],
      tools: [],
      output: {
        id: "water_collector",
        count: 1
      },
      time: 10,
      skill: {
        name: "building",
        level: 1
      },
      toolWear: 1,
      xp: 2
    },
    {
      id: "raft_kit",
      nameAr: "\u0639\u062F\u0629 \u0637\u0648\u0627\u0641\u0629",
      nameEn: "Raft Kit",
      station: "workbench",
      ingredients: [
        {
          id: "wood_log",
          count: 8
        },
        {
          id: "bamboo",
          count: 10
        },
        {
          id: "rope",
          count: 10
        },
        {
          id: "sail_cloth",
          count: 1
        }
      ],
      tools: [
        "hammer"
      ],
      output: {
        id: "raft_kit",
        count: 1
      },
      time: 60,
      skill: {
        name: "building",
        level: 3
      },
      toolWear: 1,
      xp: 20
    }
  ];

  // src/crafting/RecipeBook.ts
  var RecipeBook = class {
    all = recipes_default;
    byId = new Map(this.all.map((r) => [r.id, r]));
    seen = /* @__PURE__ */ new Set();
    unlocked = /* @__PURE__ */ new Set();
    constructor() {
      for (const id of ["rope_fiber", "rope_vine", "tinder_fiber", "stone_blade", "thatch", "campfire_kit", "hat_straw", "bandana"]) {
        this.unlocked.add(id);
      }
    }
    get(id) {
      return this.byId.get(id);
    }
    isUnlocked(id) {
      return this.unlocked.has(id);
    }
    list(station, onlyUnlocked = true) {
      return this.all.filter((r) => (!station || r.station === station) && (!onlyUnlocked || this.unlocked.has(r.id)));
    }
    /** يُستدعى عند أول مرة يحصل اللاعب فيها على عنصر. @returns الوصفات التي انفتحت الآن */
    noteItem(defId) {
      if (this.seen.has(defId)) return [];
      this.seen.add(defId);
      const opened = [];
      for (const r of this.all) {
        if (this.unlocked.has(r.id)) continue;
        const needs = [...r.ingredients.map((i) => i.id), ...r.tools];
        if (needs.every((n) => this.seen.has(n))) {
          this.unlocked.add(r.id);
          opened.push(r);
        }
      }
      return opened;
    }
    unlock(id) {
      if (this.byId.has(id)) this.unlocked.add(id);
    }
    toJSON() {
      return { seen: [...this.seen], unlocked: [...this.unlocked] };
    }
    load(data) {
      this.seen = new Set(data.seen);
      this.unlocked = new Set(data.unlocked);
    }
  };

  // src/data/npcs.ts
  var NPC_DEFS = [
    {
      id: "layla",
      nameAr: "\u0644\u064A\u0644\u0649",
      nameEn: "Layla",
      bioAr: "\u0637\u0628\u064A\u0628\u0629 \u0641\u064A \u0627\u0644\u0623\u0631\u0628\u0639\u064A\u0646 \u0643\u0627\u0646\u062A \u0639\u0644\u0649 \u0645\u062A\u0646 \u0627\u0644\u0631\u062D\u0644\u0629. \u0647\u0627\u062F\u0626\u0629 \u0648\u062F\u0642\u064A\u0642\u0629\u060C \u062A\u062D\u0645\u0644 \u062D\u0642\u064A\u0628\u0629 \u0625\u0633\u0639\u0627\u0641 \u0648\u062A\u062E\u0641\u064A \u0623\u0644\u0645\u064B\u0627 \u0639\u0644\u0649 \u0627\u0628\u0646\u0647\u0627 \u0627\u0644\u0645\u0641\u0642\u0648\u062F.",
      bioEn: "A doctor in her forties who was on the flight. Calm and precise, she carries a first-aid kit and hides grief over a missing son.",
      likes: { honey: 6, herbal_tea: 5, medicinal_herb: 4, aloe: 4, cooked_fish: 3, bandage: 2 },
      schedule: [
        { from: 22, to: 6, activity: "sleep", place: "camp" },
        { from: 6, to: 11, activity: "forage", place: "forest" },
        { from: 11, to: 17, activity: "work", place: "camp" },
        { from: 17, to: 22, activity: "camp", place: "camp" }
      ],
      dialogue: {
        start: "hello",
        nodes: {
          hello: {
            id: "hello",
            textAr: "\u0644\u0627 \u062A\u0642\u062A\u0631\u0628 \u0628\u0633\u0631\u0639\u0629... \u0623\u0646\u062A \u062C\u0631\u064A\u062D\u061F \u0623\u0631\u0646\u064A \u0630\u0631\u0627\u0639\u0643. \u0623\u0646\u0627 \u0644\u064A\u0644\u0649\u060C \u0643\u0646\u062A \u0637\u0628\u064A\u0628\u0629 \u0642\u0628\u0644 \u0643\u0644 \u0647\u0630\u0627.",
            textEn: "Don't rush at me... are you hurt? Let me see your arm. I'm Layla \u2014 I was a doctor before all this.",
            variants: [
              { when: { hasFlags: ["layla_gave_kit"] }, node: "return_kit" },
              { when: { minTrust: 25 }, node: "friendly" },
              { when: { hasFlags: ["layla_met"] }, node: "again" }
            ],
            choices: [
              { textAr: "\u0623\u0646\u0627 \u0628\u062E\u064A\u0631\u060C \u0634\u0643\u0631\u064B\u0627. \u0647\u0644 \u0631\u0623\u064A\u062A\u0650 \u0646\u0627\u062C\u064A\u0646 \u0622\u062E\u0631\u064A\u0646\u061F", textEn: "I'm fine, thanks. Have you seen other survivors?", next: "others", trust: 3, setFlags: ["layla_met"] },
              { textAr: "\u0627\u0628\u062A\u0639\u062F\u064A \u0639\u0646\u064A.", textEn: "Stay away from me.", next: null, trust: -6, setFlags: ["layla_met"] },
              { textAr: "\u0646\u0639\u0645\u060C \u0630\u0631\u0627\u0639\u064A \u062A\u0646\u0632\u0641.", textEn: "Yes, my arm is bleeding.", next: "treat", trust: 5, setFlags: ["layla_met"], action: "give_item:bandage:2" }
            ]
          },
          again: {
            id: "again",
            textAr: "\u0639\u062F\u062A\u064E. \u0647\u0644 \u0648\u062C\u062F\u062A \u0645\u0627\u0621\u064B \u0646\u0638\u064A\u0641\u064B\u0627\u061F \u0627\u0644\u063A\u0644\u064A\u0627\u0646 \u0648\u062D\u062F\u0647 \u064A\u0646\u0642\u0630 \u0627\u0644\u0623\u0631\u0648\u0627\u062D \u0647\u0646\u0627.",
            textEn: "You came back. Have you found clean water? Boiling alone saves lives here.",
            choices: [
              { textAr: "\u0633\u0623\u063A\u0644\u064A\u0647 \u0645\u0646 \u0627\u0644\u0622\u0646.", textEn: "I'll boil it from now on.", next: null, trust: 2 },
              { textAr: "\u0647\u0644 \u062A\u062D\u062A\u0627\u062C\u064A\u0646 \u0634\u064A\u0626\u064B\u0627\u061F", textEn: "Do you need anything?", next: "needs", trust: 1 }
            ]
          },
          others: {
            id: "others",
            textAr: "\u0631\u0623\u064A\u062A \u0634\u0627\u0628\u064B\u0627 \u0627\u0633\u0645\u0647 \u0639\u0645\u0631 \u0639\u0646\u062F \u062D\u0637\u0627\u0645 \u0627\u0644\u0637\u0627\u0626\u0631\u0629\u060C \u0648\u0639\u062C\u0648\u0632\u064B\u0627 \u064A\u062F\u0639\u0649 \u064A\u0648\u0633\u0641 \u064A\u0639\u064A\u0634 \u0642\u0631\u0628 \u0627\u0644\u0643\u0647\u0641. \u0627\u062D\u0630\u0631\u0647\u0645\u0627 \u0642\u0644\u064A\u0644\u064B\u0627\u060C \u0643\u0644\u0627\u0647\u0645\u0627 \u064A\u062E\u0641\u064A \u0634\u064A\u0626\u064B\u0627.",
            textEn: "I saw a young man named Omar at the wreck, and an old man named Yusuf living near the cave. Be careful \u2014 both are hiding something.",
            choices: [
              { textAr: "\u0633\u0623\u0628\u062D\u062B \u0639\u0646\u0647\u0645\u0627.", textEn: "I'll look for them.", next: null, setFlags: ["know_omar", "know_yusuf"] },
              { textAr: "\u0647\u0644 \u062A\u062D\u062A\u0627\u062C\u064A\u0646 \u0645\u0633\u0627\u0639\u062F\u0629\u061F", textEn: "Do you need help?", next: "needs", trust: 2 }
            ]
          },
          treat: {
            id: "treat",
            textAr: "\u062B\u0628\u0651\u062A \u0627\u0644\u0636\u0645\u0627\u062F\u0629 \u062C\u064A\u062F\u064B\u0627 \u0648\u0644\u0627 \u062A\u062F\u0639\u0647\u0627 \u062A\u0628\u062A\u0644. \u0627\u0644\u062C\u0631\u062D \u0627\u0644\u0645\u0641\u062A\u0648\u062D \u0647\u0646\u0627 \u064A\u062A\u062D\u0648\u0644 \u0625\u0644\u0649 \u0639\u062F\u0648\u0649 \u062E\u0644\u0627\u0644 \u0633\u0627\u0639\u0627\u062A.",
            textEn: "Keep the bandage tight and dry. An open wound turns infected within hours here.",
            choices: [{ textAr: "\u0634\u0643\u0631\u064B\u0627 \u0644\u0643\u0650.", textEn: "Thank you.", next: null, trust: 2 }]
          },
          needs: {
            id: "needs",
            textAr: "\u0623\u062D\u062A\u0627\u062C \u0639\u0634\u0631\u0629 \u0623\u0639\u0634\u0627\u0628 \u0637\u0628\u064A\u0629 \u0648\u0639\u0633\u0644\u064B\u0627 \u0625\u0646 \u0648\u062C\u062F\u062A. \u0633\u0623\u0639\u0637\u064A\u0643 \u0645\u0627 \u064A\u0641\u064A\u062F\u0643 \u0641\u064A \u0627\u0644\u0645\u0642\u0627\u0628\u0644.",
            textEn: "I need ten medicinal herbs, and honey if you find any. I will repay you with something useful.",
            choices: [
              { textAr: "\u0647\u0630\u0647 \u0627\u0644\u0623\u0639\u0634\u0627\u0628.", textEn: "Here are the herbs.", next: "thanks", requires: { hasItems: [{ id: "medicinal_herb", count: 10 }] }, trust: 12, setFlags: ["layla_herbs"], action: "take_item:medicinal_herb:10" },
              { textAr: "\u0633\u0623\u0639\u0648\u062F \u0628\u0647\u0627.", textEn: "I'll bring them.", next: null }
            ]
          },
          thanks: {
            id: "thanks",
            textAr: "\u0647\u0630\u0627 \u0645\u0627 \u0643\u0646\u062A \u0623\u062D\u062A\u0627\u062C\u0647. \u062E\u0630 \u0645\u0636\u0627\u062F\u064B\u0627 \u062D\u064A\u0648\u064A\u064B\u0627 \u0645\u0646 \u0645\u062E\u0632\u0648\u0646\u064A\u060C \u0641\u0644\u0646 \u062A\u0639\u0631\u0641 \u0645\u062A\u0649 \u0633\u062A\u062D\u062A\u0627\u062C\u0647.",
            textEn: "Exactly what I needed. Take an antibiotic from my stock \u2014 you never know when you'll need it.",
            choices: [{ textAr: "\u0645\u0645\u062A\u0646 \u062C\u062F\u064B\u0627.", textEn: "Very grateful.", next: null, trust: 4, action: "give_item:antibiotic:1" }]
          },
          friendly: {
            id: "friendly",
            textAr: "\u0635\u0631\u062A\u064E \u0623\u0642\u0631\u0628 \u0625\u0644\u064A \u0645\u0646 \u0623\u0646 \u0623\u062E\u0641\u064A \u0639\u0646\u0643 \u0627\u0644\u0623\u0645\u0631: \u0627\u0628\u0646\u064A \u0643\u0627\u0646 \u0645\u0639\u064A \u0641\u064A \u0627\u0644\u0631\u062D\u0644\u0629. \u0644\u0627 \u0623\u0639\u0631\u0641 \u0625\u0646 \u0643\u0627\u0646 \u062D\u064A\u064B\u0627. \u0625\u0646 \u0648\u062C\u062F\u062A \u0634\u064A\u0626\u064B\u0627 \u064A\u062E\u0635\u0647...",
            textEn: "You've earned the truth: my son was on the flight with me. I don't know if he's alive. If you find anything of his...",
            choices: [
              { textAr: "\u0633\u0623\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u062D\u0637\u0627\u0645. \u0623\u0639\u062F\u0643.", textEn: "I'll search the wreck. I promise.", next: "kit", trust: 10, setFlags: ["layla_gave_kit"], action: "give_item:first_aid_kit:1" },
              { textAr: "\u0644\u064A\u0633 \u0627\u0644\u0622\u0646.", textEn: "Not now.", next: null }
            ]
          },
          kit: {
            id: "kit",
            textAr: "\u062E\u0630 \u062D\u0642\u064A\u0628\u0629 \u0627\u0644\u0625\u0633\u0639\u0627\u0641 \u0647\u0630\u0647. \u0625\u0646 \u0628\u0642\u064A\u062A \u062D\u064A\u064B\u0627 \u062D\u062A\u0649 \u0627\u0644\u0625\u0646\u0642\u0627\u0630 \u0641\u0647\u0630\u0627 \u064A\u0643\u0641\u064A\u0646\u064A.",
            textEn: "Take this first-aid kit. If you survive until the rescue, that's enough for me.",
            choices: [{ textAr: "...", textEn: "...", next: null }]
          },
          return_kit: {
            id: "return_kit",
            textAr: "\u0623\u062A\u0645\u0646\u0649 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0627\u0644\u062D\u0642\u064A\u0628\u0629 \u0642\u062F \u0646\u0641\u0639\u062A\u0643. \u0647\u0644 \u0648\u062C\u062F\u062A \u0634\u064A\u0626\u064B\u0627 \u0641\u064A \u0627\u0644\u062D\u0637\u0627\u0645\u061F",
            textEn: "I hope the kit has helped. Did you find anything at the wreck?",
            choices: [
              { textAr: "\u0648\u062C\u062F\u062A \u0647\u0630\u0647 \u0627\u0644\u0635\u0648\u0631\u0629 \u0627\u0644\u0642\u062F\u064A\u0645\u0629.", textEn: "I found this old photo.", next: "photo", requires: { hasItems: [{ id: "old_photo", count: 1 }] }, trust: 30, setFlags: ["layla_photo"], action: "take_item:old_photo:1" },
              { textAr: "\u0644\u064A\u0633 \u0628\u0639\u062F.", textEn: "Not yet.", next: null }
            ]
          },
          photo: {
            id: "photo",
            textAr: "...\u0625\u0646\u0647 \u0647\u0648. \u0634\u0643\u0631\u064B\u0627 \u0644\u0643. \u0633\u0623\u062E\u0628\u0631\u0643 \u0628\u0634\u064A\u0621: \u0627\u0644\u0631\u0627\u062F\u064A\u0648 \u0627\u0644\u0630\u064A \u064A\u0628\u062D\u062B \u0639\u0646\u0647 \u0639\u0645\u0631 \u064A\u062D\u062A\u0627\u062C \u0628\u0637\u0627\u0631\u064A\u0629\u060C \u0648\u0642\u062F \u0631\u0623\u064A\u062A\u0647\u0627 \u0639\u0646\u062F \u064A\u0648\u0633\u0641.",
            textEn: "...It's him. Thank you. Let me tell you something: Omar's radio needs a battery \u2014 I saw one with Yusuf.",
            choices: [{ textAr: "\u0633\u0623\u0633\u0623\u0644 \u064A\u0648\u0633\u0641.", textEn: "I'll ask Yusuf.", next: null, setFlags: ["know_battery_yusuf"] }]
          }
        }
      }
    },
    {
      id: "omar",
      nameAr: "\u0639\u0645\u0631",
      nameEn: "Omar",
      bioAr: "\u0645\u0647\u0646\u062F\u0633 \u0627\u062A\u0635\u0627\u0644\u0627\u062A \u0634\u0627\u0628\u060C \u0645\u062A\u062D\u0645\u0633 \u0648\u0645\u062A\u0647\u0648\u0631. \u064A\u0639\u0645\u0644 \u0644\u064A\u0644 \u0646\u0647\u0627\u0631 \u0639\u0644\u0649 \u0625\u0635\u0644\u0627\u062D \u0631\u0627\u062F\u064A\u0648 \u0627\u0644\u0637\u0627\u0626\u0631\u0629 \u0648\u0647\u0648 \u0645\u0642\u062A\u0646\u0639 \u0623\u0646 \u0627\u0644\u0625\u0646\u0642\u0627\u0630 \u0642\u0631\u064A\u0628.",
      bioEn: "A young telecom engineer, eager and reckless. He works day and night repairing the plane radio, convinced rescue is near.",
      likes: { energy_bar: 6, canned_beans: 5, scrap_metal: 4, copper_ingot: 5, iron_ingot: 4, nails: 3, cooked_meat: 3 },
      schedule: [
        { from: 23, to: 7, activity: "sleep", place: "wreck" },
        { from: 7, to: 19, activity: "work", place: "wreck" },
        { from: 19, to: 23, activity: "camp", place: "camp" }
      ],
      dialogue: {
        start: "hello",
        nodes: {
          hello: {
            id: "hello",
            textAr: "\u0648\u0627\u0648! \u0628\u0634\u0631\u064A \u0622\u062E\u0631! \u0623\u0646\u0627 \u0639\u0645\u0631. \u0627\u0633\u0645\u0639\u060C \u0623\u0646\u0627 \u0642\u0631\u064A\u0628 \u0645\u0646 \u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0631\u0627\u062F\u064A\u0648\u060C \u0623\u062D\u062A\u0627\u062C \u0642\u0637\u0639\u064B\u0627 \u0641\u0642\u0637!",
            textEn: "Wow \u2014 another human! I'm Omar. Listen, I'm close to getting this radio running \u2014 I just need parts!",
            variants: [
              { when: { hasFlags: ["radio_done"] }, node: "done" },
              { when: { hasFlags: ["omar_battery_given"], notFlags: ["radio_done"] }, node: "battery_in" },
              { when: { hasFlags: ["omar_met"] }, node: "again" }
            ],
            choices: [
              { textAr: "\u0645\u0627 \u0627\u0644\u0630\u064A \u062A\u062D\u062A\u0627\u062C\u0647 \u0628\u0627\u0644\u0636\u0628\u0637\u061F", textEn: "What exactly do you need?", next: "needs", trust: 3, setFlags: ["omar_met"], action: "quest:repair_radio" },
              { textAr: "\u0647\u0644 \u062A\u0639\u0631\u0641 \u0637\u0631\u064A\u0642\u064B\u0627 \u0644\u0644\u062E\u0631\u0648\u062C \u0645\u0646 \u0627\u0644\u062C\u0632\u064A\u0631\u0629\u061F", textEn: "Do you know a way off the island?", next: "ways", setFlags: ["omar_met"] }
            ]
          },
          again: {
            id: "again",
            textAr: "\u0647\u0644 \u062C\u0644\u0628\u062A \u0627\u0644\u0642\u0637\u0639\u061F \u0643\u0644 \u0633\u0627\u0639\u0629 \u062A\u0623\u062E\u064A\u0631 \u062A\u0639\u0646\u064A \u0641\u0631\u0635\u0629 \u0623\u0642\u0644 \u0644\u062A\u062D\u062F\u064A\u062F \u0645\u0648\u0642\u0639\u0646\u0627.",
            textEn: "Did you bring the parts? Every hour of delay is a smaller chance of fixing our position.",
            choices: [
              { textAr: "\u0647\u0630\u0647 \u062E\u0631\u062F\u0629 \u0645\u0639\u062F\u0646 \u0648\u0646\u062D\u0627\u0633.", textEn: "Here is scrap metal and copper.", next: "parts", requires: { hasItems: [{ id: "scrap_metal", count: 3 }, { id: "copper_ingot", count: 1 }] }, trust: 10, setFlags: ["omar_parts"], action: "take_item:scrap_metal:3" },
              { textAr: "\u0644\u064A\u0633 \u0628\u0639\u062F.", textEn: "Not yet.", next: null }
            ]
          },
          needs: {
            id: "needs",
            textAr: "\u062B\u0644\u0627\u062B \u0642\u0637\u0639 \u062E\u0631\u062F\u0629 \u0645\u0639\u062F\u0646\u060C \u0633\u0628\u064A\u0643\u0629 \u0646\u062D\u0627\u0633\u060C \u0648\u0628\u0637\u0627\u0631\u064A\u0629. \u0627\u0644\u0628\u0637\u0627\u0631\u064A\u0629 \u0647\u064A \u0627\u0644\u0623\u0635\u0639\u0628... \u0633\u0645\u0639\u062A \u0623\u0646 \u0634\u064A\u062E\u064B\u0627 \u0642\u0631\u0628 \u0627\u0644\u0643\u0647\u0641 \u064A\u0645\u0644\u0643 \u0648\u0627\u062D\u062F\u0629.",
            textEn: "Three scrap metal pieces, a copper ingot, and a battery. The battery's the hard part... I heard an old man near the cave has one.",
            choices: [{ textAr: "\u0633\u0623\u062A\u0648\u0644\u0649 \u0627\u0644\u0623\u0645\u0631.", textEn: "I'll handle it.", next: null, trust: 2, setFlags: ["know_battery_yusuf"] }]
          },
          ways: {
            id: "ways",
            textAr: "\u0627\u0644\u0637\u0648\u0627\u0641\u0629 \u0645\u0645\u0643\u0646\u0629 \u0644\u0643\u0646\u0647\u0627 \u062E\u0637\u064A\u0631\u0629. \u0627\u0644\u0625\u0634\u0627\u0631\u0629 \u0639\u0628\u0631 \u0627\u0644\u0631\u0627\u062F\u064A\u0648 \u0623\u0623\u0645\u0646 \u0628\u0643\u062B\u064A\u0631. \u0633\u0627\u0639\u062F\u0646\u064A.",
            textEn: "A raft is possible but dangerous. Signaling by radio is far safer. Help me.",
            choices: [{ textAr: "\u062D\u0633\u0646\u064B\u0627.", textEn: "Alright.", next: "needs", trust: 3 }]
          },
          parts: {
            id: "parts",
            textAr: "\u0645\u0645\u062A\u0627\u0632! \u0628\u0642\u064A\u062A \u0627\u0644\u0628\u0637\u0627\u0631\u064A\u0629 \u0641\u0642\u0637. \u0639\u0646\u062F\u0645\u0627 \u062A\u062D\u0635\u0644 \u0639\u0644\u064A\u0647\u0627 \u0639\u062F \u0625\u0644\u064A \u0641\u0648\u0631\u064B\u0627.",
            textEn: "Excellent! Only the battery left. When you get it, come straight back.",
            choices: [{ textAr: "\u0633\u0623\u0639\u0648\u062F.", textEn: "I'll be back.", next: null }]
          },
          battery_in: {
            id: "battery_in",
            textAr: "\u0625\u0646\u0647 \u064A\u0639\u0645\u0644!... \u0623\u0646\u0627 \u0623\u0633\u0645\u0639 \u062A\u0634\u0648\u064A\u0634\u064B\u0627. \u0623\u062D\u062A\u0627\u062C \u0628\u0636\u0639 \u062F\u0642\u0627\u0626\u0642 \u0644\u0623\u0631\u0633\u0644 \u0646\u062F\u0627\u0621 \u0627\u0644\u0627\u0633\u062A\u063A\u0627\u062B\u0629.",
            textEn: "It's working!... I hear static. I need a few minutes to send the distress call.",
            choices: [{ textAr: "\u0623\u0631\u0633\u0644\u0647 \u0627\u0644\u0622\u0646!", textEn: "Send it now!", next: null, trust: 10, setFlags: ["radio_done"], action: "flag:radio_done" }]
          },
          done: {
            id: "done",
            textAr: "\u0623\u0631\u0633\u0644\u062A\u064F \u0627\u0644\u0646\u062F\u0627\u0621. \u0627\u0644\u0622\u0646 \u0639\u0644\u064A\u0646\u0627 \u0623\u0646 \u0646\u0628\u0642\u0649 \u0623\u062D\u064A\u0627\u0621 \u0648\u0646\u064F\u0634\u0639\u0644 \u0625\u0634\u0627\u0631\u0629 \u0639\u0646\u062F \u0627\u0642\u062A\u0631\u0627\u0628\u0647\u0645. \u0634\u0643\u0631\u064B\u0627 \u0644\u0643\u060C \u062D\u0642\u064B\u0627.",
            textEn: "The call is sent. Now we must stay alive and light a signal when they come close. Thank you \u2014 truly.",
            choices: [{ textAr: "\u0633\u0646\u0646\u062C\u0648.", textEn: "We'll make it.", next: null, trust: 5 }]
          }
        }
      }
    },
    {
      id: "yusuf",
      nameAr: "\u064A\u0648\u0633\u0641",
      nameEn: "Yusuf",
      bioAr: "\u0635\u064A\u0627\u062F \u0633\u0628\u0639\u064A\u0646\u064A \u064A\u0639\u064A\u0634 \u0639\u0644\u0649 \u0627\u0644\u062C\u0632\u064A\u0631\u0629 \u0645\u0646\u0630 \u0633\u0646\u0648\u0627\u062A \u0628\u0639\u062F \u063A\u0631\u0642 \u0642\u0627\u0631\u0628\u0647. \u064A\u0639\u0631\u0641 \u0623\u0633\u0631\u0627\u0631\u0647\u0627 \u0644\u0643\u0646\u0647 \u0644\u0627 \u064A\u062B\u0642 \u0628\u0633\u0647\u0648\u0644\u0629.",
      bioEn: "A seventy-year-old fisherman living on the island for years since his boat sank. He knows its secrets but trusts slowly.",
      likes: { cooked_fish: 5, salted_fish: 5, honey: 4, herbal_tea: 4, fishing_net: 6, fish_hook: 3, rope: 2 },
      schedule: [
        { from: 20, to: 5, activity: "sleep", place: "cave" },
        { from: 5, to: 12, activity: "work", place: "beach" },
        { from: 12, to: 16, activity: "camp", place: "cave" },
        { from: 16, to: 20, activity: "patrol", place: "beach" }
      ],
      dialogue: {
        start: "hello",
        nodes: {
          hello: {
            id: "hello",
            textAr: "... \u0645\u0627\u0630\u0627 \u062A\u0631\u064A\u062F\u061F \u0647\u0630\u0647 \u0623\u0631\u0636\u064A \u0648\u0623\u0646\u0627 \u0644\u0645 \u0623\u062F\u0639\u064F \u0623\u062D\u062F\u064B\u0627.",
            textEn: "... What do you want? This is my ground, and I invited no one.",
            variants: [
              { when: { hasFlags: ["yusuf_secret"] }, node: "after_secret" },
              { when: { minTrust: 40 }, node: "secret" },
              { when: { hasFlags: ["yusuf_met"] }, node: "again" }
            ],
            choices: [
              { textAr: "\u0623\u0628\u062D\u062B \u0639\u0646 \u0646\u0627\u062C\u064A\u0646 \u0641\u0642\u0637.", textEn: "Just looking for survivors.", next: "gruff", trust: 1, setFlags: ["yusuf_met"] },
              { textAr: "\u0623\u062D\u0645\u0644 \u0633\u0645\u0643\u064B\u0627 \u0637\u0627\u0632\u062C\u064B\u0627 \u0644\u0643.", textEn: "I brought you fresh fish.", next: "fish", requires: { hasItems: [{ id: "cooked_fish", count: 1 }] }, trust: 8, setFlags: ["yusuf_met"], action: "take_item:cooked_fish:1" }
            ]
          },
          gruff: {
            id: "gruff",
            textAr: "\u0646\u0627\u062C\u064A\u0646... \u0643\u0644\u0646\u0627 \u0646\u062D\u0627\u0648\u0644 \u0623\u0644\u0627 \u0646\u0645\u0648\u062A. \u0627\u0628\u062A\u0639\u062F \u0639\u0646 \u0643\u0647\u0641\u064A \u0648\u0644\u0646 \u064A\u0635\u064A\u0628\u0643 \u0623\u0630\u0649.",
            textEn: "Survivors... we're all trying not to die. Stay away from my cave and you won't get hurt.",
            choices: [{ textAr: "\u062D\u0633\u0646\u064B\u0627.", textEn: "Fine.", next: null }]
          },
          fish: {
            id: "fish",
            textAr: "\u0647\u0645\u0645... \u0633\u0645\u0643 \u0645\u0634\u0648\u064A \u062C\u064A\u062F\u064B\u0627. \u0642\u0644\u0651\u0645\u0627 \u0623\u0631\u0649 \u0645\u0646 \u064A\u062D\u0633\u0646 \u0627\u0644\u0637\u0628\u062E. \u0627\u062C\u0644\u0633 \u0625\u0646 \u0623\u0631\u062F\u062A.",
            textEn: "Hmm... well grilled. Few here can cook. Sit, if you like.",
            choices: [{ textAr: "\u0634\u0643\u0631\u064B\u0627.", textEn: "Thanks.", next: null, trust: 4 }]
          },
          again: {
            id: "again",
            textAr: "\u0623\u0646\u062A \u0645\u062C\u062F\u062F\u064B\u0627. \u0627\u0644\u0635\u064A\u062F \u062C\u064A\u062F \u0639\u0646\u062F \u0627\u0644\u0641\u062C\u0631 \u0639\u0644\u0649 \u0627\u0644\u0634\u0627\u0637\u0626 \u0627\u0644\u0634\u0631\u0642\u064A\u060C \u0625\u0646 \u0643\u0646\u062A \u062A\u0647\u062A\u0645.",
            textEn: "You again. Fishing is good at dawn on the east beach, if you care.",
            choices: [
              { textAr: "\u0647\u0644 \u0644\u062F\u064A\u0643 \u0628\u0637\u0627\u0631\u064A\u0629\u061F \u0639\u0645\u0631 \u064A\u062D\u062A\u0627\u062C\u0647\u0627.", textEn: "Do you have a battery? Omar needs one.", next: "battery_ask", requires: { hasFlags: ["know_battery_yusuf"] } },
              { textAr: "\u0633\u0623\u0639\u0648\u062F \u0644\u0627\u062D\u0642\u064B\u0627.", textEn: "I'll come back later.", next: null }
            ]
          },
          battery_ask: {
            id: "battery_ask",
            textAr: "\u0644\u0646 \u0623\u0639\u0637\u064A \u0634\u064A\u0626\u064B\u0627 \u0644\u063A\u0631\u064A\u0628. \u0627\u0643\u0633\u0628 \u062B\u0642\u062A\u064A \u0623\u0648\u0644\u064B\u0627\u060C \u0648\u0623\u062D\u0636\u0631 \u0644\u064A \u0634\u0628\u0643\u0629 \u0635\u064A\u062F \u062C\u064A\u062F\u0629.",
            textEn: "I give nothing to strangers. Earn my trust first \u2014 and bring me a good fishing net.",
            choices: [
              { textAr: "\u0647\u0630\u0647 \u0634\u0628\u0643\u0629 \u0635\u064A\u062F.", textEn: "Here is a fishing net.", next: "battery_ok", requires: { hasItems: [{ id: "fishing_net", count: 1 }] }, trust: 20, action: "take_item:fishing_net:1", setFlags: ["yusuf_net"] },
              { textAr: "\u0633\u0623\u0639\u0648\u062F \u0628\u0647\u0627.", textEn: "I'll bring it.", next: null }
            ]
          },
          battery_ok: {
            id: "battery_ok",
            textAr: "\u0634\u0628\u0643\u0629 \u0645\u062A\u0642\u0646\u0629 \u0627\u0644\u0635\u0646\u0639. \u062E\u0630 \u0627\u0644\u0628\u0637\u0627\u0631\u064A\u0629\u060C \u0644\u0643\u0646 \u0644\u0627 \u062A\u062E\u0628\u0631 \u0639\u0645\u0631 \u0623\u0646\u0646\u064A \u062A\u0633\u0627\u0647\u0644\u062A.",
            textEn: "A finely made net. Take the battery \u2014 but don't tell Omar I went soft.",
            choices: [{ textAr: "\u0634\u0643\u0631\u064B\u0627 \u064A\u0627 \u0639\u0645 \u064A\u0648\u0633\u0641.", textEn: "Thank you, Yusuf.", next: null, trust: 6, action: "give_item:radio_battery:1", setFlags: ["yusuf_battery"] }]
          },
          secret: {
            id: "secret",
            textAr: "\u062B\u0642\u062A\u064A \u0628\u0643 \u0643\u0628\u064A\u0631\u0629 \u0627\u0644\u0622\u0646. \u0647\u0630\u0647 \u0627\u0644\u062C\u0632\u064A\u0631\u0629 \u0644\u064A\u0633\u062A \u0643\u0645\u0627 \u062A\u0628\u062F\u0648: \u062A\u062D\u062A \u0627\u0644\u0628\u0631\u0643\u0627\u0646 \u0645\u062E\u0628\u0623 \u0642\u062F\u064A\u0645\u060C \u0645\u0641\u062A\u0627\u062D\u0647 \u0645\u0639\u064A. \u0645\u0627 \u0628\u062F\u0627\u062E\u0644\u0647 \u0642\u062F \u064A\u063A\u064A\u0651\u0631 \u0643\u0644 \u0634\u064A\u0621.",
            textEn: "I trust you now. This island is not what it seems: under the volcano lies an old bunker \u2014 I hold its key. What's inside could change everything.",
            choices: [
              { textAr: "\u0623\u0631\u064A\u062F \u0623\u0646 \u0623\u0631\u0627\u0647.", textEn: "I want to see it.", next: "key", trust: 8, setFlags: ["yusuf_secret"], action: "give_item:bunker_key:1" },
              { textAr: "\u0644\u0627 \u0623\u0631\u064A\u062F \u0627\u0644\u062A\u0648\u0631\u0637.", textEn: "I don't want to get involved.", next: null }
            ]
          },
          key: {
            id: "key",
            textAr: "\u062E\u0630 \u0627\u0644\u0645\u0641\u062A\u0627\u062D. \u0639\u0646\u062F \u0641\u0648\u0647\u0629 \u0627\u0644\u0628\u0631\u0643\u0627\u0646\u060C \u062E\u0644\u0641 \u0627\u0644\u0635\u062E\u0631\u0629 \u0627\u0644\u0645\u062A\u0634\u0642\u0642\u0629. \u0627\u062D\u0630\u0631 \u0645\u0646 \u0627\u0644\u0646\u0645\u0648\u0631 \u0644\u064A\u0644\u064B\u0627.",
            textEn: "Take the key. At the crater, behind the cracked rock. Beware the jaguars at night.",
            choices: [{ textAr: "\u0634\u0643\u0631\u064B\u0627.", textEn: "Thanks.", next: null }]
          },
          after_secret: {
            id: "after_secret",
            textAr: "\u0645\u0627 \u0632\u0644\u062A \u062D\u064A\u064B\u0627\u061F \u062C\u064A\u062F. \u0627\u0644\u0642\u0628\u0648 \u0641\u064A\u0647 \u0623\u0643\u062B\u0631 \u0645\u0646 \u0631\u0627\u062F\u064A\u0648... \u0627\u0628\u062D\u062B \u0639\u0646 \u0627\u0644\u0647\u0627\u062A\u0641 \u0627\u0644\u0641\u0636\u0627\u0626\u064A.",
            textEn: "Still alive? Good. The bunker holds more than a radio... look for the satellite phone.",
            choices: [{ textAr: "\u0633\u0623\u0641\u0639\u0644.", textEn: "I will.", next: null }]
          }
        }
      }
    }
  ];

  // src/core/Random.ts
  var Random = class _Random {
    state;
    constructor(seed) {
      this.state = typeof seed === "number" ? seed >>> 0 : _Random.hashString(seed);
    }
    static hashString(s) {
      let h2 = 2166136261 >>> 0;
      for (let i = 0; i < s.length; i++) {
        h2 ^= s.charCodeAt(i);
        h2 = Math.imul(h2, 16777619) >>> 0;
      }
      return h2;
    }
    /** رقم في [0,1) */
    next() {
      this.state = this.state + 1831565813 >>> 0;
      let t2 = this.state;
      t2 = Math.imul(t2 ^ t2 >>> 15, t2 | 1);
      t2 ^= t2 + Math.imul(t2 ^ t2 >>> 7, t2 | 61);
      return ((t2 ^ t2 >>> 14) >>> 0) / 4294967296;
    }
    range(min, max) {
      return min + (max - min) * this.next();
    }
    int(min, maxInclusive) {
      return Math.floor(this.range(min, maxInclusive + 1));
    }
    chance(p) {
      return this.next() < p;
    }
    pick(arr) {
      if (arr.length === 0) throw new Error("Random.pick: empty array");
      return arr[Math.floor(this.next() * arr.length)];
    }
    /** توزيع تقريبي طبيعي (مجموع ثلاثة أرقام) في [-1,1] */
    gaussian() {
      return (this.next() + this.next() + this.next()) / 1.5 - 1;
    }
  };

  // src/ai/BehaviorTree.ts
  var Condition = class {
    constructor(fn) {
      this.fn = fn;
    }
    fn;
    tick(ctx) {
      return this.fn(ctx) ? "success" : "failure";
    }
  };
  var Action = class {
    constructor(fn) {
      this.fn = fn;
    }
    fn;
    tick(ctx, dt) {
      return this.fn(ctx, dt);
    }
  };
  var Sequence = class {
    constructor(children) {
      this.children = children;
    }
    children;
    i = 0;
    tick(ctx, dt) {
      while (this.i < this.children.length) {
        const s = this.children[this.i].tick(ctx, dt);
        if (s === "running") return "running";
        if (s === "failure") {
          this.reset();
          return "failure";
        }
        this.i++;
      }
      this.reset();
      return "success";
    }
    reset() {
      this.i = 0;
      this.children.forEach((c) => c.reset?.());
    }
  };
  var Selector = class {
    constructor(children) {
      this.children = children;
    }
    children;
    lastRunning = -1;
    tick(ctx, dt) {
      for (let i = 0; i < this.children.length; i++) {
        const s = this.children[i].tick(ctx, dt);
        if (s !== "failure") {
          if (this.lastRunning !== i && this.lastRunning >= 0) this.children[this.lastRunning].reset?.();
          this.lastRunning = s === "running" ? i : -1;
          return s;
        }
      }
      this.lastRunning = -1;
      return "failure";
    }
    reset() {
      this.lastRunning = -1;
      this.children.forEach((c) => c.reset?.());
    }
  };
  var Cooldown = class {
    constructor(seconds, child) {
      this.seconds = seconds;
      this.child = child;
    }
    seconds;
    child;
    remaining = 0;
    tick(ctx, dt) {
      this.remaining = Math.max(0, this.remaining - dt);
      if (this.remaining > 0) return "failure";
      const s = this.child.tick(ctx, dt);
      if (s === "success") this.remaining = this.seconds;
      return s;
    }
    reset() {
      this.child.reset?.();
    }
  };
  var Timed = class {
    constructor(duration, fn) {
      this.duration = duration;
      this.fn = fn;
    }
    duration;
    fn;
    t = 0;
    tick(ctx, dt) {
      if (this.t === 0) this.t = this.duration();
      this.fn(ctx, dt);
      this.t -= dt;
      if (this.t <= 0) {
        this.t = 0;
        return "success";
      }
      return "running";
    }
    reset() {
      this.t = 0;
    }
  };

  // src/ai/Steering.ts
  var len = (v) => Math.hypot(v.x, v.z);
  var sub = (a, b) => ({ x: a.x - b.x, z: a.z - b.z });
  var norm = (v) => {
    const l = len(v);
    return l < 1e-6 ? { x: 0, z: 0 } : { x: v.x / l, z: v.z / l };
  };
  var scale = (v, s) => ({ x: v.x * s, z: v.z * s });
  function seek(from, to, speed) {
    return scale(norm(sub(to, from)), speed);
  }
  function flee(from, threat, speed) {
    return scale(norm(sub(from, threat)), speed);
  }
  function arrive(from, to, speed, slowRadius = 3) {
    const d = sub(to, from);
    const l = len(d);
    if (l < 0.2) return { x: 0, z: 0 };
    return scale(norm(d), speed * Math.min(1, l / slowRadius));
  }
  function wander(heading, angleNoise, maxTurn = 0.6) {
    return heading + angleNoise * maxTurn;
  }
  function avoidObstacles(pos, heading, walkable, lookAhead = 3) {
    const probe = (a) => walkable(pos.x + Math.sin(a) * lookAhead, pos.z + Math.cos(a) * lookAhead);
    if (probe(heading)) return heading;
    for (let k = 1; k <= 6; k++) {
      const a = k * Math.PI / 8;
      if (probe(heading + a)) return heading + a;
      if (probe(heading - a)) return heading - a;
    }
    return heading + Math.PI;
  }
  var headingOf = (v) => Math.atan2(v.x, v.z);
  function turnToward(current2, target, maxDelta) {
    let d = (target - current2) % (Math.PI * 2);
    if (d > Math.PI) d -= Math.PI * 2;
    if (d < -Math.PI) d += Math.PI * 2;
    return current2 + Math.max(-maxDelta, Math.min(maxDelta, d));
  }

  // src/ai/Perception.ts
  function perceive(self, heading, senses, target, wind, occluded = false) {
    const to = sub(target.pos, self);
    const d = len(to);
    if (!occluded && d <= senses.sight * target.visibility) {
      const ang = Math.atan2(to.x, to.z);
      let diff = Math.abs((ang - heading + Math.PI) % (Math.PI * 2) - Math.PI);
      if (diff > Math.PI) diff = Math.PI * 2 - diff;
      if (diff <= senses.fov) return { detected: "see", distance: d };
    }
    if (d <= senses.hearing * target.noise) return { detected: "hear", distance: d };
    const wl = len(wind);
    if (wl > 0.01 && d <= senses.smell) {
      const dirFromTargetToSelf = { x: -to.x / (d || 1), z: -to.z / (d || 1) };
      const alignment = (dirFromTargetToSelf.x * wind.x + dirFromTargetToSelf.z * wind.z) / wl;
      if (alignment > 0.5) return { detected: "smell", distance: d };
    }
    return { detected: "none", distance: d };
  }
  function playerNoise(state) {
    switch (state) {
      case "idle":
        return 0.05;
      case "crouch":
        return 0.12;
      case "walk":
        return 0.35;
      case "swim":
        return 0.4;
      case "jump":
        return 0.6;
      case "run":
        return 0.85;
      case "fight":
        return 1;
    }
  }

  // src/entities/Animal.ts
  var SPECIES = {
    deer: {
      id: "deer",
      nameAr: "\u063A\u0632\u0627\u0644",
      nameEn: "Deer",
      hp: 40,
      walk: 1.6,
      run: 8,
      domain: "land",
      temperament: "prey",
      nocturnal: false,
      senses: { sight: 40, fov: 1.6, hearing: 30, smell: 35 },
      damage: 0,
      attackRange: 0,
      attackCooldown: 0,
      alertRadius: 25,
      biomes: ["grass", "jungle"],
      drops: [{ id: "raw_meat", min: 2, max: 4, chance: 1 }, { id: "raw_hide", min: 1, max: 2, chance: 1 }, { id: "bone", min: 1, max: 3, chance: 0.8 }, { id: "animal_fat", min: 1, max: 1, chance: 0.5 }],
      spacing: 48,
      probability: 0.55
    },
    boar: {
      id: "boar",
      nameAr: "\u062E\u0646\u0632\u064A\u0631 \u0628\u0631\u064A",
      nameEn: "Wild Boar",
      hp: 70,
      walk: 1.8,
      run: 7,
      domain: "land",
      temperament: "neutral",
      nocturnal: false,
      senses: { sight: 25, fov: 1.2, hearing: 25, smell: 40 },
      damage: 14,
      attackRange: 1.8,
      attackCooldown: 1.6,
      alertRadius: 12,
      biomes: ["jungle", "grass"],
      drops: [{ id: "raw_meat", min: 3, max: 5, chance: 1 }, { id: "raw_hide", min: 1, max: 2, chance: 1 }, { id: "bone", min: 1, max: 2, chance: 0.7 }, { id: "animal_fat", min: 1, max: 2, chance: 0.7 }],
      spacing: 60,
      probability: 0.5
    },
    crab: {
      id: "crab",
      nameAr: "\u0633\u0644\u0637\u0639\u0648\u0646",
      nameEn: "Crab",
      hp: 6,
      walk: 0.8,
      run: 3.2,
      domain: "land",
      temperament: "prey",
      nocturnal: false,
      senses: { sight: 10, fov: 3, hearing: 8, smell: 0 },
      damage: 0,
      attackRange: 0,
      attackCooldown: 0,
      alertRadius: 5,
      biomes: ["beach"],
      drops: [{ id: "raw_crab", min: 1, max: 1, chance: 1 }, { id: "shell", min: 0, max: 1, chance: 0.4 }],
      spacing: 14,
      probability: 0.45
    },
    seagull: {
      id: "seagull",
      nameAr: "\u0646\u0648\u0631\u0633",
      nameEn: "Seagull",
      hp: 8,
      walk: 5,
      run: 9,
      domain: "air",
      temperament: "prey",
      nocturnal: false,
      senses: { sight: 60, fov: 2.6, hearing: 30, smell: 0 },
      damage: 0,
      attackRange: 0,
      attackCooldown: 0,
      alertRadius: 15,
      biomes: ["beach", "shallows"],
      drops: [{ id: "feather", min: 2, max: 5, chance: 1 }, { id: "raw_meat", min: 1, max: 1, chance: 0.8 }, { id: "egg", min: 0, max: 1, chance: 0.3 }],
      spacing: 40,
      probability: 0.6
    },
    shark: {
      id: "shark",
      nameAr: "\u0642\u0631\u0634",
      nameEn: "Shark",
      hp: 140,
      walk: 2.5,
      run: 9,
      domain: "water",
      temperament: "predator",
      nocturnal: false,
      senses: { sight: 45, fov: 1.5, hearing: 60, smell: 80 },
      damage: 28,
      attackRange: 2.6,
      attackCooldown: 1.4,
      alertRadius: 40,
      biomes: ["deepSea"],
      drops: [{ id: "raw_meat", min: 4, max: 7, chance: 1 }, { id: "animal_fat", min: 2, max: 3, chance: 1 }, { id: "bone", min: 2, max: 4, chance: 1 }],
      spacing: 120,
      probability: 0.8
    },
    snake: {
      id: "snake",
      nameAr: "\u0623\u0641\u0639\u0649",
      nameEn: "Snake",
      hp: 14,
      walk: 0.9,
      run: 4.5,
      domain: "land",
      temperament: "predator",
      nocturnal: false,
      senses: { sight: 8, fov: 2, hearing: 10, smell: 6 },
      damage: 9,
      attackRange: 1.4,
      attackCooldown: 1.2,
      alertRadius: 2.8,
      biomes: ["jungle", "rock", "grass"],
      drops: [{ id: "raw_meat", min: 1, max: 1, chance: 0.9 }, { id: "raw_hide", min: 0, max: 1, chance: 0.3 }],
      spacing: 40,
      probability: 0.4
    },
    jaguar: {
      id: "jaguar",
      nameAr: "\u0646\u0645\u0631",
      nameEn: "Jaguar",
      hp: 110,
      walk: 2.4,
      run: 11,
      domain: "land",
      temperament: "predator",
      nocturnal: true,
      senses: { sight: 50, fov: 1.4, hearing: 55, smell: 60 },
      damage: 24,
      attackRange: 2,
      attackCooldown: 1.2,
      alertRadius: 45,
      biomes: ["jungle", "rock"],
      drops: [{ id: "raw_meat", min: 3, max: 5, chance: 1 }, { id: "raw_hide", min: 2, max: 3, chance: 1 }, { id: "bone", min: 2, max: 3, chance: 1 }],
      spacing: 150,
      probability: 0.7
    }
  };
  var animalUid = 1;
  var Animal = class {
    constructor(species, x, z, rnd) {
      this.species = species;
      this.hp = species.hp;
      this.pos = { x, z };
      this.home = { x, z };
      this.heading = rnd.range(0, Math.PI * 2);
      this.wanderHeading = this.heading;
      this.brain = this.buildBrain();
    }
    species;
    id = animalUid++;
    hp;
    pos;
    y = 0;
    heading;
    vel = { x: 0, z: 0 };
    state = "idle";
    /** ثوانٍ منذ آخر إصابة من اللاعب (للمحايدين) */
    hurtTimer = 0;
    /** يعرف موقع التهديد؟ */
    threat = null;
    /** مدى انتباهه 0..1 */
    alert = 0;
    attackTimer = 0;
    /** مدة بقاء الجثة */
    corpseTime = 0;
    lastSeenTimer = 0;
    wanderHeading;
    brain;
    /** مركز المنزل: يعود إليه عند الملل */
    home;
    get alive() {
      return this.state !== "dead";
    }
    // ---------- أضرار ----------
    /** @returns الغنائم إن مات (مرة واحدة) */
    hurt(amount, from, rnd) {
      if (!this.alive) return null;
      this.hp -= amount;
      this.hurtTimer = 12;
      this.threat = { ...from };
      this.alert = 1;
      if (this.hp <= 0) {
        this.state = "dead";
        this.vel = { x: 0, z: 0 };
        this.corpseTime = 120;
        const drops = [];
        for (const d of this.species.drops) {
          if (rnd.next() > d.chance) continue;
          const n = d.min + Math.floor(rnd.next() * (d.max - d.min + 1));
          if (n > 0) drops.push({ id: d.id, count: n });
        }
        return drops;
      }
      return null;
    }
    // ---------- التحديث ----------
    update(dt, w) {
      if (!this.alive) {
        this.corpseTime -= dt;
        return;
      }
      this.hurtTimer = Math.max(0, this.hurtTimer - dt);
      this.attackTimer = Math.max(0, this.attackTimer - dt);
      this.sense(dt, w);
      this.brain.tick({ self: this, w, dt }, dt);
      this.integrate(dt, w);
    }
    sense(dt, w) {
      const p = perceive(this.pos, this.heading, this.species.senses, w.player.stimulus, w.wind);
      const reachable = this.species.domain !== "water" || w.player.inWater;
      if (p.detected !== "none" && w.player.alive && reachable) {
        this.threat = { ...w.player.pos };
        this.alert = Math.min(1, this.alert + dt * (p.detected === "see" ? 4 : 2));
        this.lastSeenTimer = 6;
      } else {
        this.lastSeenTimer = Math.max(0, this.lastSeenTimer - dt);
        if (this.lastSeenTimer === 0) {
          this.alert = Math.max(0, this.alert - dt * 0.25);
          if (this.alert === 0) this.threat = null;
        }
      }
    }
    distToThreat() {
      return this.threat ? len(sub(this.threat, this.pos)) : Infinity;
    }
    // ---------- الحركة ----------
    desired = { x: 0, z: 0 };
    setDesired(v) {
      this.desired = v;
    }
    canStand(x, z, w) {
      const d = this.species.domain;
      if (d === "air") return true;
      const h2 = w.height(x, z);
      if (d === "water") return h2 < -3.5;
      if (h2 < 0.45 || w.slope(x, z) > 0.65) return false;
      if (this.species.id === "crab" && h2 > 5) return false;
      return true;
    }
    integrate(dt, w) {
      const k = Math.min(1, dt * 5);
      this.vel.x += (this.desired.x - this.vel.x) * k;
      this.vel.z += (this.desired.z - this.vel.z) * k;
      const speed = len(this.vel);
      if (speed > 0.05) this.heading = turnToward(this.heading, headingOf(this.vel), dt * 6);
      let nx = this.pos.x + this.vel.x * dt;
      let nz = this.pos.z + this.vel.z * dt;
      if (!this.canStand(nx, nz, w)) {
        if (this.canStand(nx, this.pos.z, w)) nz = this.pos.z;
        else if (this.canStand(this.pos.x, nz, w)) nx = this.pos.x;
        else {
          nx = this.pos.x;
          nz = this.pos.z;
          this.vel.x = this.vel.z = 0;
          this.wanderHeading = avoidObstacles(this.pos, this.wanderHeading, (x, z) => this.canStand(x, z, w), 3);
        }
      }
      this.pos.x = nx;
      this.pos.z = nz;
      const ground = w.height(nx, nz);
      this.y = this.species.domain === "air" ? Math.max(ground, 0) + 8 : this.species.domain === "water" ? -1.2 : ground;
    }
    // ---------- أدمغة الأنواع ----------
    moveToward(target, speed) {
      this.setDesired(seek(this.pos, target, speed));
    }
    stop() {
      this.setDesired({ x: 0, z: 0 });
    }
    /** تجوال: يتغير الاتجاه كل فترة */
    wanderAction(speed) {
      let timer = 0;
      return new Action((c, dt) => {
        timer -= dt;
        if (timer <= 0) {
          timer = 2 + c.w.rnd.next() * 3;
          this.wanderHeading = wander(this.wanderHeading, c.w.rnd.next() * 2 - 1, 1.2);
          const d = len(sub(this.home, this.pos));
          if (d > 60) this.wanderHeading = headingOf(sub(this.home, this.pos));
        }
        this.wanderHeading = avoidObstacles(this.pos, this.wanderHeading, (x, z) => this.canStand(x, z, c.w), 3);
        this.setDesired({ x: Math.sin(this.wanderHeading) * speed, z: Math.cos(this.wanderHeading) * speed });
        this.state = "wander";
        return "running";
      });
    }
    grazeAction() {
      return new Timed(() => 3 + Math.random() * 3, () => {
        this.stop();
        this.state = "graze";
      });
    }
    fleeAction() {
      return new Action((c) => {
        if (!this.threat) return "failure";
        const away = flee(this.pos, this.threat, this.species.run);
        const h2 = avoidObstacles(this.pos, headingOf(away), (x, z) => this.canStand(x, z, c.w), 4);
        this.setDesired({ x: Math.sin(h2) * this.species.run, z: Math.cos(h2) * this.species.run });
        this.state = "flee";
        return "running";
      });
    }
    chaseAndAttack() {
      const attack = new Cooldown(
        this.species.attackCooldown,
        new Action((c) => {
          this.stop();
          this.state = "attack";
          if (c.w.player.alive) c.w.onAttackPlayer(this.species.damage, this);
          return "success";
        })
      );
      return new Selector([
        new Sequence([new Condition((c) => this.distToPlayer(c.w) <= this.species.attackRange), attack]),
        new Action((c) => {
          if (!this.threat) return "failure";
          const target = this.distToPlayer(c.w) < 60 ? c.w.player.pos : this.threat;
          this.moveToward(target, this.species.run);
          this.state = "chase";
          return "running";
        })
      ]);
    }
    distToPlayer(w) {
      return len(sub(w.player.pos, this.pos));
    }
    isNight(w) {
      return w.hour < 5.5 || w.hour >= 19;
    }
    buildBrain() {
      const sp2 = this.species;
      const sleep = new Sequence([
        new Condition((c) => (sp2.nocturnal ? !this.isNight(c.w) : this.isNight(c.w)) && this.alert < 0.3),
        new Action((c) => {
          if (len(sub(this.home, this.pos)) > 4) this.moveToward(this.home, sp2.walk);
          else this.stop();
          this.state = "sleep";
          void c;
          return "running";
        })
      ]);
      const idleWander = new Selector([
        new Sequence([new Condition(() => Math.random() < 4e-3), this.grazeAction()]),
        this.wanderAction(sp2.walk)
      ]);
      switch (sp2.id) {
        case "deer":
        case "crab":
        case "seagull":
          return new Selector([
            new Sequence([new Condition(() => this.threat !== null && this.distToThreat() < sp2.alertRadius && this.alert > 0.4), this.fleeAction()]),
            ...sp2.id === "deer" ? [sleep] : [],
            idleWander
          ]);
        case "boar":
          return new Selector([
            // يهرب إن كاد يموت
            new Sequence([new Condition(() => this.hp < sp2.hp * 0.25 && this.threat !== null), this.fleeAction()]),
            // محايد: يهاجم فقط إذا أُصيب مؤخرًا أو اقتُرب منه جدًا
            new Sequence([new Condition((c) => this.hurtTimer > 0 && this.distToPlayer(c.w) < 30 || this.distToPlayer(c.w) < 4 && this.alert > 0.6), this.chaseAndAttack()]),
            sleep,
            idleWander
          ]);
        case "snake":
          return new Selector([
            // كمين: يهاجم فقط ضمن نصف القطر القصير
            new Sequence([new Condition((c) => this.distToPlayer(c.w) <= sp2.alertRadius && c.w.player.alive), this.chaseAndAttack()]),
            new Sequence([new Condition(() => this.hurtTimer > 0 && this.threat !== null), this.fleeAction()]),
            new Action(() => {
              this.stop();
              this.state = "idle";
              return "running";
            })
          ]);
        case "jaguar":
          return new Selector([
            new Sequence([new Condition(() => this.hp < sp2.hp * 0.2 && this.threat !== null), this.fleeAction()]),
            // نهارًا لا يهاجم إلا إن استُفز
            new Sequence([new Condition((c) => this.threat !== null && c.w.player.alive && (this.isNight(c.w) || this.hurtTimer > 0) && this.alert > 0.35), this.chaseAndAttack()]),
            sleep,
            new Action((c) => {
              const w = this.wanderAction(sp2.walk);
              this.state = "patrol";
              return w.tick(c, c.dt);
            })
          ]);
        case "shark":
          return new Selector([
            new Sequence([new Condition((c) => this.threat !== null && c.w.player.inWater && c.w.player.alive && this.alert > 0.3), this.chaseAndAttack()]),
            new Action((c) => {
              const w = this.wanderAction(sp2.walk);
              const r = w.tick(c, c.dt);
              this.state = "patrol";
              return r;
            })
          ]);
      }
    }
  };

  // src/entities/AnimalManager.ts
  var ACTIVE_RADIUS = 130;
  var DESPAWN_NIGHT_RADIUS = 220;
  var AnimalManager = class {
    animals = [];
    onKilled = null;
    nightSpawnTimer = 0;
    populate(sampler, seed, half, keepClear = []) {
      let n = 0;
      for (const sp2 of Object.values(SPECIES)) {
        const rnd = new Random(`${seed}:animal:${sp2.id}`);
        const cells = Math.floor(half * 2 / sp2.spacing);
        for (let j = 0; j < cells; j++) {
          for (let i = 0; i < cells; i++) {
            const jx = rnd.next();
            const jz = rnd.next();
            const accept = rnd.next();
            if (accept > sp2.probability) continue;
            const x = -half + (i + jx) * sp2.spacing;
            const z = -half + (j + jz) * sp2.spacing;
            if (keepClear.some((c) => Math.hypot(c.x - x, c.z - z) < c.r)) continue;
            if (!sp2.biomes.includes(sampler.biomeAt(x, z))) continue;
            if (sp2.domain === "land" && sampler.slope(x, z) > 0.6) continue;
            this.animals.push(new Animal(sp2, x, z, rnd));
            n++;
          }
        }
      }
      return n;
    }
    count(id, alive = true) {
      return this.animals.filter((a) => a.species.id === id && (!alive || a.alive)).length;
    }
    /** @param w عالم الذكاء الاصطناعي الحالي */
    update(dt, w) {
      const p = w.player.pos;
      for (const a of this.animals) {
        const d = Math.hypot(a.pos.x - p.x, a.pos.z - p.z);
        if (d <= ACTIVE_RADIUS || !a.alive) a.update(dt, w);
      }
      for (let i = this.animals.length - 1; i >= 0; i--) {
        const a = this.animals[i];
        if (!a.alive && a.corpseTime <= 0) this.animals.splice(i, 1);
      }
      this.nightSpawnTimer -= dt;
      if (this.nightSpawnTimer <= 0) {
        this.nightSpawnTimer = 10;
        this.manageNightPredators(w);
      }
    }
    /** نمور تظهر ليلًا قرب اللاعب في الغابة/الصخور وتختفي نهارًا حين تبتعد */
    manageNightPredators(w) {
      const night = w.hour < 5.5 || w.hour >= 19;
      const p = w.player.pos;
      const sp2 = SPECIES.jaguar;
      if (night && w.player.alive) {
        const near = this.animals.filter((a) => a.species.id === "jaguar" && a.alive && Math.hypot(a.pos.x - p.x, a.pos.z - p.z) < 150).length;
        const biome = w.biomeAt(p.x, p.z);
        if (near < 2 && sp2.biomes.includes(biome)) {
          const ang = w.rnd.range(0, Math.PI * 2);
          const dist = w.rnd.range(70, 100);
          const x = p.x + Math.cos(ang) * dist;
          const z = p.z + Math.sin(ang) * dist;
          if (sp2.biomes.includes(w.biomeAt(x, z)) && w.slope(x, z) < 0.6) this.animals.push(new Animal(sp2, x, z, w.rnd));
        }
      } else {
        for (let i = this.animals.length - 1; i >= 0; i--) {
          const a = this.animals[i];
          if (a.species.id === "jaguar" && a.alive && Math.hypot(a.pos.x - p.x, a.pos.z - p.z) > DESPAWN_NIGHT_RADIUS * 0.5 && a.state === "sleep") this.animals.splice(i, 1);
        }
      }
    }
    /** ضربة من اللاعب على أقرب حيوان داخل المدى والمخروط */
    playerAttack(w, origin, yaw, damage, reach = 2.6) {
      let best = null;
      let bd = reach;
      const fx = -Math.sin(yaw);
      const fz = -Math.cos(yaw);
      for (const a of this.animals) {
        if (!a.alive) continue;
        const dx = a.pos.x - origin.x;
        const dz = a.pos.z - origin.z;
        const d = Math.hypot(dx, dz);
        if (d > bd) continue;
        if ((dx * fx + dz * fz) / (d || 1) < 0.3 && d > 1) continue;
        bd = d;
        best = a;
      }
      if (!best) return { hit: null, killed: false };
      const drops = best.hurt(damage, origin, w.rnd);
      if (drops) this.onKilled?.(best, drops);
      return { hit: best, killed: drops !== null };
    }
  };

  // src/ai/Schedule.ts
  var Schedule = class {
    constructor(entries, fallback = { from: 0, to: 24, activity: "idle", place: "camp" }) {
      this.entries = entries;
      this.fallback = fallback;
    }
    entries;
    fallback;
    at(hour) {
      const h2 = (hour % 24 + 24) % 24;
      for (const e of this.entries) {
        const inside = e.from <= e.to ? h2 >= e.from && h2 < e.to : h2 >= e.from || h2 < e.to;
        if (inside) return e;
      }
      return this.fallback;
    }
  };

  // src/core/math.ts
  var clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  // src/entities/NPC.ts
  function trustLevel(t2) {
    if (t2 < -30) return "hostile";
    if (t2 < 0) return "wary";
    if (t2 < 30) return "neutral";
    if (t2 < 70) return "friendly";
    return "trusted";
  }
  var NPC = class {
    constructor(def, start) {
      this.def = def;
      this.pos = { ...start };
      this.target = { ...start };
      this.schedule = new Schedule(def.schedule);
    }
    def;
    pos;
    trust = 0;
    flags = /* @__PURE__ */ new Set();
    activity = "idle";
    schedule;
    target;
    giftsToday = 0;
    lastDay = -1;
    get level() {
      return trustLevel(this.trust);
    }
    adjustTrust(delta) {
      this.trust = clamp(this.trust + delta, -100, 100);
    }
    /** هدية: الثقة تزداد بحسب تفضيله، وبحد أقصى 3 هدايا مؤثرة في اليوم */
    gift(itemId, day) {
      if (day !== this.lastDay) {
        this.lastDay = day;
        this.giftsToday = 0;
      }
      if (this.giftsToday >= 3) return { accepted: false, delta: 0 };
      const like = this.def.likes[itemId] ?? 1;
      this.giftsToday++;
      this.adjustTrust(like);
      return { accepted: true, delta: like };
    }
    /** @param places أماكن العالم المسمّاة (camp, beach, forest, ...) */
    update(dt, hour, places) {
      const entry = this.schedule.at(hour);
      this.activity = entry.activity;
      this.target = places[entry.place] ?? places.camp ?? this.pos;
      const speed = entry.activity === "sleep" ? 0 : 1.4;
      const v = arrive(this.pos, this.target, speed, 4);
      this.pos.x += v.x * dt;
      this.pos.z += v.z * dt;
    }
    get atTarget() {
      return len(sub(this.target, this.pos)) < 1.5;
    }
    toJSON() {
      return { id: this.def.id, trust: this.trust, flags: [...this.flags], pos: this.pos };
    }
    load(d) {
      this.trust = d.trust;
      this.flags.clear();
      d.flags.forEach((f) => this.flags.add(f));
      this.pos = { ...d.pos };
    }
  };

  // src/world/ResourceNode.ts
  var D = (id, min, max, chance = 1) => ({ id, min, max, chance });
  var NODE_DEFS = {
    palm: {
      kind: "palm",
      action: "chop",
      minPower: 0.9,
      hp: 60,
      hitDrops: [D("palm_leaf", 1, 1, 0.3), D("coconut", 1, 1, 0.15)],
      finalDrops: [D("wood_log", 2, 3), D("palm_leaf", 3, 5), D("coconut", 1, 3, 0.7), D("plant_fiber", 2, 4)],
      respawnHours: 240,
      radius: 0.35,
      height: 9,
      solid: true
    },
    jungleTree: {
      kind: "jungleTree",
      action: "chop",
      minPower: 0.9,
      hp: 90,
      hitDrops: [D("stick", 1, 2, 0.4), D("bark", 1, 1, 0.25)],
      finalDrops: [D("wood_log", 3, 5), D("stick", 3, 6), D("resin", 1, 2, 0.4), D("vine", 1, 3, 0.5)],
      respawnHours: 360,
      radius: 0.5,
      height: 12,
      solid: true
    },
    boulder: {
      kind: "boulder",
      action: "mine",
      minPower: 0.9,
      hp: 70,
      hitDrops: [D("stone", 1, 2, 0.7), D("flint", 1, 1, 0.12)],
      finalDrops: [D("stone", 3, 6), D("flint", 1, 2, 0.5), D("sand", 0, 2, 0.3)],
      respawnHours: 480,
      radius: 0.9,
      height: 1.4,
      solid: true
    },
    ironRock: {
      kind: "ironRock",
      action: "mine",
      minPower: 1,
      hp: 110,
      hitDrops: [D("stone", 1, 1, 0.4), D("iron_ore", 1, 1, 0.45)],
      finalDrops: [D("iron_ore", 2, 4), D("stone", 2, 4), D("scrap_metal", 0, 1, 0.2)],
      respawnHours: 720,
      radius: 1,
      height: 1.6,
      solid: true
    },
    copperRock: {
      kind: "copperRock",
      action: "mine",
      minPower: 1,
      hp: 100,
      hitDrops: [D("stone", 1, 1, 0.4), D("copper_ore", 1, 1, 0.45)],
      finalDrops: [D("copper_ore", 2, 3), D("stone", 2, 3), D("sulfur", 0, 1, 0.15)],
      respawnHours: 720,
      radius: 1,
      height: 1.5,
      solid: true
    },
    berryBush: {
      kind: "berryBush",
      action: "hand",
      minPower: 0,
      hp: 1,
      hitDrops: [],
      finalDrops: [D("berries", 2, 5), D("stick", 0, 1, 0.3)],
      respawnHours: 48,
      radius: 0.6,
      height: 1,
      solid: false
    },
    fiberPlant: {
      kind: "fiberPlant",
      action: "hand",
      minPower: 0,
      hp: 1,
      hitDrops: [],
      finalDrops: [D("plant_fiber", 2, 4), D("medicinal_herb", 0, 1, 0.2), D("seeds", 0, 1, 0.15)],
      respawnHours: 36,
      radius: 0.5,
      height: 0.8,
      solid: false
    },
    bamboo: {
      kind: "bamboo",
      action: "chop",
      minPower: 0.9,
      hp: 40,
      hitDrops: [],
      finalDrops: [D("bamboo", 2, 4), D("vine", 0, 2, 0.4)],
      respawnHours: 200,
      radius: 0.7,
      height: 6,
      solid: true
    },
    mushroomPatch: {
      kind: "mushroomPatch",
      action: "hand",
      minPower: 0,
      hp: 1,
      hitDrops: [],
      finalDrops: [D("mushroom", 1, 3), D("edible_roots", 0, 1, 0.2)],
      respawnHours: 72,
      radius: 0.4,
      height: 0.3,
      solid: false
    },
    clayBank: {
      kind: "clayBank",
      action: "dig",
      minPower: 0.9,
      hp: 30,
      hitDrops: [D("clay", 1, 2, 0.8)],
      finalDrops: [D("clay", 3, 6), D("sand", 1, 3)],
      respawnHours: 300,
      radius: 1.2,
      height: 0.6,
      solid: false
    }
  };
  var BARE_HANDS = { chop: 0, mine: 0, dig: 0, damage: 4 };
  function toolPowerOf(effects) {
    if (!effects) return BARE_HANDS;
    const n = (k) => typeof effects[k] === "number" ? effects[k] : 0;
    return { chop: n("chop"), mine: n("mine"), dig: n("dig"), damage: Math.max(4, n("damage")) };
  }
  function applyHit(node, tool, rnd, gatherBonus = 0) {
    if (!node.alive) return { ok: false, reason: "dead", damage: 0, destroyed: false, drops: [] };
    const def = NODE_DEFS[node.kind];
    const power = def.action === "chop" ? tool.chop : def.action === "mine" ? tool.mine : def.action === "dig" ? tool.dig : 1;
    if (power < def.minPower) return { ok: false, reason: "wrongTool", damage: 0, destroyed: false, drops: [] };
    const damage = def.action === "hand" ? def.hp : tool.damage * Math.max(1, power) * (0.85 + rnd.next() * 0.3);
    node.hp -= damage;
    const destroyed = node.hp <= 0;
    if (destroyed) node.alive = false;
    const drops = [];
    const roll = (list) => {
      for (const d of list) {
        if (rnd.next() >= d.chance) continue;
        let n = d.min + Math.floor(rnd.next() * (d.max - d.min + 1));
        const extra = n * gatherBonus;
        n += Math.floor(extra) + (rnd.next() < extra - Math.floor(extra) ? 1 : 0);
        if (n > 0) drops.push({ id: d.id, count: n });
      }
    };
    if (!destroyed) roll(def.hitDrops);
    else roll(def.finalDrops);
    return { ok: true, damage, destroyed, drops: mergeDrops(drops) };
  }
  function mergeDrops(list) {
    const m = /* @__PURE__ */ new Map();
    for (const d of list) m.set(d.id, (m.get(d.id) ?? 0) + d.count);
    return [...m].map(([id, count]) => ({ id, count }));
  }

  // src/gameplay/Gatherer.ts
  var REACH = 3.2;
  var SWING_COOLDOWN = 0.6;
  var SWING_STAMINA = 4;
  var AIM_ASSIST_DROPS = [0, 0.3, 0.6, 0.9];
  var Gatherer = class {
    constructor(field, ground, inv, skills, recipes, rnd) {
      this.field = field;
      this.ground = ground;
      this.inv = inv;
      this.skills = skills;
      this.recipes = recipes;
      this.rnd = rnd;
    }
    field;
    ground;
    inv;
    skills;
    recipes;
    rnd;
    cooldown = 0;
    update(dt) {
      this.cooldown = Math.max(0, this.cooldown - dt);
    }
    get ready() {
      return this.cooldown <= 0;
    }
    /**
     * @param stamina النفَس الحالي (يمنع الضرب إن نفد)
     * @param feet موضع القدمين لإسقاط الفائض على الأرض
     */
    swing(origin, dir, stamina, feet) {
      if (this.cooldown > 0) return { kind: "cooldown" };
      if (stamina < SWING_STAMINA) return { kind: "tired" };
      this.cooldown = SWING_COOLDOWN;
      let hit = null;
      for (const drop of AIM_ASSIST_DROPS) {
        hit = this.field.raycast(origin.x, origin.y, origin.z, dir.x, dir.y - drop, dir.z, REACH);
        if (hit) break;
      }
      if (!hit) return { kind: "miss", staminaCost: SWING_STAMINA * 0.5 };
      const held = this.inv.held;
      const tool = held ? toolPowerOf(ItemDB.get(held.defId).effects) : BARE_HANDS;
      const usable = held && held.durability !== 0 ? tool : BARE_HANDS;
      const gloves = this.inv.equipment.gatherBonus;
      const bonus = gloves + this.skills.bonus("survival", 0.04);
      const res = this.field.hit(hit.node.id, usable, this.rnd, bonus);
      if (!res.ok) {
        return { kind: "wrongTool", node: hit.node, needs: NODE_DEFS[hit.node.kind].action, staminaCost: SWING_STAMINA * 0.5 };
      }
      let toolBroke = false;
      if (held && NODE_DEFS[hit.node.kind].action !== "hand" && usable !== BARE_HANDS) {
        toolBroke = this.inv.damage(held.uid, 1);
      }
      let dropped = 0;
      const newRecipes = [];
      for (const d of res.drops) {
        const left = this.inv.add(d.id, d.count);
        if (left < d.count) for (const r of this.recipes.noteItem(d.id)) newRecipes.push(r.id);
        if (left > 0) {
          this.ground.dropNew(d.id, left, feet.x, feet.y, feet.z);
          dropped += left;
        }
      }
      this.skills.addXp("survival", res.destroyed ? 3 : 1);
      return { kind: res.destroyed ? "destroyed" : "hit", node: hit.node, drops: res.drops, dropped, toolBroke, newRecipes, staminaCost: SWING_STAMINA };
    }
  };

  // src/inventory/Container.ts
  var Container = class _Container {
    constructor(id, defId) {
      this.id = id;
      this.defId = defId;
      const d = ItemDB.get(defId);
      const w = Number(d.effects.gridW ?? 4);
      const h2 = Number(d.effects.gridH ?? 4);
      this.grid = new Grid(w, h2);
      this.preserve = Number(d.effects.preserve ?? 1);
    }
    id;
    defId;
    grid;
    /** مضاعِف إبطاء الفساد (1 = عادي) */
    preserve;
    toJSON() {
      return { id: this.id, defId: this.defId, grid: this.grid.toJSON() };
    }
    static fromJSON(d) {
      const c = new _Container(d.id, d.defId);
      const loaded = Grid.fromJSON(d.grid);
      for (const e of loaded.list()) c.grid.place(e.stack, e.x, e.y, e.rotated);
      return c;
    }
    /** يقدّم الفساد داخل الحاوية */
    updateSpoil(dtHours) {
      for (const e of this.grid.list()) {
        const def = ItemDB.get(e.stack.defId);
        if (def.spoilTime > 0) e.stack.spoil += dtHours / this.preserve;
      }
      _Container.convertRotten(this.grid);
    }
    /** يحوّل الأطعمة التي تجاوزت زمن فسادها إلى "طعام فاسد" */
    static convertRotten(grid) {
      for (const e of grid.list()) {
        const def = ItemDB.get(e.stack.defId);
        if (def.spoilTime > 0 && def.type === "food" && e.stack.spoil >= def.spoilTime && def.id !== "rotten_food") {
          e.stack.defId = "rotten_food";
          e.stack.spoil = 0;
          e.stack.count = Math.min(e.stack.count, ItemDB.get("rotten_food").stack);
        }
      }
    }
  };

  // src/inventory/Equipment.ts
  var Equipment = class {
    slots = /* @__PURE__ */ new Map();
    constructor() {
      for (const s of EQUIP_SLOTS) this.slots.set(s, null);
    }
    get(slot) {
      return this.slots.get(slot) ?? null;
    }
    set(slot, stack) {
      this.slots.set(slot, stack);
    }
    /** الخانة التي يناسبها العنصر أو null إن لم يكن قابلًا للتجهيز */
    static slotFor(defId) {
      const d = ItemDB.get(defId);
      if (d.type === "clothing" || d.type === "backpack") {
        const s = d.effects.slot;
        return typeof s === "string" && EQUIP_SLOTS.includes(s) ? s : null;
      }
      if (d.type === "tool" && (d.effects.light || d.effects.compass || d.effects.zoom)) return "tool";
      return null;
    }
    list() {
      const out = [];
      for (const [slot, stack] of this.slots) if (stack) out.push({ slot, stack });
      return out;
    }
    sum(key) {
      let total = 0;
      for (const { stack } of this.list()) {
        const v = ItemDB.get(stack.defId).effects[key];
        if (typeof v === "number" && stack.durability !== 0) total += v;
      }
      return total;
    }
    /** عزل حراري إجمالي (يقلل فقدان حرارة الجسم) */
    get warmth() {
      return this.sum("warmth");
    }
    get defense() {
      return this.sum("defense");
    }
    get sunProtection() {
      return Math.min(1, this.sum("sunProtect"));
    }
    get rainProof() {
      return this.sum("rainProof") > 0;
    }
    get gatherBonus() {
      return this.sum("gatherBonus");
    }
    get lightLevel() {
      return this.sum("light");
    }
  };

  // src/inventory/Hotbar.ts
  var HOTBAR_SIZE = 8;
  var Hotbar = class {
    slots = new Array(HOTBAR_SIZE).fill(null);
    selected = 0;
    select(i) {
      this.selected = (i % HOTBAR_SIZE + HOTBAR_SIZE) % HOTBAR_SIZE;
    }
    /** عجلة الماوس: dir = +1 أو -1 */
    scroll(dir) {
      this.select(this.selected + (dir > 0 ? 1 : -1));
    }
    assign(slot, uid) {
      if (slot < 0 || slot >= HOTBAR_SIZE) return;
      if (uid !== null) {
        for (let i = 0; i < HOTBAR_SIZE; i++) if (this.slots[i] === uid) this.slots[i] = null;
      }
      this.slots[slot] = uid;
    }
    clearUid(uid) {
      for (let i = 0; i < HOTBAR_SIZE; i++) if (this.slots[i] === uid) this.slots[i] = null;
    }
    get heldUid() {
      return this.slots[this.selected];
    }
    /** أول خانة فارغة أو -1 */
    firstFree() {
      return this.slots.indexOf(null);
    }
  };

  // src/inventory/Weight.ts
  function loadEffect(weight, maxWeight) {
    const ratio = maxWeight > 0 ? weight / maxWeight : 0;
    const over = Math.max(0, ratio - 1);
    return {
      ratio,
      // حتى 100% لا عقوبة، بعدها تنخفض السرعة تدريجيًا حتى 30%
      speedMultiplier: ratio <= 1 ? 1 - Math.max(0, ratio - 0.8) * 0.25 : Math.max(0.3, 0.95 - over * 1.2),
      staminaDrainMultiplier: 1 + over * 3,
      overloaded: ratio > 1,
      immobilized: ratio > 1.6
    };
  }

  // src/inventory/Inventory.ts
  var EQUIP_SLOTS_ALL = EQUIP_SLOTS;
  var POCKET_GRID = { w: 4, h: 2, maxWeight: 20 };
  var Inventory = class {
    grid = new Grid(POCKET_GRID.w, POCKET_GRID.h);
    equipment = new Equipment();
    hotbar = new Hotbar();
    onChange = null;
    get maxWeight() {
      const bp = this.equipment.get("backpack");
      return bp ? Number(ItemDB.get(bp.defId).effects.maxWeight ?? POCKET_GRID.maxWeight) : POCKET_GRID.maxWeight;
    }
    get totalWeight() {
      let w = 0;
      for (const e of this.grid.list()) w += ItemDB.get(e.stack.defId).weight * e.stack.count;
      for (const { stack } of this.equipment.list()) w += ItemDB.get(stack.defId).weight * stack.count;
      return Math.round(w * 100) / 100;
    }
    get burden() {
      return loadEffect(this.totalWeight, this.maxWeight);
    }
    changed() {
      this.onChange?.();
    }
    // ---------- إضافة / إزالة ----------
    /** @returns العدد الذي لم يتسع (0 = أُضيف الكل) */
    add(defId, count = 1, opts = {}) {
      const left = this.grid.add(defId, count, opts);
      if (left < count) this.changed();
      return left;
    }
    addStack(stack) {
      const left = this.grid.addStack(stack);
      if (left === 0) this.changed();
      return left;
    }
    count(defId) {
      return this.grid.count(defId);
    }
    has(defId, n = 1) {
      return this.count(defId) >= n;
    }
    /**
     * يزيل عددًا من عنصر. يبدأ من الأكثر تلفًا/فسادًا (الأقل قيمة) فيبقى الأفضل.
     * @returns العدد الذي أُزيل فعلًا
     */
    remove(defId, count = 1) {
      const entries = this.grid.list().filter((e) => e.stack.defId === defId).sort((a, b) => a.stack.durability - b.stack.durability || b.stack.spoil - a.stack.spoil);
      let left = count;
      for (const e of entries) {
        if (left <= 0) break;
        const take = Math.min(left, e.stack.count);
        e.stack.count -= take;
        left -= take;
        if (e.stack.count <= 0) this.removeEntry(e.stack.uid);
      }
      if (left < count) this.changed();
      return count - left;
    }
    removeEntry(uid) {
      this.grid.remove(uid);
      this.hotbar.clearUid(uid);
    }
    /** يزيل مكدّسًا كاملًا أو جزءًا منه ويعيد المزال (للرمي/النقل) */
    take(uid, count) {
      const e = this.grid.get(uid);
      if (!e) return null;
      const n = count === void 0 ? e.stack.count : Math.min(count, e.stack.count);
      if (n >= e.stack.count) {
        this.removeEntry(uid);
        this.changed();
        return e.stack;
      }
      e.stack.count -= n;
      this.changed();
      return { ...e.stack, uid: ItemDB.create(e.stack.defId, 1).uid, count: n };
    }
    /** تقسيم مكدّس إلى مكدّسين (الجزء الجديد يوضع في أول مكان متاح) */
    split(uid, amount) {
      const e = this.grid.get(uid);
      if (!e || amount <= 0 || amount >= e.stack.count) return false;
      const def = ItemDB.get(e.stack.defId);
      const spot = this.grid.findSpot(def);
      if (!spot) return false;
      const part = ItemDB.create(e.stack.defId, amount, { durability: e.stack.durability, spoil: e.stack.spoil });
      e.stack.count -= amount;
      this.grid.place(part, spot.x, spot.y, spot.rotated);
      this.changed();
      return true;
    }
    /** ترتيب تلقائي: الأكبر أولًا ثم حسب النوع. إن فشل التعبئة يُستعاد الترتيب الأصلي */
    sort() {
      const before = this.grid.list().map((e) => ({ ...e }));
      const stacks = before.map((e) => e.stack);
      stacks.sort((a, b) => {
        const da = ItemDB.get(a.defId);
        const db = ItemDB.get(b.defId);
        return db.size[0] * db.size[1] - da.size[0] * da.size[1] || da.type.localeCompare(db.type) || da.id.localeCompare(db.id);
      });
      this.grid.clear();
      let ok = true;
      for (const s of stacks) {
        if (this.grid.addStack(s) > 0) {
          ok = false;
          break;
        }
      }
      if (!ok) {
        this.grid.clear();
        for (const e of before) this.grid.place(e.stack, e.x, e.y, e.rotated);
        return false;
      }
      this.changed();
      return true;
    }
    // ---------- تجهيز ----------
    /** يجهّز عنصرًا من الحقيبة. يبدّل مع القطعة المجهزة سابقًا. يفشل إن لم تتسع الحقيبة بعد تبديل حقيبة الظهر */
    equip(uid) {
      const e = this.grid.get(uid);
      if (!e) return { ok: false, reason: "notFound" };
      const slot = Equipment.slotFor(e.stack.defId);
      if (!slot) return { ok: false, reason: "notEquippable" };
      const previous = this.equipment.get(slot);
      if (slot === "backpack") return this.swapBackpack(uid, e.stack, previous);
      this.grid.remove(uid);
      this.hotbar.clearUid(uid);
      if (previous && this.grid.addStack(previous) > 0) {
        this.grid.place(e.stack, e.x, e.y, e.rotated);
        return { ok: false, reason: "noSpace" };
      }
      this.equipment.set(slot, e.stack);
      this.changed();
      return { ok: true };
    }
    swapBackpack(uid, next, previous) {
      const nd = ItemDB.get(next.defId);
      const newW = Number(nd.effects.gridW);
      const newH = Number(nd.effects.gridH);
      const entry = this.grid.get(uid);
      if (!entry) return { ok: false, reason: "notFound" };
      const oldW = this.grid.width;
      const oldH = this.grid.height;
      this.grid.remove(uid);
      if (!this.grid.resize(newW, newH)) {
        this.grid.place(entry.stack, entry.x, entry.y, entry.rotated);
        return { ok: false, reason: "itemsWouldNotFit" };
      }
      if (previous && this.grid.addStack(previous) > 0) {
        this.grid.resize(oldW, oldH);
        this.grid.place(entry.stack, entry.x, entry.y, entry.rotated);
        return { ok: false, reason: "noSpace" };
      }
      this.equipment.set("backpack", next);
      this.hotbar.clearUid(uid);
      this.changed();
      return { ok: true };
    }
    /** يخلع قطعة ويعيدها للحقيبة */
    unequip(slot) {
      const s = this.equipment.get(slot);
      if (!s) return { ok: false, reason: "empty" };
      if (slot === "backpack") {
        if (!this.grid.resize(POCKET_GRID.w, POCKET_GRID.h)) return { ok: false, reason: "itemsWouldNotFit" };
        this.equipment.set("backpack", null);
        if (this.grid.addStack(s) > 0) {
          const bd = ItemDB.get(s.defId);
          this.grid.resize(Number(bd.effects.gridW), Number(bd.effects.gridH));
          this.equipment.set("backpack", s);
          return { ok: false, reason: "noSpace" };
        }
        this.changed();
        return { ok: true };
      }
      if (this.grid.addStack(s) > 0) return { ok: false, reason: "noSpace" };
      this.equipment.set(slot, null);
      this.changed();
      return { ok: true };
    }
    // ---------- استخدام ----------
    /** يستهلك وحدة من طعام/شراب/دواء ويعيد تأثيرها مُعدَّلًا بحالة الفساد */
    use(uid) {
      const e = this.grid.get(uid);
      if (!e) return { ok: false, reason: "notFound", effects: {}, state: "none" };
      const def = ItemDB.get(e.stack.defId);
      if (def.type !== "food" && def.type !== "drink" && def.type !== "medicine") {
        return { ok: false, reason: "notUsable", effects: {}, state: "none" };
      }
      const state = spoilState(def, e.stack);
      const effects = { ...def.effects };
      if (state === "stale") {
        for (const k of ["hunger", "thirst", "health", "energy"]) {
          if (typeof effects[k] === "number") effects[k] = Math.round(effects[k] * 0.6);
        }
        effects.sick = Math.min(1, Number(effects.sick ?? 0) + 0.25);
      } else if (state === "rotten") {
        effects.hunger = 1;
        effects.sick = 0.95;
      }
      e.stack.count -= 1;
      if (e.stack.count <= 0) this.removeEntry(uid);
      this.changed();
      return { ok: true, defId: def.id, effects, state };
    }
    // ---------- متانة ----------
    /** ينقص متانة عنصر. @returns true إذا تحطّم وأُزيل */
    damage(uid, amount) {
      const e = this.grid.get(uid);
      if (!e) return false;
      const def = ItemDB.get(e.stack.defId);
      if (def.durability <= 0) return false;
      e.stack.durability = Math.max(0, e.stack.durability - amount);
      if (e.stack.durability === 0) {
        this.removeEntry(uid);
        this.changed();
        return true;
      }
      this.changed();
      return false;
    }
    /** إصلاح: يعيد المتانة جزئيًا دون تجاوز الحد الأقصى. @returns المضاف فعليًا */
    repair(uid, amount) {
      const e = this.grid.get(uid);
      if (!e) return 0;
      const max = ItemDB.get(e.stack.defId).durability;
      if (max <= 0) return 0;
      const before = e.stack.durability;
      e.stack.durability = Math.min(max, before + amount);
      this.changed();
      return e.stack.durability - before;
    }
    /** ينقص متانة القطعة المجهزة في خانة (مثلًا الحذاء أثناء المشي) */
    damageEquipped(slot, amount) {
      const s = this.equipment.get(slot);
      if (!s || ItemDB.get(s.defId).durability <= 0) return;
      s.durability = Math.max(0, s.durability - amount);
    }
    // ---------- زمن ----------
    /** تقدّم الفساد في الحقيبة (بالساعات داخل اللعبة) */
    updateSpoil(dtHours) {
      for (const e of this.grid.list()) {
        const def = ItemDB.get(e.stack.defId);
        if (def.spoilTime > 0) e.stack.spoil += dtHours;
      }
      Container.convertRotten(this.grid);
    }
    /** العنصر المحمول في اليد (الخانة المحددة في الشريط السريع) */
    get held() {
      const uid = this.hotbar.heldUid;
      return uid === null ? null : this.grid.get(uid)?.stack ?? null;
    }
    toJSON() {
      return {
        grid: this.grid.toJSON(),
        equipment: this.equipment.list(),
        hotbar: { slots: [...this.hotbar.slots], selected: this.hotbar.selected }
      };
    }
    /** يستعيد الحالة المحفوظة ويضمن ألا تتكرر معرّفات المكدّسات الجديدة */
    load(d) {
      this.grid = Grid.fromJSON(d.grid);
      for (const slot of EQUIP_SLOTS_ALL) this.equipment.set(slot, null);
      let maxUid = 0;
      for (const { slot, stack } of d.equipment) {
        this.equipment.set(slot, stack);
        maxUid = Math.max(maxUid, stack.uid);
      }
      for (const e of this.grid.list()) maxUid = Math.max(maxUid, e.stack.uid);
      ensureUidAbove(maxUid);
      d.hotbar.slots.forEach((u, i) => this.hotbar.assign(i, u));
      this.hotbar.select(d.hotbar.selected);
      this.changed();
    }
  };

  // src/quests/ActionRunner.ts
  function runAction(action, h2) {
    const [cmd, a, b] = action.split(":");
    const n = b ? Math.max(1, parseInt(b, 10) || 1) : 1;
    switch (cmd) {
      case "give_item": {
        if (!ItemDB.has(a)) return { ok: false, reason: "unknownItem" };
        const left = h2.inv.add(a, n);
        if (left > 0) h2.dropOverflow(a, left);
        h2.quests.onInventoryChanged();
        const d = ItemDB.get(a);
        h2.notify(`\u062D\u0635\u0644\u062A \u0639\u0644\u0649 ${d.nameAr} \xD7${n}`, `Received ${d.nameEn} \xD7${n}`);
        return { ok: true };
      }
      case "take_item": {
        if (!ItemDB.has(a)) return { ok: false, reason: "unknownItem" };
        if (h2.inv.count(a) < n) return { ok: false, reason: "notEnough" };
        h2.inv.remove(a, n);
        h2.quests.onInventoryChanged();
        return { ok: true };
      }
      case "flag":
        h2.quests.notify({ type: "flag", flag: a });
        return { ok: true };
      case "quest":
        return h2.quests.start(a) ? { ok: true } : { ok: false, reason: "cannotStart" };
      default:
        return { ok: false, reason: "unknownAction" };
    }
  }
  function useStoryItem(itemId, h2, place) {
    if (itemId === "satellite_phone") {
      if (!h2.inv.has("flight_recorder")) {
        h2.notify("\u062A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u0627\u0644\u0635\u0646\u062F\u0648\u0642 \u0627\u0644\u0623\u0633\u0648\u062F \u0644\u062A\u064F\u0631\u0633\u0644 \u0634\u064A\u0626\u064B\u0627 \u0630\u0627 \u0642\u064A\u0645\u0629.", "You need the flight recorder to send anything meaningful.");
        return { ok: false, reason: "needRecorder" };
      }
      if (place !== "bunker" && place !== "peak") {
        h2.notify("\u0644\u0627 \u062A\u0648\u062C\u062F \u0625\u0634\u0627\u0631\u0629 \u0647\u0646\u0627. \u0627\u0635\u0639\u062F \u0625\u0644\u0649 \u0627\u0644\u0642\u0645\u0629 \u0623\u0648 \u0627\u062F\u062E\u0644 \u0627\u0644\u0645\u062E\u0628\u0623.", "No signal here. Climb to the peak or enter the bunker.");
        return { ok: false, reason: "noSignal" };
      }
      h2.quests.notify({ type: "flag", flag: "secret_sent" });
      h2.notify("\u0623\u064F\u0631\u0633\u0644\u062A \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A. \u0627\u0644\u0639\u0627\u0644\u0645 \u0633\u064A\u0639\u0631\u0641.", "Data sent. The world will know.");
      return { ok: true };
    }
    if (itemId === "flare_gun" || itemId === "flare") {
      if (place !== "peak") return { ok: false, reason: "notOnPeak" };
      return { ok: true };
    }
    return { ok: false, reason: "notStoryItem" };
  }

  // src/quests/Story.ts
  var QUESTS = [
    {
      id: "wake_up",
      main: true,
      auto: true,
      titleAr: "\u0627\u0644\u0627\u0633\u062A\u064A\u0642\u0627\u0638 \u0639\u0644\u0649 \u0627\u0644\u0634\u0627\u0637\u0626",
      titleEn: "Wake on the Shore",
      descAr: "\u0646\u062C\u0648\u062A\u064E \u0645\u0646 \u0627\u0644\u062A\u062D\u0637\u0645. \u0627\u062C\u0645\u0639 \u0645\u0627 \u062A\u062D\u062A\u0627\u062C\u0647 \u0644\u062A\u0628\u0642\u0649 \u062D\u064A\u064B\u0627 \u0627\u0644\u0644\u064A\u0644\u0629 \u0627\u0644\u0623\u0648\u0644\u0649.",
      descEn: "You survived the crash. Gather what you need to last the first night.",
      objectives: [
        { type: "collect", item: "stick", count: 6, textAr: "\u0627\u062C\u0645\u0639 6 \u0639\u0635\u064A", textEn: "Collect 6 sticks" },
        { type: "collect", item: "plant_fiber", count: 4, textAr: "\u0627\u062C\u0645\u0639 4 \u0623\u0644\u064A\u0627\u0641 \u0646\u0628\u0627\u062A\u064A\u0629", textEn: "Collect 4 plant fibers" },
        { type: "collect", item: "stone", count: 3, textAr: "\u0627\u062C\u0645\u0639 3 \u062D\u062C\u0627\u0631\u0629", textEn: "Collect 3 stones" }
      ],
      reward: { xp: [{ skill: "survival", amount: 10 }], items: [{ id: "bandage", count: 2 }] }
    },
    {
      id: "first_tools",
      main: true,
      requires: ["wake_up"],
      auto: true,
      titleAr: "\u0623\u062F\u0648\u0627\u062A \u0627\u0644\u0625\u0646\u0633\u0627\u0646 \u0627\u0644\u0623\u0648\u0644",
      titleEn: "First Tools",
      descAr: "\u0627\u0635\u0646\u0639 \u0623\u0648\u0644 \u0623\u062F\u0648\u0627\u062A\u0643: \u0633\u0643\u064A\u0646 \u062B\u0645 \u0641\u0623\u0633.",
      descEn: "Craft your first tools: a knife, then an axe.",
      objectives: [
        { type: "craft", item: "knife_stone", count: 1, textAr: "\u0627\u0635\u0646\u0639 \u0633\u0643\u064A\u0646\u064B\u0627 \u062D\u062C\u0631\u064A\u064B\u0627", textEn: "Craft a stone knife" },
        { type: "craft", item: "axe_stone", count: 1, textAr: "\u0627\u0635\u0646\u0639 \u0641\u0623\u0633\u064B\u0627 \u062D\u062C\u0631\u064A\u064B\u0627", textEn: "Craft a stone axe" }
      ],
      reward: { xp: [{ skill: "crafting", amount: 20 }] }
    },
    {
      id: "fire_and_water",
      main: true,
      requires: ["first_tools"],
      auto: true,
      titleAr: "\u0646\u0627\u0631 \u0648\u0645\u0627\u0621",
      titleEn: "Fire and Water",
      descAr: "\u0623\u0648\u0642\u062F \u0646\u0627\u0631\u064B\u0627 \u0648\u063A\u0644\u0650 \u0627\u0644\u0645\u0627\u0621 \u0642\u0628\u0644 \u0623\u0646 \u062A\u0634\u0631\u0628\u0647.",
      descEn: "Light a fire and boil water before drinking.",
      objectives: [
        { type: "craft", item: "campfire_kit", count: 1, textAr: "\u0627\u0635\u0646\u0639 \u0639\u062F\u0629 \u0645\u0648\u0642\u062F", textEn: "Craft a campfire kit" },
        { type: "build", piece: "campfire", count: 1, textAr: "\u0636\u0639 \u0627\u0644\u0645\u0648\u0642\u062F", textEn: "Place the campfire" },
        { type: "craft", item: "water_boiled", count: 1, textAr: "\u0627\u063A\u0644\u0650 \u0645\u0627\u0621\u064B", textEn: "Boil some water" }
      ],
      reward: { xp: [{ skill: "survival", amount: 25 }], items: [{ id: "bottle_empty", count: 2 }] }
    },
    {
      id: "find_survivors",
      main: true,
      requires: ["fire_and_water"],
      auto: true,
      titleAr: "\u0644\u0633\u062A\u064E \u0648\u062D\u062F\u0643",
      titleEn: "Not Alone",
      descAr: "\u062F\u062E\u0627\u0646 \u0628\u0639\u064A\u062F \u064A\u0648\u062D\u064A \u0628\u0648\u062C\u0648\u062F \u0646\u0627\u062C\u064A\u0646. \u0627\u0628\u062D\u062B \u0639\u0646\u0647\u0645.",
      descEn: "Distant smoke suggests survivors. Find them.",
      objectives: [
        { type: "talk", npc: "layla", textAr: "\u062A\u062D\u062F\u0651\u062B \u0625\u0644\u0649 \u0644\u064A\u0644\u0649", textEn: "Talk to Layla" },
        { type: "talk", npc: "omar", textAr: "\u062A\u062D\u062F\u0651\u062B \u0625\u0644\u0649 \u0639\u0645\u0631", textEn: "Talk to Omar" },
        { type: "talk", npc: "yusuf", textAr: "\u062A\u062D\u062F\u0651\u062B \u0625\u0644\u0649 \u064A\u0648\u0633\u0641", textEn: "Talk to Yusuf" }
      ],
      reward: { xp: [{ skill: "survival", amount: 20 }], items: [{ id: "compass", count: 1 }] },
      onComplete: ["met_all_survivors"]
    },
    {
      id: "repair_radio",
      main: true,
      requires: ["find_survivors"],
      titleAr: "\u0625\u0635\u0644\u0627\u062D \u0627\u0644\u0631\u0627\u062F\u064A\u0648",
      titleEn: "Repair the Radio",
      descAr: "\u0639\u0645\u0631 \u064A\u062D\u062A\u0627\u062C \u062E\u0631\u062F\u0629 \u0645\u0639\u062F\u0646 \u0648\u0633\u0628\u064A\u0643\u0629 \u0646\u062D\u0627\u0633 \u0648\u0628\u0637\u0627\u0631\u064A\u0629 \u0645\u0646 \u064A\u0648\u0633\u0641.",
      descEn: "Omar needs scrap metal, a copper ingot and a battery from Yusuf.",
      objectives: [
        { type: "collect", item: "scrap_metal", count: 3, textAr: "\u0627\u062C\u0645\u0639 3 \u062E\u0631\u062F\u0629 \u0645\u0639\u062F\u0646", textEn: "Collect 3 scrap metal" },
        { type: "collect", item: "copper_ingot", count: 1, textAr: "\u0627\u0635\u0647\u0631 \u0633\u0628\u064A\u0643\u0629 \u0646\u062D\u0627\u0633", textEn: "Smelt a copper ingot" },
        { type: "collect", item: "radio_battery", count: 1, textAr: "\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \u0627\u0644\u0628\u0637\u0627\u0631\u064A\u0629 \u0645\u0646 \u064A\u0648\u0633\u0641", textEn: "Get the battery from Yusuf" },
        { type: "flag", flag: "radio_done", textAr: "\u0633\u0644\u0651\u0645 \u0627\u0644\u0642\u0637\u0639 \u0644\u0639\u0645\u0631", textEn: "Deliver the parts to Omar" }
      ],
      reward: { xp: [{ skill: "crafting", amount: 40 }] },
      onComplete: ["distress_sent"]
    },
    {
      id: "signal_fire",
      main: true,
      requires: ["repair_radio"],
      auto: true,
      titleAr: "\u0625\u0634\u0627\u0631\u0629 \u0627\u0644\u0625\u0646\u0642\u0627\u0630",
      titleEn: "Rescue Signal",
      descAr: "\u0627\u0644\u0646\u062F\u0627\u0621 \u0623\u064F\u0631\u0633\u0644. \u0627\u0628\u0646\u0650 \u0646\u0627\u0631\u064B\u0627 \u0643\u0628\u064A\u0631\u0629 \u0639\u0644\u0649 \u0627\u0644\u0642\u0645\u0629 \u0648\u0627\u0646\u062A\u0638\u0631 \u0627\u0644\u0645\u0631\u0648\u062D\u064A\u0629.",
      descEn: "The call is out. Build a big fire on the peak and wait for the helicopter.",
      objectives: [
        { type: "collect", item: "firewood", count: 20, textAr: "\u0627\u062C\u0645\u0639 20 \u062D\u0637\u0628\u0629", textEn: "Collect 20 firewood" },
        { type: "reach", place: "peak", textAr: "\u0627\u0635\u0639\u062F \u0625\u0644\u0649 \u0627\u0644\u0642\u0645\u0629", textEn: "Climb to the peak" },
        { type: "flag", flag: "signal_lit", textAr: "\u0623\u0634\u0639\u0644 \u0646\u0627\u0631 \u0627\u0644\u0625\u0634\u0627\u0631\u0629", textEn: "Light the signal fire" },
        { type: "survive", days: 2, textAr: "\u0627\u0628\u0642\u064E \u062D\u064A\u064B\u0627 \u062D\u062A\u0649 \u0648\u0635\u0648\u0644 \u0627\u0644\u0625\u0646\u0642\u0627\u0630 (\u064A\u0648\u0645\u0627\u0646)", textEn: "Stay alive until rescue (2 days)" }
      ],
      onComplete: ["ending_rescue_ready"]
    },
    // ---- النهاية البديلة: الطوافة ----
    {
      id: "build_raft",
      requires: ["first_tools"],
      titleAr: "\u0637\u0648\u0627\u0641\u0629 \u0627\u0644\u0623\u0645\u0644",
      titleEn: "Raft of Hope",
      descAr: "\u0625\u0646 \u062A\u0623\u062E\u0631 \u0627\u0644\u0625\u0646\u0642\u0627\u0630 \u0641\u0627\u0644\u0628\u062D\u0631 \u0637\u0631\u064A\u0642 \u0622\u062E\u0631. \u0627\u062C\u0645\u0639 \u0627\u0644\u062E\u0634\u0628 \u0648\u0627\u0644\u062D\u0628\u0627\u0644 \u0648\u0642\u0645\u0627\u0634 \u0627\u0644\u0634\u0631\u0627\u0639.",
      descEn: "If rescue is slow, the sea is another way. Gather wood, rope and sail cloth.",
      objectives: [
        { type: "collect", item: "wood_log", count: 8, textAr: "\u0627\u062C\u0645\u0639 8 \u062C\u0630\u0648\u0639", textEn: "Collect 8 logs" },
        { type: "collect", item: "bamboo", count: 10, textAr: "\u0627\u062C\u0645\u0639 10 \u062E\u064A\u0632\u0631\u0627\u0646\u0627\u062A", textEn: "Collect 10 bamboo" },
        { type: "collect", item: "sail_cloth", count: 1, textAr: "\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \u0642\u0645\u0627\u0634 \u0627\u0644\u0634\u0631\u0627\u0639 \u0645\u0646 \u0627\u0644\u062D\u0637\u0627\u0645", textEn: "Find sail cloth in the wreck" },
        { type: "craft", item: "raft_kit", count: 1, textAr: "\u0627\u0635\u0646\u0639 \u0639\u062F\u0629 \u0627\u0644\u0637\u0648\u0627\u0641\u0629", textEn: "Craft the raft kit" },
        { type: "build", piece: "raft", count: 1, textAr: "\u0623\u0646\u0632\u0644 \u0627\u0644\u0637\u0648\u0627\u0641\u0629 \u0625\u0644\u0649 \u0627\u0644\u0645\u0627\u0621", textEn: "Launch the raft" },
        { type: "reach", place: "open_sea", textAr: "\u0623\u0628\u062D\u0631 \u0646\u062D\u0648 \u0627\u0644\u0623\u0641\u0642", textEn: "Sail towards the horizon" }
      ],
      onComplete: ["ending_raft_ready"]
    },
    // ---- سر الجزيرة ----
    {
      id: "island_secret",
      requires: ["find_survivors"],
      titleAr: "\u0633\u0631 \u0627\u0644\u062C\u0632\u064A\u0631\u0629",
      titleEn: "The Island Secret",
      descAr: "\u064A\u0648\u0633\u0641 \u064A\u0644\u0645\u0651\u062D \u0625\u0644\u0649 \u0645\u062E\u0628\u0623 \u062A\u062D\u062A \u0627\u0644\u0628\u0631\u0643\u0627\u0646. \u0627\u0643\u062A\u0634\u0641 \u0645\u0627 \u064A\u062E\u0641\u064A\u0647.",
      descEn: "Yusuf hints at a bunker under the volcano. Discover what it hides.",
      objectives: [
        { type: "collect", item: "bunker_key", count: 1, textAr: "\u0627\u0643\u0633\u0628 \u062B\u0642\u0629 \u064A\u0648\u0633\u0641 \u0648\u062E\u0630 \u0627\u0644\u0645\u0641\u062A\u0627\u062D", textEn: "Earn Yusuf's trust and take the key" },
        { type: "reach", place: "bunker", textAr: "\u0627\u062F\u062E\u0644 \u0627\u0644\u0645\u062E\u0628\u0623 \u062A\u062D\u062A \u0627\u0644\u0628\u0631\u0643\u0627\u0646", textEn: "Enter the bunker under the volcano" },
        { type: "collect", item: "flight_recorder", count: 1, textAr: "\u0627\u0628\u062D\u062B \u0639\u0646 \u0627\u0644\u0635\u0646\u062F\u0648\u0642 \u0627\u0644\u0623\u0633\u0648\u062F", textEn: "Find the flight recorder" },
        { type: "collect", item: "satellite_phone", count: 1, textAr: "\u062E\u0630 \u0627\u0644\u0647\u0627\u062A\u0641 \u0627\u0644\u0641\u0636\u0627\u0626\u064A", textEn: "Take the satellite phone" }
      ],
      reward: { xp: [{ skill: "survival", amount: 60 }] },
      onComplete: ["ending_secret_ready"]
    },
    // ---- جانبية ----
    {
      id: "hunter",
      requires: ["first_tools"],
      titleAr: "\u0627\u0644\u0635\u064A\u0627\u062F",
      titleEn: "The Hunter",
      descAr: "\u0627\u0644\u0644\u062D\u0645 \u0623\u0633\u0627\u0633 \u0627\u0644\u0628\u0642\u0627\u0621. \u0627\u0635\u0646\u0639 \u0631\u0645\u062D\u064B\u0627 \u0648\u0635\u0650\u062F.",
      descEn: "Meat is survival. Craft a spear and hunt.",
      objectives: [
        { type: "craft", item: "spear_wood", count: 1, textAr: "\u0627\u0635\u0646\u0639 \u0631\u0645\u062D\u064B\u0627", textEn: "Craft a spear" },
        { type: "kill", species: "deer", count: 1, textAr: "\u0635\u0650\u062F \u063A\u0632\u0627\u0644\u064B\u0627", textEn: "Hunt a deer" },
        { type: "craft", item: "cooked_meat", count: 1, textAr: "\u0627\u0634\u0648\u0650 \u0627\u0644\u0644\u062D\u0645", textEn: "Grill the meat" }
      ],
      reward: { xp: [{ skill: "hunting", amount: 30 }], items: [{ id: "fishing_net", count: 1 }] }
    },
    {
      id: "shelter",
      requires: ["first_tools"],
      titleAr: "\u0633\u0642\u0641 \u0641\u0648\u0642 \u0627\u0644\u0631\u0623\u0633",
      titleEn: "A Roof Overhead",
      descAr: "\u0627\u0628\u0646\u0650 \u0645\u0644\u062C\u0623\u064B \u064A\u0642\u064A\u0643 \u0627\u0644\u0645\u0637\u0631 \u0648\u0627\u0644\u0628\u0631\u062F.",
      descEn: "Build a shelter against rain and cold.",
      objectives: [
        { type: "build", piece: "foundation", count: 1, textAr: "\u0627\u0628\u0646\u0650 \u0623\u0633\u0627\u0633\u064B\u0627", textEn: "Build a foundation" },
        { type: "build", piece: "wall", count: 2, textAr: "\u0627\u0628\u0646\u0650 \u062C\u062F\u0627\u0631\u064A\u0646", textEn: "Build two walls" },
        { type: "build", piece: "roof", count: 1, textAr: "\u0636\u0639 \u0633\u0642\u0641\u064B\u0627", textEn: "Add a roof" },
        { type: "build", piece: "bed", count: 1, textAr: "\u0636\u0639 \u0641\u0631\u0627\u0634\u064B\u0627", textEn: "Place a bed" }
      ],
      reward: { xp: [{ skill: "building", amount: 40 }] }
    },
    {
      id: "ironworks",
      requires: ["first_tools"],
      titleAr: "\u0639\u0635\u0631 \u0627\u0644\u062D\u062F\u064A\u062F",
      titleEn: "The Iron Age",
      descAr: "\u0627\u0628\u062D\u062B \u0639\u0646 \u0627\u0644\u062D\u062F\u064A\u062F \u0641\u064A \u0627\u0644\u0643\u0647\u0641 \u0648\u0627\u0635\u0647\u0631\u0647.",
      descEn: "Find iron in the cave and smelt it.",
      objectives: [
        { type: "reach", place: "cave", textAr: "\u0627\u062F\u062E\u0644 \u0627\u0644\u0643\u0647\u0641", textEn: "Enter the cave" },
        { type: "collect", item: "iron_ore", count: 4, textAr: "\u0627\u062C\u0645\u0639 4 \u062E\u0627\u0645 \u062D\u062F\u064A\u062F", textEn: "Collect 4 iron ore" },
        { type: "craft", item: "iron_ingot", count: 2, textAr: "\u0627\u0635\u0647\u0631 \u0633\u0628\u064A\u0643\u062A\u064A \u062D\u062F\u064A\u062F", textEn: "Smelt 2 iron ingots" },
        { type: "craft", item: "axe_iron", count: 1, textAr: "\u0627\u0635\u0646\u0639 \u0641\u0623\u0633\u064B\u0627 \u062D\u062F\u064A\u062F\u064A\u064B\u0627", textEn: "Craft an iron axe" }
      ],
      reward: { xp: [{ skill: "crafting", amount: 50 }] }
    }
  ];
  var QUEST_BY_ID = new Map(QUESTS.map((q) => [q.id, q]));

  // src/quests/Journal.ts
  var Journal = class {
    entries = [];
    pages = /* @__PURE__ */ new Set();
    add(id, day, textAr, textEn) {
      if (this.entries.some((e) => e.id === id)) return;
      this.entries.push({ id, day, textAr, textEn });
    }
    /** يربط المهام بالمفكرة: تُسجَّل بداية وإنجاز كل مهمة رئيسية */
    attach(quests, getDay) {
      const prev = quests.onUpdate;
      quests.onUpdate = (id, kind) => {
        prev?.(id, kind);
        const q = QUESTS.find((x) => x.id === id);
        if (!q) return;
        if (kind === "started") this.add(`${id}:start`, getDay(), `\u0628\u062F\u0623\u062A \u0645\u0647\u0645\u0629: ${q.titleAr}. ${q.descAr}`, `Started: ${q.titleEn}. ${q.descEn}`);
        if (kind === "completed") this.add(`${id}:done`, getDay(), `\u0623\u0646\u062C\u0632\u062A: ${q.titleAr}.`, `Completed: ${q.titleEn}.`);
      };
    }
    /** صفحة مذكرات (عنصر قصة): نصوص ثابتة تُكتشف */
    collectPage(pageId, day) {
      if (this.pages.has(pageId)) return false;
      const p = JOURNAL_PAGES[pageId];
      if (!p) return false;
      this.pages.add(pageId);
      this.add(`page:${pageId}`, day, p.ar, p.en);
      return true;
    }
    noteNPC(npc, day) {
      this.add(`npc:${npc.def.id}`, day, `\u0627\u0644\u062A\u0642\u064A\u062A ${npc.def.nameAr}. ${npc.def.bioAr}`, `Met ${npc.def.nameEn}. ${npc.def.bioEn}`);
    }
    toJSON() {
      return { entries: this.entries, pages: [...this.pages] };
    }
    load(d) {
      this.entries.length = 0;
      this.entries.push(...d.entries);
      this.pages.clear();
      d.pages.forEach((p) => this.pages.add(p));
    }
  };
  var JOURNAL_PAGES = {
    pilot_1: {
      ar: '\u0645\u0630\u0643\u0631\u0627\u062A \u0627\u0644\u0637\u064A\u0627\u0631 \u2014 \u0627\u0644\u0635\u0641\u062D\u0629 1: \u0645\u0633\u0627\u0631\u0646\u0627 \u062A\u063A\u064A\u0651\u0631 \u0642\u0628\u0644 \u0633\u0627\u0639\u0629 \u0645\u0646 \u0627\u0644\u0625\u0642\u0644\u0627\u0639 \u0628\u0623\u0645\u0631 \u0644\u0645 \u0623\u0641\u0647\u0645\u0647. \u0642\u064A\u0644 \u0625\u0646\u0647 "\u062D\u0645\u0648\u0644\u0629 \u0625\u0636\u0627\u0641\u064A\u0629" \u0645\u0646 \u062C\u0647\u0629 \u0644\u0627 \u0623\u0639\u0631\u0641\u0647\u0627.',
      en: "Pilot's journal \u2014 page 1: Our route changed an hour before takeoff on an order I didn't understand. They called it an 'extra cargo' from a party I don't know."
    },
    pilot_2: {
      ar: "\u0627\u0644\u0635\u0641\u062D\u0629 2: \u0627\u0644\u0645\u062D\u0631\u0643 \u0627\u0644\u0623\u064A\u0633\u0631 \u062A\u0648\u0642\u0641 \u0628\u0644\u0627 \u0625\u0646\u0630\u0627\u0631. \u0627\u0644\u0623\u062C\u0647\u0632\u0629 \u062A\u064F\u0638\u0647\u0631 \u0642\u0631\u0627\u0621\u0627\u062A \u063A\u064A\u0631 \u0645\u0645\u0643\u0646\u0629. \u0623\u0638\u0646 \u0623\u0646 \u0623\u062D\u062F\u064B\u0627 \u0639\u0628\u062B \u0628\u0647\u0627.",
      en: "Page 2: The left engine died without warning. The instruments show impossible readings. I think someone tampered with them."
    },
    pilot_3: {
      ar: "\u0627\u0644\u0635\u0641\u062D\u0629 3: \u0625\u0646 \u0648\u062C\u062F \u0623\u062D\u062F\u064C \u0647\u0630\u0627\u060C \u0641\u0627\u0644\u062C\u0632\u064A\u0631\u0629 \u0627\u0644\u0645\u0642\u0627\u0628\u0644\u0629 \u0644\u064A\u0633\u062A \u0645\u0647\u062C\u0648\u0631\u0629. \u0631\u0623\u064A\u062A \u0623\u0636\u0648\u0627\u0621 \u062A\u062D\u062A \u0627\u0644\u0628\u0631\u0643\u0627\u0646. \u0647\u0646\u0627\u0643 \u0642\u0628\u0648.",
      en: "Page 3: If anyone finds this \u2014 the island ahead isn't abandoned. I saw lights under the volcano. There's a bunker."
    },
    bunker_1: {
      ar: "\u0633\u062C\u0644 \u0627\u0644\u0642\u0628\u0648: \u0645\u0634\u0631\u0648\u0639 \u0627\u0644\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0635\u0627\u0645\u062A. \u0643\u0644 \u0625\u0634\u0627\u0631\u0629 \u0645\u0646 \u0627\u0644\u062C\u0632\u064A\u0631\u0629 \u062A\u064F\u062D\u062C\u0628. \u0627\u0644\u0647\u0627\u062A\u0641 \u0627\u0644\u0641\u0636\u0627\u0626\u064A \u0647\u0648 \u0627\u0644\u0648\u062D\u064A\u062F \u0627\u0644\u0630\u064A \u064A\u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u062D\u062C\u0628.",
      en: "Bunker log: Silent Relay project. Every signal from the island is jammed. The satellite phone is the only one that bypasses it."
    },
    bunker_2: {
      ar: "\u0645\u0644\u0627\u062D\u0638\u0629 \u0623\u062E\u064A\u0631\u0629: \u0627\u0644\u0635\u0646\u062F\u0648\u0642 \u0627\u0644\u0623\u0633\u0648\u062F \u064A\u062D\u0645\u0644 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u0643\u0627\u0645\u0644. \u0645\u0646 \u064A\u0631\u0633\u0644\u0647 \u064A\u063A\u064A\u0651\u0631 \u0643\u0644 \u0634\u064A\u0621.",
      en: "Final note: the flight recorder holds the full recording. Whoever sends it changes everything."
    }
  };

  // src/quests/MapData.ts
  var MapData = class _MapData {
    constructor(landmarks) {
      this.landmarks = landmarks;
      for (const l of landmarks) if (l.known) this.discovered.add(l.id);
    }
    landmarks;
    discovered = /* @__PURE__ */ new Set();
    /** خلايا الضباب المستكشفة (شبكة 32م) */
    explored = /* @__PURE__ */ new Set();
    static FOG_CELL = 32;
    /** بوصلة ضرورية لعرض الشمال؟ الخريطة نفسها تتطلب قطعة خريطة لتفتح كاملة */
    fullMapUnlocked = false;
    /** يستدعى كل فترة بموضع اللاعب. @returns المعالم المكتشفة حديثًا */
    update(x, z, viewRadius = 40) {
      const found = [];
      const cell = _MapData.FOG_CELL;
      const r = Math.ceil(viewRadius / cell);
      const cx = Math.floor(x / cell);
      const cz = Math.floor(z / cell);
      for (let dz = -r; dz <= r; dz++) {
        for (let dx = -r; dx <= r; dx++) {
          if (dx * dx + dz * dz <= r * r) this.explored.add(`${cx + dx},${cz + dz}`);
        }
      }
      for (const l of this.landmarks) {
        if (this.discovered.has(l.id)) continue;
        if (Math.hypot(l.x - x, l.z - z) <= l.radius) {
          this.discovered.add(l.id);
          found.push(l);
        }
      }
      return found;
    }
    isDiscovered(id) {
      return this.discovered.has(id);
    }
    isExplored(x, z) {
      return this.fullMapUnlocked || this.explored.has(`${Math.floor(x / _MapData.FOG_CELL)},${Math.floor(z / _MapData.FOG_CELL)}`);
    }
    /** المعالم الظاهرة على الخريطة */
    visibleLandmarks() {
      return this.landmarks.filter((l) => this.fullMapUnlocked || this.discovered.has(l.id));
    }
    /** اسم أقرب معلم ضمن نطاق (لتفعيل أماكن المهام مثل 'peak' و'cave') */
    placeAt(x, z) {
      let best = null;
      let bd = Infinity;
      for (const l of this.landmarks) {
        const d = Math.hypot(l.x - x, l.z - z);
        if (d <= l.radius && d < bd) {
          bd = d;
          best = l;
        }
      }
      return best?.id ?? null;
    }
    /** من إحداثيات العالم إلى بكسلات الخريطة (الشمال للأعلى: -z) */
    static worldToMap(x, z, worldHalf, size) {
      return { px: (x + worldHalf) / (worldHalf * 2) * size, py: (z + worldHalf) / (worldHalf * 2) * size };
    }
    static mapToWorld(px, py, worldHalf, size) {
      return { x: px / size * worldHalf * 2 - worldHalf, z: py / size * worldHalf * 2 - worldHalf };
    }
    toJSON() {
      return { discovered: [...this.discovered], explored: [...this.explored], full: this.fullMapUnlocked };
    }
    load(d) {
      this.discovered = new Set(d.discovered);
      this.explored = new Set(d.explored);
      this.fullMapUnlocked = d.full;
    }
  };

  // src/quests/Objectives.ts
  function objectiveTarget(o) {
    switch (o.type) {
      case "collect":
      case "craft":
      case "kill":
      case "build":
        return o.count;
      case "survive":
        return o.days;
      default:
        return 1;
    }
  }
  function progressFrom(o, e) {
    switch (o.type) {
      case "collect":
        return e.type === "itemGained" && e.item === o.item ? e.count : 0;
      case "craft":
        return e.type === "crafted" && e.item === o.item ? e.count : 0;
      case "kill":
        return e.type === "killed" && e.species === o.species ? 1 : 0;
      case "reach":
        return e.type === "arrived" && e.place === o.place ? 1 : 0;
      case "talk":
        return e.type === "talked" && e.npc === o.npc ? 1 : 0;
      case "flag":
        return e.type === "flag" && e.flag === o.flag ? 1 : 0;
      case "build":
        return e.type === "built" && e.piece === o.piece ? 1 : 0;
      case "survive":
        return 0;
    }
  }

  // src/quests/QuestManager.ts
  var QuestManager = class {
    constructor(hooks) {
      this.hooks = hooks;
      for (const q of QUESTS) this.states.set(q.id, { status: "locked", progress: q.objectives.map(() => 0), current: 0 });
      this.refreshAvailability();
    }
    hooks;
    states = /* @__PURE__ */ new Map();
    flags = /* @__PURE__ */ new Set();
    day = 0;
    onUpdate = null;
    status(id) {
      return this.states.get(id)?.status ?? "locked";
    }
    get active() {
      return QUESTS.filter((q) => this.status(q.id) === "active");
    }
    get available() {
      return QUESTS.filter((q) => this.status(q.id) === "available");
    }
    get completed() {
      return QUESTS.filter((q) => this.status(q.id) === "completed");
    }
    /** المهمة الرئيسية الحالية (للتتبع على الشاشة) */
    get tracked() {
      const act = this.active;
      return act.find((q) => q.main) ?? act[0] ?? null;
    }
    progressOf(id) {
      const q = QUEST_BY_ID.get(id);
      const s = this.states.get(id);
      return {
        objectives: q.objectives.map((o, i) => ({
          done: s.status === "completed" || i < s.current,
          value: Math.min(s.progress[i], objectiveTarget(o)),
          target: objectiveTarget(o),
          current: s.status === "active" && i === s.current
        }))
      };
    }
    requirementsMet(q) {
      return (q.requires ?? []).every((r) => this.status(r) === "completed");
    }
    /** يحدّث locked→available وتفعيل auto */
    refreshAvailability() {
      let changed = true;
      while (changed) {
        changed = false;
        for (const q of QUESTS) {
          const s = this.states.get(q.id);
          if (s.status === "locked" && this.requirementsMet(q)) {
            s.status = "available";
            changed = true;
          }
          if (s.status === "available" && q.auto) {
            this.start(q.id);
            changed = true;
          }
        }
      }
    }
    start(id) {
      const q = QUEST_BY_ID.get(id);
      const s = this.states.get(id);
      if (!q || !s || s.status !== "available" && s.status !== "locked" || !this.requirementsMet(q)) return false;
      s.status = "active";
      s.current = 0;
      s.progress = q.objectives.map(() => 0);
      this.onUpdate?.(id, "started");
      this.syncCurrent(q, s);
      return true;
    }
    /** يغذّي حدثًا لكل المهام النشطة */
    notify(e) {
      if (e.type === "flag") this.flags.add(e.flag);
      if (e.type === "dayPassed") this.day = e.day;
      for (const q of [...this.active]) {
        const s = this.states.get(q.id);
        const o = q.objectives[s.current];
        if (!o) continue;
        if (o.type === "survive") {
          if (e.type === "dayPassed") s.progress[s.current] = Math.min(o.days, s.progress[s.current] + 1);
        } else if (o.type === "flag") {
          if (this.flags.has(o.flag)) s.progress[s.current] = 1;
        } else if (o.type === "collect") {
          s.progress[s.current] = Math.min(o.count, this.hooks.itemCount(o.item));
        } else {
          s.progress[s.current] += progressFrom(o, e);
        }
        this.syncCurrent(q, s);
      }
      this.refreshAvailability();
    }
    /** يُستدعى حين تتغير الحقيبة: يحدّث أهداف الحيازة (مثلًا بعد استلام عنصر من حوار) */
    onInventoryChanged() {
      this.notify({ type: "itemGained", item: "", count: 0 });
    }
    /** ينقل التقدم إلى الهدف التالي إن اكتمل الحالي؛ يكمل المهمة عند الانتهاء */
    syncCurrent(q, s) {
      let advanced = false;
      while (s.current < q.objectives.length) {
        const o = q.objectives[s.current];
        if (o.type === "collect") s.progress[s.current] = Math.min(o.count, this.hooks.itemCount(o.item));
        if (o.type === "flag" && this.flags.has(o.flag)) s.progress[s.current] = 1;
        if (s.progress[s.current] >= objectiveTarget(o)) {
          s.current++;
          advanced = true;
        } else break;
      }
      if (s.current >= q.objectives.length) {
        this.complete(q, s);
      } else if (advanced) {
        this.onUpdate?.(q.id, "progress");
      } else {
        this.onUpdate?.(q.id, "progress");
      }
    }
    complete(q, s) {
      if (s.status === "completed") return;
      s.status = "completed";
      for (const f of q.onComplete ?? []) this.flags.add(f);
      if (q.reward) {
        for (const f of q.reward.flags ?? []) this.flags.add(f);
        this.hooks.giveReward(q.reward);
      }
      this.onUpdate?.(q.id, "completed");
    }
    /** هل النهاية جاهزة؟ */
    endingsReady() {
      return {
        rescue: this.flags.has("ending_rescue_ready"),
        raft: this.flags.has("ending_raft_ready"),
        secret: this.flags.has("ending_secret_ready")
      };
    }
    toJSON() {
      return { states: [...this.states], flags: [...this.flags], day: this.day };
    }
    load(d) {
      for (const [id, st] of d.states) if (this.states.has(id)) this.states.set(id, st);
      this.flags.clear();
      d.flags.forEach((f) => this.flags.add(f));
      this.day = d.day;
    }
  };

  // src/quests/RescueEnding.ts
  var RESCUE_WAIT_DAYS = 2;
  function evaluateEnding(c) {
    if (!c.alive) return "death";
    if (c.flags.has("ending_secret_ready") && c.has("flight_recorder") && c.has("satellite_phone") && c.flags.has("secret_sent")) return "secret";
    if (c.flags.has("ending_raft_ready") && c.place === "open_sea") return "raft";
    if (c.flags.has("ending_rescue_ready") && c.flags.has("signal_lit") && c.signalDay !== null && c.day - c.signalDay >= RESCUE_WAIT_DAYS) return "rescue";
    return null;
  }

  // src/survival/Fire.ts
  var FUEL_MINUTES = {
    wood_log: 90,
    firewood: 60,
    charcoal: 75,
    stick: 12,
    bark: 8,
    thatch: 6
  };
  var MAX_FUEL_MINUTES = 240;
  var Fire = class _Fire {
    constructor(x = 0, y = 0, z = 0, covered = false) {
      this.x = x;
      this.y = y;
      this.z = z;
      this.covered = covered;
    }
    x;
    y;
    z;
    covered;
    /** دقائق الوقود المتبقية (زمن اللعبة) */
    fuel = 0;
    burning = false;
    /** 0..1 */
    strength = 0;
    /** رطوبة الوقود: ترتفع تحت المطر وتصعّب الإشعال */
    dampness = 0;
    /** الحد الأقصى لتأثير الدفء بالمتر */
    warmRadius = 5;
    addFuel(item, count = 1) {
      this.fuel = Math.min(MAX_FUEL_MINUTES, this.fuel + FUEL_MINUTES[item] * count);
    }
    static isFuel(id) {
      return id in FUEL_MINUTES;
    }
    /**
     * محاولة الإشعال.
     * @param method احتمال نجاح الأداة (مثلًا ولّاعة 0.98، مثقاب 0.35)
     * @param rnd رقم عشوائي [0,1)
     * @param rainIntensity 0..1 (المطر يقلل النجاح إن كانت النار مكشوفة)
     */
    ignite(method, rnd, rainIntensity = 0) {
      if (this.fuel <= 0) return false;
      const rainPenalty = this.covered ? 0.1 : 0.85;
      const p = method * (1 - rainIntensity * rainPenalty) * (1 - this.dampness * 0.6);
      if (rnd < p) {
        this.burning = true;
        this.strength = Math.max(this.strength, 0.35);
        return true;
      }
      return false;
    }
    /** @param dtMinutes دقائق زمن اللعبة */
    update(dtMinutes, rainIntensity, windSpeed = 0) {
      const exposed = this.covered ? 0.1 : 1;
      this.dampness = clamp01(this.dampness + (rainIntensity * exposed * 0.02 - 4e-3) * dtMinutes);
      if (!this.burning) return;
      this.fuel = Math.max(0, this.fuel - dtMinutes * (1 + windSpeed * 0.02));
      const rainDamage = rainIntensity * exposed * 0.15 * dtMinutes;
      const targetStrength = Math.min(1, this.fuel / 60) * (1 - this.dampness * 0.4);
      this.strength += (targetStrength - this.strength) * Math.min(1, dtMinutes * 0.1);
      this.strength -= rainDamage;
      if (this.fuel <= 0 || this.strength <= 0.04) {
        this.burning = false;
        this.strength = 0;
      }
    }
    /** الدفء الذي يشعر به من يبعد d متر (0..1) */
    heatAt(d) {
      if (!this.burning) return 0;
      if (d >= this.warmRadius) return 0;
      return this.strength * (1 - d / this.warmRadius);
    }
    /** نصف قطر ضوء النار */
    get lightRadius() {
      return this.burning ? 6 + this.strength * 12 : 0;
    }
    toJSON() {
      return { x: this.x, y: this.y, z: this.z, covered: this.covered, fuel: this.fuel, burning: this.burning, strength: this.strength, dampness: this.dampness };
    }
    static fromJSON(d) {
      const f = new _Fire(d.x, d.y, d.z, d.covered);
      f.fuel = d.fuel;
      f.burning = d.burning;
      f.strength = d.strength;
      f.dampness = d.dampness;
      return f;
    }
    extinguish() {
      this.burning = false;
      this.strength = 0;
    }
  };
  function clamp01(v) {
    return Math.max(0, Math.min(1, v));
  }

  // src/survival/Farming.ts
  var SLOTS_PER_PLOT = 4;
  var GROW_HOURS = 72;
  var WATER_HOURS = 30;
  var WATER_ITEMS = ["rainwater", "water_boiled", "water_dirty"];
  var FarmPlot = class _FarmPlot {
    slots = Array.from({ length: SLOTS_PER_PLOT }, () => null);
    freeSlot() {
      return this.slots.findIndex((s) => s === null);
    }
    plant(slot = this.freeSlot()) {
      if (slot < 0 || slot >= SLOTS_PER_PLOT || this.slots[slot]) return false;
      this.slots[slot] = { growth: 0, water: 0 };
      return true;
    }
    /** يسقي كل المحاصيل. @returns كم نبتة سُقيت */
    water() {
      let n = 0;
      for (const c of this.slots) if (c && c.water < 1) {
        c.water = 1;
        n++;
      }
      return n;
    }
    stage(slot) {
      const c = this.slots[slot];
      if (!c) return null;
      const f = c.growth / GROW_HOURS;
      return f >= 1 ? 3 : f >= 0.66 ? 2 : f >= 0.25 ? 1 : 0;
    }
    get ripeCount() {
      return this.slots.filter((_, i) => this.stage(i) === 3).length;
    }
    get plantedCount() {
      return this.slots.filter(Boolean).length;
    }
    get thirsty() {
      return this.slots.some((c) => c && c.water <= 0 && c.growth < GROW_HOURS);
    }
    /** أقل ساعات متبقية لنضج نبتة غير ناضجة، أو null */
    hoursToRipe() {
      let best = null;
      for (const c of this.slots) if (c && c.growth < GROW_HOURS) best = Math.min(best ?? Infinity, GROW_HOURS - c.growth);
      return best;
    }
    /** @param dh ساعات اللعبة @param rain شدة المطر 0..1: المطر الغزير يسقي */
    update(dh, rain) {
      for (const c of this.slots) {
        if (!c) continue;
        if (rain > 0.3) c.water = 1;
        if (c.water > 0) {
          c.growth = Math.min(GROW_HOURS, c.growth + dh);
          c.water = Math.max(0, c.water - dh / WATER_HOURS);
        }
      }
    }
    /** يحصد كل الناضج: يامس 2–3 وبذور 1–2 لكل نبتة */
    harvest(rnd) {
      const out = /* @__PURE__ */ new Map();
      for (let i = 0; i < SLOTS_PER_PLOT; i++) {
        if (this.stage(i) !== 3) continue;
        this.slots[i] = null;
        out.set("yam", (out.get("yam") ?? 0) + 2 + Math.floor(rnd.next() * 2));
        out.set("seeds", (out.get("seeds") ?? 0) + 1 + Math.floor(rnd.next() * 2));
      }
      return [...out].map(([id, count]) => ({ id, count }));
    }
    toJSON() {
      return this.slots.map((c) => c ? { ...c } : null);
    }
    static fromJSON(d) {
      const p = new _FarmPlot();
      d.slice(0, SLOTS_PER_PLOT).forEach((c, i) => {
        p.slots[i] = c ? { growth: Math.max(0, Math.min(GROW_HOURS, Number(c.growth) || 0)), water: Math.max(0, Math.min(1, Number(c.water) || 0)) } : null;
      });
      return p;
    }
  };

  // src/survival/Fishing.ts
  var BAITS = /* @__PURE__ */ new Set(["berries", "raw_fish", "raw_crab", "seaweed", "plant_fiber", "mushroom"]);
  var BITE_WINDOW = 1.6;
  function catchTable(depth) {
    if (depth < 0.6) return [];
    if (depth < 3) return [{ id: "raw_fish", count: 1, weight: 6 }, { id: "raw_crab", count: 1, weight: 3 }, { id: "seaweed", count: 1, weight: 2 }, { id: "shell", count: 1, weight: 1 }];
    if (depth < 8) return [{ id: "raw_fish", count: 1, weight: 7 }, { id: "raw_fish", count: 2, weight: 3 }, { id: "raw_crab", count: 1, weight: 1 }, { id: "scrap_metal", count: 1, weight: 0.2 }];
    return [{ id: "raw_fish", count: 2, weight: 5 }, { id: "raw_fish", count: 3, weight: 2 }, { id: "glass_shard", count: 1, weight: 0.3 }];
  }
  var Fishing = class {
    constructor(rnd) {
      this.rnd = rnd;
    }
    rnd;
    state = "idle";
    timer = 0;
    cast = null;
    lastCatch = null;
    /** ما يستهلكه الصيد من الطُّعم عند اللدغة */
    consumedBait = null;
    static isBait(id) {
      return BAITS.has(id);
    }
    start(info) {
      if (this.state !== "idle" && this.state !== "caught" && this.state !== "escaped") return false;
      if (info.depth < 0.6) return false;
      this.cast = info;
      this.state = "waiting";
      this.lastCatch = null;
      this.consumedBait = null;
      this.timer = this.waitTime(info);
      return true;
    }
    /** زمن الانتظار قبل اللدغة: أقصر مع المهارة والطُّعم والفجر/الغروب */
    waitTime(i) {
      let t2 = 8 + this.rnd.next() * 10;
      t2 *= 1 - i.skill * 0.04;
      if (i.bait) t2 *= 0.6;
      const dawnDusk = Math.min(Math.abs(i.hour - 6), Math.abs(i.hour - 18)) < 1.5;
      if (dawnDusk) t2 *= 0.7;
      return t2 / Math.max(1, i.rodPower);
    }
    update(dt) {
      if (this.state === "waiting") {
        this.timer -= dt;
        if (this.timer <= 0) {
          this.state = "bite";
          this.timer = BITE_WINDOW;
          this.consumedBait = this.cast.bait;
        }
      } else if (this.state === "bite") {
        this.timer -= dt;
        if (this.timer <= 0) this.state = "escaped";
      }
    }
    /** يسحب الصنارة: ينجح فقط أثناء اللدغة */
    reel() {
      if (this.state === "waiting") {
        this.state = "idle";
        return null;
      }
      if (this.state !== "bite" || !this.cast) return null;
      const table = catchTable(this.cast.depth);
      if (!table.length) {
        this.state = "escaped";
        return null;
      }
      const total = table.reduce((s, e) => s + e.weight, 0);
      let r = this.rnd.next() * total;
      let pick2 = table[0];
      for (const e of table) {
        r -= e.weight;
        if (r <= 0) {
          pick2 = e;
          break;
        }
      }
      const count = pick2.count * (this.cast.rodPower >= 2 ? 2 : 1);
      this.lastCatch = { id: pick2.id, count };
      this.state = "caught";
      return this.lastCatch;
    }
    cancel() {
      this.state = "idle";
      this.cast = null;
    }
  };

  // src/survival/Environment.ts
  function ambientTemperature(hour, weatherDelta, altitude) {
    const daily = Math.sin((hour - 8) / 24 * Math.PI * 2);
    const base = 26 + daily * 6;
    return base + weatherDelta - Math.max(0, altitude) * 65e-4 * 3;
  }
  var HOURS_PER_REAL_SECOND = 24 / 1200;
  var dayOf = (totalHours) => Math.floor(totalHours / 24);
  var hourOf = (totalHours) => (totalHours % 24 + 24) % 24;
  function activityFrom(loco, working, sleeping) {
    if (sleeping) return "rest";
    if (working) return "work";
    switch (loco) {
      case "run":
        return "run";
      case "walk":
        return "walk";
      case "swim":
        return "swim";
      case "crouch":
        return "idle";
      case "jump":
        return "walk";
      default:
        return "idle";
    }
  }

  // src/survival/Sleep.ts
  var SLEEP_TIME_SCALE = 12;
  function canSleep(c) {
    if (c.hostileNearby) return { ok: false, reason: "danger" };
    if (c.energy > 85) return { ok: false, reason: "notTired" };
    if (c.bodyTemp < 34.5) return { ok: false, reason: "tooCold" };
    if (c.hunger < 5 || c.thirst < 5) return { ok: false, reason: "tooHungry" };
    return { ok: true };
  }
  function shouldWake(c) {
    return c.damaged || c.hostileNearby || c.energy >= 100 || c.hunger < 5 || c.thirst < 5 || c.bodyTemp < 34;
  }

  // src/survival/Skills.ts
  var SKILL_NAMES = ["survival", "hunting", "crafting", "building"];
  var MAX_SKILL_LEVEL = 10;
  var Skills = class {
    xp = { survival: 0, hunting: 0, crafting: 0, building: 0 };
    onLevelUp = null;
    /** المستوى = floor(sqrt(xp/10)): 10xp⇒1، 40⇒2، 90⇒3 ... */
    level(name) {
      return Math.min(MAX_SKILL_LEVEL, Math.floor(Math.sqrt(this.xp[name] / 10)));
    }
    addXp(name, amount) {
      const before = this.level(name);
      this.xp[name] += amount;
      const after = this.level(name);
      if (after > before) this.onLevelUp?.(name, after);
    }
    /** تقدّم المستوى الحالي 0..1 (لشريط التقدم) */
    progress(name) {
      const lv = this.level(name);
      if (lv >= MAX_SKILL_LEVEL) return 1;
      const a = lv * lv * 10;
      const b = (lv + 1) * (lv + 1) * 10;
      return (this.xp[name] - a) / (b - a);
    }
    /** مكافأة تتحسن مع المستوى (مثلًا نسبة جمع إضافية) */
    bonus(name, perLevel = 0.05) {
      return this.level(name) * perLevel;
    }
    toJSON() {
      return { ...this.xp };
    }
    load(data) {
      for (const k of SKILL_NAMES) this.xp[k] = data[k] ?? 0;
    }
  };

  // src/survival/Stats.ts
  function newStats() {
    return { health: 100, hunger: 85, thirst: 85, energy: 100, stamina: 100, sanity: 100, bodyTemp: 37, wetness: 0 };
  }
  var DIFFICULTY = {
    easy: { drain: 0.6, damage: 0.6, permadeath: false },
    normal: { drain: 1, damage: 1, permadeath: false },
    hard: { drain: 1.35, damage: 1.4, permadeath: false },
    realistic: { drain: 1.6, damage: 1.8, permadeath: true }
  };

  // src/survival/SurvivalSystem.ts
  var FOOD_POISON_HOURS = 8;
  var INFECTION_DELAY_HOURS = 6;
  var BROKEN_LEG_HEAL_HOURS = 48;
  var SurvivalSystem = class {
    constructor(rng = Math.random) {
      this.rng = rng;
    }
    rng;
    stats = newStats();
    conditions = /* @__PURE__ */ new Map();
    difficulty = "normal";
    dead = false;
    deathCause = null;
    /** ساعات منذ بدء النزيف/الجرح غير المعالج (لحساب العدوى) */
    woundHours = 0;
    has(id) {
      return this.conditions.has(id);
    }
    addCondition(id, hours, severity = 0.5) {
      const cur = this.conditions.get(id);
      if (cur) {
        cur.remaining = Math.max(cur.remaining, hours);
        cur.severity = Math.min(1, Math.max(cur.severity, severity));
      } else {
        this.conditions.set(id, { id, remaining: hours, severity });
      }
    }
    cure(id) {
      if (id === "bleeding") this.woundHours = 0;
      return this.conditions.delete(id);
    }
    /** مضاعِف سرعة الحركة بسبب الإصابات */
    get speedMultiplier() {
      let m = 1;
      if (this.has("brokenLeg")) m *= 0.45;
      if (this.stats.energy < 15) m *= 0.8;
      if (this.has("hypothermia")) m *= 0.85;
      return m;
    }
    get canRun() {
      return this.stats.stamina > 8 && !this.has("brokenLeg");
    }
    /** يطبّق تأثيرات عنصر مستهلك (من Inventory.use) */
    consume(effects) {
      const n = (k) => typeof effects[k] === "number" ? effects[k] : 0;
      const s = this.stats;
      s.hunger = clamp2(s.hunger + n("hunger"), 0, 100);
      s.thirst = clamp2(s.thirst + n("thirst"), 0, 100);
      s.health = clamp2(s.health + n("health"), 0, 100);
      s.energy = clamp2(s.energy + n("energy"), 0, 100);
      if (n("stopBleeding")) this.cure("bleeding");
      if (n("cureInfection")) this.cure("infection");
      if (n("healBone")) {
        const leg = this.conditions.get("brokenLeg");
        if (leg) leg.remaining = Math.min(leg.remaining, 12);
      }
      if (n("cureFoodPoison")) this.cure("foodPoisoning");
      if (n("cureSunburn")) this.cure("sunburn");
      if (n("painRelief")) this.cure("pain");
      if (n("preventInfection") && this.has("bleeding")) this.woundHours = Math.max(0, this.woundHours - 6);
      let gotSick = false;
      const sick = n("sick");
      if (sick > 0 && this.rng() < sick) {
        this.addCondition("foodPoisoning", FOOD_POISON_HOURS, Math.min(1, 0.3 + sick * 0.5));
        gotSick = true;
      }
      return { gotSick };
    }
    /** ضرر مباشر مع احتمال نزيف/كسر */
    damage(amount, source, defense = 0) {
      const d = DIFFICULTY[this.difficulty];
      const final = Math.max(0, amount * d.damage * (1 - Math.min(0.7, defense * 0.05)));
      this.stats.health -= final;
      if (source === "cut" || source === "animal") {
        if (this.rng() < 0.35 + final * 0.01) this.addCondition("bleeding", Infinity, Math.min(1, final / 40));
      }
      if (source === "fall" && final >= 15 && this.rng() < Math.min(0.9, final / 40)) {
        this.addCondition("brokenLeg", BROKEN_LEG_HEAL_HOURS, 0.8);
      }
      if (final >= 10) this.addCondition("pain", 2, 0.5);
      this.checkDeath(source);
    }
    /** ضرر السقوط من سرعة هبوط (م/ث) */
    fallDamage(speed) {
      const safe = 9;
      if (speed <= safe) return 0;
      const dmg = (speed - safe) * 9;
      this.damage(dmg, "fall");
      return dmg;
    }
    /** @param dt ثواني حقيقية  @param gameHours ساعات اللعبة المقابلة */
    update(dt, gameHours, ctx) {
      if (this.dead) return;
      const s = this.stats;
      const diff = DIFFICULTY[this.difficulty];
      this.updateStamina(dt, ctx);
      this.updateWetness(gameHours, ctx);
      this.updateTemperature(gameHours, ctx);
      const actMul = { rest: 0.5, idle: 1, walk: 1.3, run: 2, work: 1.8, swim: 2.2 }[ctx.activity];
      const sleepMul = ctx.sleeping ? 0.35 : 1;
      const heatMul = ctx.ambientTemp > 32 ? 1.6 : 1;
      const sickMul = this.has("foodPoisoning") ? 2 : 1;
      s.hunger = clamp2(s.hunger - 3.5 * gameHours * actMul * sleepMul * diff.drain, 0, 100);
      s.thirst = clamp2(s.thirst - 5.5 * gameHours * actMul * sleepMul * heatMul * sickMul * diff.drain, 0, 100);
      if (ctx.sleeping) {
        s.energy = clamp2(s.energy + (ctx.inShelter ? 14 : 8) * gameHours, 0, 100);
      } else {
        const drain = { rest: -2, idle: 1.2, walk: 2, run: 3.5, work: 3, swim: 4 }[ctx.activity];
        s.energy = clamp2(s.energy - drain * gameHours * diff.drain, 0, 100);
      }
      const night = ctx.hour < 5 || ctx.hour > 19.5;
      let sanityRate = 0.5;
      if (night && ctx.fireHeat === 0) sanityRate -= 3;
      if (s.hunger < 20 || s.thirst < 20) sanityRate -= 2;
      if (ctx.fireHeat > 0 || ctx.inShelter) sanityRate += 1.5;
      s.sanity = clamp2(s.sanity + sanityRate * gameHours, 0, 100);
      this.updateConditions(gameHours, ctx);
      let dps = 0;
      if (s.hunger <= 0) dps += 3;
      if (s.thirst <= 0) dps += 6;
      for (const c of this.conditions.values()) dps += conditionDamage(c);
      dps *= diff.damage;
      if (dps > 0) {
        s.health -= dps * gameHours;
      } else if (this.conditions.size === 0 && s.hunger > 50 && s.thirst > 50 && s.bodyTemp > 35.5 && s.bodyTemp < 38.5) {
        s.health = clamp2(s.health + (ctx.sleeping ? 4 : 1.5) * gameHours, 0, 100);
      }
      s.health = Math.min(100, s.health);
      let cause = null;
      if (s.thirst <= 0) cause = "dehydration";
      else if (s.hunger <= 0) cause = "starvation";
      else if (this.has("hypothermia")) cause = "hypothermia";
      else if (this.has("heatstroke")) cause = "heatstroke";
      else if (this.has("infection")) cause = "infection";
      else if (this.has("bleeding")) cause = "bleeding";
      this.checkDeath(cause ?? "unknown");
    }
    updateStamina(dt, ctx) {
      const s = this.stats;
      if (ctx.activity === "run") s.stamina -= 14 * dt * ctx.staminaDrainMult;
      else if (ctx.activity === "swim") s.stamina -= 4 * dt * ctx.staminaDrainMult;
      else s.stamina += (ctx.activity === "rest" || ctx.sleeping ? 25 : 14) * dt * (s.energy / 100 + 0.3);
      s.stamina = clamp2(s.stamina, 0, 100);
      if (ctx.inWater && s.stamina <= 0) this.damage(6 * dt, "drown");
    }
    updateWetness(h2, ctx) {
      const s = this.stats;
      let rate = -0.12;
      if (ctx.isRaining) rate += ctx.rainProof ? 0.08 : 0.5;
      if (ctx.inWater) rate += 3;
      if (ctx.fireHeat > 0) rate -= 0.5 * ctx.fireHeat;
      if (ctx.inShelter && !ctx.isRaining) rate -= 0.1;
      s.wetness = clamp2(s.wetness + rate * h2, 0, 1);
    }
    updateTemperature(h2, ctx) {
      const s = this.stats;
      let eff = ctx.ambientTemp;
      eff += ctx.warmth * 0.9;
      eff += ctx.fireHeat * 16;
      if (ctx.inShelter) eff += 4;
      eff -= s.wetness * (ctx.rainProof ? 4 : 10);
      if (ctx.inWater) eff -= 6;
      if (ctx.activity === "run" || ctx.activity === "work") eff += 3;
      const sunny = ctx.hour > 9 && ctx.hour < 16 && !ctx.inShelter && !ctx.isRaining;
      if (sunny) eff += 4 * (1 - ctx.sunProtection * 0.6);
      const targetBody = clamp2(37 + (eff - 24) * 0.12, 30, 42);
      const speed = 0.35;
      s.bodyTemp += (targetBody - s.bodyTemp) * Math.min(1, speed * h2 * 2);
      s.bodyTemp = clamp2(s.bodyTemp, 28, 43);
    }
    updateConditions(h2, ctx) {
      const s = this.stats;
      this.setDerived("hypothermia", s.bodyTemp < 35, clamp2((35 - s.bodyTemp) / 5, 0.2, 1));
      this.setDerived("heatstroke", s.bodyTemp > 39, clamp2((s.bodyTemp - 39) / 3, 0.2, 1));
      this.setDerived("dehydration", s.thirst < 10, clamp2((10 - s.thirst) / 10, 0.2, 1));
      if (ctx.hour > 10 && ctx.hour < 15 && !ctx.inShelter && !ctx.isRaining && ctx.sunProtection < 0.5 && ctx.ambientTemp > 30) {
        if (this.rng() < 0.02 * h2 * 10) this.addCondition("sunburn", 12, 0.3);
      }
      if (this.has("bleeding")) {
        this.woundHours += h2;
        if (this.woundHours > INFECTION_DELAY_HOURS && !this.has("infection")) this.addCondition("infection", Infinity, 0.5);
      }
      for (const [id, c] of this.conditions) {
        if (!Number.isFinite(c.remaining)) continue;
        if (id === "hypothermia" || id === "heatstroke" || id === "dehydration") continue;
        c.remaining -= h2;
        if (c.remaining <= 0) this.conditions.delete(id);
      }
    }
    setDerived(id, active, severity) {
      if (active) this.addCondition(id, Infinity, severity);
      else this.conditions.delete(id);
    }
    checkDeath(cause) {
      if (this.stats.health <= 0 && !this.dead) {
        this.stats.health = 0;
        this.dead = true;
        this.deathCause = cause;
      }
    }
    get permadeath() {
      return DIFFICULTY[this.difficulty].permadeath;
    }
    load(d) {
      this.stats = { ...newStats(), ...d.stats };
      this.conditions.clear();
      for (const c of d.conditions) this.conditions.set(c.id, { ...c, remaining: c.remaining === null || c.remaining === void 0 ? Infinity : c.remaining });
      this.difficulty = d.difficulty;
      this.woundHours = d.woundHours ?? 0;
      this.dead = this.stats.health <= 0;
    }
    toJSON() {
      return { stats: { ...this.stats }, conditions: [...this.conditions.values()].map((c) => ({ ...c })), difficulty: this.difficulty, woundHours: this.woundHours, dead: this.dead, deathCause: this.deathCause };
    }
  };
  function conditionDamage(c) {
    switch (c.id) {
      case "bleeding":
        return 3 * (0.5 + c.severity);
      case "infection":
        return 2 * (0.5 + c.severity);
      case "foodPoisoning":
        return 1.5 * c.severity * 2;
      case "heatstroke":
        return 4 * c.severity;
      case "hypothermia":
        return 3 * c.severity;
      case "dehydration":
        return 1 * c.severity;
      case "sunburn":
        return 0.4;
      default:
        return 0;
    }
  }
  function clamp2(v, a, b) {
    return Math.max(a, Math.min(b, v));
  }

  // src/world/GroundItems.ts
  var DESPAWN_SECONDS = 600;
  var MERGE_RADIUS = 0.6;
  var GroundItems = class {
    items = /* @__PURE__ */ new Map();
    nextId = 1;
    onChanged = null;
    list() {
      return [...this.items.values()];
    }
    get size() {
      return this.items.size;
    }
    /** يرمي مكدّسًا؛ المتماثلات القريبة تندمج لتفادي تكدّس الكيانات */
    drop(stack, x, y, z) {
      const def = ItemDB.get(stack.defId);
      if (def.stack > 1) {
        for (const it of this.items.values()) {
          if (it.stack.defId !== stack.defId || it.stack.count >= def.stack) continue;
          if (Math.hypot(it.x - x, it.z - z) > MERGE_RADIUS) continue;
          const room = def.stack - it.stack.count;
          const moved = Math.min(room, stack.count);
          it.stack.count += moved;
          stack.count -= moved;
          it.age = 0;
          this.onChanged?.(it, false);
          if (stack.count <= 0) return it;
        }
      }
      const item = { id: this.nextId++, stack, x, y, z, age: 0 };
      this.items.set(item.id, item);
      this.onChanged?.(item, false);
      return item;
    }
    dropNew(defId, count, x, y, z) {
      return this.drop(ItemDB.create(defId, count), x, y, z);
    }
    /** أقرب عنصر ضمن مسافة */
    nearest(x, z, r) {
      let best = null;
      let bd = r;
      for (const it of this.items.values()) {
        const d = Math.hypot(it.x - x, it.z - z);
        if (d <= bd) {
          bd = d;
          best = it;
        }
      }
      return best;
    }
    /** يلتقط عنصرًا إلى الحقيبة؛ ما لا يتسع يبقى على الأرض */
    pickup(id, inv) {
      const it = this.items.get(id);
      if (!it) return { ok: false, picked: 0, left: 0 };
      const before = it.stack.count;
      const left = inv.add(it.stack.defId, it.stack.count, { durability: it.stack.durability, spoil: it.stack.spoil });
      if (left < before && ItemDB.get(it.stack.defId).durability > 0) {
        const e = inv.grid.list().filter((g) => g.stack.defId === it.stack.defId).pop();
        if (e) e.stack.durability = it.stack.durability;
      }
      if (left === 0) {
        this.items.delete(id);
        this.onChanged?.(it, true);
      } else {
        it.stack.count = left;
        this.onChanged?.(it, false);
      }
      return { ok: left < before, picked: before - left, left };
    }
    toJSON() {
      return this.list();
    }
    load(items) {
      this.items.clear();
      let maxUid = 0;
      for (const it of items) {
        this.items.set(it.id, it);
        this.nextId = Math.max(this.nextId, it.id + 1);
        maxUid = Math.max(maxUid, it.stack.uid);
        this.onChanged?.(it, false);
      }
      ensureUidAbove(maxUid);
    }
    /** @param dt ثواني حقيقية */
    update(dt) {
      for (const it of [...this.items.values()]) {
        it.age += dt;
        if (it.age >= DESPAWN_SECONDS) {
          this.items.delete(it.id);
          this.onChanged?.(it, true);
        }
      }
    }
  };

  // src/world/ResourceField.ts
  var CELL = 16;
  var ResourceField = class _ResourceField {
    nodes = /* @__PURE__ */ new Map();
    buckets = /* @__PURE__ */ new Map();
    nextId = 1;
    /** عدّاد ساعات اللعبة التراكمي */
    hours = 0;
    onChanged = null;
    static key(cx, cz) {
      return `${cx},${cz}`;
    }
    get size() {
      return this.nodes.size;
    }
    all() {
      return [...this.nodes.values()];
    }
    get(id) {
      return this.nodes.get(id);
    }
    add(kind, x, y, z, scale2 = 1, rotY = 0) {
      const n = { id: this.nextId++, kind, x, y, z, scale: scale2, rotY, hp: NODE_DEFS[kind].hp, alive: true, respawnAt: 0 };
      this.nodes.set(n.id, n);
      const k = _ResourceField.key(Math.floor(x / CELL), Math.floor(z / CELL));
      const b = this.buckets.get(k);
      if (b) b.push(n);
      else this.buckets.set(k, [n]);
      return n;
    }
    /** يحذف عقدة نهائيًا (لا تعود). يستخدم لموارد وُلّدت فوق مواقع محجوزة */
    remove(id) {
      const n = this.nodes.get(id);
      if (!n) return false;
      this.nodes.delete(id);
      const b = this.buckets.get(_ResourceField.key(Math.floor(n.x / CELL), Math.floor(n.z / CELL)));
      if (b) b.splice(b.indexOf(n), 1);
      return true;
    }
    /** العقد الحية ضمن نصف قطر */
    nearby(x, z, r, aliveOnly = true) {
      const out = [];
      const c0x = Math.floor((x - r) / CELL);
      const c1x = Math.floor((x + r) / CELL);
      const c0z = Math.floor((z - r) / CELL);
      const c1z = Math.floor((z + r) / CELL);
      for (let cx = c0x; cx <= c1x; cx++) {
        for (let cz = c0z; cz <= c1z; cz++) {
          const b = this.buckets.get(_ResourceField.key(cx, cz));
          if (!b) continue;
          for (const n of b) {
            if (aliveOnly && !n.alive) continue;
            if (Math.hypot(n.x - x, n.z - z) <= r) out.push(n);
          }
        }
      }
      return out;
    }
    /** أقرب عقدة تقطعها الأسطوانة العمودية على امتداد شعاع */
    raycast(ox, oy, oz, dx, dy, dz, maxDist) {
      const len2 = Math.hypot(dx, dy, dz) || 1;
      dx /= len2;
      dy /= len2;
      dz /= len2;
      const step = 0.1;
      const ex = ox + dx * maxDist;
      const ez = oz + dz * maxDist;
      const cands = this.nearby((ox + ex) / 2, (oz + ez) / 2, maxDist / 2 + 2.5);
      if (cands.length === 0) return null;
      let best = null;
      for (let t2 = 0; t2 <= maxDist; t2 += step) {
        const px = ox + dx * t2;
        const py = oy + dy * t2;
        const pz = oz + dz * t2;
        for (const n of cands) {
          const def = NODE_DEFS[n.kind];
          const r = def.radius * n.scale;
          const h2 = def.height * n.scale;
          const ddx = px - n.x;
          const ddz = pz - n.z;
          if (ddx * ddx + ddz * ddz <= r * r && py >= n.y - 0.1 && py <= n.y + h2) {
            if (!best || t2 < best.distance) best = { node: n, distance: t2 };
          }
        }
        if (best) return best;
      }
      return best;
    }
    /** ضربة على عقدة؛ تُحدّد وقت العودة عند الاستنفاد */
    hit(id, tool, rnd, gatherBonus = 0) {
      const n = this.nodes.get(id);
      if (!n) return { ok: false, reason: "dead", damage: 0, destroyed: false, drops: [] };
      const res = applyHit(n, tool, rnd, gatherBonus);
      if (res.ok && res.destroyed) {
        n.alive = false;
        n.respawnAt = this.hours + NODE_DEFS[n.kind].respawnHours;
        this.onChanged?.(n);
      }
      return res;
    }
    /** تقدّم الساعات وتعيد العقد المنتهية فترتها */
    update(dtHours) {
      this.hours += dtHours;
      for (const n of this.nodes.values()) {
        if (!n.alive && this.hours >= n.respawnAt) {
          n.alive = true;
          n.hp = NODE_DEFS[n.kind].hp;
          this.onChanged?.(n);
        }
      }
    }
    toJSON() {
      return { hours: this.hours, dead: this.all().filter((n) => !n.alive).map((n) => ({ id: n.id, respawnAt: n.respawnAt })) };
    }
    /** يطبّق حالة محفوظة على عالم مولّد بنفس البذرة (المعرّفات حتمية) */
    load(data) {
      this.hours = data.hours;
      for (const n of this.nodes.values()) {
        if (!n.alive) {
          n.alive = true;
          n.hp = NODE_DEFS[n.kind].hp;
          this.onChanged?.(n);
        }
      }
      for (const d of data.dead) {
        const n = this.nodes.get(d.id);
        if (n) {
          n.alive = false;
          n.respawnAt = d.respawnAt;
          this.onChanged?.(n);
        }
      }
    }
  };

  // src/world/ScatterGenerator.ts
  var RULES = [
    { kind: "palm", spacing: 8, probability: 0.55, biomes: ["beach", "grass"], minH: 1.4, maxH: 9, maxSlope: 0.35, scale: [0.85, 1.25] },
    { kind: "jungleTree", spacing: 5, probability: 0.8, biomes: ["jungle", "grass"], minH: 2.5, maxH: 28, maxSlope: 0.5, scale: [0.8, 1.4] },
    { kind: "boulder", spacing: 12, probability: 0.55, biomes: ["beach", "grass", "rock", "jungle"], minH: 1, maxH: 38, maxSlope: 0.7, scale: [0.7, 1.8] },
    { kind: "ironRock", spacing: 34, probability: 0.8, biomes: ["rock", "volcanic"], minH: 12, maxH: 45, maxSlope: 0.8, scale: [0.9, 1.3] },
    { kind: "copperRock", spacing: 44, probability: 0.8, biomes: ["rock", "volcanic"], minH: 10, maxH: 45, maxSlope: 0.8, scale: [0.9, 1.3] },
    { kind: "berryBush", spacing: 11, probability: 0.55, biomes: ["grass", "jungle"], minH: 2.5, maxH: 25, maxSlope: 0.4, scale: [0.8, 1.2] },
    { kind: "fiberPlant", spacing: 6, probability: 0.6, biomes: ["grass", "jungle", "beach"], minH: 1.5, maxH: 25, maxSlope: 0.4, scale: [0.8, 1.3] },
    { kind: "bamboo", spacing: 14, probability: 0.7, biomes: ["jungle"], minH: 3, maxH: 20, maxSlope: 0.35, minMoisture: 0.62, scale: [0.9, 1.2] },
    { kind: "mushroomPatch", spacing: 16, probability: 0.5, biomes: ["jungle"], minH: 4, maxH: 25, maxSlope: 0.35, minMoisture: 0.55, scale: [0.9, 1.2] },
    { kind: "clayBank", spacing: 40, probability: 0.6, biomes: ["beach", "grass"], minH: 1, maxH: 4, maxSlope: 0.15, scale: [1, 1.4] }
  ];
  function scatterResources(sampler, field, seed, opts) {
    let count = 0;
    for (const rule of RULES) {
      const rnd = new Random(`${seed}:${rule.kind}`);
      const n = Math.floor(opts.half * 2 / rule.spacing);
      for (let j = 0; j < n; j++) {
        for (let i = 0; i < n; i++) {
          const jx = rnd.next();
          const jz = rnd.next();
          const accept = rnd.next();
          const sc = rnd.range(rule.scale[0], rule.scale[1]);
          const rot = rnd.range(0, Math.PI * 2);
          const x = -opts.half + (i + jx) * rule.spacing;
          const z = -opts.half + (j + jz) * rule.spacing;
          if (accept > rule.probability) continue;
          const h2 = sampler.height(x, z);
          if (h2 < rule.minH || h2 > rule.maxH) continue;
          if (sampler.slope(x, z) > rule.maxSlope) continue;
          if (!rule.biomes.includes(sampler.biomeAt(x, z))) continue;
          if (rule.minMoisture !== void 0 && sampler.moisture(x, z) < rule.minMoisture) continue;
          if (opts.keepClear?.some((c) => Math.hypot(c.x - x, c.z - z) < c.r)) continue;
          field.add(rule.kind, x, h2, z, sc, rot);
          count++;
        }
      }
    }
    return count;
  }

  // src/core/GameSession.ts
  var SAVE_VERSION = 1;
  var CRAFT_STATION_RANGE = 4;
  var FIRE_RANGE = 3.5;
  var GameSession = class {
    constructor(seed, terrain2, difficulty = "normal") {
      this.seed = seed;
      this.terrain = terrain2;
      this.rnd = new Random(`${seed}:session`);
      this.fishing = new Fishing(this.rnd);
      this.survival = new SurvivalSystem(() => this.rnd.next());
      this.survival.difficulty = difficulty;
      this.quests = new QuestManager({
        itemCount: (id) => this.inventory.count(id),
        giveReward: (r) => {
          for (const it of r.items ?? []) this.giveItem(it.id, it.count);
          for (const x of r.xp ?? []) this.skills.addXp(x.skill, x.amount);
          for (const id of r.recipes ?? []) this.recipes.unlock(id);
        }
      });
      this.journal.attach(this.quests, () => this.day);
      const prev = this.quests.onUpdate;
      this.quests.onUpdate = (id, kind) => {
        prev?.(id, kind);
        this.emit({ type: "questUpdate", id, kind });
      };
      this.skills.onLevelUp = (skill, level) => this.emit({ type: "levelUp", skill, level });
      this.inventory.onChange = () => this.onInventoryChanged();
      this.buildings = new BuildingGrid({ height: (x, z) => terrain2.height(x, z), slope: (x, z) => terrain2.slope(x, z), waterLevel: 0 });
      const sp2 = terrain2.spawn;
      const peak = this.findPeak();
      const inland = this.dirTo(sp2, { x: 0, z: 0 });
      const wreck = this.inlandPoint(sp2, inland, 55);
      const camp = this.inlandPoint(sp2, inland, 22);
      const cave = terrain2.caveSites[0];
      this.places = {
        camp,
        beach: { x: sp2.x, z: sp2.z },
        wreck,
        forest: this.inlandPoint(sp2, inland, 90),
        cave: cave ? { x: cave.x, z: cave.z } : camp,
        peak,
        bunker: { x: peak.x + 14, z: peak.z + 6 }
      };
      const lm = (id, ar, en, icon, r, known = false) => ({ id, nameAr: ar, nameEn: en, icon, radius: r, known, x: this.places[id].x, z: this.places[id].z });
      this.map = new MapData([
        lm("beach", "\u0627\u0644\u0634\u0627\u0637\u0626", "Beach", "\u{1F3D6}\uFE0F", 25, true),
        lm("camp", "\u0627\u0644\u0645\u062E\u064A\u0645", "Camp", "\u26FA", 15),
        lm("wreck", "\u062D\u0637\u0627\u0645 \u0627\u0644\u0637\u0627\u0626\u0631\u0629", "Plane Wreck", "\u2708\uFE0F", 22),
        lm("forest", "\u0627\u0644\u063A\u0627\u0628\u0629", "Forest", "\u{1F334}", 30),
        ...cave ? [lm("cave", "\u0627\u0644\u0643\u0647\u0641", "Cave", "\u{1F573}\uFE0F", 18)] : [],
        lm("peak", "\u0627\u0644\u0642\u0645\u0629", "Peak", "\u26F0\uFE0F", 14),
        lm("bunker", "\u0645\u062F\u062E\u0644 \u0627\u0644\u0645\u062E\u0628\u0623", "Bunker Entrance", "\u{1F6AA}", 9)
      ]);
      const keepClear = [{ x: sp2.x, z: sp2.z, r: 10 }, { x: wreck.x, z: wreck.z, r: 8 }, { x: camp.x, z: camp.z, r: 6 }];
      const sampler = terrain2;
      scatterResources(sampler, this.resources, seed, {
        half: terrain2.half,
        keepClear
      });
      for (const n of this.resources.all()) if (terrain2.insideCaveFootprint(n.x, n.z)) this.resources.remove(n.id);
      this.animals.populate(sampler, seed, terrain2.half, keepClear);
      this.animals.onKilled = (a, drops) => this.onAnimalKilled(a, drops);
      this.npcs = NPC_DEFS.map((def) => new NPC(def, this.npcStart(def.id)));
      this.placeStoryItems();
      this.gatherer = new Gatherer(this.resources, this.ground, this.inventory, this.skills, this.recipes, this.rnd);
      this.inventory.grid.resize(4, 2);
      this.inventory.add("bandage", 1);
      this.inventory.add("bottle_empty", 1);
      this.noteStartingItems();
      this.quests.onInventoryChanged();
      this.map.update(sp2.x, sp2.z);
    }
    seed;
    terrain;
    rnd;
    survival;
    inventory = new Inventory();
    skills = new Skills();
    recipes = new RecipeBook();
    quests;
    journal = new Journal();
    map;
    resources = new ResourceField();
    ground = new GroundItems();
    animals = new AnimalManager();
    buildings;
    craftQueue = new CraftQueue();
    npcs;
    gatherer;
    places;
    fires = /* @__PURE__ */ new Map();
    stations = /* @__PURE__ */ new Map();
    containers = /* @__PURE__ */ new Map();
    story = [];
    farms = /* @__PURE__ */ new Map();
    fishing;
    /** نقطة رمي الصنارة (للعوّامة) */
    castPos = null;
    fishPrev = "idle";
    totalHours = 7.5;
    // الصباح
    playTime = 0;
    sleeping = false;
    ending = null;
    signalDay = null;
    /** آخر ساعة تم فيها إشعار dayPassed */
    lastDay = 0;
    mapTimer = 0;
    recentDamage = false;
    wakeReason = null;
    events = [];
    onEvent = null;
    // ======================= أدوات تهيئة =======================
    findPeak() {
      const t2 = this.terrain;
      let best = { x: 0, z: 0, h: -Infinity };
      for (let z = -120; z <= 120; z += 4) for (let x = -120; x <= 120; x += 4) {
        const h2 = t2.height(x, z);
        if (h2 > best.h) best = { x, z, h: h2 };
      }
      return { x: best.x, z: best.z };
    }
    dirTo(a, b) {
      const dx = b.x - a.x;
      const dz = b.z - a.z;
      const l = Math.hypot(dx, dz) || 1;
      return { x: dx / l, z: dz / l };
    }
    /** نقطة على الخط نحو الداخل؛ إن كانت مغمورة نتقدم حتى تجد يابسة */
    inlandPoint(from, dir, dist) {
      for (let d = dist; d < dist + 80; d += 3) {
        const x = from.x + dir.x * d;
        const z = from.z + dir.z * d;
        if (this.terrain.height(x, z) > 1.8 && this.terrain.slope(x, z) < 0.45) return { x, z };
      }
      return { x: from.x + dir.x * dist, z: from.z + dir.z * dist };
    }
    npcStart(id) {
      const def = NPC_DEFS.find((d) => d.id === id);
      const entry = def.schedule.find((s) => s.from <= s.to ? 8 >= s.from && 8 < s.to : 8 >= s.from || 8 < s.to);
      return { ...this.places[entry?.place ?? "camp"] ?? this.places.camp };
    }
    placeStoryItems() {
      const w = this.places.wreck;
      const b = this.places.bunker;
      const at = (p, dx, dz) => ({ x: p.x + dx, y: this.terrain.height(p.x + dx, p.z + dz), z: p.z + dz });
      const add = (id, p, dx, dz, item, count = 1, extra = {}) => {
        this.story.push({ id, ...at(p, dx, dz), item, count, taken: false, ...extra });
      };
      add("w_sail", w, 3, 2, "sail_cloth");
      add("w_scrap", w, -4, 1, "scrap_metal", 4);
      add("w_engine", w, 5, -3, "engine_part");
      add("w_flare", w, -2, -4, "flare_gun");
      add("w_photo", w, 1, 5, "old_photo");
      add("w_fuel", w, -5, -2, "fuel_can");
      add("w_food", w, 2, -2, "canned_beans", 2);
      add("w_map", w, 6, 4, "map_piece");
      add("w_p1", w, -1, 3, "journal_page", 1, { page: "pilot_1" });
      add("w_p2", w, 4, 0, "journal_page", 1, { page: "pilot_2" });
      add("w_p3", w, -3, 5, "journal_page", 1, { page: "pilot_3" });
      add("b_rec", b, 2, 2, "flight_recorder", 1, { requires: "bunker_key" });
      add("b_phone", b, -2, 2, "satellite_phone", 1, { requires: "bunker_key" });
      add("b_p1", b, 0, 3, "journal_page", 1, { page: "bunker_1", requires: "bunker_key" });
      add("b_p2", b, 3, -1, "journal_page", 1, { page: "bunker_2", requires: "bunker_key" });
      add("b_kit", b, -3, -2, "antibiotic", 2, { requires: "bunker_key" });
      add("b_bat", b, 1, -3, "radio_battery", 1, { requires: "bunker_key" });
    }
    noteStartingItems() {
      for (const e of this.inventory.grid.list()) this.recipes.noteItem(e.stack.defId);
    }
    // ======================= حالات =======================
    get hour() {
      return hourOf(this.totalHours);
    }
    get day() {
      return dayOf(this.totalHours);
    }
    emit(e) {
      this.events.push(e);
      this.onEvent?.(e);
    }
    notify(ar, en) {
      this.emit({ type: "notify", ar, en });
    }
    /** يفرّغ الأحداث المتراكمة (للواجهة) */
    drainEvents() {
      const e = this.events;
      this.events = [];
      return e;
    }
    onInventoryChanged() {
      const opened = [];
      for (const e of this.inventory.grid.list()) for (const r of this.recipes.noteItem(e.stack.defId)) opened.push(r.id);
      if (opened.length) this.emit({ type: "newRecipes", ids: opened });
      this.quests.onInventoryChanged();
    }
    giveItem(id, count) {
      const left = this.inventory.add(id, count);
      if (left > 0) {
        const p = this.places.camp;
        this.ground.dropNew(id, left, p.x, this.terrain.height(p.x, p.z), p.z);
      }
    }
    /** نقطة الظهور (قدما اللاعب) */
    get spawnPoint() {
      const s = this.terrain.spawn;
      return { x: s.x, y: s.y, z: s.z };
    }
    placeAt(x, y, z) {
      const named = this.map.placeAt(x, z);
      if (named) return named;
      if (Math.hypot(x, z) > 235 && this.terrain.height(x, z) < -8) return "open_sea";
      void y;
      return null;
    }
    // ======================= التحديث =======================
    /**
     * @param dt ثواني حقيقية
     * @param p حالة اللاعب
     * @param env الطقس والبيئة
     */
    update(dt, p, env) {
      if (this.ending) return;
      this.playTime += dt;
      const timeScale = this.sleeping ? SLEEP_TIME_SCALE : 1;
      const dh = dt * HOURS_PER_REAL_SECOND * timeScale;
      this.totalHours += dh;
      const day = this.day;
      if (day !== this.lastDay) {
        this.lastDay = day;
        this.quests.notify({ type: "dayPassed", day });
      }
      const inShelter = this.buildings.isSheltered(p.x, p.z) || env.inCave;
      const fireHeat = this.heatAt(p.x, p.z);
      const alt = this.terrain.height(p.x, p.z);
      const ambient = ambientTemperature(this.hour, env.weatherTempDelta, alt) + (env.inCave ? -2 : 0);
      const load = this.inventory.burden;
      const eq = this.inventory.equipment;
      const ctx = {
        ambientTemp: ambient,
        isRaining: env.rainIntensity > 0.15 && !inShelter,
        inWater: p.inWater,
        fireHeat,
        inShelter,
        activity: activityFrom(p.loco, p.working, this.sleeping),
        sleeping: this.sleeping,
        hour: this.hour,
        warmth: eq.warmth,
        sunProtection: eq.sunProtection,
        rainProof: eq.rainProof,
        staminaDrainMult: load.staminaDrainMultiplier
      };
      const hpBefore = this.survival.stats.health;
      this.survival.update(dt, dh, ctx);
      this.recentDamage = this.survival.stats.health < hpBefore - 0.01 && this.survival.conditions.size === 0;
      this.inventory.updateSpoil(dh);
      for (const c of this.containers.values()) c.updateSpoil(dh);
      for (const [id, f] of this.fires) {
        f.update(dh * 60, env.rainIntensity, Math.hypot(env.windX, env.windZ));
        void id;
      }
      for (const [id, st] of this.stations) st.update(dt, this.stationHeat(id));
      for (const plot of this.farms.values()) plot.update(dh, env.rainIntensity);
      this.updateFishing(dt, p);
      this.resources.update(dh);
      this.ground.update(dt);
      this.gatherer.update(dt);
      for (const ev of this.craftQueue.update(dt, this.inventory, this.craftContext(p))) {
        const out = ev.recipe.output;
        if (ev.overflow > 0) this.ground.dropNew(out.id, ev.overflow, p.x, p.y, p.z);
        this.quests.notify({ type: "crafted", item: out.id, count: out.count });
        const d = ItemDB.get(out.id);
        this.notify(`\u062A\u0645 \u0635\u0646\u0639 ${d.nameAr}`, `Crafted ${d.nameEn}`);
      }
      for (const n of this.npcs) n.update(dt, this.hour, this.places);
      this.animals.update(dt, this.aiWorld(p, env));
      this.mapTimer -= dt;
      if (this.mapTimer <= 0) {
        this.mapTimer = 0.5;
        for (const l of this.map.update(p.x, p.z)) this.emit({ type: "landmark", landmark: l });
        const place = this.placeAt(p.x, p.y, p.z);
        if (place) this.quests.notify({ type: "arrived", place });
      }
      if (this.sleeping) {
        const wake = shouldWake({
          energy: this.survival.stats.energy,
          hostileNearby: this.hostileNearby(p),
          inShelterOrBed: inShelter,
          bodyTemp: this.survival.stats.bodyTemp,
          hunger: this.survival.stats.hunger,
          thirst: this.survival.stats.thirst,
          damaged: this.recentDamage
        });
        if (wake) this.wake();
      }
      this.checkEnding(p);
    }
    wake() {
      this.sleeping = false;
      this.emit({ type: "woke" });
    }
    checkEnding(p) {
      const id = evaluateEnding({
        flags: this.quests.flags,
        place: this.placeAt(p.x, p.y, p.z),
        has: (i) => this.inventory.has(i),
        alive: !this.survival.dead,
        day: this.day,
        signalDay: this.signalDay
      });
      if (id) {
        this.ending = id;
        this.emit({ type: "ending", id });
      }
    }
    hostileNearby(p) {
      for (const a of this.animals.animals) {
        if (!a.alive || a.species.temperament === "prey") continue;
        if (Math.hypot(a.pos.x - p.x, a.pos.z - p.z) < 25 && (a.state === "chase" || a.state === "attack" || a.species.temperament === "predator")) return true;
      }
      return false;
    }
    aiWorld(p, env) {
      const t2 = this.terrain;
      const night = this.hour < 5.5 || this.hour >= 19;
      const noise = playerNoise(p.working ? "fight" : p.loco === "run" ? "run" : p.loco === "walk" ? "walk" : p.loco === "crouch" ? "crouch" : p.loco === "swim" ? "swim" : p.loco === "jump" ? "jump" : "idle");
      const vis = (night ? 0.55 : 1) * (p.loco === "crouch" ? 0.6 : 1) * (this.sleeping ? 0.4 : 1);
      return {
        height: (x, z) => t2.height(x, z),
        slope: (x, z) => t2.slope(x, z),
        biomeAt: (x, z) => t2.biomeAt(x, z),
        hour: this.hour,
        wind: { x: env.windX, z: env.windZ },
        rnd: this.rnd,
        player: { pos: { x: p.x, z: p.z }, stimulus: { pos: { x: p.x, z: p.z }, noise, visibility: vis }, inWater: p.inWater, alive: !this.survival.dead, y: p.y },
        onAttackPlayer: (dmg, by) => {
          const defense = this.inventory.equipment.defense;
          this.survival.damage(dmg, by.species.id === "snake" ? "cut" : "animal", defense);
          this.recentDamage = true;
          if (this.sleeping) this.wake();
        }
      };
    }
    // ======================= النار والمحطات =======================
    heatAt(x, z) {
      let h2 = 0;
      for (const [id, f] of this.fires) {
        const piece = this.buildings.get(id);
        if (!piece) continue;
        h2 = Math.max(h2, f.heatAt(Math.hypot(piece.x - x, piece.z - z)));
      }
      return h2;
    }
    /** حرارة محطة: النار نفسها، والرف يستفيد من أقوى نار قريبة */
    stationHeat(pieceId) {
      const own = this.fires.get(pieceId);
      if (own) return own.burning ? own.strength : 0;
      const piece = this.buildings.get(pieceId);
      if (!piece) return 0;
      let best = 0;
      for (const [fid, f] of this.fires) {
        const fp = this.buildings.get(fid);
        if (fp && f.burning && Math.hypot(fp.x - piece.x, fp.z - piece.z) <= 4) best = Math.max(best, f.strength * 0.8);
      }
      return best;
    }
    /** يضيف وقودًا من الحقيبة إلى نار قطعة */
    addFuel(pieceId, itemId, count = 1) {
      const fire = this.fires.get(pieceId);
      if (!fire || !Fire.isFuel(itemId)) return false;
      const n = Math.min(count, this.inventory.count(itemId));
      if (n <= 0) return false;
      this.inventory.remove(itemId, n);
      fire.addFuel(itemId, n);
      return true;
    }
    /** إشعال نار بأفضل أداة في الحقيبة. @returns null إن لا أداة */
    ignite(pieceId, rainIntensity) {
      const fire = this.fires.get(pieceId);
      if (!fire) return { ok: false, reason: "noFire" };
      if (fire.fuel <= 0) return { ok: false, reason: "noFuel" };
      let best = null;
      for (const e of this.inventory.grid.list()) {
        const d = ItemDB.get(e.stack.defId);
        const p = typeof d.effects.ignite === "number" ? d.effects.ignite : 0;
        if (p > 0 && e.stack.durability !== 0 && (!best || p > best.p)) best = { uid: e.stack.uid, p, id: d.id };
      }
      if (!best) return { ok: false, reason: "noTool" };
      const ok = fire.ignite(best.p, this.rnd.next(), rainIntensity);
      if (best.id === "matches") this.inventory.remove("matches", 1);
      else this.inventory.damage(best.uid, 1);
      if (ok) {
        this.quests.notify({ type: "flag", flag: "fire_lit" });
        if (this.hasSignalPotential(pieceId)) this.lightSignal();
      }
      return ok ? { ok: true, tool: best.id } : { ok: false, reason: "failed", tool: best.id };
    }
    /** نار كبيرة على القمة بوقود كافٍ تُحتسب نار إشارة */
    hasSignalPotential(pieceId) {
      const piece = this.buildings.get(pieceId);
      const fire = this.fires.get(pieceId);
      if (!piece || !fire) return false;
      return this.map.placeAt(piece.x, piece.z) === "peak" && fire.fuel >= 120 && this.quests.flags.has("ending_rescue_ready") === false && this.quests.status("signal_fire") === "active";
    }
    lightSignal() {
      this.signalDay = this.day;
      this.quests.notify({ type: "flag", flag: "signal_lit" });
      this.notify("\u0623\u064F\u0634\u0639\u0644\u062A \u0646\u0627\u0631 \u0627\u0644\u0625\u0634\u0627\u0631\u0629! \u0627\u0628\u0642\u064E \u062D\u064A\u064B\u0627 \u062D\u062A\u0649 \u062A\u0635\u0644 \u0627\u0644\u0645\u0631\u0648\u062D\u064A\u0629.", "Signal fire lit! Survive until the helicopter arrives.");
    }
    /** المحطات المتاحة قرب اللاعب لسياق الصنع */
    nearbyStations(p) {
      const s = /* @__PURE__ */ new Set(["hand"]);
      for (const piece of this.buildings.list()) {
        const d = Math.hypot(piece.x - p.x, piece.z - p.z);
        if (piece.type === "workbench" && d <= CRAFT_STATION_RANGE) s.add("workbench");
      }
      return s;
    }
    craftContext(p) {
      return { stations: this.nearbyStations(p), skills: this.skills };
    }
    /** محطة معالجة (موقد/فرن/رف) ضمن مدى اللاعب */
    nearestProcessing(p, kind) {
      let best = null;
      for (const [id, st] of this.stations) {
        if (st.config.station !== kind) continue;
        const piece = this.buildings.get(id);
        if (!piece) continue;
        const d = Math.hypot(piece.x - p.x, piece.z - p.z);
        if (d <= FIRE_RANGE && (!best || d < best.d)) best = { pieceId: id, d };
      }
      return best ? { pieceId: best.pieceId, station: this.stations.get(best.pieceId), fire: this.fires.get(best.pieceId) ?? null } : null;
    }
    // ======================= أفعال اللاعب =======================
    /** ضربة جمع/قطع. تستهلك النفَس وتعيد النتيجة */
    swing(origin, dir, feet) {
      const r = this.gatherer.swing(origin, dir, this.survival.stats.stamina, feet);
      const cost = r.staminaCost;
      if (cost) this.survival.stats.stamina = Math.max(0, this.survival.stats.stamina - cost);
      if (r.kind === "hit" || r.kind === "destroyed") this.quests.onInventoryChanged();
      return r;
    }
    /** هجوم على حيوان بالسلاح الممسوك */
    attack(p, env) {
      const held = this.inventory.held;
      const def = held ? ItemDB.get(held.defId) : null;
      const dmg = def && typeof def.effects.damage === "number" && held && held.durability !== 0 ? def.effects.damage : 4;
      const reach = def && def.id.startsWith("spear") ? 3.2 : 2.4;
      const res = this.animals.playerAttack(this.aiWorld({ ...p, y: 0, loco: "idle", inWater: false, working: true }, env), p, p.yaw, dmg, reach);
      if (res.hit && held && def && def.durability > 0) this.inventory.damage(held.uid, 1);
      if (res.hit) this.skills.addXp("hunting", res.killed ? 6 : 1);
      return { ...res, weapon: def?.id ?? null };
    }
    onAnimalKilled(a, drops) {
      for (const d of drops) this.ground.dropNew(d.id, d.count, a.pos.x + this.rnd.range(-0.4, 0.4), a.y, a.pos.z + this.rnd.range(-0.4, 0.4));
      this.quests.notify({ type: "killed", species: a.species.id });
      this.emit({ type: "animalKilled", species: a.species.id });
    }
    /** يستهلك عنصرًا (طعام/ماء/دواء/قصة) */
    useItem(uid, p) {
      const e = this.inventory.grid.get(uid);
      if (!e) return { ok: false, reason: "notFound", effects: {}, state: "none" };
      const def = ItemDB.get(e.stack.defId);
      if (def.type === "story") return useStoryItem(def.id, this.actionHooks(), this.placeAt(p.x, p.y, p.z));
      if (def.id === "bottle_empty" || def.id === "canteen_empty") return this.fillContainerItem(uid, p);
      const r = this.inventory.use(uid);
      if (r.ok) {
        const { gotSick } = this.survival.consume(r.effects);
        if (gotSick) this.notify("\u0634\u0639\u0631\u062A \u0628\u0627\u0644\u063A\u062B\u064A\u0627\u0646... \u0631\u0628\u0645\u0627 \u0623\u0643\u0644\u062A \u0634\u064A\u0626\u064B\u0627 \u0641\u0627\u0633\u062F\u064B\u0627.", "You feel nauseous... something was off.");
        if (r.state === "rotten") this.notify("\u0643\u0627\u0646 \u0627\u0644\u0637\u0639\u0627\u0645 \u0641\u0627\u0633\u062F\u064B\u0627!", "That food was rotten!");
      }
      return r;
    }
    /** تعبئة زجاجة/قربة من ماء بحر مالح؟ لا: ماء عذب من المطر فقط، وإلا ماء ملوث من البرك */
    fillContainerItem(uid, p) {
      const e = this.inventory.grid.get(uid);
      if (!e) return { ok: false, reason: "notFound" };
      const isCanteen = e.stack.defId === "canteen_empty";
      const nearCollector = this.buildings.list().some((b) => b.type === "collector" && Math.hypot(b.x - p.x, b.z - p.z) < 3);
      const h2 = this.terrain.height(p.x, p.z);
      const inShallows = h2 < 0.3 && h2 > -2;
      if (!nearCollector && !inShallows) return { ok: false, reason: "noWater" };
      this.inventory.remove(e.stack.defId, 1);
      this.giveItem(isCanteen ? "canteen_full" : nearCollector ? "rainwater" : "water_dirty", 1);
      return { ok: true };
    }
    actionHooks() {
      return {
        inv: this.inventory,
        quests: this.quests,
        dropOverflow: (id, n) => {
          const p = this.places.camp;
          this.ground.dropNew(id, n, p.x, this.terrain.height(p.x, p.z), p.z);
        },
        notify: (ar, en) => this.notify(ar, en)
      };
    }
    /** ينفّذ إجراءات حوار ويسجل الأفعال */
    applyDialogue(npcId, log2) {
      const npc = this.npcs.find((n) => n.def.id === npcId);
      if (npc) {
        npc.adjustTrust(log2.trustDelta);
        for (const f of log2.flags) npc.flags.add(f);
      }
      for (const f of log2.flags) this.quests.notify({ type: "flag", flag: f });
      for (const a of log2.actions) runAction(a, this.actionHooks());
      this.quests.notify({ type: "talked", npc: npcId });
      if (npc) this.journal.noteNPC(npc, this.day);
    }
    /** حالة الحوار للناجي: الثقة والرايات (الجلسة + العامة) */
    dialogueContext(npcId) {
      const npc = this.npcs.find((n) => n.def.id === npcId);
      return { trust: npc.trust, flags: /* @__PURE__ */ new Set([...npc.flags, ...this.quests.flags]), itemCount: (id) => this.inventory.count(id) };
    }
    giveGift(npcId, itemId) {
      const npc = this.npcs.find((n) => n.def.id === npcId);
      if (!npc || !this.inventory.has(itemId)) return { accepted: false, delta: 0 };
      const r = npc.gift(itemId, this.day);
      if (r.accepted) this.inventory.remove(itemId, 1);
      return r;
    }
    /** يلتقط أقرب عنصر قصة مفتوح ضمن المدى */
    takeStoryPickup(p, range = 2.4) {
      let best = null;
      let bd = range;
      for (const s of this.story) {
        if (s.taken) continue;
        const d2 = Math.hypot(s.x - p.x, s.z - p.z);
        if (d2 <= bd) {
          bd = d2;
          best = s;
        }
      }
      if (!best) return { ok: false, reason: "none" };
      if (best.requires && !this.inventory.has(best.requires)) {
        this.notify("\u0645\u063A\u0644\u0642. \u062A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u0645\u0641\u062A\u0627\u062D.", "Locked. You need a key.");
        return { ok: false, reason: "locked", pickup: best };
      }
      if (best.page) {
        this.journal.collectPage(best.page, this.day);
        best.taken = true;
        this.notify("\u0648\u062C\u062F\u062A \u0635\u0641\u062D\u0629 \u0645\u0646 \u0627\u0644\u0645\u0630\u0643\u0631\u0627\u062A.", "You found a journal page.");
        return { ok: true, pickup: best };
      }
      const left = this.inventory.add(best.item, best.count);
      if (left >= best.count) {
        this.notify("\u0627\u0644\u062D\u0642\u064A\u0628\u0629 \u0645\u0645\u062A\u0644\u0626\u0629.", "Inventory full.");
        return { ok: false, reason: "none", pickup: best };
      }
      if (left > 0) this.ground.dropNew(best.item, left, best.x, best.y, best.z);
      best.taken = true;
      if (best.item === "map_piece") this.map.fullMapUnlocked = true;
      const d = ItemDB.get(best.item);
      this.notify(`\u062D\u0635\u0644\u062A \u0639\u0644\u0649 ${d.nameAr}`, `Obtained ${d.nameEn}`);
      return { ok: true, pickup: best };
    }
    // ======================= الصنع والبناء =======================
    craftNow(recipe, p) {
      const ctx = this.craftContext(p);
      const r = craft(recipe, this.inventory, ctx);
      if (r.ok) this.quests.notify({ type: "crafted", item: recipe.output.id, count: recipe.output.count });
      return r;
    }
    /** يبدأ صنعًا مؤقتًا (شريط تقدم) */
    craftQueued(recipe, p) {
      return this.craftQueue.start(recipe, this.inventory, this.craftContext(p));
    }
    canCraft(recipe, p) {
      return checkRecipe(recipe, this.inventory, this.craftContext(p)).length === 0;
    }
    /** يُدخل وصفة في محطة معالجة؛ ويُبلغ المهام عند السحب */
    processInsert(pieceId, recipe) {
      const st = this.stations.get(pieceId);
      if (!st) return { ok: false, reason: "wrongStation" };
      return st.insert(recipe, this.inventory);
    }
    processCollect(pieceId, slot) {
      const st = this.stations.get(pieceId);
      if (!st) return { ok: false };
      const r = st.collect(slot, this.inventory);
      if (r.ok && r.item) {
        this.quests.notify({ type: "crafted", item: r.item, count: r.count ?? 1 });
        this.skills.addXp("survival", 2);
      }
      return r;
    }
    place(type, target) {
      const r = this.buildings.build(type, target, this.inventory);
      if (!r.ok) return r;
      const piece = r.piece;
      if (type === "campfire") {
        this.fires.set(piece.id, new Fire(piece.x, piece.y, piece.z, false));
        this.stations.set(piece.id, createCampfireStation());
      } else if (type === "furnace") {
        this.fires.set(piece.id, new Fire(piece.x, piece.y, piece.z, true));
        this.stations.set(piece.id, createFurnace());
      } else if (type === "rack") {
        this.stations.set(piece.id, createDryingRack());
      } else if (type === "farm") {
        this.farms.set(piece.id, new FarmPlot());
      } else if (type === "storage" || type === "barrel" || type === "cooler") {
        const defId = type === "storage" ? "storage_box" : type;
        this.containers.set(piece.id, new Container(`piece-${piece.id}`, defId));
      }
      this.quests.notify({ type: "built", piece: type });
      this.skills.addXp("building", 2);
      return r;
    }
    /** يزيل قطعة (وما سقط معها): يعيد جزءًا من المواد ويرمي المحتويات */
    removePiece(id) {
      const removed = this.buildings.remove(id);
      for (const piece of removed) {
        for (const [item, n] of Object.entries(BuildingGrid.refund(piece))) this.ground.dropNew(item, n, piece.x, piece.y + 0.5, piece.z);
        const c = this.containers.get(piece.id);
        if (c) for (const e of c.grid.list()) this.ground.drop(e.stack, piece.x, piece.y + 0.5, piece.z);
        const st = this.stations.get(piece.id);
        if (st) st.slots.forEach((s, i) => s && st.discard(i));
        this.fires.delete(piece.id);
        this.stations.delete(piece.id);
        this.containers.delete(piece.id);
        this.farms.delete(piece.id);
        this.emit({ type: "pieceRemoved", piece });
      }
      return removed;
    }
    // ======================= الصيد =======================
    heldId() {
      const h2 = this.inventory.held;
      return h2 ? ItemDB.get(h2.defId).id : "";
    }
    /** يرمي الصنارة/الشبكة نحو نقطة في الماء بعمق depth */
    castLine(target, depth) {
      const id = this.heldId();
      if (id !== "fishing_rod" && id !== "fishing_net") return { ok: false, reason: "noRod" };
      if (this.fishing.state === "waiting" || this.fishing.state === "bite") return { ok: false, reason: "busy" };
      let bait = null;
      for (const e of this.inventory.grid.list()) {
        if (Fishing.isBait(e.stack.defId)) {
          bait = e.stack.defId;
          break;
        }
      }
      const ok = this.fishing.start({ depth, bait, skill: Math.min(10, this.skills.level("hunting")), hour: this.hour, rodPower: id === "fishing_net" ? 2 : 1 });
      if (!ok) return { ok: false, reason: "shallow" };
      if (bait) this.inventory.remove(bait, 1);
      this.castPos = { x: target.x, z: target.z };
      this.fishPrev = "waiting";
      this.emit({ type: "fishing", state: "cast" });
      return { ok: true };
    }
    /** يسحب الخيط: ينجح أثناء اللدغة؛ السحب المبكر يلغي الرمية */
    reelLine() {
      const before = this.fishing.state;
      const c = this.fishing.reel();
      if (c) {
        this.giveItem(c.id, c.count);
        const h2 = this.inventory.held;
        if (h2) this.inventory.damage(h2.uid, 1);
        this.skills.addXp("hunting", 4);
        this.emit({ type: "fishing", state: "caught", item: c.id, count: c.count });
      } else if (before === "waiting") {
        this.emit({ type: "fishing", state: "cancel" });
      }
      this.fishPrev = this.fishing.state;
      return c;
    }
    updateFishing(dt, p) {
      const f = this.fishing;
      if (f.state === "waiting" || f.state === "bite") {
        const id = this.heldId();
        const far = this.castPos ? Math.hypot(this.castPos.x - p.x, this.castPos.z - p.z) > 16 : false;
        if (far || id !== "fishing_rod" && id !== "fishing_net") {
          f.cancel();
          this.fishPrev = "idle";
          this.emit({ type: "fishing", state: "cancel" });
          return;
        }
        f.update(dt);
      }
      if (f.state !== this.fishPrev) {
        if (f.state === "bite") this.emit({ type: "fishing", state: "bite" });
        else if (f.state === "escaped") this.emit({ type: "fishing", state: "escaped" });
        this.fishPrev = f.state;
      }
    }
    // ======================= الزراعة =======================
    farmMode(pieceId) {
      const plot = this.farms.get(pieceId);
      if (!plot) return null;
      if (plot.ripeCount > 0) return "harvest";
      const held = this.inventory.held ? ItemDB.get(this.inventory.held.defId).id : "";
      if (held === "seeds" && plot.freeSlot() >= 0) return "plant";
      if (WATER_ITEMS.includes(held) && plot.plantedCount > 0 && plot.thirsty) return "water";
      return "info";
    }
    /** الفعل المناسب على قطعة مزرعة بحسب ما في اليد وحالة المحاصيل */
    farmAction(pieceId) {
      const plot = this.farms.get(pieceId);
      const mode = this.farmMode(pieceId);
      if (!plot || !mode) return null;
      switch (mode) {
        case "harvest": {
          const drops = plot.harvest(this.rnd);
          for (const d of drops) this.giveItem(d.id, d.count);
          this.skills.addXp("survival", 4);
          return { action: mode, drops };
        }
        case "plant":
          this.inventory.remove("seeds", 1);
          plot.plant();
          this.skills.addXp("survival", 1);
          return { action: mode };
        case "water": {
          const held = this.inventory.held;
          const id = ItemDB.get(held.defId).id;
          this.inventory.remove(id, 1);
          this.giveItem("bottle_empty", 1);
          return { action: mode, planted: plot.water() };
        }
        default:
          return { action: "info", hours: plot.hoursToRipe(), planted: plot.plantedCount };
      }
    }
    // ======================= النوم =======================
    /** يحاول النوم؛ قرب فراش أو تحت سقف أفضل */
    trySleep(p, bodyTempOk = true) {
      const nearBed = this.buildings.list().some((b) => b.type === "bed" && Math.hypot(b.x - p.x, b.z - p.z) < 2.5);
      const r = canSleep({
        energy: this.survival.stats.energy,
        hostileNearby: this.hostileNearby({ x: p.x, y: 0, z: p.z, yaw: 0, loco: "idle", inWater: false, working: false }),
        inShelterOrBed: nearBed || this.buildings.isSheltered(p.x, p.z),
        bodyTemp: bodyTempOk ? this.survival.stats.bodyTemp : 30,
        hunger: this.survival.stats.hunger,
        thirst: this.survival.stats.thirst
      });
      if (!r.ok) return r;
      this.sleeping = true;
      return { ok: true };
    }
    get wakeNote() {
      return this.wakeReason;
    }
    // ======================= الحفظ =======================
    toJSON(player) {
      return {
        version: SAVE_VERSION,
        seed: this.seed,
        savedAt: Date.now(),
        playTime: this.playTime,
        difficulty: this.survival.difficulty,
        totalHours: this.totalHours,
        player: { ...player },
        survival: this.survival.toJSON(),
        inventory: this.inventory.toJSON(),
        skills: this.skills.toJSON(),
        recipes: this.recipes.toJSON(),
        quests: this.quests.toJSON(),
        journal: this.journal.toJSON(),
        map: this.map.toJSON(),
        resources: this.resources.toJSON(),
        ground: this.ground.toJSON(),
        buildings: this.buildings.toJSON(),
        fires: [...this.fires].map(([pieceId, f]) => ({ pieceId, ...f.toJSON() })),
        stations: [...this.stations].map(([pieceId, s]) => ({ pieceId, slots: s.toJSON() })),
        containers: [...this.containers].map(([pieceId, c]) => ({ pieceId, ...c.toJSON() })),
        npcs: this.npcs.map((n) => n.toJSON()),
        farms: [...this.farms].map(([pieceId, f]) => ({ pieceId, slots: f.toJSON() })),
        story: { taken: this.story.filter((s) => s.taken).map((s) => s.id), signalDay: this.signalDay, ending: this.ending }
      };
    }
    /** يستعيد حالة محفوظة على جلسة مولّدة بنفس البذرة */
    load(d) {
      if (d.seed !== this.seed) throw new Error(`GameSession.load: \u0627\u0644\u0628\u0630\u0631\u0629 \u0644\u0627 \u062A\u0637\u0627\u0628\u0642 (${d.seed} \u2260 ${this.seed})`);
      this.totalHours = d.totalHours;
      this.lastDay = dayOf(d.totalHours);
      this.playTime = d.playTime;
      this.survival.load(d.survival);
      this.inventory.load(d.inventory);
      this.skills.load(d.skills);
      this.recipes.load(d.recipes);
      this.quests.load(d.quests);
      this.journal.load(d.journal);
      this.map.load(d.map);
      this.resources.load(d.resources);
      this.ground.load(d.ground);
      this.buildings.load(d.buildings);
      this.fires.clear();
      this.stations.clear();
      this.containers.clear();
      for (const f of d.fires) this.fires.set(f.pieceId, Fire.fromJSON(f));
      for (const s of d.stations) {
        const piece = this.buildings.get(s.pieceId);
        if (!piece) continue;
        const st = piece.type === "campfire" ? createCampfireStation() : piece.type === "furnace" ? createFurnace() : createDryingRack();
        st.load(s.slots, (id) => this.recipes.get(id));
        this.stations.set(s.pieceId, st);
      }
      for (const c of d.containers) this.containers.set(c.pieceId, Container.fromJSON(c));
      this.farms.clear();
      for (const f of d.farms ?? []) if (this.buildings.get(f.pieceId)) this.farms.set(f.pieceId, FarmPlot.fromJSON(f.slots));
      this.fishing.cancel();
      this.castPos = null;
      for (const n of d.npcs) this.npcs.find((x) => x.def.id === n.id)?.load(n);
      const taken = new Set(d.story.taken);
      for (const s of this.story) s.taken = taken.has(s.id);
      this.signalDay = d.story.signalDay;
      this.ending = d.story.ending;
      this.sleeping = false;
      this.mapTimer = 0;
    }
  };

  // src/data/i18n_ar.json
  var i18n_ar_default = {
    title: "\u062C\u0632\u064A\u0631\u0629 \u0627\u0644\u0628\u0642\u0627\u0621",
    click_to_play: "\u0627\u0636\u063A\u0637 \u0644\u0644\u0628\u062F\u0621",
    paused: "\u0627\u0644\u0644\u0639\u0628\u0629 \u0645\u062A\u0648\u0642\u0641\u0629 \u0645\u0624\u0642\u062A\u064B\u0627",
    controls_desktop: "WASD \u062D\u0631\u0643\u0629 \xB7 Shift \u062C\u0631\u064A \xB7 Space \u0642\u0641\u0632 \xB7 C \u0627\u0646\u062D\u0646\u0627\u0621 \xB7 E \u062A\u0641\u0627\u0639\u0644 \xB7 Tab \u062D\u0642\u064A\u0628\u0629 \xB7 K \u0635\u0646\u0639 \xB7 B \u0628\u0646\u0627\u0621 \xB7 M \u062E\u0631\u064A\u0637\u0629 \xB7 J \u0645\u0630\u0643\u0631\u0627\u062A \xB7 Z \u0646\u0648\u0645 \xB7 1-8 \u0634\u0631\u064A\u0637 \u0633\u0631\u064A\u0639 \xB7 Esc \u0625\u064A\u0642\u0627\u0641",
    controls_touch: "\u0627\u0633\u062D\u0628 \u0627\u0644\u0639\u0635\u0627 \u0627\u0644\u064A\u0633\u0631\u0649 \u0644\u0644\u062D\u0631\u0643\u0629 \xB7 \u0627\u0633\u062D\u0628 \u0627\u0644\u0634\u0627\u0634\u0629 \u0644\u0644\u0646\u0638\u0631 \xB7 \u0627\u0644\u0623\u0632\u0631\u0627\u0631 \u0639\u0644\u0649 \u0627\u0644\u064A\u0645\u064A\u0646",
    loading: "\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644\u2026",
    jump: "\u0642\u0641\u0632",
    run: "\u062C\u0631\u064A",
    view: "\u0645\u0646\u0638\u0648\u0631",
    btn_attack: "\u0647\u062C\u0648\u0645",
    btn_use: "\u062A\u0641\u0627\u0639\u0644",
    btn_bag: "\u062D\u0642\u064A\u0628\u0629",
    btn_menu: "\u0642\u0627\u0626\u0645\u0629",
    yes: "\u0646\u0639\u0645",
    no: "\u0644\u0627",
    close: "\u0625\u063A\u0644\u0627\u0642",
    back: "\u0631\u062C\u0648\u0639",
    ok: "\u062D\u0633\u0646\u064B\u0627",
    stat_health: "\u0627\u0644\u0635\u062D\u0629",
    stat_hunger: "\u0627\u0644\u062C\u0648\u0639",
    stat_thirst: "\u0627\u0644\u0639\u0637\u0634",
    stat_energy: "\u0627\u0644\u0637\u0627\u0642\u0629",
    stat_stamina: "\u0627\u0644\u0646\u064E\u0651\u0641\u064E\u0633",
    stat_sanity: "\u0627\u0644\u0627\u062A\u0632\u0627\u0646",
    stat_temp: "\u0627\u0644\u062D\u0631\u0627\u0631\u0629",
    stat_wet: "\u0627\u0644\u0628\u0644\u0644",
    cond_foodPoisoning: "\u062A\u0633\u0645\u0645 \u063A\u0630\u0627\u0626\u064A",
    cond_dehydration: "\u062C\u0641\u0627\u0641",
    cond_heatstroke: "\u0636\u0631\u0628\u0629 \u0634\u0645\u0633",
    cond_hypothermia: "\u0627\u0646\u062E\u0641\u0627\u0636 \u062D\u0631\u0627\u0631\u0629",
    cond_infection: "\u0639\u062F\u0648\u0649",
    cond_bleeding: "\u0646\u0632\u064A\u0641",
    cond_brokenLeg: "\u0633\u0627\u0642 \u0645\u0643\u0633\u0648\u0631\u0629",
    cond_sunburn: "\u062D\u0631\u0648\u0642 \u0634\u0645\u0633",
    cond_pain: "\u0623\u0644\u0645",
    skill_survival: "\u0627\u0644\u0628\u0642\u0627\u0621",
    skill_hunting: "\u0627\u0644\u0635\u064A\u062F",
    skill_crafting: "\u0627\u0644\u0635\u0646\u0627\u0639\u0629",
    skill_building: "\u0627\u0644\u0628\u0646\u0627\u0621",
    skill_level: "\u0627\u0644\u0645\u0633\u062A\u0648\u0649 {n}",
    skills: "\u0627\u0644\u0645\u0647\u0627\u0631\u0627\u062A",
    day_n: "\u0627\u0644\u064A\u0648\u0645 {n}",
    prompt_pickup: "\u0627\u0644\u062A\u0642\u0627\u0637 {name}",
    prompt_talk: "\u0627\u0644\u062A\u062D\u062F\u062B \u0625\u0644\u0649 {name}",
    prompt_story: "\u0641\u062D\u0635",
    prompt_fire_add: "\u0625\u0636\u0627\u0641\u0629 \u0648\u0642\u0648\u062F",
    prompt_fire_light: "\u0625\u0634\u0639\u0627\u0644",
    prompt_open: "\u0641\u062A\u062D",
    prompt_sleep: "\u0627\u0644\u0646\u0648\u0645",
    prompt_cook: "\u0627\u0644\u0637\u0647\u064A",
    prompt_gather: "\u062C\u0645\u0639",
    prompt_plant: "\u0632\u0631\u0639 \u0628\u0630\u0631\u0629",
    prompt_water: "\u0633\u0642\u064A \u0627\u0644\u0645\u062D\u0627\u0635\u064A\u0644",
    prompt_harvest: "\u062D\u0635\u0627\u062F",
    prompt_farm_info: "\u0641\u062D\u0635 \u0627\u0644\u0645\u0632\u0631\u0639\u0629",
    prompt_reel: "\u0627\u0633\u062D\u0628!",
    farm_planted: "\u0632\u064F\u0631\u0639\u062A \u0627\u0644\u0628\u0630\u0631\u0629",
    farm_watered: "\u0633\u064F\u0642\u064A\u062A \u0627\u0644\u0645\u062D\u0627\u0635\u064A\u0644",
    farm_harvested: "\u062D\u0635\u062F\u062A {name} \xD7{n}",
    farm_growing: "{n} \u0645\u062D\u0635\u0648\u0644 \u064A\u0646\u0645\u0648\u060C \u0627\u0644\u062D\u0635\u0627\u062F \u0628\u0639\u062F ~{h} \u0633\u0627\u0639\u0629",
    farm_empty: "\u0627\u0644\u0645\u0632\u0631\u0639\u0629 \u0641\u0627\u0631\u063A\u0629\u060C \u0627\u062D\u0645\u0644 \u0628\u0630\u0648\u0631\u064B\u0627",
    farm_thirsty: "\u0627\u0644\u0645\u062D\u0627\u0635\u064A\u0644 \u0639\u0637\u0634\u0649\u060C \u0627\u062D\u0645\u0644 \u0645\u0627\u0621\u064B",
    fish_cast: "\u0631\u0645\u064A\u062A \u0627\u0644\u062E\u064A\u0637...",
    fish_bite: "\u0633\u0645\u0643\u0629 \u062A\u0623\u0643\u0644! \u0627\u0633\u062D\u0628 \u0627\u0644\u0622\u0646",
    fish_escaped: "\u0647\u0631\u0628\u062A \u0627\u0644\u0633\u0645\u0643\u0629",
    fish_cancel: "\u0633\u062D\u0628\u062A \u0627\u0644\u062E\u064A\u0637",
    fish_shallow: "\u0627\u0644\u0645\u0627\u0621 \u0636\u062D\u0644 \u062C\u062F\u064B\u0627 \u0644\u0644\u0635\u064A\u062F",
    fish_no_rod: "\u062A\u062D\u062A\u0627\u062C \u0635\u0646\u0627\u0631\u0629 \u0623\u0648 \u0634\u0628\u0643\u0629 \u0641\u064A \u064A\u062F\u0643",
    prompt_board: "\u0631\u0643\u0648\u0628 \u0627\u0644\u0637\u0648\u0627\u0641\u0629",
    prompt_leave: "\u0627\u0644\u0646\u0632\u0648\u0644",
    inventory: "\u0627\u0644\u062D\u0642\u064A\u0628\u0629",
    equipment: "\u0627\u0644\u062A\u062C\u0647\u064A\u0632",
    weight: "\u0627\u0644\u0648\u0632\u0646",
    slot_head: "\u0627\u0644\u0631\u0623\u0633",
    slot_chest: "\u0627\u0644\u0635\u062F\u0631",
    slot_legs: "\u0627\u0644\u0633\u0627\u0642\u0627\u0646",
    slot_feet: "\u0627\u0644\u0642\u062F\u0645\u0627\u0646",
    slot_hands: "\u0627\u0644\u064A\u062F\u0627\u0646",
    slot_tool: "\u0627\u0644\u0623\u062F\u0627\u0629",
    slot_backpack: "\u062D\u0642\u064A\u0628\u0629 \u0627\u0644\u0638\u0647\u0631",
    act_use: "\u0627\u0633\u062A\u062E\u062F\u0627\u0645",
    act_equip: "\u062A\u062C\u0647\u064A\u0632",
    act_unequip: "\u0646\u0632\u0639",
    act_drop: "\u0631\u0645\u064A",
    act_split: "\u062A\u0642\u0633\u064A\u0645",
    act_rotate: "\u062A\u062F\u0648\u064A\u0631",
    act_sort: "\u062A\u0631\u062A\u064A\u0628",
    act_hotbar: "\u0625\u0644\u0649 \u0627\u0644\u0634\u0631\u064A\u0637 \u0627\u0644\u0633\u0631\u064A\u0639",
    act_repair: "\u0625\u0635\u0644\u0627\u062D",
    durability: "\u0627\u0644\u0645\u062A\u0627\u0646\u0629",
    spoil_fresh: "\u0637\u0627\u0632\u062C",
    spoil_stale: "\u0642\u062F\u064A\u0645",
    spoil_rotten: "\u0641\u0627\u0633\u062F",
    rarity_common: "\u0639\u0627\u062F\u064A",
    rarity_uncommon: "\u063A\u064A\u0631 \u0634\u0627\u0626\u0639",
    rarity_rare: "\u0646\u0627\u062F\u0631",
    rarity_epic: "\u0623\u0633\u0637\u0648\u0631\u064A",
    container: "\u0627\u0644\u062D\u0627\u0648\u064A\u0629",
    inv_full: "\u0627\u0644\u062D\u0642\u064A\u0628\u0629 \u0645\u0645\u062A\u0644\u0626\u0629",
    overweight: "\u062D\u0645\u0648\u0644\u0629 \u062B\u0642\u064A\u0644\u0629: \u062D\u0631\u0643\u062A\u0643 \u0623\u0628\u0637\u0623",
    drag_hint: "\u0627\u0633\u062D\u0628 \u0644\u0646\u0642\u0644 \xB7 R \u062A\u062F\u0648\u064A\u0631 \xB7 \u0627\u0646\u0642\u0631 \u064A\u0645\u064A\u0646\u064B\u0627 \u0644\u0644\u0642\u0627\u0626\u0645\u0629",
    crafting: "\u0627\u0644\u0635\u0646\u0627\u0639\u0629",
    craft: "\u0635\u0646\u0639",
    craft_all: "\u0635\u0646\u0639 \u0627\u0644\u0643\u0644",
    ingredients: "\u0627\u0644\u0645\u0643\u0648\u0646\u0627\u062A",
    tools_needed: "\u0623\u062F\u0648\u0627\u062A \u0645\u0637\u0644\u0648\u0628\u0629",
    output: "\u0627\u0644\u0646\u0627\u062A\u062C",
    station: "\u0627\u0644\u0645\u062D\u0637\u0629",
    station_hand: "\u0627\u0644\u064A\u062F",
    station_workbench: "\u0637\u0627\u0648\u0644\u0629 \u0639\u0645\u0644",
    station_campfire: "\u0645\u0648\u0642\u062F",
    station_furnace: "\u0641\u0631\u0646",
    station_drying_rack: "\u0631\u0641 \u062A\u062C\u0641\u064A\u0641",
    missing_ingredient: "\u064A\u0646\u0642\u0635\u0643 {name} ({have}/{need})",
    missing_tool: "\u062A\u062D\u062A\u0627\u062C \u0623\u062F\u0627\u0629: {name}",
    missing_station: "\u062A\u062D\u062A\u0627\u062C: {name}",
    missing_skill: "\u062A\u062D\u062A\u0627\u062C {name} \u0645\u0633\u062A\u0648\u0649 {need}",
    missing_space: "\u0644\u0627 \u0645\u0633\u0627\u062D\u0629 \u0641\u064A \u0627\u0644\u062D\u0642\u064A\u0628\u0629",
    no_recipes: "\u0644\u0627 \u0648\u0635\u0641\u0627\u062A \u0645\u0639\u0631\u0648\u0641\u0629 \u0628\u0639\u062F. \u0627\u062C\u0645\u0639 \u0627\u0644\u0645\u0632\u064A\u062F \u0645\u0646 \u0627\u0644\u0645\u0648\u0627\u062F!",
    crafted: "\u062A\u0645 \u0635\u0646\u0639 {name}",
    new_recipes: "\u0648\u0635\u0641\u0627\u062A \u062C\u062F\u064A\u062F\u0629: {n}",
    cook_slot_empty: "\u0641\u0627\u0631\u063A",
    cook_collect: "\u0633\u062D\u0628",
    cook_ready: "\u062C\u0627\u0647\u0632",
    cook_burnt: "\u0645\u062D\u0631\u0648\u0642",
    build: "\u0628\u0646\u0627\u0621",
    build_cancel: "\u0625\u0644\u063A\u0627\u0621",
    build_place: "\u0648\u0636\u0639",
    build_remove: "\u0647\u062F\u0645",
    build_rotate: "\u062A\u062F\u0648\u064A\u0631 \u0627\u0644\u0642\u0637\u0639\u0629 (R)",
    build_hint: "\u0627\u0646\u0642\u0631 \u0644\u0648\u0636\u0639 \u0627\u0644\u0642\u0637\u0639\u0629 \xB7 R \u062A\u062F\u0648\u064A\u0631 \xB7 Esc \u0625\u0644\u063A\u0627\u0621",
    build_mode_remove: "\u0648\u0636\u0639 \u0627\u0644\u0647\u062F\u0645: \u0627\u0646\u0642\u0631 \u0639\u0644\u0649 \u0642\u0637\u0639\u0629 \u0644\u0625\u0632\u0627\u0644\u062A\u0647\u0627",
    err_noSupport: "\u0644\u0627 \u062F\u0639\u0645 \u0643\u0627\u0641\u064D",
    err_occupied: "\u0627\u0644\u0645\u0643\u0627\u0646 \u0645\u0634\u063A\u0648\u0644",
    err_badGround: "\u0623\u0631\u0636 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629",
    err_overlap: "\u062A\u062F\u0627\u062E\u0644 \u0645\u0639 \u0642\u0637\u0639\u0629 \u0623\u062E\u0631\u0649",
    err_noMaterials: "\u0645\u0648\u0627\u062F \u063A\u064A\u0631 \u0643\u0627\u0641\u064A\u0629",
    err_noDoorway: "\u064A\u062D\u062A\u0627\u062C \u0625\u0637\u0627\u0631 \u0628\u0627\u0628",
    err_needsWalls: "\u064A\u062D\u062A\u0627\u062C \u062C\u062F\u0631\u0627\u0646\u064B\u0627",
    err_notOnWater: "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0639\u0644\u0649 \u0627\u0644\u0645\u0627\u0621",
    piece_removed: "\u0647\u064F\u062F\u0645\u062A \u0627\u0644\u0642\u0637\u0639\u0629",
    quests: "\u0627\u0644\u0645\u0647\u0627\u0645",
    journal: "\u0627\u0644\u0645\u0630\u0643\u0631\u0627\u062A",
    map: "\u0627\u0644\u062E\u0631\u064A\u0637\u0629",
    quest_active: "\u0646\u0634\u0637\u0629",
    quest_available: "\u0645\u062A\u0627\u062D\u0629",
    quest_completed: "\u0645\u0643\u062A\u0645\u0644\u0629",
    quest_main: "\u0631\u0626\u064A\u0633\u064A\u0629",
    quest_side: "\u062C\u0627\u0646\u0628\u064A\u0629",
    no_quests: "\u0644\u0627 \u0645\u0647\u0627\u0645 \u0646\u0634\u0637\u0629",
    quest_started: "\u0645\u0647\u0645\u0629 \u062C\u062F\u064A\u062F\u0629: {name}",
    quest_done: "\u0627\u0643\u062A\u0645\u0644\u062A: {name}",
    journal_entries: "\u0627\u0644\u064A\u0648\u0645\u064A\u0627\u062A",
    journal_pages: "\u0635\u0641\u062D\u0627\u062A \u0645\u0643\u062A\u0634\u0641\u0629",
    journal_empty: "\u0644\u0627 \u0645\u0630\u0643\u0631\u0627\u062A \u0628\u0639\u062F",
    journal_day: "\u0627\u0644\u064A\u0648\u0645 {n}",
    map_you: "\u0623\u0646\u062A \u0647\u0646\u0627",
    map_unknown: "\u0645\u0646\u0637\u0642\u0629 \u063A\u064A\u0631 \u0645\u0633\u062A\u0643\u0634\u0641\u0629",
    landmark_found: "\u0627\u0643\u062A\u064F\u0634\u0641: {name}",
    dlg_end: "\u0625\u0646\u0647\u0627\u0621 \u0627\u0644\u062D\u062F\u064A\u062B",
    dlg_gift: "\u062A\u0642\u062F\u064A\u0645 \u0647\u062F\u064A\u0629",
    trust: "\u0627\u0644\u062B\u0642\u0629",
    trust_hostile: "\u0639\u062F\u0627\u0626\u064A",
    trust_wary: "\u062D\u0630\u0631",
    trust_neutral: "\u0645\u062D\u0627\u064A\u062F",
    trust_friendly: "\u0648\u062F\u0648\u062F",
    trust_trusted: "\u0645\u0648\u062B\u0648\u0642",
    gift_accepted: "\u0642\u0628\u0650\u0644 \u0627\u0644\u0647\u062F\u064A\u0629",
    gift_refused: "\u0644\u0645 \u064A\u0642\u0628\u0644 \u0627\u0644\u0647\u062F\u064A\u0629",
    gift_pick: "\u0627\u062E\u062A\u0631 \u0639\u0646\u0635\u0631\u064B\u0627 \u0645\u0646 \u0627\u0644\u062D\u0642\u064A\u0628\u0629",
    menu_resume: "\u0645\u062A\u0627\u0628\u0639\u0629",
    menu_save: "\u062D\u0641\u0638",
    menu_load: "\u062A\u062D\u0645\u064A\u0644",
    menu_settings: "\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A",
    menu_new: "\u0644\u0639\u0628\u0629 \u062C\u062F\u064A\u062F\u0629",
    menu_quit: "\u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
    menu_continue: "\u0645\u062A\u0627\u0628\u0639\u0629 \u0627\u0644\u0644\u0639\u0628",
    slot_n: "\u062E\u0627\u0646\u0629 {n}",
    slot_empty: "\u0641\u0627\u0631\u063A\u0629",
    slot_corrupt: "\u0645\u0644\u0641 \u062A\u0627\u0644\u0641",
    slot_delete: "\u062D\u0630\u0641",
    slot_info: "\u0627\u0644\u064A\u0648\u0645 {day} \xB7 {time} \xB7 {diff}",
    saved: "\u062A\u0645 \u0627\u0644\u062D\u0641\u0638",
    save_failed: "\u0641\u0634\u0644 \u0627\u0644\u062D\u0641\u0638",
    loaded: "\u062A\u0645 \u0627\u0644\u062A\u062D\u0645\u064A\u0644",
    load_failed: "\u0641\u0634\u0644 \u0627\u0644\u062A\u062D\u0645\u064A\u0644",
    autosaved: "\u062D\u0641\u0638 \u062A\u0644\u0642\u0627\u0626\u064A",
    confirm_overwrite: "\u0627\u0633\u062A\u0628\u062F\u0627\u0644 \u0627\u0644\u062D\u0641\u0638 \u0627\u0644\u062D\u0627\u0644\u064A\u061F",
    confirm_delete: "\u062D\u0630\u0641 \u0647\u0630\u0627 \u0627\u0644\u062D\u0641\u0638 \u0646\u0647\u0627\u0626\u064A\u064B\u0627\u061F",
    diff_easy: "\u0633\u0647\u0644",
    diff_normal: "\u0639\u0627\u062F\u064A",
    diff_hard: "\u0635\u0639\u0628",
    diff_realistic: "\u0648\u0627\u0642\u0639\u064A (\u0645\u0648\u062A \u0646\u0647\u0627\u0626\u064A)",
    difficulty: "\u0627\u0644\u0635\u0639\u0648\u0628\u0629",
    set_language: "\u0627\u0644\u0644\u063A\u0629",
    set_quality: "\u0627\u0644\u062C\u0648\u062F\u0629",
    q_low: "\u0645\u0646\u062E\u0641\u0636\u0629",
    q_medium: "\u0645\u062A\u0648\u0633\u0637\u0629",
    q_high: "\u0639\u0627\u0644\u064A\u0629",
    set_invertY: "\u0639\u0643\u0633 \u0627\u0644\u0645\u062D\u0648\u0631 \u0627\u0644\u0631\u0623\u0633\u064A",
    set_sens: "\u0627\u0644\u062D\u0633\u0627\u0633\u064A\u0629",
    set_fov: "\u0632\u0627\u0648\u064A\u0629 \u0627\u0644\u0631\u0624\u064A\u0629",
    set_master: "\u0627\u0644\u0635\u0648\u062A \u0627\u0644\u0639\u0627\u0645",
    set_sfx: "\u0627\u0644\u0645\u0624\u062B\u0631\u0627\u062A",
    set_music: "\u0627\u0644\u0645\u0648\u0633\u064A\u0642\u0649",
    set_ambient: "\u0627\u0644\u0623\u062C\u0648\u0627\u0621",
    set_postfx: "\u0645\u0624\u062B\u0631\u0627\u062A \u0627\u0644\u0635\u0648\u0631\u0629",
    set_subtitles: "\u062A\u0631\u062C\u0645\u0629 \u0627\u0644\u0623\u0635\u0648\u0627\u062A",
    tut_move: "\u062A\u062D\u0631\u0651\u0643 \u0628\u0640 WASD \u0648\u0627\u0646\u0638\u0631 \u0628\u0627\u0644\u0641\u0623\u0631\u0629",
    tut_gather: "\u0627\u0642\u062A\u0631\u0628 \u0645\u0646 \u0646\u0628\u0627\u062A \u0623\u0648 \u0635\u062E\u0631\u0629 \u0648\u0627\u0646\u0642\u0631 \u0644\u062C\u0645\u0639\u0647",
    tut_bag: "\u0627\u0641\u062A\u062D \u0627\u0644\u062D\u0642\u064A\u0628\u0629 \u0628\u0627\u0644\u0632\u0631 Tab",
    tut_craft: "\u0627\u0641\u062A\u062D \u0627\u0644\u0635\u0646\u0627\u0639\u0629 \u0628\u0627\u0644\u0632\u0631 K \u0648\u0635\u0646\u0639 \u0623\u062F\u0648\u0627\u062A\u0643 \u0627\u0644\u0623\u0648\u0644\u0649",
    tut_fire: "\u0627\u0628\u0646\u0650 \u0645\u0648\u0642\u062F\u064B\u0627 \u0628\u0627\u0644\u0632\u0631 B \u0648\u0623\u0634\u0639\u0644\u0647 \u0642\u0628\u0644 \u0627\u0644\u0644\u064A\u0644",
    tut_water: "\u0627\u0634\u0631\u0628 \u0642\u0628\u0644 \u0623\u0646 \u064A\u0634\u062A\u062F \u0627\u0644\u0639\u0637\u0634: \u0627\u0645\u0644\u0623 \u0632\u062C\u0627\u062C\u062A\u0643 \u0645\u0646 \u0627\u0644\u0645\u0627\u0621 \u0627\u0644\u0636\u062D\u0644 \u062B\u0645 \u0627\u063A\u0644\u0650\u0647\u0627",
    tut_sleep: "\u0646\u0645 \u062F\u0627\u062E\u0644 \u0645\u0623\u0648\u0649 \u0628\u0627\u0644\u0632\u0631 Z \u0644\u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0627\u0644\u0637\u0627\u0642\u0629",
    got_item: "\u062D\u0635\u0644\u062A \u0639\u0644\u0649 {name} \xD7{n}",
    tool_broke: "\u0627\u0646\u0643\u0633\u0631\u062A \u0627\u0644\u0623\u062F\u0627\u0629: {name}",
    level_up: "\u0627\u0631\u062A\u0641\u0639\u062A \u0645\u0647\u0627\u0631\u0629 {skill} \u0625\u0644\u0649 {n}",
    woke_up: "\u0627\u0633\u062A\u064A\u0642\u0638\u062A",
    cannot_sleep_hostile: "\u0644\u0627 \u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u0646\u0648\u0645 \u0645\u0639 \u0648\u062C\u0648\u062F \u062E\u0637\u0631 \u0642\u0631\u064A\u0628",
    cannot_sleep_energy: "\u0644\u0633\u062A \u0645\u062A\u0639\u0628\u064B\u0627 \u0628\u0645\u0627 \u064A\u0643\u0641\u064A",
    cannot_sleep_cold: "\u0627\u0644\u062C\u0648 \u0628\u0627\u0631\u062F \u062C\u062F\u064B\u0627 \u0644\u0644\u0646\u0648\u0645",
    cannot_sleep_hunger: "\u0623\u0646\u062A \u062C\u0627\u0626\u0639 \u0623\u0648 \u0639\u0637\u0634\u0627\u0646 \u062C\u062F\u064B\u0627 \u0644\u0644\u0646\u0648\u0645",
    cannot_sleep_exposed: "\u0627\u0628\u062D\u062B \u0639\u0646 \u0645\u0623\u0648\u0649 \u0623\u0648 \u0641\u0631\u0627\u0634",
    ate_rotten: "\u0643\u0627\u0646 \u0627\u0644\u0637\u0639\u0627\u0645 \u0641\u0627\u0633\u062F\u064B\u0627!",
    no_tool_fire: "\u062A\u062D\u062A\u0627\u062C \u0645\u0634\u0639\u0644\u064B\u0627: \u0642\u062F\u0627\u062D\u0629 \u0623\u0648 \u0639\u064A\u062F\u0627\u0646 \u062B\u0642\u0627\u0628 \u0623\u0648 \u0642\u0648\u0633 \u0646\u0627\u0631",
    fire_failed: "\u0641\u0634\u0644\u062A \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629\u060C \u062D\u0627\u0648\u0644 \u0645\u062C\u062F\u062F\u064B\u0627",
    fire_lit: "\u0627\u0634\u062A\u0639\u0644\u062A \u0627\u0644\u0646\u0627\u0631",
    no_fuel: "\u0623\u0636\u0641 \u0648\u0642\u0648\u062F\u064B\u0627 \u0623\u0648\u0644\u064B\u0627",
    hit_nothing: "\u0644\u0627 \u0634\u064A\u0621 \u0644\u0644\u062C\u0645\u0639",
    too_tired: "\u0623\u0646\u062A \u0645\u062A\u0639\u0628 \u062C\u062F\u064B\u0627",
    wrong_tool: "\u062A\u062D\u062A\u0627\u062C \u0623\u062F\u0627\u0629 \u0623\u0641\u0636\u0644",
    water_filled: "\u0645\u0644\u0623\u062A \u0627\u0644\u0632\u062C\u0627\u062C\u0629",
    no_water: "\u0644\u0627 \u0645\u0627\u0621 \u0647\u0646\u0627",
    raft_boarded: "\u0639\u0644\u0649 \u0645\u062A\u0646 \u0627\u0644\u0637\u0648\u0627\u0641\u0629: A/D \u062A\u0648\u062C\u064A\u0647\u060C W \u062A\u062C\u062F\u064A\u0641\u060C Shift \u0634\u0631\u0627\u0639",
    ending_rescue: "\u0627\u0644\u0646\u062C\u0627\u0629",
    ending_raft: "\u0639\u0628\u0648\u0631 \u0627\u0644\u0628\u062D\u0631",
    ending_secret: "\u0633\u0631 \u0627\u0644\u062C\u0632\u064A\u0631\u0629",
    ending_death: "\u0627\u0644\u0646\u0647\u0627\u064A\u0629",
    ending_rescue_text: "\u0647\u0628\u0637\u062A \u0627\u0644\u0645\u0631\u0648\u062D\u064A\u0629 \u0639\u0644\u0649 \u0627\u0644\u062C\u0632\u064A\u0631\u0629. \u0638\u0644\u0644\u062A\u064E \u062D\u064A\u064B\u0627 \u062D\u062A\u0649 \u062C\u0627\u0621 \u0627\u0644\u0625\u0646\u0642\u0627\u0630.",
    ending_raft_text: "\u0623\u0628\u062D\u0631\u062A\u064E \u0639\u0644\u0649 \u0637\u0648\u0627\u0641\u062A\u0643 \u0646\u062D\u0648 \u0627\u0644\u0623\u0641\u0642\u060C \u0648\u062E\u0644\u0641\u0643 \u062C\u0632\u064A\u0631\u0629 \u0643\u0627\u062F\u062A \u062A\u0628\u062A\u0644\u0639\u0643.",
    ending_secret_text: "\u0623\u0631\u0633\u0644\u062A\u064E \u0627\u0644\u0625\u0634\u0627\u0631\u0629 \u0645\u0646 \u0627\u0644\u0645\u062E\u0628\u0623\u060C \u0648\u0639\u0631\u0641 \u0627\u0644\u0639\u0627\u0644\u0645 \u0645\u0627 \u0623\u064F\u062E\u0641\u064A \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u062C\u0632\u064A\u0631\u0629.",
    ending_death_text: "\u0644\u0645 \u062A\u0646\u062C\u064F. \u0627\u0644\u062C\u0632\u064A\u0631\u0629 \u0644\u0627 \u062A\u063A\u0641\u0631.",
    death_cause_fall: "\u0633\u0642\u0637\u0629 \u0642\u0627\u062A\u0644\u0629",
    death_cause_animal: "\u0647\u062C\u0648\u0645 \u062D\u064A\u0648\u0627\u0646",
    death_cause_cut: "\u062C\u0631\u062D \u0646\u0627\u0632\u0641",
    death_cause_fire: "\u062D\u0631\u0648\u0642",
    death_cause_drown: "\u063A\u0631\u0642",
    death_cause_starve: "\u062C\u0648\u0639 \u0648\u0639\u0637\u0634",
    death_cause_cold: "\u0628\u0631\u062F \u0642\u0627\u0631\u0633",
    death_cause_unknown: "\u0633\u0628\u0628 \u0645\u062C\u0647\u0648\u0644",
    stats_played: "\u0632\u0645\u0646 \u0627\u0644\u0644\u0639\u0628",
    stats_days: "\u0623\u064A\u0627\u0645 \u0627\u0644\u0646\u062C\u0627\u0629",
    retry: "\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629",
    snd_thunder: "[\u0631\u0639\u062F]",
    snd_growl: "[\u0632\u0645\u062C\u0631\u0629]",
    snd_howl: "[\u0639\u0648\u0627\u0621]",
    snd_heli: "[\u0645\u0631\u0648\u062D\u064A\u0629]"
  };

  // src/data/i18n_en.json
  var i18n_en_default = {
    title: "Island Survival",
    click_to_play: "Click to play",
    paused: "Game paused",
    controls_desktop: "WASD move \xB7 Shift run \xB7 Space jump \xB7 C crouch \xB7 E interact \xB7 Tab bag \xB7 K craft \xB7 B build \xB7 M map \xB7 J journal \xB7 Z sleep \xB7 1-8 hotbar \xB7 Esc pause",
    controls_touch: "Drag left stick to move \xB7 drag screen to look \xB7 buttons on the right",
    loading: "Loading\u2026",
    jump: "Jump",
    run: "Run",
    view: "View",
    btn_attack: "Attack",
    btn_use: "Use",
    btn_bag: "Bag",
    btn_menu: "Menu",
    yes: "Yes",
    no: "No",
    close: "Close",
    back: "Back",
    ok: "OK",
    stat_health: "Health",
    stat_hunger: "Hunger",
    stat_thirst: "Thirst",
    stat_energy: "Energy",
    stat_stamina: "Stamina",
    stat_sanity: "Sanity",
    stat_temp: "Temp",
    stat_wet: "Wetness",
    cond_foodPoisoning: "Food poisoning",
    cond_dehydration: "Dehydration",
    cond_heatstroke: "Heatstroke",
    cond_hypothermia: "Hypothermia",
    cond_infection: "Infection",
    cond_bleeding: "Bleeding",
    cond_brokenLeg: "Broken leg",
    cond_sunburn: "Sunburn",
    cond_pain: "Pain",
    skill_survival: "Survival",
    skill_hunting: "Hunting",
    skill_crafting: "Crafting",
    skill_building: "Building",
    skill_level: "Level {n}",
    skills: "Skills",
    day_n: "Day {n}",
    prompt_pickup: "Pick up {name}",
    prompt_talk: "Talk to {name}",
    prompt_story: "Inspect",
    prompt_fire_add: "Add fuel",
    prompt_fire_light: "Light fire",
    prompt_open: "Open",
    prompt_sleep: "Sleep",
    prompt_cook: "Cook",
    prompt_gather: "Gather",
    prompt_plant: "Plant seed",
    prompt_water: "Water crops",
    prompt_harvest: "Harvest",
    prompt_farm_info: "Inspect plot",
    prompt_reel: "Reel in!",
    farm_planted: "Seed planted",
    farm_watered: "Crops watered",
    farm_harvested: "Harvested {name} \xD7{n}",
    farm_growing: "{n} growing, ripe in ~{h} h",
    farm_empty: "Plot is empty, hold seeds",
    farm_thirsty: "Crops are thirsty, hold water",
    fish_cast: "Line cast...",
    fish_bite: "A bite! Reel in now",
    fish_escaped: "It got away",
    fish_cancel: "Line pulled in",
    fish_shallow: "Water too shallow to fish",
    fish_no_rod: "Hold a rod or net",
    prompt_board: "Board raft",
    prompt_leave: "Leave raft",
    inventory: "Backpack",
    equipment: "Equipment",
    weight: "Weight",
    slot_head: "Head",
    slot_chest: "Chest",
    slot_legs: "Legs",
    slot_feet: "Feet",
    slot_hands: "Hands",
    slot_tool: "Tool",
    slot_backpack: "Backpack",
    act_use: "Use",
    act_equip: "Equip",
    act_unequip: "Unequip",
    act_drop: "Drop",
    act_split: "Split",
    act_rotate: "Rotate",
    act_sort: "Sort",
    act_hotbar: "To hotbar",
    act_repair: "Repair",
    durability: "Durability",
    spoil_fresh: "Fresh",
    spoil_stale: "Stale",
    spoil_rotten: "Rotten",
    rarity_common: "Common",
    rarity_uncommon: "Uncommon",
    rarity_rare: "Rare",
    rarity_epic: "Epic",
    container: "Container",
    inv_full: "Inventory full",
    overweight: "Overloaded: you move slower",
    drag_hint: "Drag to move \xB7 R rotate \xB7 right-click for menu",
    crafting: "Crafting",
    craft: "Craft",
    craft_all: "Craft all",
    ingredients: "Ingredients",
    tools_needed: "Tools needed",
    output: "Output",
    station: "Station",
    station_hand: "Hand",
    station_workbench: "Workbench",
    station_campfire: "Campfire",
    station_furnace: "Furnace",
    station_drying_rack: "Drying rack",
    missing_ingredient: "Missing {name} ({have}/{need})",
    missing_tool: "Need tool: {name}",
    missing_station: "Need: {name}",
    missing_skill: "Need {name} level {need}",
    missing_space: "No inventory space",
    no_recipes: "No known recipes yet. Gather more materials!",
    crafted: "Crafted {name}",
    new_recipes: "New recipes: {n}",
    cook_slot_empty: "Empty",
    cook_collect: "Collect",
    cook_ready: "Ready",
    cook_burnt: "Burnt",
    build: "Build",
    build_cancel: "Cancel",
    build_place: "Place",
    build_remove: "Demolish",
    build_rotate: "Rotate piece (R)",
    build_hint: "Click to place \xB7 R rotate \xB7 Esc cancel",
    build_mode_remove: "Demolish mode: click a piece to remove it",
    err_noSupport: "No support",
    err_occupied: "Occupied",
    err_badGround: "Bad ground",
    err_overlap: "Overlaps another piece",
    err_noMaterials: "Not enough materials",
    err_noDoorway: "Needs a doorway",
    err_needsWalls: "Needs walls",
    err_notOnWater: "Must be on water",
    piece_removed: "Piece demolished",
    quests: "Quests",
    journal: "Journal",
    map: "Map",
    quest_active: "Active",
    quest_available: "Available",
    quest_completed: "Completed",
    quest_main: "Main",
    quest_side: "Side",
    no_quests: "No active quests",
    quest_started: "New quest: {name}",
    quest_done: "Completed: {name}",
    journal_entries: "Entries",
    journal_pages: "Found pages",
    journal_empty: "Nothing here yet",
    journal_day: "Day {n}",
    map_you: "You are here",
    map_unknown: "Unexplored",
    landmark_found: "Discovered: {name}",
    dlg_end: "End conversation",
    dlg_gift: "Give a gift",
    trust: "Trust",
    trust_hostile: "Hostile",
    trust_wary: "Wary",
    trust_neutral: "Neutral",
    trust_friendly: "Friendly",
    trust_trusted: "Trusted",
    gift_accepted: "Gift accepted",
    gift_refused: "Gift refused",
    gift_pick: "Pick an item from your bag",
    menu_resume: "Resume",
    menu_save: "Save",
    menu_load: "Load",
    menu_settings: "Settings",
    menu_new: "New game",
    menu_quit: "Main menu",
    menu_continue: "Continue",
    slot_n: "Slot {n}",
    slot_empty: "Empty",
    slot_corrupt: "Corrupt file",
    slot_delete: "Delete",
    slot_info: "Day {day} \xB7 {time} \xB7 {diff}",
    saved: "Saved",
    save_failed: "Save failed",
    loaded: "Loaded",
    load_failed: "Load failed",
    autosaved: "Autosaved",
    confirm_overwrite: "Overwrite this save?",
    confirm_delete: "Delete this save permanently?",
    diff_easy: "Easy",
    diff_normal: "Normal",
    diff_hard: "Hard",
    diff_realistic: "Realistic (permadeath)",
    difficulty: "Difficulty",
    set_language: "Language",
    set_quality: "Quality",
    q_low: "Low",
    q_medium: "Medium",
    q_high: "High",
    set_invertY: "Invert Y",
    set_sens: "Sensitivity",
    set_fov: "Field of view",
    set_master: "Master volume",
    set_sfx: "Effects",
    set_music: "Music",
    set_ambient: "Ambience",
    set_postfx: "Post-processing",
    set_subtitles: "Sound captions",
    tut_move: "Move with WASD and look with the mouse",
    tut_gather: "Approach a plant or rock and click to gather",
    tut_bag: "Open your backpack with Tab",
    tut_craft: "Open Crafting with K and make your first tools",
    tut_fire: "Build a campfire with B and light it before night",
    tut_water: "Drink before thirst bites: fill your bottle in the shallows, then boil it",
    tut_sleep: "Sleep indoors with Z to restore energy",
    got_item: "Got {name} \xD7{n}",
    tool_broke: "Tool broke: {name}",
    level_up: "{skill} reached level {n}",
    woke_up: "You woke up",
    cannot_sleep_hostile: "Cannot sleep with danger nearby",
    cannot_sleep_energy: "You are not tired enough",
    cannot_sleep_cold: "Too cold to sleep",
    cannot_sleep_hunger: "Too hungry or thirsty to sleep",
    cannot_sleep_exposed: "Find shelter or a bed",
    ate_rotten: "That food was rotten!",
    no_tool_fire: "You need a fire starter",
    fire_failed: "It failed, try again",
    fire_lit: "The fire is lit",
    no_fuel: "Add fuel first",
    hit_nothing: "Nothing to gather",
    too_tired: "Too tired",
    wrong_tool: "You need a better tool",
    water_filled: "Bottle filled",
    no_water: "No water here",
    raft_boarded: "On the raft: A/D steer, W paddle, Shift sail",
    ending_rescue: "Rescued",
    ending_raft: "Across the Sea",
    ending_secret: "Island Secret",
    ending_death: "The End",
    ending_rescue_text: "The helicopter landed on the island. You stayed alive until rescue arrived.",
    ending_raft_text: "You sailed your raft toward the horizon, leaving behind an island that nearly swallowed you.",
    ending_secret_text: "You sent the signal from the bunker, and the world learned what this island hid.",
    ending_death_text: "You did not make it. The island does not forgive.",
    death_cause_fall: "A fatal fall",
    death_cause_animal: "Animal attack",
    death_cause_cut: "Bleeding wound",
    death_cause_fire: "Burns",
    death_cause_drown: "Drowned",
    death_cause_starve: "Starvation",
    death_cause_cold: "Exposure",
    death_cause_unknown: "Unknown cause",
    stats_played: "Time played",
    stats_days: "Days survived",
    retry: "Try again",
    snd_thunder: "[thunder]",
    snd_growl: "[growl]",
    snd_howl: "[howl]",
    snd_heli: "[helicopter]"
  };

  // src/core/i18n.ts
  var dicts = { ar: i18n_ar_default, en: i18n_en_default };
  var current = "ar";
  function setLanguage(lang) {
    current = lang;
    if (typeof document !== "undefined") {
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
      applyToDom();
    }
  }
  function getLanguage() {
    return current;
  }
  function t(key, params) {
    let s = dicts[current][key] ?? dicts.en[key] ?? key;
    if (params) for (const [k, v] of Object.entries(params)) s = s.split(`{${k}}`).join(String(v));
    return s;
  }
  function pick(o) {
    return current === "ar" ? o.ar : o.en;
  }
  function applyToDom(root = document) {
    root.querySelectorAll("[data-i18n]").forEach((el) => {
      el.textContent = t(el.dataset.i18n ?? "");
    });
  }

  // src/core/SaveSystem.ts
  var SLOT_COUNT = 3;
  var MemoryBackend = class {
    name = "memory";
    data = /* @__PURE__ */ new Map();
    async get(k) {
      return this.data.get(k) ?? null;
    }
    async set(k, v) {
      this.data.set(k, v);
    }
    async remove(k) {
      this.data.delete(k);
    }
  };
  var LocalStorageBackend = class {
    name = "localStorage";
    async get(k) {
      return localStorage.getItem(k);
    }
    async set(k, v) {
      localStorage.setItem(k, v);
    }
    async remove(k) {
      localStorage.removeItem(k);
    }
  };
  var IndexedDBBackend = class {
    name = "indexedDB";
    dbp = null;
    db() {
      this.dbp ??= new Promise((res, rej) => {
        const req = indexedDB.open("island-survival", 1);
        req.onupgradeneeded = () => req.result.createObjectStore("kv");
        req.onsuccess = () => res(req.result);
        req.onerror = () => rej(req.error);
      });
      return this.dbp;
    }
    async tx(mode, f) {
      const db = await this.db();
      return new Promise((res, rej) => {
        const r = f(db.transaction("kv", mode).objectStore("kv"));
        r.onsuccess = () => res(r.result);
        r.onerror = () => rej(r.error);
      });
    }
    async get(k) {
      return await this.tx("readonly", (s) => s.get(k)) ?? null;
    }
    async set(k, v) {
      await this.tx("readwrite", (s) => s.put(v, k));
    }
    async remove(k) {
      await this.tx("readwrite", (s) => s.delete(k));
    }
  };
  function createBackend() {
    try {
      if (typeof indexedDB !== "undefined") return new IndexedDBBackend();
    } catch {
    }
    try {
      if (typeof localStorage !== "undefined") {
        localStorage.setItem("__t", "1");
        localStorage.removeItem("__t");
        return new LocalStorageBackend();
      }
    } catch {
    }
    return new MemoryBackend();
  }
  function checksum(s) {
    let h2 = 2166136261;
    for (let i = 0; i < s.length; i++) {
      h2 ^= s.charCodeAt(i);
      h2 = Math.imul(h2, 16777619);
    }
    return (h2 >>> 0).toString(16).padStart(8, "0");
  }
  var MIGRATIONS = {};
  function migrate(d) {
    let v = d.version ?? 0;
    while (v < SAVE_VERSION) {
      const m = MIGRATIONS[v];
      if (!m) throw new Error(`\u0644\u0627 \u062A\u0631\u0642\u064A\u0629 \u0645\u0646 \u0627\u0644\u0625\u0635\u062F\u0627\u0631 ${v}`);
      d = m(d);
      v++;
      d.version = v;
    }
    if (v > SAVE_VERSION) throw new Error(`\u062D\u0641\u0638 \u0645\u0646 \u0625\u0635\u062F\u0627\u0631 \u0623\u062D\u062F\u062B (${v})`);
    return d;
  }
  var SaveSystem = class {
    constructor(backend = createBackend()) {
      this.backend = backend;
    }
    backend;
    key(slot) {
      if (!Number.isInteger(slot) || slot < 0 || slot >= SLOT_COUNT) throw new RangeError(`\u062E\u0627\u0646\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629: ${slot}`);
      return `save.${slot}`;
    }
    async save(slot, data) {
      const body = JSON.stringify(data);
      const env = { v: SAVE_VERSION, sum: checksum(body), body };
      const k = this.key(slot);
      const prev = await this.backend.get(k);
      if (prev) await this.backend.set(`${k}.bak`, prev);
      await this.backend.set(k, JSON.stringify(env));
    }
    async load(slot) {
      const k = this.key(slot);
      const r = await this.tryRead(k);
      if (r.ok || r.error === "empty" || r.error === "version") {
        if (r.ok || r.error !== "empty") return r;
        return r;
      }
      const b = await this.tryRead(`${k}.bak`);
      return b.ok ? b : r;
    }
    async tryRead(k) {
      const raw = await this.backend.get(k);
      if (raw === null) return { ok: false, error: "empty" };
      try {
        const env = JSON.parse(raw);
        if (typeof env.body !== "string" || checksum(env.body) !== env.sum) return { ok: false, error: "corrupt" };
        const data = migrate(JSON.parse(env.body));
        return { ok: true, data };
      } catch (e) {
        return { ok: false, error: /إصدار/.test(String(e)) ? "version" : "corrupt" };
      }
    }
    async delete(slot) {
      const k = this.key(slot);
      await this.backend.remove(k);
      await this.backend.remove(`${k}.bak`);
    }
    async list() {
      const out = [];
      for (let i = 0; i < SLOT_COUNT; i++) {
        const r = await this.load(i);
        if (r.ok) {
          out.push({ slot: i, empty: false, savedAt: r.data.savedAt, playTime: r.data.playTime, day: Math.floor(r.data.totalHours / 24) + 1, difficulty: r.data.difficulty });
        } else out.push({ slot: i, empty: r.error === "empty", corrupt: r.error === "corrupt" });
      }
      return out;
    }
  };

  // src/core/Noise.ts
  var Noise2D = class _Noise2D {
    perm = new Uint8Array(512);
    static G2 = (3 - Math.sqrt(3)) / 6;
    static F2 = 0.5 * (Math.sqrt(3) - 1);
    static GRAD = [
      [1, 1],
      [-1, 1],
      [1, -1],
      [-1, -1],
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1]
    ];
    constructor(seed) {
      const rnd = new Random(seed);
      const p = new Uint8Array(256);
      for (let i = 0; i < 256; i++) p[i] = i;
      for (let i = 255; i > 0; i--) {
        const j = Math.floor(rnd.next() * (i + 1));
        const tmp = p[i];
        p[i] = p[j];
        p[j] = tmp;
      }
      for (let i = 0; i < 512; i++) this.perm[i] = p[i & 255];
    }
    /** قيمة في [-1,1] تقريبًا */
    noise(x, y) {
      const { F2, G2, GRAD } = _Noise2D;
      const s = (x + y) * F2;
      const i = Math.floor(x + s);
      const j = Math.floor(y + s);
      const t2 = (i + j) * G2;
      const x0 = x - (i - t2);
      const y0 = y - (j - t2);
      const i1 = x0 > y0 ? 1 : 0;
      const j1 = x0 > y0 ? 0 : 1;
      const x1 = x0 - i1 + G2;
      const y1 = y0 - j1 + G2;
      const x2 = x0 - 1 + 2 * G2;
      const y2 = y0 - 1 + 2 * G2;
      const ii = i & 255;
      const jj = j & 255;
      const corner = (cx, cy, gi) => {
        let tt = 0.5 - cx * cx - cy * cy;
        if (tt < 0) return 0;
        tt *= tt;
        const g = GRAD[gi & 7];
        return tt * tt * (g[0] * cx + g[1] * cy);
      };
      const n0 = corner(x0, y0, this.perm[ii + this.perm[jj]]);
      const n1 = corner(x1, y1, this.perm[ii + i1 + this.perm[jj + j1]]);
      const n2 = corner(x2, y2, this.perm[ii + 1 + this.perm[jj + 1]]);
      return 70 * (n0 + n1 + n2);
    }
    /** ضوضاء كسورية متعددة الأوكتافات، تعيد قيمة في [-1,1] تقريبًا */
    fbm(x, y, octaves = 5, lacunarity = 2, gain = 0.5) {
      let amp = 1;
      let freq = 1;
      let sum = 0;
      let norm2 = 0;
      for (let o = 0; o < octaves; o++) {
        sum += amp * this.noise(x * freq, y * freq);
        norm2 += amp;
        amp *= gain;
        freq *= lacunarity;
      }
      return sum / norm2;
    }
    /** ضوضاء حادة الحواف (ridged) تناسب السلاسل الجبلية، في [0,1] */
    ridged(x, y, octaves = 4) {
      let amp = 1;
      let freq = 1;
      let sum = 0;
      let norm2 = 0;
      for (let o = 0; o < octaves; o++) {
        const n = 1 - Math.abs(this.noise(x * freq, y * freq));
        sum += amp * n * n;
        norm2 += amp;
        amp *= 0.5;
        freq *= 2;
      }
      return sum / norm2;
    }
  };

  // src/world/BiomeRules.ts
  function classifyBiome(h2, slope, moisture) {
    if (h2 < -6) return "deepSea";
    if (h2 < 0.4) return "shallows";
    if (h2 < 2.2 && slope < 0.5) return "beach";
    if (h2 > 38) return "volcanic";
    if (slope > 0.55) return "rock";
    if (h2 > 24) return "rock";
    return moisture > 0.5 ? "jungle" : "grass";
  }

  // src/world/TerrainGenerator.ts
  var CAVE_LENGTH = 40;
  var CAVE_TERRACE_HALF_WIDTH = 8;
  var CAVE_TERRACE_BLEND = 7;
  var TERRAIN_SIZE = 512;
  var TERRAIN_RES = 256;
  var TerrainGenerator = class {
    constructor(seed = "island-1") {
      this.seed = seed;
      this.noise = new Noise2D(seed);
      this.warp = new Noise2D(`${seed}-warp`);
      this.moistureNoise = new Noise2D(`${seed}-moist`);
      const n = TERRAIN_RES + 1;
      this.heights = new Float32Array(n * n);
      for (let j = 0; j < n; j++) {
        for (let i = 0; i < n; i++) {
          const x = i * this.cell - this.half;
          const z = j * this.cell - this.half;
          this.heights[j * n + i] = this.computeHeight(x, z);
        }
      }
      this.spawn = this.findBeachSpawn();
      this.planCaves(2);
    }
    seed;
    noise;
    warp;
    moistureNoise;
    /** شبكة الارتفاعات (RES+1)² مخزنة مسبقًا للسرعة */
    heights;
    cell = TERRAIN_SIZE / TERRAIN_RES;
    half = TERRAIN_SIZE / 2;
    /** نقطة صالحة للظهور على الشاطئ */
    spawn = { x: 0, y: 0, z: 0 };
    /** مواقع الكهوف المخططة (بعد تسوية المصاطب) */
    caveSites = [];
    /** الارتفاع الخام (بدون استيفاء) */
    computeHeight(x, z) {
      const wx = x + this.warp.fbm(x * 6e-3, z * 6e-3, 3) * 55;
      const wz = z + this.warp.fbm(x * 6e-3 + 40, z * 6e-3 - 17, 3) * 55;
      const r = Math.hypot(wx, wz);
      const islandRadius = 190;
      const t2 = r / islandRadius;
      const m = 1 - t2 * t2;
      const m0 = 0.03;
      const beachSlope = 3.8;
      const base = this.noise.fbm(x * 8e-3, z * 8e-3, 5) * 0.5 + 0.5;
      const hills = this.noise.fbm(x * 0.02, z * 0.02, 4) * 3;
      const ridge = this.noise.ridged(x * 0.012 + 100, z * 0.012 + 100, 4);
      const peak = Math.exp(-(r * r) / (2 * 45 * 45)) * 26;
      const inland = base * 10 + ridge * 6 + peak + hills;
      let h2;
      if (m >= m0) {
        h2 = beachSlope * (m - m0) + inland * smoothstep(0.12, 0.55, m);
      } else {
        h2 = -(m0 - m) * 8;
      }
      return Math.max(-48, h2);
    }
    /** ارتفاع مستمر بالاستيفاء الثنائي من الشبكة (يطابق الشبكة المرسومة تمامًا) */
    height(x, z) {
      const n = TERRAIN_RES + 1;
      const fx = (x + this.half) / this.cell;
      const fz = (z + this.half) / this.cell;
      if (fx < 0 || fz < 0 || fx >= TERRAIN_RES || fz >= TERRAIN_RES) return -50;
      const i = Math.floor(fx);
      const j = Math.floor(fz);
      const tx = fx - i;
      const tz = fz - j;
      const h00 = this.heights[j * n + i];
      const h10 = this.heights[j * n + i + 1];
      const h01 = this.heights[(j + 1) * n + i];
      const h11 = this.heights[(j + 1) * n + i + 1];
      return (h00 * (1 - tx) + h10 * tx) * (1 - tz) + (h01 * (1 - tx) + h11 * tx) * tz;
    }
    /** الميل 0..1 (0 مسطح) */
    slope(x, z) {
      const e = this.cell;
      const dx = (this.height(x + e, z) - this.height(x - e, z)) / (2 * e);
      const dz = (this.height(x, z + e) - this.height(x, z - e)) / (2 * e);
      return Math.min(1, Math.hypot(dx, dz));
    }
    normal(x, z, out = { x: 0, y: 0, z: 0 }) {
      const e = this.cell;
      const dx = this.height(x + e, z) - this.height(x - e, z);
      const dz = this.height(x, z + e) - this.height(x, z - e);
      const nx = -dx;
      const ny = 2 * e;
      const nz = -dz;
      const len2 = Math.hypot(nx, ny, nz) || 1;
      out.x = nx / len2;
      out.y = ny / len2;
      out.z = nz / len2;
      return out;
    }
    moisture(x, z) {
      return this.moistureNoise.fbm(x * 0.01, z * 0.01, 3) * 0.5 + 0.5;
    }
    biomeAt(x, z) {
      return classifyBiome(this.height(x, z), this.slope(x, z), this.moisture(x, z));
    }
    /** يبحث على امتداد أشعة من المركز عن أول نقطة شاطئ ارتفاعها بين 0.8 و 1.6م */
    findBeachSpawn() {
      for (let a = 0; a < 360; a += 5) {
        const ang = a * Math.PI / 180;
        for (let r = 260; r > 20; r -= 1) {
          const x = Math.cos(ang) * r;
          const z = Math.sin(ang) * r;
          const h2 = this.height(x, z);
          if (h2 > 0.8 && h2 < 1.6 && this.slope(x, z) < 0.25) {
            if (this.height(Math.cos(ang) * (r - 25), Math.sin(ang) * (r - 25)) > 2) {
              return { x, y: h2, z };
            }
          }
        }
      }
      return { x: 0, y: this.height(0, 0) + 1, z: 0 };
    }
    /**
     * يخطط كهوفًا على سفوح التلال: يبحث عن ميل معتدل بارتفاع 8–18م بعيدًا عن الشاطئ ونقطة الظهور،
     * ثم يسوّي مصطبة مستوية تحت النفق (خريطة الارتفاعات لا تمثل التجاويف، فالنفق يُبنى كهيكل مستقل فوقها).
     */
    planCaves(count) {
      const sites = [];
      const rnd = new Noise2D(`${this.seed}-caves`);
      for (let ring = 40; ring <= 170 && sites.length < count; ring += 6) {
        for (let k = 0; k < 48 && sites.length < count; k++) {
          const a = k / 48 * Math.PI * 2 + rnd.noise(ring, k) * 0.2;
          const x = Math.cos(a) * ring;
          const z = Math.sin(a) * ring;
          const h2 = this.height(x, z);
          const s = this.slope(x, z);
          if (h2 < 8 || h2 > 18 || s < 0.2 || s > 0.5) continue;
          if (Math.hypot(x - this.spawn.x, z - this.spawn.z) < 70) continue;
          if (sites.some((c) => Math.hypot(c.x - x, c.z - z) < 90)) continue;
          const e = this.cell;
          let ux = this.height(x + e, z) - this.height(x - e, z);
          let uz = this.height(x, z + e) - this.height(x, z - e);
          const ul = Math.hypot(ux, uz);
          if (ul < 1e-4) continue;
          ux /= ul;
          uz /= ul;
          const ex = x + ux * CAVE_LENGTH;
          const ez = z + uz * CAVE_LENGTH;
          if (this.height(ex, ez) < h2) continue;
          sites.push({ x, y: h2, z, yaw: Math.atan2(ux, uz), length: CAVE_LENGTH });
        }
      }
      for (const c of sites) this.flattenForCave(c);
      this.caveSites = sites;
    }
    /** تسوية مصطبة مستطيلة موجّهة مع انتقال ناعم عند الحواف */
    flattenForCave(c) {
      const n = TERRAIN_RES + 1;
      const fx = Math.sin(c.yaw);
      const fz = Math.cos(c.yaw);
      const front = 8;
      const reach = c.length + front + CAVE_TERRACE_BLEND + CAVE_TERRACE_HALF_WIDTH + 4;
      for (let j = 0; j < n; j++) {
        for (let i = 0; i < n; i++) {
          const x = i * this.cell - this.half;
          const z = j * this.cell - this.half;
          const dx = x - c.x;
          const dz = z - c.z;
          if (Math.abs(dx) > reach || Math.abs(dz) > reach) continue;
          const along = dx * fx + dz * fz;
          const side = dx * fz - dz * fx;
          const dA = Math.max(-front - along, along - (c.length + 4), 0);
          const dS = Math.max(Math.abs(side) - CAVE_TERRACE_HALF_WIDTH, 0);
          const d = Math.hypot(dA, dS);
          if (d >= CAVE_TERRACE_BLEND) continue;
          const w = 1 - smoothstep(0, CAVE_TERRACE_BLEND, d);
          const idx = j * n + i;
          this.heights[idx] = this.heights[idx] * (1 - w) + c.y * w;
        }
      }
    }
    /** هل النقطة داخل مصطبة كهف (لمنع توزيع الأشجار والصخور هناك) */
    insideCaveFootprint(x, z, margin = 4) {
      for (const c of this.caveSites) {
        const fx = Math.sin(c.yaw);
        const fz = Math.cos(c.yaw);
        const dx = x - c.x;
        const dz = z - c.z;
        const along = dx * fx + dz * fz;
        const side = dx * fz - dz * fx;
        if (along > -8 - margin && along < c.length + margin && Math.abs(side) < CAVE_TERRACE_HALF_WIDTH + margin) return true;
      }
      return false;
    }
  };
  function smoothstep(a, b, x) {
    const t2 = Math.min(1, Math.max(0, (x - a) / (b - a)));
    return t2 * t2 * (3 - 2 * t2);
  }

  // src/inventory/DragDrop.ts
  var DragController = class {
    held = null;
    origin = null;
    get active() {
      return this.held !== null;
    }
    /** يلتقط عنصرًا (أو جزءًا منه) من شبكة */
    pickup(grid, uid, amount) {
      if (this.held) return false;
      const e = grid.get(uid);
      if (!e) return false;
      if (amount !== void 0 && amount > 0 && amount < e.stack.count) {
        const part = ItemDB.create(e.stack.defId, amount, { durability: e.stack.durability, spoil: e.stack.spoil });
        e.stack.count -= amount;
        this.held = { stack: part, rotated: e.rotated };
        this.origin = { grid, x: e.x, y: e.y, rotated: e.rotated };
        return true;
      }
      grid.remove(uid);
      this.held = { stack: e.stack, rotated: e.rotated };
      this.origin = { grid, x: e.x, y: e.y, rotated: e.rotated };
      return true;
    }
    rotate() {
      if (this.held) this.held.rotated = !this.held.rotated;
    }
    /** يفلت العنصر عند الخلية (x,y) في شبكة؛ يدمج أو يبدّل إن لزم */
    drop(grid, x, y) {
      if (!this.held) return "rejected";
      const { stack, rotated } = this.held;
      const def = ItemDB.get(stack.defId);
      if (grid.canPlace(def, x, y, rotated)) {
        grid.place(stack, x, y, rotated);
        return this.finish("placed");
      }
      const overlap = grid.overlapping(def, x, y, rotated);
      if (overlap.length === 1) {
        const target = overlap[0];
        const td = ItemDB.get(target.stack.defId);
        if (target.stack.defId === stack.defId && td.stack > 1 && target.stack.count < td.stack) {
          const room = td.stack - target.stack.count;
          const moved = Math.min(room, stack.count);
          target.stack.spoil = (target.stack.spoil * target.stack.count + stack.spoil * moved) / (target.stack.count + moved);
          target.stack.count += moved;
          stack.count -= moved;
          if (stack.count <= 0) return this.finish("merged");
          return "merged";
        }
        grid.remove(target.stack.uid);
        if (grid.canPlace(def, x, y, rotated)) {
          grid.place(stack, x, y, rotated);
          this.held = { stack: target.stack, rotated: target.rotated };
          this.origin = { grid, x: target.x, y: target.y, rotated: target.rotated };
          return "swapped";
        }
        grid.place(target.stack, target.x, target.y, target.rotated);
      }
      return "rejected";
    }
    /** إلغاء: إعادة العنصر لمكانه الأصلي أو أقرب مكان متاح في نفس الشبكة */
    cancel() {
      if (!this.held || !this.origin) return false;
      const { stack } = this.held;
      const { grid, x, y, rotated } = this.origin;
      const def = ItemDB.get(stack.defId);
      const at = grid.at(x, y);
      if (at && at.stack.defId === stack.defId && ItemDB.get(stack.defId).stack > 1) {
        at.stack.count += stack.count;
      } else if (grid.canPlace(def, x, y, rotated)) {
        grid.place(stack, x, y, rotated);
      } else if (grid.addStack(stack) > 0) {
        return false;
      }
      this.held = null;
      this.origin = null;
      return true;
    }
    finish(r) {
      this.held = null;
      this.origin = null;
      return r;
    }
  };

  // src/ui/dom.ts
  function h(tag, attrs = {}, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === void 0 || v === null || v === false) continue;
      if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
      else if (k === "class") el.className = String(v);
      else if (v === true) el.setAttribute(k, "");
      else el.setAttribute(k, String(v));
    }
    for (const c of kids) if (c !== null && c !== void 0 && c !== false) el.append(typeof c === "number" ? String(c) : c);
    return el;
  }
  function clear(el) {
    while (el.firstChild) el.removeChild(el.firstChild);
  }
  function clamp012(v) {
    return v < 0 ? 0 : v > 1 ? 1 : v;
  }
  function fmtClock(hour) {
    const hh = Math.floor(hour) % 24;
    const mm = Math.floor(hour % 1 * 60);
    return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
  }
  function fmtDuration(sec) {
    const h2 = Math.floor(sec / 3600);
    const m = Math.floor(sec % 3600 / 60);
    return h2 > 0 ? `${h2}h ${m}m` : `${m}m`;
  }
  var Panel = class {
    constructor(id, cls = "") {
      this.id = id;
      this.root = h("div", { class: `panel ${cls}`, id: `panel-${id}`, hidden: true });
      this.root.addEventListener("contextmenu", (e) => e.preventDefault());
    }
    id;
    root;
    isOpen = false;
    open() {
      this.isOpen = true;
      this.root.hidden = false;
      this.refresh();
    }
    close() {
      this.isOpen = false;
      this.root.hidden = true;
      this.onClose();
    }
    toggle() {
      if (this.isOpen) this.close();
      else this.open();
    }
    onClose() {
    }
    /** يُستدعى ~4 مرات/ث أثناء الفتح لتحديث القيم الحية */
    tick() {
      this.refresh();
    }
  };

  // src/ui/Tooltip.ts
  function itemName(defId) {
    const d = ItemDB.get(defId);
    return getLanguage() === "ar" ? d.nameAr : d.nameEn;
  }
  var EFFECT_LABEL = {
    hunger: ["\u062C\u0648\u0639", "Hunger"],
    thirst: ["\u0639\u0637\u0634", "Thirst"],
    health: ["\u0635\u062D\u0629", "Health"],
    energy: ["\u0637\u0627\u0642\u0629", "Energy"],
    stamina: ["\u0646\u0641\u064E\u0633", "Stamina"],
    sanity: ["\u0627\u062A\u0632\u0627\u0646", "Sanity"],
    damage: ["\u0636\u0631\u0631", "Damage"],
    warmth: ["\u062F\u0641\u0621", "Warmth"],
    defense: ["\u062D\u0645\u0627\u064A\u0629", "Defense"],
    ignite: ["\u0625\u0634\u0639\u0627\u0644", "Ignite"]
  };
  function tooltipFor(stack) {
    const d = ItemDB.get(stack.defId);
    const st = spoilState(d, stack);
    const ar = getLanguage() === "ar";
    const lines = [];
    for (const [k, v] of Object.entries(d.effects)) {
      const lab = EFFECT_LABEL[k];
      if (lab && typeof v === "number") lines.push(`${ar ? lab[0] : lab[1]}: ${v > 0 && k !== "damage" && k !== "warmth" && k !== "defense" && k !== "ignite" ? "+" : ""}${v}`);
    }
    const body = h(
      "div",
      {},
      h("b", { style: `color:${RARITY_COLORS[d.rarity]}` }, `${d.icon} ${itemName(d.id)}`),
      h("div", { class: "dim" }, t(`rarity_${d.rarity}`), ` \xB7 ${t("weight")}: ${(d.weight * stack.count).toFixed(1)}`)
    );
    if (d.durability > 0) body.append(h("div", {}, `${t("durability")}: ${Math.ceil(stack.durability)}/${d.durability}`));
    if (st !== "none") body.append(h("div", {}, t(`spoil_${st}`)));
    for (const l of lines) body.append(h("div", {}, l));
    return body;
  }
  var Tooltip = class {
    root = h("div", { class: "tip", hidden: true });
    show(content, x, y) {
      this.root.replaceChildren(content);
      this.root.hidden = false;
      const w = this.root.offsetWidth || 220;
      const hh = this.root.offsetHeight || 80;
      this.root.style.left = `${Math.min(x + 14, window.innerWidth - w - 6)}px`;
      this.root.style.top = `${Math.min(y + 14, window.innerHeight - hh - 6)}px`;
    }
    hide() {
      this.root.hidden = true;
    }
  };

  // src/ui/BackpackUI.ts
  var BackpackUI = class extends Panel {
    /** يُستدعى عند الإفلات خارج اللوحة على شريط سريع: يُحدَّد من HUD عبر data-hslot */
    constructor(host2) {
      super("backpack", "bag");
      this.host = host2;
      this.root.append(this.body);
      window.addEventListener("keydown", (e) => {
        if (this.isOpen && this.drag.active && e.code === "KeyR") {
          this.drag.rotate();
          this.updateGhostSize();
        }
      });
    }
    host;
    drag = new DragController();
    views = [];
    ghost = null;
    selected = null;
    container = null;
    body = h("div");
    tooltip = new Tooltip();
    openContainer(c) {
      this.container = c;
      if (this.isOpen) this.refresh();
    }
    onClose() {
      this.cancelDrag();
      this.selected = null;
      this.container = null;
      this.tooltip.hide();
    }
    get cell() {
      return parseFloat(getComputedStyle(this.root).getPropertyValue("--cell")) || 46;
    }
    tick() {
      if (!this.drag.active) this.refresh();
    }
    refresh() {
      if (!this.drag.active) this.render();
    }
    render() {
      const inv = this.host.session.inventory;
      this.views = [];
      clear(this.body);
      const load = inv.burden;
      const pct = clamp012(inv.totalWeight / inv.maxWeight);
      const wbar = h("div", { class: `wbar ${load.speedMultiplier < 0.6 ? "heavy" : load.speedMultiplier < 0.999 ? "over" : ""}` }, h("i", { style: `width:${pct * 100}%` }));
      this.body.append(
        h("h2", {}, h("span", {}, `\u{1F392} ${t("inventory")}`), h("button", { onclick: () => this.close() }, "\u2715")),
        h("div", { class: "dim" }, `${t("weight")}: ${inv.totalWeight.toFixed(1)} / ${inv.maxWeight}`),
        wbar
      );
      const row = h("div", { class: "row" });
      row.append(this.equipmentView());
      const col = h("div", {}, h("div", { class: "row" }, h("button", { onclick: () => {
        inv.sort();
        this.host.sfx("click");
        this.refresh();
      } }, t("act_sort"))), this.gridView(inv.grid, "bag"));
      row.append(col);
      if (this.container) row.append(h("div", {}, h("h3", {}, `\u{1F4E6} ${t("container")}`), this.gridView(this.container.grid, "box")));
      this.body.append(row, this.actionBar(), h("div", { class: "dim" }, t("drag_hint")));
    }
    // ---------- شبكة ----------
    gridView(grid, id) {
      const c = this.cell;
      const el = h("div", { class: "igrid", style: `width:${grid.width * c}px;height:${grid.height * c}px` });
      this.views.push({ grid, el, id });
      for (const e of grid.list()) el.append(this.tile(grid, e.stack, e.x, e.y, e.rotated, c));
      return el;
    }
    tile(grid, stack, x, y, rotated, c) {
      const d = ItemDB.get(stack.defId);
      const [w, hh] = Grid.dims(d, rotated);
      const st = spoilState(d, stack);
      const el = h("div", {
        class: `item${this.selected?.uid === stack.uid ? " sel" : ""}${st === "stale" ? " stale" : st === "rotten" ? " rotten" : ""}`,
        style: `left:${x * c}px;top:${y * c}px;width:${w * c}px;height:${hh * c}px;border-color:${RARITY_COLORS[d.rarity]}`,
        "data-uid": stack.uid
      }, d.icon);
      if (stack.count > 1) el.append(h("span", { class: "cnt" }, stack.count));
      if (d.durability > 0) el.append(h("span", { class: "dur", style: `width:${clamp012(stack.durability / d.durability) * 100}%;background:${RARITY_COLORS[d.rarity]}` }));
      el.addEventListener("pointerdown", (ev) => this.onDown(ev, grid, stack.uid));
      el.addEventListener("pointerenter", (ev) => this.tooltip.show(tooltipFor(stack), ev.clientX, ev.clientY));
      el.addEventListener("pointermove", (ev) => !this.drag.active && this.tooltip.show(tooltipFor(stack), ev.clientX, ev.clientY));
      el.addEventListener("pointerleave", () => this.tooltip.hide());
      return el;
    }
    // ---------- سحب ----------
    onDown(ev, grid, uid) {
      if (ev.button !== 0 && ev.pointerType === "mouse") return;
      ev.preventDefault();
      const sx = ev.clientX;
      const sy = ev.clientY;
      let dragging = false;
      const move = (e) => {
        if (!dragging && Math.hypot(e.clientX - sx, e.clientY - sy) > 6) {
          dragging = true;
          this.tooltip.hide();
          if (!this.drag.pickup(grid, uid)) {
            dragging = false;
            return;
          }
          this.makeGhost();
        }
        if (dragging) this.moveGhost(e.clientX, e.clientY);
      };
      const up = (e) => {
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
        window.removeEventListener("pointercancel", up);
        if (dragging) this.finishDrag(e.clientX, e.clientY);
        else {
          this.selected = this.selected?.uid === uid ? null : { uid, grid };
          this.host.sfx("click");
          this.refresh();
        }
      };
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", up);
      window.addEventListener("pointercancel", up);
    }
    makeGhost() {
      const hd = this.drag.held;
      const d = ItemDB.get(hd.stack.defId);
      const c = this.cell;
      const [w, hh] = Grid.dims(d, hd.rotated);
      this.ghost = h("div", { class: "item ghost", style: `width:${w * c}px;height:${hh * c}px;border-color:${RARITY_COLORS[d.rarity]}` }, d.icon);
      document.body.append(this.ghost);
      this.render();
    }
    updateGhostSize() {
      if (!this.ghost || !this.drag.held) return;
      const d = ItemDB.get(this.drag.held.stack.defId);
      const [w, hh] = Grid.dims(d, this.drag.held.rotated);
      this.ghost.style.width = `${w * this.cell}px`;
      this.ghost.style.height = `${hh * this.cell}px`;
    }
    moveGhost(x, y) {
      if (!this.ghost) return;
      const w = this.ghost.offsetWidth;
      const hh = this.ghost.offsetHeight;
      this.ghost.style.left = `${x - w / 2}px`;
      this.ghost.style.top = `${y - hh / 2}px`;
    }
    finishDrag(px, py) {
      const held = this.drag.held;
      const ghostRect = this.ghost.getBoundingClientRect();
      this.ghost?.remove();
      this.ghost = null;
      const under = document.elementFromPoint(px, py);
      const inv = this.host.session.inventory;
      const hs = under?.closest("[data-hslot]");
      const view = this.views.find((v) => v.el.contains(under) || v.el === under) ?? this.views.find((v) => {
        const r = v.el.getBoundingClientRect();
        return px >= r.left && px <= r.right && py >= r.top && py <= r.bottom;
      });
      if (hs) {
        const uid = held.stack.uid;
        this.drag.cancel();
        if (inv.grid.get(uid)) inv.hotbar.assign(Number(hs.dataset.hslot), uid);
      } else if (view) {
        const r = view.el.getBoundingClientRect();
        const c = this.cell;
        const x = Math.round((ghostRect.left - r.left) / c);
        const y = Math.round((ghostRect.top - r.top) / c);
        const res = this.drag.drop(view.grid, x, y);
        if (res === "rejected") {
          this.drag.cancel();
          this.host.sfx("click");
        } else this.host.sfx("equip");
      } else if (!this.root.contains(under) && !under?.closest(".panel")) {
        const stack = held.stack;
        this.drag.held = null;
        const p = this.host.player();
        this.host.session.ground.drop(stack, p.x - Math.sin(p.yaw) * 1.2, p.y, p.z - Math.cos(p.yaw) * 1.2);
        inv.hotbar.clearUid(stack.uid);
      } else {
        this.drag.cancel();
      }
      inv.onChange?.();
      this.refresh();
    }
    cancelDrag() {
      if (this.drag.active) this.drag.cancel();
      this.ghost?.remove();
      this.ghost = null;
    }
    // ---------- تجهيز ----------
    equipmentView() {
      const inv = this.host.session.inventory;
      const wrap = h("div", {}, h("h3", {}, t("equipment")));
      const g = h("div", { class: "eqgrid" });
      for (const slot of EQUIP_SLOTS) {
        const s = inv.equipment.get(slot);
        const el = h(
          "div",
          { class: `eqslot${s ? " full" : ""}`, onclick: () => {
            if (s) {
              inv.unequip(slot);
              this.host.sfx("equip");
              this.refresh();
            }
          } },
          s ? ItemDB.get(s.defId).icon : "",
          h("small", {}, t(`slot_${slot}`))
        );
        if (s) {
          el.addEventListener("pointerenter", (ev) => this.tooltip.show(tooltipFor(s), ev.clientX, ev.clientY));
          el.addEventListener("pointerleave", () => this.tooltip.hide());
        }
        g.append(el);
      }
      wrap.append(g, h("div", { class: "dim" }, `\u{1F6E1} ${inv.equipment.defense} \xB7 \u{1F525} ${inv.equipment.warmth}`));
      return wrap;
    }
    // ---------- إجراءات ----------
    actionBar() {
      const bar = h("div", { class: "actions" });
      const sel = this.selected;
      if (!sel) return bar;
      const inv = this.host.session.inventory;
      const e = sel.grid.get(sel.uid);
      if (!e) {
        this.selected = null;
        return bar;
      }
      const d = ItemDB.get(e.stack.defId);
      bar.append(h("b", {}, `${d.icon} ${itemName(d.id)}`));
      const inBag = sel.grid === inv.grid;
      const btn = (label, fn, primary = false) => {
        bar.append(h("button", { class: primary ? "primary" : "", onclick: () => {
          fn();
          this.refresh();
        } }, label));
      };
      const usable = ["food", "drink", "medicine", "story"].includes(d.type) || d.id.endsWith("_empty");
      if (inBag && usable) btn(t("act_use"), () => this.use(sel.uid), true);
      if (inBag && ["clothing", "backpack", "tool", "weapon"].includes(d.type)) btn(t("act_equip"), () => {
        const r = inv.equip(sel.uid);
        if (!r.ok && r.reason) this.host.notify(r.reason, "bad");
        this.host.sfx("equip");
      });
      if (inBag) btn(t("act_hotbar"), () => {
        const i = inv.hotbar.firstFree();
        inv.hotbar.assign(i < 0 ? inv.hotbar.selected : i, sel.uid);
      });
      if (e.stack.count > 1) btn(t("act_split"), () => {
        if (sel.grid === inv.grid) inv.split(sel.uid, Math.floor(e.stack.count / 2));
      });
      if (this.container) btn(inBag ? "\u2192 \u{1F4E6}" : "\u2190 \u{1F392}", () => this.transfer(sel.grid, sel.uid));
      btn(t("act_drop"), () => this.dropItem(sel.grid, sel.uid));
      return bar;
    }
    use(uid) {
      const p = this.host.player();
      const r = this.host.session.useItem(uid, p);
      if (r.ok) {
        const d = ItemDB.get(this.host.session.inventory.grid.get(uid)?.stack.defId ?? "");
        void d;
        this.host.sfx("eat");
      }
      this.selected = null;
    }
    transfer(from, uid) {
      const inv = this.host.session.inventory;
      const to = from === inv.grid ? this.container.grid : inv.grid;
      const e = from.get(uid);
      if (!e) return;
      const stack = e.stack;
      from.remove(uid);
      const left = to.addStack(stack);
      if (left > 0) {
        from.addStack({ ...stack, count: left });
        this.host.notify(t("inv_full"), "bad");
      }
      inv.hotbar.clearUid(uid);
      inv.onChange?.();
      this.selected = null;
    }
    dropItem(from, uid) {
      const inv = this.host.session.inventory;
      const e = from.get(uid);
      if (!e) return;
      from.remove(uid);
      inv.hotbar.clearUid(uid);
      const p = this.host.player();
      this.host.session.ground.drop(e.stack, p.x - Math.sin(p.yaw) * 1.2, p.y, p.z - Math.cos(p.yaw) * 1.2);
      inv.onChange?.();
      this.selected = null;
    }
  };

  // src/ui/BuildUI.ts
  var BuildUI = class extends Panel {
    constructor(host2) {
      super("build");
      this.host = host2;
    }
    host;
    demolish = false;
    refresh() {
      const inv = this.host.session.inventory;
      const ar = getLanguage() === "ar";
      const list = h("div", { class: "buildlist" });
      for (const bp of Object.values(BLUEPRINTS)) {
        const afford = Object.entries(bp.cost).every(([id, n]) => inv.count(id) >= n);
        list.append(h(
          "div",
          { class: `bp${afford ? "" : " no"}`, onclick: () => {
            this.host.startBuild(bp.type);
            this.close();
          } },
          h("b", {}, ar ? bp.nameAr : bp.nameEn),
          h("small", {}, Object.entries(bp.cost).map(([id, n]) => `${ItemDB.get(id).icon}${itemName(id)} ${inv.count(id)}/${n}`).join(" \xB7 "))
        ));
      }
      this.root.replaceChildren(
        h("h2", {}, h("span", {}, `\u{1F3D7} ${t("build")}`), h("button", { onclick: () => this.close() }, "\u2715")),
        list,
        h("div", { class: "actions" }, h("button", { onclick: () => {
          this.host.setDemolish(true);
          this.close();
        } }, `\u{1F528} ${t("build_remove")}`)),
        h("div", { class: "dim" }, t("build_hint"))
      );
    }
  };

  // src/ui/CraftUI.ts
  var PROCESSING = ["campfire", "furnace", "drying_rack"];
  function missingText(m) {
    switch (m.kind) {
      case "ingredient":
        return t("missing_ingredient", { name: itemName(m.id), have: m.have, need: m.need });
      case "tool":
        return t("missing_tool", { name: itemName(m.id) });
      case "station":
        return t("missing_station", { name: t(`station_${m.station}`) });
      case "skill":
        return t("missing_skill", { name: t(`skill_${m.skill}`), need: m.need });
      case "space":
        return t("missing_space");
    }
  }
  function recipeName(r) {
    return getLanguage() === "ar" ? r.nameAr : r.nameEn;
  }
  var CraftUI = class extends Panel {
    constructor(host2) {
      super("craft");
      this.host = host2;
      this.root.append(
        h("h2", {}, h("span", {}, `\u{1F528} ${t("crafting")}`), h("button", { onclick: () => this.close() }, "\u2715")),
        h("div", { class: "tabs", id: "craft-tabs" }),
        h("div", { class: "row" }, this.list, this.detail),
        this.queue,
        this.stations
      );
    }
    host;
    sel = null;
    filter = "all";
    list = h("div", { class: "recipes" });
    detail = h("div", { class: "detail" });
    stations = h("div");
    queue = h("div");
    tabs() {
      const el = this.root.querySelector("#craft-tabs");
      clear(el);
      for (const f of ["all", "hand", "workbench", "campfire", "furnace", "drying_rack"]) {
        el.append(h("button", { class: this.filter === f ? "on" : "", onclick: () => {
          this.filter = f;
          this.refresh();
        } }, f === "all" ? "\u2605" : t(`station_${f}`)));
      }
    }
    refresh() {
      const s = this.host.session;
      const p = this.host.player();
      this.tabs();
      clear(this.list);
      const all = s.recipes.list(this.filter === "all" ? void 0 : this.filter);
      if (all.length === 0) this.list.append(h("div", { class: "dim" }, t("no_recipes")));
      const rows = all.map((r) => ({ r, ok: s.canCraft(r, p) })).sort((a, b) => Number(b.ok) - Number(a.ok));
      for (const { r, ok } of rows) {
        this.list.append(h(
          "div",
          { class: `recipe${this.sel === r.id ? " sel" : ""}${ok ? "" : " no"}`, onclick: () => {
            this.sel = r.id;
            this.host.sfx("click");
            this.refresh();
          } },
          h("span", { class: "ic" }, ItemDB.get(r.output.id).icon),
          h("span", {}, recipeName(r)),
          r.output.count > 1 ? h("span", { class: "dim" }, `\xD7${r.output.count}`) : null
        ));
      }
      this.renderDetail();
      this.renderQueue();
      this.renderStations();
    }
    renderDetail() {
      clear(this.detail);
      const r = this.sel ? this.host.session.recipes.get(this.sel) : void 0;
      if (!r) return;
      const s = this.host.session;
      const p = this.host.player();
      const missing = checkRecipe(r, s.inventory, s.craftContext(p));
      const d = ItemDB.get(r.output.id);
      this.detail.append(h("h3", {}, `${d.icon} ${recipeName(r)} \xD7${r.output.count}`), h("div", { class: "dim" }, `${t("station")}: ${t(`station_${r.station}`)} \xB7 \u23F1 ${r.time}s`), h("h3", {}, t("ingredients")));
      for (const g of r.ingredients) {
        const have = s.inventory.count(g.id);
        this.detail.append(h("div", { class: `ing${have < g.count ? " miss" : ""}` }, h("span", {}, `${ItemDB.get(g.id).icon} ${itemName(g.id)}`), h("span", {}, `${have}/${g.count}`)));
      }
      if (r.tools.length) this.detail.append(h("h3", {}, t("tools_needed")), ...r.tools.map((x) => h("div", { class: "ing" }, `${ItemDB.get(x).icon} ${itemName(x)}`)));
      for (const m of missing) if (m.kind !== "ingredient") this.detail.append(h("div", { class: "ing miss" }, missingText(m)));
      const processing = PROCESSING.includes(r.station);
      const target = processing ? s.nearestProcessing(p, r.station) : null;
      const can = missing.length === 0 && (!processing || !!target);
      const label = processing ? t("prompt_cook") : t("craft");
      this.detail.append(h("div", { class: "actions" }, h("button", {
        class: "primary",
        disabled: !can,
        onclick: () => this.doCraft(r, processing, target?.pieceId ?? null)
      }, label)));
      if (processing && !target) this.detail.append(h("div", { class: "ing miss" }, t("missing_station", { name: t(`station_${r.station}`) })));
    }
    doCraft(r, processing, pieceId) {
      const s = this.host.session;
      const p = this.host.player();
      if (processing && pieceId !== null) {
        const res = s.processInsert(pieceId, r);
        if (!res.ok) this.host.notify(res.reason ?? "", "bad");
        else this.host.sfx("craft");
      } else {
        const res = r.time <= 0.5 ? s.craftNow(r, p) : s.craftQueued(r, p);
        if (res.ok) {
          this.host.sfx("craft");
          if (r.time <= 0.5) this.host.notify(t("crafted", { name: recipeName(r) }), "good");
        } else if (res.missing[0]) this.host.notify(missingText(res.missing[0]), "bad");
      }
      this.refresh();
    }
    renderQueue() {
      clear(this.queue);
      const jobs = this.host.session.craftQueue.jobs;
      if (!jobs.length) return;
      this.queue.append(h("h3", {}, "\u23F3"));
      jobs.forEach((j, i) => {
        const pct = i === 0 ? Math.round((1 - j.remaining / Math.max(0.01, j.recipe.time)) * 100) : 0;
        this.queue.append(h("div", { class: "ing" }, h("span", {}, recipeName(j.recipe)), h("span", {}, i === 0 ? `${pct}%` : "\u2026")));
      });
    }
    renderStations() {
      clear(this.stations);
      const s = this.host.session;
      const p = this.host.player();
      for (const kind of PROCESSING) {
        const near = s.nearestProcessing(p, kind);
        if (!near) continue;
        const fire = near.fire;
        this.stations.append(h("h3", {}, `${t(`station_${kind}`)}${fire ? fire.burning ? " \u{1F525}" : " \xB7" : ""}`));
        const box = h("div", { class: "slots" });
        near.station.slots.forEach((slot, i) => {
          if (!slot) return void box.append(h("div", { class: "pslot dim" }, t("cook_slot_empty")));
          const pct = Math.min(100, Math.round(slot.progress / slot.recipe.time * 100));
          const st = slot.state === "done" ? t("cook_ready") : slot.state === "burnt" ? t("cook_burnt") : `${pct}%`;
          box.append(h(
            "div",
            { class: "pslot" },
            ItemDB.get(slot.recipe.output.id).icon,
            h("span", {}, recipeName(slot.recipe)),
            h("span", { class: "dim" }, st),
            h("button", { disabled: slot.state === "processing", onclick: () => {
              const r = s.processCollect(near.pieceId, i);
              if (r.ok) this.host.sfx("pickup");
              this.refresh();
            } }, t("cook_collect"))
          ));
        });
        this.stations.append(box);
      }
    }
  };

  // src/quests/Dialogue.ts
  function checkCondition(c, ctx) {
    if (!c) return true;
    if (c.minTrust !== void 0 && ctx.trust < c.minTrust) return false;
    if (c.maxTrust !== void 0 && ctx.trust > c.maxTrust) return false;
    if (c.hasFlags && !c.hasFlags.every((f) => ctx.flags.has(f))) return false;
    if (c.notFlags && c.notFlags.some((f) => ctx.flags.has(f))) return false;
    if (c.hasItems && !c.hasItems.every((i) => ctx.itemCount(i.id) >= i.count)) return false;
    return true;
  }
  var DialogueRunner = class {
    constructor(graph, ctx) {
      this.graph = graph;
      this.ctx = ctx;
      this.nodeId = this.resolve(graph.start);
    }
    graph;
    ctx;
    nodeId;
    log = { trustDelta: 0, flags: [], actions: [] };
    resolve(id) {
      const node = this.graph.nodes[id];
      if (!node) throw new Error(`Dialogue: \u0639\u0642\u062F\u0629 \u0645\u0641\u0642\u0648\u062F\u0629 "${id}"`);
      for (const v of node.variants ?? []) if (checkCondition(v.when, this.ctx)) return this.resolve(v.node);
      return id;
    }
    get finished() {
      return this.nodeId === null;
    }
    current() {
      if (!this.nodeId) return null;
      const node = this.graph.nodes[this.nodeId];
      const choices = node.choices.map((choice, index) => ({ index, choice })).filter(({ choice }) => checkCondition(choice.requires, this.currentCtx()));
      return { node, choices };
    }
    /** السياق يتضمن تأثير الاختيارات السابقة داخل نفس الحوار */
    currentCtx() {
      const flags = /* @__PURE__ */ new Set([...this.ctx.flags, ...this.log.flags]);
      return { trust: this.ctx.trust + this.log.trustDelta, flags, itemCount: (id) => this.ctx.itemCount(id) };
    }
    /** @param index الفهرس الأصلي للخيار في العقدة (كما في current().choices[i].index) */
    choose(index) {
      const cur = this.current();
      if (!cur) return false;
      const entry = cur.choices.find((c2) => c2.index === index);
      if (!entry) return false;
      const c = entry.choice;
      this.log.trustDelta += c.trust ?? 0;
      if (c.setFlags) this.log.flags.push(...c.setFlags);
      if (c.action) this.log.actions.push(c.action);
      this.nodeId = c.next === null ? null : this.resolve(c.next);
      return true;
    }
  };

  // src/ui/DialogueUI.ts
  var DialogueUI = class extends Panel {
    constructor(host2) {
      super("dialogue", "dlg");
      this.host = host2;
    }
    host;
    runner = null;
    npcId = "";
    applied = { flags: 0, actions: 0, trust: 0 };
    giftMode = false;
    onEnd = null;
    start(npcId) {
      const s = this.host.session;
      this.npcId = npcId;
      this.runner = new DialogueRunner(s.npcs.find((n) => n.def.id === npcId).def.dialogue, s.dialogueContext(npcId));
      this.applied = { flags: 0, actions: 0, trust: 0 };
      this.giftMode = false;
      this.open();
    }
    onClose() {
      this.runner = null;
      this.onEnd?.();
    }
    applyNew() {
      const r = this.runner;
      const log2 = r.log;
      const delta = {
        trustDelta: log2.trustDelta - this.applied.trust,
        flags: log2.flags.slice(this.applied.flags),
        actions: log2.actions.slice(this.applied.actions)
      };
      this.applied = { flags: log2.flags.length, actions: log2.actions.length, trust: log2.trustDelta };
      if (delta.trustDelta || delta.flags.length || delta.actions.length) this.host.session.applyDialogue(this.npcId, delta);
    }
    refresh() {
      clear(this.root);
      const s = this.host.session;
      const npc = s.npcs.find((n) => n.def.id === this.npcId);
      if (!npc || !this.runner) return;
      const ar = getLanguage() === "ar";
      this.root.append(h("div", { class: "who" }, `${ar ? npc.def.nameAr : npc.def.nameEn} \xB7 ${t("trust")}: ${t(`trust_${trustLevel(npc.trust)}`)}`));
      if (this.giftMode) return this.renderGift();
      const cur = this.runner.current();
      if (!cur) return this.close();
      this.root.append(h("div", { class: "line" }, ar ? cur.node.textAr : cur.node.textEn));
      const box = h("div", { class: "choices" });
      for (const { index, choice } of cur.choices) {
        box.append(h("button", { onclick: () => {
          this.runner.choose(index);
          this.applyNew();
          this.host.sfx("click");
          if (this.runner.finished) this.close();
          else this.refresh();
        } }, ar ? choice.textAr : choice.textEn));
      }
      box.append(h("button", { onclick: () => this.giftToggle(true) }, `\u{1F381} ${t("dlg_gift")}`), h("button", { onclick: () => this.close() }, t("dlg_end")));
      this.root.append(box);
    }
    giftToggle(on) {
      this.giftMode = on;
      this.refresh();
    }
    renderGift() {
      const s = this.host.session;
      this.root.append(h("div", { class: "line" }, t("gift_pick")));
      const box = h("div", { class: "choices" });
      const seen = /* @__PURE__ */ new Set();
      for (const e of s.inventory.grid.list()) {
        if (seen.has(e.stack.defId)) continue;
        seen.add(e.stack.defId);
        const d = ItemDB.get(e.stack.defId);
        if (d.type === "story") continue;
        box.append(h("button", { onclick: () => {
          const r = s.giveGift(this.npcId, d.id);
          this.host.notify(r.accepted ? t("gift_accepted") : t("gift_refused"), r.accepted ? "good" : "bad");
          this.giftToggle(false);
        } }, `${d.icon} ${itemName(d.id)} \xD7${s.inventory.count(d.id)}`));
      }
      box.append(h("button", { onclick: () => this.giftToggle(false) }, t("back")));
      this.root.append(box);
    }
  };

  // src/ui/EndingUI.ts
  var EndingUI = class extends Panel {
    constructor(host2) {
      super("ending", "ending");
      this.host = host2;
    }
    host;
    endingId = "death";
    show(id) {
      this.endingId = id;
      this.open();
    }
    refresh() {
      const s = this.host.session;
      const cause = s.survival.deathCause ?? "unknown";
      const causeKey = ["fall", "animal", "cut", "fire", "drown", "starve", "cold"].includes(cause) ? cause : "unknown";
      this.root.replaceChildren(
        h("h1", {}, t(`ending_${this.endingId}`)),
        h("p", {}, t(`ending_${this.endingId}_text`)),
        ...this.endingId === "death" ? [h("p", { class: "dim" }, t(`death_cause_${causeKey}`))] : [],
        h("p", { class: "dim" }, `${t("stats_days")}: ${s.day + 1} \xB7 ${t("stats_played")}: ${fmtDuration(s.playTime)}`),
        h(
          "div",
          { class: "actions" },
          h("button", { class: "primary", onclick: () => this.host.newGame(s.survival.difficulty) }, t("retry")),
          h("button", { onclick: () => {
            this.host.resume();
          } }, t("menu_load"))
        )
      );
    }
    tick() {
    }
  };

  // src/ui/Notifications.ts
  var Notifications = class {
    root = h("div", { class: "toasts" });
    max = 5;
    push(text, kind = "info", ms = 3200) {
      const last = this.root.lastElementChild;
      if (last && last.textContent === text) {
        last.dataset.n = String((Number(last.dataset.n) || 1) + 1);
        last.textContent = `${text} \xD7${last.dataset.n}`;
        return;
      }
      const el = h("div", { class: `toast ${kind === "info" ? "" : kind}` }, text);
      this.root.append(el);
      while (this.root.children.length > this.max) this.root.firstElementChild?.remove();
      setTimeout(() => el.remove(), ms);
    }
  };

  // src/ui/HUD.ts
  var HUD = class {
    constructor(host2, onSelectSlot) {
      this.host = host2;
      this.onSelectSlot = onSelectSlot;
      const stats = h("div", { class: "hud-stats" });
      for (const n of ["health", "hunger", "thirst", "energy", "stamina", "sanity"]) {
        const fill = h("i");
        const label = h("span");
        const el = h("div", { class: `bar ${n}` }, fill, label);
        stats.append(el);
        this.bars[n] = { el, fill, label, name: n };
      }
      const top = h("div", { class: "hud-top" }, this.clock, this.temp, this.conds);
      for (let i = 0; i < HOTBAR_SIZE; i++) {
        const el = h("div", { class: "hslot", "data-hslot": i, onclick: () => this.onSelectSlot(i) });
        this.slotEls.push(el);
        this.hotbar.append(el);
      }
      this.root.append(this.hurt, this.dark, stats, top, this.tracker, this.hotbar, this.prompt, this.caption, this.weight, this.notifications.root);
    }
    host;
    onSelectSlot;
    root = h("div", { class: "hud" });
    notifications = new Notifications();
    bars = {};
    clock = h("div");
    temp = h("div", { class: "temp" });
    conds = h("div", { class: "conds" });
    tracker = h("div", { class: "tracker", hidden: true });
    prompt = h("div", { class: "prompt", hidden: true });
    caption = h("div", { class: "caption", hidden: true });
    hurt = h("div", { class: "hurt" });
    dark = h("div", { class: "dark" });
    weight = h("div", { class: "weightwarn", hidden: true });
    hotbar = h("div", { class: "hotbar" });
    slotEls = [];
    lastHealth = 100;
    capTimer = 0;
    trackerKey = "";
    setPrompt(text) {
      this.prompt.hidden = !text;
      if (text) this.prompt.textContent = text;
    }
    showCaption(text) {
      this.caption.textContent = text;
      this.caption.hidden = false;
      this.capTimer = 2.2;
    }
    /** تعتيم الشاشة (النوم/النهاية) */
    setDark(on) {
      this.dark.style.opacity = on ? "1" : "0";
    }
    update(dt) {
      const s = this.host.session;
      const st = s.survival.stats;
      const set = (n, v, text) => {
        const b = this.bars[n];
        const p = clamp012(v / 100);
        b.fill.style.width = `${Math.round(p * 100)}%`;
        b.label.textContent = `${text} ${Math.round(v)}`;
        b.el.classList.toggle("low", p < 0.2);
      };
      set("health", st.health, t("stat_health"));
      set("hunger", st.hunger, t("stat_hunger"));
      set("thirst", st.thirst, t("stat_thirst"));
      set("energy", st.energy, t("stat_energy"));
      set("stamina", st.stamina, t("stat_stamina"));
      set("sanity", st.sanity, t("stat_sanity"));
      this.clock.textContent = `${t("day_n", { n: s.day + 1 })} \xB7 ${fmtClock(s.hour)}`;
      this.temp.textContent = `${t("stat_temp")}: ${st.bodyTemp.toFixed(1)}\xB0` + (st.wetness > 0.3 ? ` \xB7 ${t("stat_wet")} ${Math.round(st.wetness * 100)}%` : "");
      const ids = [...s.survival.conditions.keys()].join(",");
      if (this.conds.dataset.k !== ids) {
        this.conds.dataset.k = ids;
        clear(this.conds);
        for (const id of s.survival.conditions.keys()) this.conds.append(h("span", { class: "cond" }, t(`cond_${id}`)));
      }
      if (st.health < this.lastHealth - 0.5) {
        this.hurt.style.opacity = String(Math.min(1, 0.4 + (this.lastHealth - st.health) / 25));
        setTimeout(() => this.hurt.style.opacity = st.health < 25 ? "0.45" : "0", 160);
      }
      this.lastHealth = st.health;
      this.updateTracker();
      this.updateHotbar();
      const burden = s.inventory.burden;
      this.weight.hidden = burden.speedMultiplier >= 0.999;
      if (!this.weight.hidden) this.weight.textContent = t("overweight");
      if (this.capTimer > 0 && (this.capTimer -= dt) <= 0) this.caption.hidden = true;
    }
    updateTracker() {
      const q = this.host.session.quests.tracked;
      if (!q) {
        this.tracker.hidden = true;
        return;
      }
      const prog = this.host.session.quests.progressOf(q.id);
      const key = q.id + prog.objectives.map((o) => `${o.done ? 1 : 0}${o.value}`).join("|") + getLanguage();
      if (key === this.trackerKey) return;
      this.trackerKey = key;
      this.tracker.hidden = false;
      clear(this.tracker);
      const ar = getLanguage() === "ar";
      this.tracker.append(h("b", {}, ar ? q.titleAr : q.titleEn));
      q.objectives.forEach((o, i) => {
        const p = prog.objectives[i];
        const txt = (ar ? o.textAr : o.textEn) + (p.target > 1 ? ` (${p.value}/${p.target})` : "");
        this.tracker.append(h("div", { class: `obj ${p.done ? "done" : p.current ? "cur" : ""}` }, `${p.done ? "\u2713" : p.current ? "\u25B8" : "\xB7"} ${txt}`));
      });
    }
    updateHotbar() {
      const inv = this.host.session.inventory;
      this.slotEls.forEach((el, i) => {
        const uid = inv.hotbar.slots[i];
        const e = uid !== null ? inv.grid.get(uid) : void 0;
        const sel = i === inv.hotbar.selected;
        const key = `${i}:${e?.stack.defId}:${e?.stack.count}:${Math.round(e?.stack.durability ?? 0)}:${sel}`;
        if (el.dataset.k === key) return;
        el.dataset.k = key;
        el.className = `hslot${sel ? " sel" : ""}`;
        clear(el);
        el.append(h("span", { class: "k" }, i + 1));
        if (e) {
          const d = ItemDB.get(e.stack.defId);
          el.append(d.icon);
          if (e.stack.count > 1) el.append(h("span", { class: "n" }, e.stack.count));
          if (d.durability > 0) el.append(h("span", { class: "d", style: `width:${clamp012(e.stack.durability / d.durability) * 100}%` }));
        }
      });
    }
  };

  // src/ui/JournalUI.ts
  var JournalUI = class extends Panel {
    constructor(host2) {
      super("journal");
      this.host = host2;
      this.root.append(h("h2", {}, h("span", {}, `\u{1F4D6} ${t("journal")}`), h("button", { onclick: () => this.close() }, "\u2715")), h("div", { class: "tabs", id: "jtabs" }), this.body);
    }
    host;
    tab = "quests";
    body = h("div");
    refresh() {
      const tabs = this.root.querySelector("#jtabs");
      clear(tabs);
      for (const k of ["quests", "journal"]) tabs.append(h("button", { class: this.tab === k ? "on" : "", onclick: () => {
        this.tab = k;
        this.refresh();
      } }, t(k)));
      clear(this.body);
      if (this.tab === "quests") this.renderQuests();
      else this.renderJournal();
    }
    questCard(q, withProgress) {
      const ar = getLanguage() === "ar";
      const el = h("div", { class: `quest${q.main ? " main" : ""}` }, h("h4", {}, ar ? q.titleAr : q.titleEn, " ", h("span", { class: "dim" }, q.main ? t("quest_main") : t("quest_side"))), h("div", { class: "dim" }, ar ? q.descAr : q.descEn));
      if (withProgress) {
        const prog = this.host.session.quests.progressOf(q.id);
        q.objectives.forEach((o, i) => {
          const p = prog.objectives[i];
          el.append(h("div", { class: `obj ${p.done ? "done" : p.current ? "cur" : ""}` }, `${p.done ? "\u2713" : p.current ? "\u25B8" : "\xB7"} ${ar ? o.textAr : o.textEn}${p.target > 1 ? ` (${p.value}/${p.target})` : ""}`));
        });
      }
      return el;
    }
    renderQuests() {
      const q = this.host.session.quests;
      const group = (title, list, prog) => {
        if (!list.length) return;
        this.body.append(h("h3", {}, title));
        for (const d of list) this.body.append(this.questCard(d, prog));
      };
      if (!q.active.length && !q.available.length && !q.completed.length) this.body.append(h("div", { class: "dim" }, t("no_quests")));
      group(t("quest_active"), q.active, true);
      group(t("quest_available"), q.available, false);
      group(t("quest_completed"), q.completed, false);
    }
    renderJournal() {
      const j = this.host.session.journal;
      const ar = getLanguage() === "ar";
      if (!j.entries.length && !j.pages.size) this.body.append(h("div", { class: "dim" }, t("journal_empty")));
      if (j.pages.size) {
        this.body.append(h("h3", {}, t("journal_pages")));
        for (const id of j.pages) {
          const pg = JOURNAL_PAGES[id];
          if (pg) this.body.append(h("div", { class: "page" }, ar ? pg.ar : pg.en));
        }
      }
      if (j.entries.length) {
        this.body.append(h("h3", {}, t("journal_entries")));
        for (const e of [...j.entries].reverse()) this.body.append(h("div", { class: "entry" }, h("span", { class: "dim" }, t("journal_day", { n: e.day + 1 }), " \xB7 "), ar ? e.textAr : e.textEn));
      }
    }
  };

  // src/ui/MapUI.ts
  var RES = 128;
  var SIZE = 512;
  function colorFor(hgt) {
    if (hgt < -8) return [14, 50, 80];
    if (hgt < 0) return [30, 100, 140];
    if (hgt < 1.6) return [214, 196, 140];
    if (hgt < 9) return [96, 140, 70];
    if (hgt < 20) return [64, 104, 52];
    if (hgt < 32) return [118, 114, 106];
    return [70, 66, 62];
  }
  var MapUI = class extends Panel {
    constructor(host2) {
      super("map");
      this.host = host2;
      this.root.append(h("h2", {}, h("span", {}, `\u{1F5FA} ${t("map")}`), h("button", { onclick: () => this.close() }, "\u2715")), h("div", { class: "mapwrap" }, this.canvas), this.legend);
    }
    host;
    canvas = h("canvas", { class: "map", width: SIZE, height: SIZE });
    base = null;
    legend = h("div", { class: "dim" });
    ensureBase() {
      if (this.base) return this.base;
      const terr = this.host.session.terrain;
      const img = new ImageData(RES, RES);
      for (let j = 0; j < RES; j++) for (let i = 0; i < RES; i++) {
        const w = MapData.mapToWorld((i + 0.5) * (SIZE / RES), (j + 0.5) * (SIZE / RES), terr.half, SIZE);
        const [r, g, b] = colorFor(terr.height(w.x, w.z));
        const k = (j * RES + i) * 4;
        img.data[k] = r;
        img.data[k + 1] = g;
        img.data[k + 2] = b;
        img.data[k + 3] = 255;
      }
      return this.base = img;
    }
    refresh() {
      const s = this.host.session;
      const half = s.terrain.half;
      const ctx = this.canvas.getContext("2d");
      const base = this.ensureBase();
      const full = s.map.fullMapUnlocked;
      const img = new ImageData(new Uint8ClampedArray(base.data), RES, RES);
      for (let j = 0; j < RES; j++) for (let i = 0; i < RES; i++) {
        const w = MapData.mapToWorld((i + 0.5) * (SIZE / RES), (j + 0.5) * (SIZE / RES), half, SIZE);
        if (!full && !s.map.isExplored(w.x, w.z)) {
          const k = (j * RES + i) * 4;
          img.data[k] = 10;
          img.data[k + 1] = 18;
          img.data[k + 2] = 24;
        }
      }
      const off = document.createElement("canvas");
      off.width = RES;
      off.height = RES;
      off.getContext("2d").putImageData(img, 0, 0);
      ctx.imageSmoothingEnabled = true;
      ctx.clearRect(0, 0, SIZE, SIZE);
      ctx.drawImage(off, 0, 0, SIZE, SIZE);
      const ar = getLanguage() === "ar";
      ctx.font = "16px system-ui";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      for (const l of full ? s.map.landmarks : s.map.visibleLandmarks()) {
        const { px, py } = MapData.worldToMap(l.x, l.z, half, SIZE);
        ctx.fillText(l.icon, px, py);
        ctx.fillStyle = "#fff";
        ctx.font = "11px system-ui";
        ctx.fillText(ar ? l.nameAr : l.nameEn, px, py + 15);
        ctx.font = "16px system-ui";
      }
      const p = this.host.player();
      const m = MapData.worldToMap(p.x, p.z, half, SIZE);
      ctx.save();
      ctx.translate(m.px, m.py);
      ctx.rotate(-p.yaw + Math.PI);
      ctx.fillStyle = "#ff5050";
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, -9);
      ctx.lineTo(6, 7);
      ctx.lineTo(0, 3);
      ctx.lineTo(-6, 7);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
      this.legend.textContent = `\u25B2 ${t("map_you")}`;
    }
  };

  // src/ui/PauseMenu.ts
  var PauseMenu = class extends Panel {
    constructor(host2) {
      super("pause", "menu");
      this.host = host2;
    }
    host;
    view = "main";
    open() {
      this.view = "main";
      super.open();
    }
    refresh() {
      clear(this.root);
      this.root.append(h("h2", {}, h("span", {}, this.view === "main" ? t("paused") : t(`menu_${this.view === "new" ? "new" : this.view}`)), this.view === "main" ? null : h("button", { onclick: () => this.go("main") }, t("back"))));
      if (this.view === "main") this.main();
      else if (this.view === "settings") this.settings();
      else if (this.view === "new") this.newGame();
      else void this.slots(this.view);
    }
    go(v) {
      this.view = v;
      this.host.sfx("click");
      this.refresh();
    }
    tick() {
    }
    main() {
      this.root.append(h(
        "div",
        { class: "col" },
        h("button", { class: "primary", onclick: () => this.host.resume() }, t("menu_resume")),
        h("button", { onclick: () => this.go("save") }, `\u{1F4BE} ${t("menu_save")}`),
        h("button", { onclick: () => this.go("load") }, `\u{1F4C2} ${t("menu_load")}`),
        h("button", { onclick: () => this.go("settings") }, `\u2699 ${t("menu_settings")}`),
        h("button", { onclick: () => this.go("new") }, `\u2726 ${t("menu_new")}`)
      ));
    }
    async slots(mode) {
      const list = await this.host.saves.list();
      if (this.view !== mode) return;
      const col = h("div", { class: "col" });
      for (const s of list) col.append(this.slotRow(s, mode));
      this.root.append(col);
    }
    slotRow(s, mode) {
      const info = s.empty ? t("slot_empty") : s.corrupt ? t("slot_corrupt") : t("slot_info", { day: s.day ?? 1, time: fmtDuration(s.playTime ?? 0), diff: t(`diff_${s.difficulty ?? "normal"}`) });
      const date = s.savedAt ? new Date(s.savedAt).toLocaleString() : "";
      const act = h("button", {
        class: "primary",
        disabled: mode === "load" && (s.empty || !!s.corrupt),
        onclick: async () => {
          if (mode === "save") {
            if (!s.empty && !confirm(t("confirm_overwrite"))) return;
            const ok = await this.host.saveTo(s.slot);
            this.host.notify(t(ok ? "saved" : "save_failed"), ok ? "good" : "bad");
          } else {
            const ok = await this.host.loadFrom(s.slot);
            this.host.notify(t(ok ? "loaded" : "load_failed"), ok ? "good" : "bad");
            if (ok) this.host.resume();
          }
          this.refresh();
        }
      }, mode === "save" ? t("menu_save") : t("menu_load"));
      const del = s.empty ? null : h("button", { onclick: async () => {
        if (confirm(t("confirm_delete"))) {
          await this.host.saves.delete(s.slot);
          this.refresh();
        }
      } }, "\u{1F5D1}");
      return h("div", { class: "slotrow" }, h("div", { class: "info" }, h("b", {}, t("slot_n", { n: s.slot + 1 })), h("div", { class: "dim" }, info), h("div", { class: "dim" }, date)), act, del);
    }
    settings() {
      const c = this.host.config;
      const row = (label, ctl) => h("div", { class: "setrow" }, h("span", {}, label), ctl);
      const range = (key, min, max, step) => h("input", { type: "range", min, max, step, value: c[key], oninput: (e) => this.host.setConfig({ [key]: Number(e.target.value) }) });
      const check = (key) => h("input", { type: "checkbox", checked: c[key], onchange: (e) => this.host.setConfig({ [key]: e.target.checked }) });
      const select = (opts, cur, on) => {
        const el = h("select", { onchange: (e) => on(e.target.value) }, ...opts.map(([v, l]) => h("option", { value: v, selected: v === cur }, l)));
        return el;
      };
      this.root.append(
        row(t("set_language"), select([["ar", "\u0627\u0644\u0639\u0631\u0628\u064A\u0629"], ["en", "English"]], c.language, (v) => {
          this.host.setConfig({ language: v });
          this.refresh();
        })),
        row(t("set_quality"), select([["low", t("q_low")], ["medium", t("q_medium")], ["high", t("q_high")]], c.quality, (v) => this.host.setConfig({ quality: v }))),
        row(t("set_postfx"), check("postfx")),
        row(t("set_fov"), range("fov", 55, 100, 1)),
        row(t("set_sens"), range("mouseSensitivity", 0.2, 3, 0.05)),
        row(t("set_invertY"), check("invertY")),
        row(t("set_master"), range("masterVolume", 0, 1, 0.05)),
        row(t("set_sfx"), range("sfxVolume", 0, 1, 0.05)),
        row(t("set_music"), range("musicVolume", 0, 1, 0.05)),
        row(t("set_ambient"), range("ambientVolume", 0, 1, 0.05)),
        row(t("set_subtitles"), check("subtitles"))
      );
    }
    newGame() {
      const col = h("div", { class: "col" });
      for (const d of ["easy", "normal", "hard", "realistic"]) {
        col.append(h("button", { onclick: () => {
          if (confirm(t("confirm_overwrite"))) this.host.newGame(d);
        } }, t(`diff_${d}`)));
      }
      this.root.append(h("div", { class: "dim" }, t("difficulty")), col);
    }
  };

  // src/ui/Tutorial.ts
  var KEY2 = "island-survival:tutorial";
  var Tutorial = class {
    constructor(host2) {
      this.host = host2;
      try {
        if (localStorage.getItem(KEY2) === "done") this.enabled = false;
      } catch {
      }
      this.root.hidden = !this.enabled;
    }
    host;
    root = h("div", { class: "tut", hidden: true });
    idx = 0;
    enabled = true;
    start = null;
    moved = 0;
    opened = /* @__PURE__ */ new Set();
    hold = 0;
    steps = [
      { key: "tut_move", done: (_h, s) => s.moved > 6 },
      { key: "tut_gather", done: (host2) => host2.session.inventory.count("stick") + host2.session.inventory.count("stone") + host2.session.inventory.count("plant_fiber") > 0 },
      { key: "tut_bag", done: () => this.opened.has("backpack") },
      { key: "tut_craft", done: () => this.opened.has("craft") },
      { key: "tut_fire", done: (host2) => host2.session.fires.size > 0 },
      { key: "tut_water", done: (host2) => host2.session.survival.stats.thirst > 98 || host2.session.inventory.count("water_boiled") > 0 },
      { key: "tut_sleep", done: (host2) => host2.session.sleeping || host2.session.day >= 1 }
    ];
    /** تُستدعى عند فتح لوحة (لتحقق خطوات الحقيبة/الصنع) */
    panelOpened(id) {
      this.opened.add(id);
    }
    update(dt) {
      if (!this.enabled) return;
      const p = this.host.player();
      this.start ??= { x: p.x, z: p.z };
      this.moved = Math.max(this.moved, Math.hypot(p.x - this.start.x, p.z - this.start.z));
      const step = this.steps[this.idx];
      if (!step) return this.finish();
      this.root.hidden = false;
      this.root.textContent = t(step.key);
      if (this.hold > 0) {
        this.hold -= dt;
        return;
      }
      if (step.done(this.host, { moved: this.moved, hp: this.host.session.survival.stats.health })) {
        this.idx++;
        this.hold = 1.5;
        this.root.hidden = true;
      }
    }
    finish() {
      this.enabled = false;
      this.root.hidden = true;
      try {
        localStorage.setItem(KEY2, "done");
      } catch {
      }
    }
    skip() {
      this.finish();
    }
  };

  // src/ui/UIManager.ts
  var UIManager = class {
    constructor(host2, mount = document.body) {
      this.host = host2;
      this.hud = new HUD(host2, (i) => {
        host2.session.inventory.hotbar.select(i);
        host2.sfx("click");
      });
      this.backpack = new BackpackUI(host2);
      this.craft = new CraftUI(host2);
      this.map = new MapUI(host2);
      this.journal = new JournalUI(host2);
      this.build = new BuildUI(host2);
      this.pause = new PauseMenu(host2);
      this.dialogue = new DialogueUI(host2);
      this.ending = new EndingUI(host2);
      this.tutorial = new Tutorial(host2);
      this.panels = { backpack: this.backpack, craft: this.craft, map: this.map, journal: this.journal, build: this.build, pause: this.pause, dialogue: this.dialogue, ending: this.ending };
      this.root.append(this.hud.root, this.tutorial.root, ...Object.values(this.panels).map((p) => p.root), this.backpack.tooltip.root);
      mount.append(this.root);
      this.dialogue.onEnd = () => this.afterClose();
    }
    host;
    root = h("div", { id: "ui" });
    hud;
    backpack;
    craft;
    map;
    journal;
    build;
    pause;
    dialogue;
    ending;
    tutorial;
    panels;
    tickTimer = 0;
    /** هل لوحة مفتوحة (اللعبة تحرر المؤشر وتتجاهل الحركة) */
    get anyOpen() {
      return Object.values(this.panels).some((p) => p.isOpen);
    }
    get current() {
      for (const [k, p] of Object.entries(this.panels)) if (p.isOpen) return k;
      return null;
    }
    open(name) {
      for (const [k, p] of Object.entries(this.panels)) if (k !== name && p.isOpen) p.close();
      this.panels[name].open();
      this.tutorial.panelOpened(name);
      this.host.sfx("click");
    }
    close(name) {
      const n = name ?? this.current;
      if (!n) return;
      this.panels[n].close();
      this.afterClose();
    }
    closeAll() {
      for (const p of Object.values(this.panels)) if (p.isOpen) p.close();
      this.afterClose();
    }
    toggle(name) {
      if (this.panels[name].isOpen) this.close(name);
      else this.open(name);
    }
    afterClose() {
      if (!this.anyOpen) this.host.panelClosed();
    }
    update(dt) {
      this.hud.update(dt);
      this.tutorial.update(dt);
      this.handleEvents();
      this.tickTimer -= dt;
      if (this.tickTimer <= 0) {
        this.tickTimer = 0.25;
        for (const p of Object.values(this.panels)) if (p.isOpen) p.tick();
      }
    }
    handleEvents() {
      for (const e of this.host.session.drainEvents()) this.onEvent(e);
    }
    onEvent(e) {
      const n = this.hud.notifications;
      switch (e.type) {
        case "notify":
          n.push(pick({ ar: e.ar, en: e.en }), "info");
          break;
        case "questUpdate": {
          if (e.kind === "started" || e.kind === "completed") {
            const q = QUEST_NAME(e.id);
            n.push(t(e.kind === "started" ? "quest_started" : "quest_done", { name: q }), "quest", 4500);
            this.host.sfx("ding");
          }
          break;
        }
        case "landmark":
          n.push(t("landmark_found", { name: pick({ ar: e.landmark.nameAr, en: e.landmark.nameEn }) }), "good");
          break;
        case "newRecipes":
          n.push(t("new_recipes", { n: e.ids.length }), "good");
          break;
        case "levelUp":
          n.push(t("level_up", { skill: t(`skill_${e.skill}`), n: e.level }), "good");
          this.host.sfx("ding");
          break;
        case "woke":
          n.push(t("woke_up"));
          this.hud.setDark(false);
          break;
        case "ending":
          this.open("ending");
          this.ending.show(e.id);
          break;
        case "fishing":
          if (e.state === "cast") n.push(t("fish_cast"));
          else if (e.state === "bite") {
            n.push(t("fish_bite"), "good", 1500);
            this.host.sfx("ding");
          } else if (e.state === "escaped") n.push(t("fish_escaped"), "bad");
          else if (e.state === "cancel") n.push(t("fish_cancel"));
          else if (e.state === "caught" && e.item) n.push(t("got_item", { name: pick({ ar: ItemDB.get(e.item).nameAr, en: ItemDB.get(e.item).nameEn }), n: e.count ?? 1 }), "good");
          break;
        case "animalKilled":
          break;
        case "pieceRemoved":
          n.push(t("piece_removed"));
          break;
      }
    }
    /** تلميح العنصر في الأرض لمسافة قريبة */
    groundPrompt(defId) {
      return t("prompt_pickup", { name: `${ItemDB.get(defId).icon} ${pick({ ar: ItemDB.get(defId).nameAr, en: ItemDB.get(defId).nameEn })}` });
    }
  };
  function QUEST_NAME(id) {
    const q = QUEST_BY_ID.get(id);
    return q ? getLanguage() === "ar" ? q.titleAr : q.titleEn : id;
  }

  // tests/browser/harness.ts
  var terrain = new TerrainGenerator("ui-seed");
  var session = new GameSession("ui-seed", terrain);
  var saves = new SaveSystem(new MemoryBackend());
  var config = { ...loadConfig() };
  var sp = session.spawnPoint;
  var pl = { x: sp.x, y: sp.y, z: sp.z, yaw: 0 };
  var log = [];
  var host = {
    get session() {
      return session;
    },
    player: () => pl,
    notify: (t2, k) => {
      log.push(`notify:${k ?? "info"}:${t2}`);
      ui.hud.notifications.push(t2, k);
    },
    sfx: (n) => {
      log.push(`sfx:${n}`);
    },
    saves,
    config,
    setConfig: (p) => {
      Object.assign(config, p);
      if (p.language) setLanguage(p.language);
    },
    saveTo: async (slot) => {
      await saves.save(slot, session.toJSON(pl));
      return true;
    },
    loadFrom: async (slot) => {
      const r = await saves.load(slot);
      if (!r.ok) return false;
      session.load(r.data);
      return true;
    },
    newGame: () => {
      session = new GameSession("ui-seed", terrain);
      log.push("newGame");
    },
    resume: () => ui.closeAll(),
    startBuild: (t2) => log.push(`build:${t2}`),
    setDemolish: (on) => log.push(`demolish:${on}`),
    panelClosed: () => log.push("panelClosed")
  };
  setLanguage("ar");
  var ui = new UIManager(host);
  session.inventory.grid.resize(8, 6);
  for (const [id, n] of [["stick", 8], ["stone", 5], ["plant_fiber", 6], ["wood_log", 3], ["berries", 4], ["water_boiled", 1], ["axe_stone", 1], ["campfire_kit", 1], ["rope", 3]]) session.giveItem(id, n);
  ui.update(0.016);
  window.T = { ui, host, log, get session() {
    return session;
  }, terrain, config, update: (dt = 0.3) => ui.update(dt), setLanguage };
  window.addEventListener("error", (e) => log.push(`ERROR:${e.message}`));
  window.addEventListener("unhandledrejection", (e) => log.push(`REJECT:${String(e.reason)}`));
})();
