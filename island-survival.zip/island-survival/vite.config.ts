import { defineConfig } from 'vite';

export default defineConfig({
  base: './', // يعمل من أي مسار فرعي (GitHub Pages وغيره)
  build: {
    target: 'es2022',
    chunkSizeWarningLimit: 2000,
  },
  // Rapier بنسخة compat يضمّن ملف WASM داخل الحزمة فلا نحتاج إعدادًا إضافيًا
  optimizeDeps: {
    exclude: ['@dimforge/rapier3d-compat'],
  },
});
